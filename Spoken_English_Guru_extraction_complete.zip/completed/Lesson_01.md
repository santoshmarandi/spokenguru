# Lesson 1 — Use of “This, That, These & Those”

**PDF pages:** 6–12  
**Printed page numbers:** 5–11

## Exercise and answer pairs

The Hindi sentence and its Romanized reading are followed by the corresponding English answer from the book’s answer key.

### 1

- **Hindi:** ये लड़की कौन है?
- **Romanized:** Ye ladki kaun hai?
- **Answer:** Who is this girl?

### 2

- **Hindi:** ये लड़कियाँ कौन हैं?
- **Romanized:** Ye ladkiyaan kaun hain?
- **Answer:** Who are these girls?

### 3

- **Hindi:** वो लड़की कौन है?
- **Romanized:** Vo ladki kaun hai?
- **Answer:** Who is that girl?

### 4

- **Hindi:** वो लड़कियाँ कौन हैं?
- **Romanized:** Vo ladkiyaan kaun hain?
- **Answer:** Who are those girls?

### 5

- **Hindi:** ये लड़का बहुत शैतान है।
- **Romanized:** Ye ladka bahut shaitaan hai.
- **Answer:** This boy is very naughty.

### 6

- **Hindi:** यह दरवाजा बंद है।
- **Romanized:** Yah darwaza band hai.
- **Answer:** This door is locked.

### 7

- **Hindi:** वह बगीचा प्यारा लग रहा है।
- **Romanized:** Vah bageecha pyara lag raha hai.
- **Answer:** That garden looks lovely.

### 8

- **Hindi:** ये लड़का अमित है।
- **Romanized:** Ye ladka Amit hai.
- **Answer:** This boy is amit.

### 9

- **Hindi:** वो लड़का रोहन है।
- **Romanized:** Vo ladka Rohan hai.
- **Answer:** That boy is Rohan.

### 10

- **Hindi:** वो लड़के गाँव से आए हैं।
- **Romanized:** Vah ladke gaon se aayein hain.
- **Answer:** Those boys have come from the village.

### 11

- **Hindi:** वे असली बिल्लियाँ नहीं हैं।
- **Romanized:** Ve asli billiyan nahi hain.
- **Answer:** Those aren’t real cats.

### 12

- **Hindi:** इस कार को क्या हुआ?
- **Romanized:** Is car ko kya huwa?
- **Answer:** What happened to this car?

### 13

- **Hindi:** क्या तुम इस लड़के को जानती हो?
- **Romanized:** Kya tum is ladke ko jaanti ho?
- **Answer:** Do you know this boy?

### 14

- **Hindi:** वो गमले लाल रंग के हैं।
- **Romanized:** Vo gamle laal rang kai hain.
- **Answer:** Those pots are red in colour.

### 15

- **Hindi:** ये बच्चे हँस क्यों रहे हैं?
- **Romanized:** Ye bachche hans kyun rahe hain?
- **Answer:** Why are these kids laughing?

### 16

- **Hindi:** आपने वह घड़ी कहाँ से खरीदी?
- **Romanized:** Aapne vah ghadi kha se khareedi?
- **Answer:** Where did you buy that watch from?

### 17

- **Hindi:** ये सब्जी बहुत टेस्टी है।
- **Romanized:** Ye sabzi bahut tasty hai.
- **Answer:** This vegetable is very tasty.

### 18

- **Hindi:** मुझे वो खिड़की पेंट करनी है।
- **Romanized:** Mujhe vo khidki paint karni hai.
- **Answer:** I have to paint that window.

### 19

- **Hindi:** मैं उन किताबों का ध्यान रखूँगा।
- **Romanized:** Main un kitaabon ka dhyan rakhunga.
- **Answer:** I will take care of those books.

### 20

- **Hindi:** वह मेरी फेवरेट जगह है।
- **Romanized:** Vah meri favourite jagah hai.
- **Answer:** That is my favourite place.

### 21

- **Hindi:** मुझे ये मोबाइल खरीदना है।
- **Romanized:** Mujhe ye mobile kharidna hai.
- **Answer:** I have to buy this mobile.

### 22

- **Hindi:** क्या ये सभी चॉकलेट मेरे लिए हैं?
- **Romanized:** Kya ye sabhi chocolate mere liye hain?
- **Answer:** Are all these chocolates for me?

### 23

- **Hindi:** वे सपने सबसे बुरे थे।
- **Romanized:** Ve sapne sabse bure the.
- **Answer:** Those dreams were the worst.

### 24

- **Hindi:** ये सपने सबसे बुरे थे।
- **Romanized:** Ye sapne sabse bure the.
- **Answer:** These dreams were the worst.

### 25

- **Hindi:** आइए, इस बारे में बात करते हैं।
- **Romanized:** Aaeye, is bare me baat karte hain.
- **Answer:** Come, let’s talk about it.

### 26

- **Hindi:** यह पार्टी बहुत बोरिंग है।
- **Romanized:** Yah party bahut boring hai.
- **Answer:** This party is very boring.

### 27

- **Hindi:** वह शहर काफी छोटा है।
- **Romanized:** Vah shahar kaafi chhota hai.
- **Answer:** That city is very small.

### 28

- **Hindi:** वह लड़कियाँ बहुत चालाक लग रही थी।
- **Romanized:** Vah ladkiyan bahut chalaak lag rahi thi.
- **Answer:** Those girls were looking very clever.

### 29

- **Hindi:** यह मेरा दोस्त समीर है।
- **Romanized:** Yah mera dost Sameer hai.
- **Answer:** This is my friend Sameer.

### 30

- **Hindi:** तुम ये खाना क्यों नहीं खा रहे?
- **Romanized:** Tum ye khana kyun nahi kha rahe?
- **Answer:** Why are you not eating this food?

### 31

- **Hindi:** वो हमारा घर है।
- **Romanized:** Vo humara ghar hai.
- **Answer:** That is our home.

### 32

- **Hindi:** वो काले वाले मेरे जूते हैं।
- **Romanized:** Vo kale wale mere joote hain.
- **Answer:** Those black ones are my shoes.

### 33

- **Hindi:** ये डान्स परफॉरमेन्स कमाल है।
- **Romanized:** Ye dance performance kamaal hai.
- **Answer:** This dance performance is amazing.

### 34

- **Hindi:** वो लोग तो कल तक आयेंगे।
- **Romanized:** Vo log to kal tak aaenge.
- **Answer:** Those people will come by tomorrow.

### 35

- **Hindi:** ये फूल मुरझा गये हैं।
- **Romanized:** Yah phool murjha gaye hain.
- **Answer:** These flowers are dead.

### 36

- **Hindi:** यह बारिश मुझे उदास कर रही है।
- **Romanized:** Yah barish mujhe udas kar rahi hai.
- **Answer:** This rain is making me feel sad.

### 37

- **Hindi:** वे घर सब नये है।
- **Romanized:** Ve ghar sab naye hai.
- **Answer:** Those houses are all new.

### 38

- **Hindi:** ये ट्रैफिक हर साल और बदतर हो रहा है।
- **Romanized:** Ye traffic har saal aur badtar ho raha hai.
- **Answer:** This traffic gets worse every year.

### 39

- **Hindi:** मेज़ पर वे चाबियाँ किसकी हैं?
- **Romanized:** Mez par ve chabiyan kiski hain?
- **Answer:** Whose are those keys on table?

### 40

- **Hindi:** तुम्हें वो दिन याद है?
- **Romanized:** Tumhe vo din yaad hai?
- **Answer:** Do you remember that day?

### 41

- **Hindi:** मुझे वो पग डॉग्स बहुत अच्छे लगते है।
- **Romanized:** Mujhe vo pug dogs bahut ache lagte hai.
- **Answer:** I love those pug dogs.

### 42

- **Hindi:** वे डब्बे ऊपर ले जाओ।
- **Romanized:** Ve dabbe oopar le jao.
- **Answer:** Take those boxes up.

### 43

- **Hindi:** वो पेड़ बहुत सुन्दर है।
- **Romanized:** Vo ped bahut sundar hai.
- **Answer:** That tree is very beautiful.

### 44

- **Hindi:** ये सारे सेब सबसे ज़्यादा मीठे है।
- **Romanized:** Ye sare seb sabse zyada meethe hain.
- **Answer:** These apples are sweetest of all.

### 45

- **Hindi:** ये लैटर किसका है?
- **Romanized:** Ye letter kiska hai?
- **Answer:** Whose letter is this?

### 46

- **Hindi:** वो है दूध की दुकान।
- **Romanized:** Vo hai dhoodh ki dukan.
- **Answer:** That is a milk shop.

### 47

- **Hindi:** वो मेरे माता-पिता नहीं हैं।
- **Romanized:** Vo mere mata-pita nahi hai.
- **Answer:** Those are not my parents.

### 48

- **Hindi:** वो मेरा लेपटॉप है।
- **Romanized:** Vo mera laptop hai.
- **Answer:** That is my laptop.

### 49

- **Hindi:** ये संगीतकार प्रतिभाशाली है।
- **Romanized:** Ye sangeetkaar pratibhashali hai.
- **Answer:** This musician is talented.

### 50

- **Hindi:** ये साल मेरे लिए अच्छा नहीं रहा।
- **Romanized:** Yai saal mere liye acha nahi raha.
- **Answer:** This year hasn’t been good for me.

### 51

- **Hindi:** वे मिटिंग्स कल हैं।
- **Romanized:** Ve meetings kal hain.
- **Answer:** Those meetings will be held tomorrow.

### 52

- **Hindi:** मुझे ये हार दिवाली के लिए चाहिए।
- **Romanized:** Mujhe ye haar Diwali kai liye chahiye.
- **Answer:** I want this necklace for diwali.

### 53

- **Hindi:** ये मेरा भाई नहीं है।
- **Romanized:** Yeh mera Bhai Nahi hai.
- **Answer:** This is not my brother.

### 54

- **Hindi:** वह तुम्हारा था।
- **Romanized:** Vah tumhaara tha.
- **Answer:** That was yours.

### 55

- **Hindi:** वो सब लोग मेरे मेहमान है।
- **Romanized:** Vo sab log mere mehamaan hai.
- **Answer:** All those people are my guests.

### 56

- **Hindi:** यह चाबी किसकी है?
- **Romanized:** Yah chabee kiski hai?
- **Answer:** Whose key is this?

### 57

- **Hindi:** यह मेरा है।
- **Romanized:** Yah mera hai.
- **Answer:** This is mine.

### 58

- **Hindi:** यह घर अब हमारा है।
- **Romanized:** Yah ghar ab hamaara hai.
- **Answer:** This house is ours now.

### 59

- **Hindi:** वह आदमी दूर है।
- **Romanized:** Vah aadami door hai.
- **Answer:** That man is far away.

### 60

- **Hindi:** वे मेरे बच्चे नहीं थे।
- **Romanized:** Ve mere bachche nahi the.
- **Answer:** Those were not my children.

### 61

- **Hindi:** यह किताब मेरी नहीं थी।
- **Romanized:** Yah kitaab meri nahi thi.
- **Answer:** This book was not mine.

### 62

- **Hindi:** वह लड़की बहुत होशियार है।
- **Romanized:** Vah ladki bahut hoshiyaar hai.
- **Answer:** That girl is very smart.

### 63

- **Hindi:** ये मेरी लड़कियाँ नहीं हैं।
- **Romanized:** Ye meri ladakiyaan nahi hain.
- **Answer:** These are not my girls.

### 64

- **Hindi:** वह पेड़ बहुत हरा है।
- **Romanized:** Vah ped bahut hara hai.
- **Answer:** That tree is very green.

### 65

- **Hindi:** यह घर बहुत महँगा है।
- **Romanized:** Yah ghar bahut mahanga hai.
- **Answer:** This house is so expensive.

### 66

- **Hindi:** ये लड़के रोज़ कॉलेज जाते हैं।
- **Romanized:** Ye ladke roz college jaate hain.
- **Answer:** These boys go to college everyday.

### 67

- **Hindi:** वो लड़कियाँ हमेशा यहाँ आती हैं।
- **Romanized:** Vo ladakiyaan hamesha yahaan aati hain.
- **Answer:** Those girls always come here.

### 68

- **Hindi:** ये लड़के मेरे दोस्त हैं।
- **Romanized:** Ye ladake mere dost hain.
- **Answer:** These boys are my friends.

### 69

- **Hindi:** क्या ये बच्चे घर पर पढ़ते हैं?
- **Romanized:** kya ye bachche ghar par padhate hain?
- **Answer:** Do these children study at home?

### 70

- **Hindi:** यह मेरा मोबाइल फोन है और वहाँ पर शेल्फ पर आपका मोबाइल फोन है।
- **Romanized:** Yah mera mobile phone hai aur vahaan par shelf par aapka mobile phone hai.
- **Answer:** This is my mobile phone and that one on the shelf there is your mobile phone.

### 71

- **Hindi:** जॉन, ये फ़ोल्डर को ले लो और इसे वहाँ डेस्क पर रख दो।
- **Romanized:** John, ye folder ko le lo aur ise vahaan desk par rakh do.
- **Answer:** John, take this folder and put it on the desk over there.

### 72

- **Hindi:** वहाँ पर वह इमारत न्यूयॉर्क बिल्डिंग है।
- **Romanized:** Vahaan par vah imaarat Newyork building hai.
- **Answer:** That building over there is the Newyork Building.

### 73

- **Hindi:** वह एक प्यारी शाम थी।
- **Romanized:** Vah ek pyari shaam thi.
- **Answer:** That was a lovely evening.

### 74

- **Hindi:** यह आज एक खूबसूरत दिन है।
- **Romanized:** Yah aaj ek khoobasoorat din hai.
- **Answer:** This is a beautiful day today.

### 75

- **Hindi:** वहाँ पर वह बोतल खाली है।
- **Romanized:** Vahaan par vah botal khali hai.
- **Answer:** That bottle over there is empty.

### 76

- **Hindi:** वे सेब लाल हैं, लेकिन यहाँ के सेब हरे हैं।
- **Romanized:** Ve seb laal hain, lekin yahaan ke seb hare hain.
- **Answer:** Those apples are red, but these apples over here are green.

### 77

- **Hindi:** ये अंगूर वाकई मीठे हैं!
- **Romanized:** Ye angoor vakai meethe hain!
- **Answer:** These grapes are really sweet!

### 78

- **Hindi:** यह एक कठिन परीक्षा थी जो हमने पिछले सप्ताह की थी।
- **Romanized:** Yah ek kathin pareeksha thi jo hamne pichhale saptaah ki thi.
- **Answer:** That was a difficult test we had last week.

### 79

- **Hindi:** यह किताब बहुत अच्छी है, है ना?
- **Romanized:** Yah kitaab bahut achchhee hai, hai na?
- **Answer:** This book is great, isn’t it.

### 80

- **Hindi:** वे लड़के अपना दोपहर का खाना खा रहे हैं।
- **Romanized:** Ve ladke apna dopahar ka khana kha rahe h.
- **Answer:** Those boys are eating their lunch.

### 81

- **Hindi:** ये हमारे बच्चे हैं।
- **Romanized:** Ye hamaare bachche hain.
- **Answer:** These are our children.

### 82

- **Hindi:** आप इन में से कौन सा चाहेंगे?
- **Romanized:** Aap inmeIn se kaun sa chaahenge?
- **Answer:** Which of those would you like?

### 83

- **Hindi:** यह जैकेट दुकान में सबसे महँगी है।
- **Romanized:** Yah jacket dukaan mein sabase mahangee hai.
- **Answer:** This jacket is the most expensive one in the shop.

### 84

- **Hindi:** यह पत्र कब भेजे जा रहे हैं?
- **Romanized:** Yah patra kab bheje ja rahe hain?
- **Answer:** When are these letters going to be sent?

### 85

- **Hindi:** यह मेरी पसंदीदा टी-शर्ट है।
- **Romanized:** Yah meree pasandeeda t-shirt hai.
- **Answer:** This is my favorite T-shirt.

### 86

- **Hindi:** यह संगीत मुझे खुश करता है।
- **Romanized:** Yah sangeet mujhe khush karata hai.
- **Answer:** This music makes me happy.

### 87

- **Hindi:** ये प्रदर्शन अद्भुत है।
- **Romanized:** Ye pradarshan adbhut hai.
- **Answer:** These performances are amazing.

### 88

- **Hindi:** यह ट्रेन देहरादून से होते हुए मथुरा जायेगी।
- **Romanized:** Ye train Dehradun se hote hue Mathura jaegi.
- **Answer:** This train will go to Mathura via Dehradun.

### 89

- **Hindi:** यह अंतिम चरण था।
- **Romanized:** Yah antim charan tha.
- **Answer:** This was the final step.

### 90

- **Hindi:** यह अब तक का सबसे कठिन निर्णय हो सकता है।
- **Romanized:** Yah ab tak ka sabase kathin nirnay ho sakata hai.
- **Answer:** This might be the toughest decision so far.

### 91

- **Hindi:** यह समय अच्छा नहीं है...
- **Romanized:** Yah samay achchha nahin hai....
- **Answer:** This isn't a good time. / This time is not good.

### 92

- **Hindi:** यह चीज़ आपको परेशान नहीं करती है।
- **Romanized:** Yah cheez aapako pareshan nahi karati hai.
- **Answer:** This thing does not bother you.

### 93

- **Hindi:** वे आँखें उसका मज़ाक उड़ा रही होंगी।
- **Romanized:** ve aankhein uska mazaak uda rahi hongi.
- **Answer:** Those eyes would be mocking her.

### 94

- **Hindi:** मुझे वे मेरी रसोई में चाहिए।
- **Romanized:** Mujhe ve meree rasoee mein chaahiye.
- **Answer:** I want those in my kitchen.

### 95

- **Hindi:** वे विचार मुझसे चुराए गए थे।
- **Romanized:** Ve vichaar mujhse churae gae the.
- **Answer:** Those ideas were stolen from me.

### 96

- **Hindi:** जो टेबल पर बैठे थे, वे चुप हो गए और देखते रहे।
- **Romanized:** Jo table par baithe the, ve chup ho gaye aur dekhate rahe.
- **Answer:** Those, who were sitting at the table, became silent and kept watching.

### 97

- **Hindi:** जो शायद उसके दोस्त थे वो चले गए।
- **Romanized:** Jo shaayad usake dost the vo chale gaye.
- **Answer:** Those, who were probably his friends, left.

### 98

- **Hindi:** यहाँ की ये तस्वीरें किताब की उन तस्वीरों से काफी बेहतर हैं।
- **Romanized:** Yahaan ki ye tasveeren kitaab ki un tasveeron se kafi behatar hain.
- **Answer:** These photos here are much better than those photos on the book.

### 99

- **Hindi:** ये मेरे दादा-दादी हैं, और वे लोग मेरे दोस्त के दादा-दादी हैं।
- **Romanized:** Ye mere dada-dadi hain, aur ve log mere dost ke dada-dadi hain.
- **Answer:** These are my grandparents, and those people over there are my friend's grandparents.

### 100

- **Hindi:** हमारे पास इतना समय नहीं है।
- **Romanized:** Humare pass itna samay nahi hai.
- **Answer:** We don’t have that much time.

### 101

- **Hindi:** ये कैंचियाँ अच्छे से काटती हैं।
- **Romanized:** Ye kainchiyan ache se kaatti hai.
- **Answer:** These scissors cut well.

---
**Verification:** 101 prompts and 101 answers; prompt sequence 1–101 paired in order. Hindi was transcribed from the page images and checked against the Romanized source text; answer wording is from the printed answer pages.
