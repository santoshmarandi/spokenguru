# Lesson 23 — Causative Verbs

**PDF pages:** 322–335 (printed pages 321–334)

## Please translate the following sentences into English

1. **Hindi prompt:** वो मुझसे लिखवाता है।  
   **Romanized:** Vo mujhse likhvaata hai.  
   **English answer:** He makes me write.  

2. **Hindi prompt:** वो मुझसे अपना होमवर्क लिखवाता है।  
   **Romanized:** Vo mujhse apna homework likhvata hai.  
   **English answer:** He makes me write his homework  

3. **Hindi prompt:** वो मुझसे अपना होमवर्क नहीं लिखवाता है।  
   **Romanized:** Vo mujhse apna homework nahi likhvata h.  
   **English answer:** He doesn’t make me write his homework.  

4. **Hindi prompt:** क्या वो मुझसे अपना होमवर्क लिखवाता है?  
   **Romanized:** Kya vo mujhse apna homework likhvata h?  
   **English answer:** Does he make me write his homework?  

5. **Hindi prompt:** वो मुझसे अपना होमवर्क क्यों लिखवाता है?  
   **Romanized:** Vo mujhse apna homework kyo likhvata h?  
   **English answer:** Why does he make me write his homework?  

6. **Hindi prompt:** वो मुझे भिजवाता है।  
   **Romanized:** Vo mujhe bhijvaata hai.  
   **English answer:** He makes me go.  

7. **Hindi prompt:** वो मुझे भिजवाता है जहाँ मैं वास्तव में जाना नहीं चाहता।  
   **Romanized:** Vo mujhe bhijvaata hai jaha main vastav mein jana nahi chahta.  
   **English answer:** He makes me go where I really don’t want to.  

8. **Hindi prompt:** तुम्हें ये काम करवाना पड़ेगा।  
   **Romanized:** Tumhein ye kaam karvaana padega.  
   **English answer:** You will have to get this work done.  

9. **Hindi prompt:** तुम्हें ये काम मुझसे करवाना पड़ेगा।  
   **Romanized:** Tumhein ye kaam mujhse karvaana padega.  
   **English answer:** You’ll have to get this work done by me./ You’ll have to make me do this work.  

10. **Hindi prompt:** मैं आपको खाना खिलवाऊँगा।  
   **Romanized:** Main aapko khana khilvaunga.  
   **English answer:** I’ll make you eat the food.  

11. **Hindi prompt:** मैं आपसे खाना खिलवाऊँगा।  
   **Romanized:** Main aapse khana khilvaunga.  
   **English answer:** I’ll make you serve the food.  

12. **Hindi prompt:** वो मुझसे काम करवाती है।  
   **Romanized:** Vo mujhse kaam karvati hai.  
   **English answer:** She makes me work.  

13. **Hindi prompt:** वो मुझसे पत्र लिखवाती है।  
   **Romanized:** Vo mujhse patr likhvatee hai.  
   **English answer:** She makes me write the letter. / She gets the letter written by me.  

14. **Hindi prompt:** वो मुझे भिजवा रही है।  
   **Romanized:** Vo mujhe bhijva rahi hai.  
   **English answer:** She is making me go.  

15. **Hindi prompt:** वह मुझे बेवकूफ बना रही है।  
   **Romanized:** Vah mujhe bevakuf bana rahi hai.  
   **English answer:** She is making me fool.  

16. **Hindi prompt:** उसने मुझे समझाया।  
   **Romanized:** Usne mujhe samjhaya.  
   **English answer:** She made me understand.  

17. **Hindi prompt:** मैं तुमसे काम करवाऊँगा।  
   **Romanized:** Main tumse kaam karvaoonga.  
   **English answer:** I will make you work. / I will get the work done by you.  

18. **Hindi prompt:** मैं उसे भिजवा चुका होऊँगा।  
   **Romanized:** Main use bhijva chuka hounga.  
   **English answer:** I will have made him go.  

19. **Hindi prompt:** तुम मुझे उससे लड़वा रहे हो।  
   **Romanized:** Tum mujhe usse ladva rahe ho.  
   **English answer:** You are making me fight him. / You are making me have a quarrel with him.  

20. **Hindi prompt:** बच्चे मुझे बेवकूफ बना रहे हैं।  
   **Romanized:** Bachche mujhe bevakuf bana rahe hain.  
   **English answer:** Kids are making me fool.  

21. **Hindi prompt:** मेरा प्यार मुझे रुला रहा है।  
   **Romanized:** Mera pyar mujhe rula raha hai.  
   **English answer:** My love is making me cry.  

22. **Hindi prompt:** तुम हमें हँसाते थे।  
   **Romanized:** Tum hamein hasate the.  
   **English answer:** You used to make us laugh.  

23. **Hindi prompt:** मैं तुम्हें जाने दे सकता था।  
   **Romanized:** Main tumhein jane de sakta tha.  
   **English answer:** I could have let you go.  

24. **Hindi prompt:** राम ये किसी से भी करवा सकता है।  
   **Romanized:** Ram ye kisi se bhi karva sakta hai.  
   **English answer:** Ram can make anyone do it. / Ram can get it done by anyone.  

25. **Hindi prompt:** मैं तुम्हें खाने को कुछ दिलवा सकता हूँ।  
   **Romanized:** Main tumhein khane ko kuch dilva sakta hun.  
   **English answer:** I can get you something to eat.  

26. **Hindi prompt:** राम मुझे पानी दिलवा सकता है।  
   **Romanized:** Ram mujhe panee dilwa sakta hai.  
   **English answer:** Ram can get me water.  

27. **Hindi prompt:** क्या तुम मुझे एग्जाम में पास करवा सकते हो?  
   **Romanized:** Kya tum mujhe exam pass karva sakte ho?  
   **English answer:** Can you make me pass the exam?  

28. **Hindi prompt:** मैं तुम्हें पास करवा सकता हूँ।  
   **Romanized:** Main tumhein pass karva sakta hoon.  
   **English answer:** I can make you pass.  

29. **Hindi prompt:** पैसा तुम्हें प्यार नहीं दिलवा सकता।  
   **Romanized:** Paisa tumhein pyar nahi dilva sakta.  
   **English answer:** Money can’t get you love.  

30. **Hindi prompt:** मेरे पापा ने मुझे महसूस करवाया कि हमें ज़रूरतमंदों की मदद करनी चाहिए।  
   **Romanized:** Mere papa ne mujhe mahsoos karvaaya ki hamein zarurat mandon ki madad karni chaahiye.  
   **English answer:** My dad made me realize that we should help needy people.  

31. **Hindi prompt:** समय मुझे उन गलतियों का अहसास करवा रहा है जो मैंने पहले की हैं।  
   **Romanized:** Samay mujhe un galtiyon ka ahsaas karva raha hai jo maine pahle ki hain.  
   **English answer:** Time is making me realize those mistakes that I’ve made in the past.  

32. **Hindi prompt:** तुम हर किसी को खुश नहीं कर सकते।  
   **Romanized:** Tum har kisi ko khush nahi kar sakte.  
   **English answer:** You can’t make everyone happy. / You can’t please everyone.  

33. **Hindi prompt:** पापा आपको कार नहीं दिलवा सकते क्योंकि उनके पास पैसे बिल्कुल नहीं हैं।  
   **Romanized:** Papa aapko car nahi dilva sakte kyoki unke pass paise bilkul nahi hai.  
   **English answer:** Dad can’t get you a car as he doesn’t have money at all. / Dad can’t buy you a car as he doesn’t have money at all.  

34. **Hindi prompt:** मैं तुमसे ये नहीं खरीदवा सकता।  
   **Romanized:** Main tumse ye nahi khareedva sakta.  
   **English answer:** I can’t make you buy this.  

35. **Hindi prompt:** क्या वो उसे हँसा सका?  
   **Romanized:** Kya vo use hasa saka?  
   **English answer:** Could he make her laugh?  

36. **Hindi prompt:** उसे मुझे अहसास दिलवाना होगा कि वो सबसे अच्छा है।  
   **Romanized:** Use mujhe ahsaas dilvaana hoga ki vo sabse acha hai.  
   **English answer:** He will have to make me realize, he is the best.  

37. **Hindi prompt:** तुम्हें ये काम करवाना पड़ेगा।  
   **Romanized:** Tumhein ye kaam karvaana padega.  
   **English answer:** You will have to get this work done.  

38. **Hindi prompt:** वो मुझे बर्गर खिलाता है।  
   **Romanized:** Vo mujhe burger khilata hai.  
   **English answer:** He makes me eat Burger. / He gets me eat Burger.  

39. **Hindi prompt:** वो मुझे अच्छा खाना खिलाता है।  
   **Romanized:** Vo mujhe acha khana khilata hai.  
   **English answer:** He makes me eat good food. / He gets me eat good food.  

40. **Hindi prompt:** तुम मुझे अमेरिका कब भिजवाओगे?  
   **Romanized:** Tum mujhe America kab bhijvaoge?  
   **English answer:** When will you make me go America?  

41. **Hindi prompt:** राम हमें पानी पिलवा रहा था।  
   **Romanized:** Ram hamein panee pilva raha tha.  
   **English answer:** Ram was making us drink water. / Ram is getting us water.  

42. **Hindi prompt:** उस बच्चे ने हर किसी को हँसाया।  
   **Romanized:** Us bachche ne har kisi ko hasaaya.  
   **English answer:** That child made everyone laugh.  

43. **Hindi prompt:** तुमने मुझे रुलाया है।  
   **Romanized:** Tumne mujhe rulaya hai.  
   **English answer:** You have made me cry.  

44. **Hindi prompt:** वो हास्य कलाकार है। वो लोगों को हँसाता है।  
   **Romanized:** Vo haasya kalakaar hai. Vo logon ko hansata hai.  
   **English answer:** He is a comedian. He makes people laugh.  

45. **Hindi prompt:** मैं तुमसे गवा नहीं सकता क्योंकि तुम्हारी आवाज सुरीली नहीं है।  
   **Romanized:** Main tumse gavaa nahi sakta kyoki tumhari awaaz sureelee nahi hai.  
   **English answer:** I can’t make you sing as your voice is not melodious.  

46. **Hindi prompt:** राहुल मुझसे अपना होमवर्क करवायेगा।  
   **Romanized:** Rahul mujhse apna homework karavayega.  
   **English answer:** Rahul will make me write his homework.  

47. **Hindi prompt:** तुम उससे अपना होमवर्क क्यों करवाते हो?  
   **Romanized:** Tum usse apna homework kyo karvate ho?  
   **English answer:** Why do you make him write your homework?  

48. **Hindi prompt:** उसने तुमसे किसे कॉल करवाई?  
   **Romanized:** Usne tumse kise call karvaee?  
   **English answer:** Whom did he make you call?  

49. **Hindi prompt:** उसने ये पैन तुम्हें कैसे दिलवाया?  
   **Romanized:** Usne ye pen tumhein kaise dilvaya?  
   **English answer:** How did he get you this pen?  

50. **Hindi prompt:** तुम्हारे प्यार ने मुझे महसूस करवाया।  
   **Romanized:** Tumhare pyar ne mujhe mahsoos karvaya.  
   **English answer:** Your love made me realize.  

51. **Hindi prompt:** तुमने मुझे प्यार की कीमत समझायी।  
   **Romanized:** tumne mujhe pyar ki keemat samjhayee.  
   **English answer:** You made me understand the value of love.  

52. **Hindi prompt:** तुम्हारे भाषण ने मुझे प्रेरित किया।  
   **Romanized:** Tumhare bhashan ne mujhe prerit kiya.  
   **English answer:** Your lecture motivated me.  

53. **Hindi prompt:** तुम राम को उससे नहीं पिटवा सकते।  
   **Romanized:** Tum Ram ko usse nahi pitva sakte.  
   **English answer:** You can’t make him beat Ram.  

54. **Hindi prompt:** तुम राम से उसे नहीं पिटवा सकते।  
   **Romanized:** Tum ram se use nahi pitva sakte.  
   **English answer:** You can’t make Ram beat him.  

55. **Hindi prompt:** मैं तुम्हें समझा नहीं सकता।  
   **Romanized:** Main tumhein samjha nahi sakta.  
   **English answer:** I can’t make you understand.  

56. **Hindi prompt:** मैंने तुमसे बाल्टी भरवाई।  
   **Romanized:** Maine tumse baltee bharvai.  
   **English answer:** I made you fill the bucket.  

57. **Hindi prompt:** उसने तुमसे पैसे क्यों खर्च करवाये?  
   **Romanized:** Usne tumse paise kyo kharch karvaye?  
   **English answer:** Why did he make you spend the money?  

58. **Hindi prompt:** मैं क्या करवाता हूँ?  
   **Romanized:** Main kya karvata hoon?  
   **English answer:** What do I get done?  

59. **Hindi prompt:** लोग जबरदस्ती तुम्हें वहाँ भिजवायेंगे।  
   **Romanized:** log jabardastee tumhein vaha bhijvayenge.  
   **English answer:** People will forcefully make you go there.  

60. **Hindi prompt:** मैं केवल उससे ही किताब पढ़वाऊँगा।  
   **Romanized:** Main keval usse hi kitaab padhvaoonga.  
   **English answer:** I will make only him read the book.  

61. **Hindi prompt:** राम तुमसे ये काम करवायेगा।  
   **Romanized:** Ram tumse ye kaam karvayega.  
   **English answer:** Ram will make you do this work.  

62. **Hindi prompt:** मैं बाल कटवाने जा चुका था।  
   **Romanized:** Main baal katvane ja chuka tha.  
   **English answer:** I had gone to get the hair cut.  

63. **Hindi prompt:** तुमने बाल कहाँ से कटवाये?  
   **Romanized:** Tumne baal kaha se katvaye?  
   **English answer:** From where did you get the hair cut?  

64. **Hindi prompt:** मुझे ये काम करवाना है।  
   **Romanized:** Mujhe ye kaam karvana hai.  
   **English answer:** I have to get this work done.  

65. **Hindi prompt:** राम मुझसे काम करवा सकता था।  
   **Romanized:** Ram Mujhse kaam karva sakta tha.  
   **English answer:** Ram could have got the work done by me.  

66. **Hindi prompt:** हम राम से गाना गवा सकते हैं।  
   **Romanized:** Hum Ram se gaana gava sakte hai.  
   **English answer:** We can make Ram sing the song.  

67. **Hindi prompt:** वो मुझे पिटवायेगा।  
   **Romanized:** vo Mujhe pitvayega.  
   **English answer:** He will make me be beaten.  

68. **Hindi prompt:** मैं तुम्हें क्या समझा रहा हूँ?  
   **Romanized:** Main tumhein kya samjha raha hoon?  
   **English answer:** What am I making you understand?  

69. **Hindi prompt:** वो मुझसे अपने 2 बैच पढ़वा रहा है।  
   **Romanized:** Vo mujhse apne 2 batch padhva raha hai.  
   **English answer:** He is making me teach his 2 batches.  

70. **Hindi prompt:** हमने उसे बाहर भिजवाया।  
   **Romanized:** Humne use bahar bhijvaya.  
   **English answer:** We made him go out.  

71. **Hindi prompt:** तुम ये किससे करवाओगे?  
   **Romanized:** Tum ye kisse karvaoge?  
   **English answer:** From whom will you get this done?  

72. **Hindi prompt:** जब कोई नहीं आया, तब पापा ने हमसे ये करवाया।  
   **Romanized:** Jab koi nahi aaya, tab papa ne humse ye karvaya.  
   **English answer:** When nobody came, dad made us do it.  

73. **Hindi prompt:** मैंने हर किसी को उस होटल में खाना खिलवाया।  
   **Romanized:** Maine har kisi ko us hotel mein khana khilvaya.  
   **English answer:** I made everyone eat the food in that hotel.  

74. **Hindi prompt:** तुमने मुझसे झूठ बुलवाया।  
   **Romanized:** Tumne mujhse jhooth bulvaya.  
   **English answer:** You made me tell a lie.  

75. **Hindi prompt:** राम मुझे रोज़ रुलाता है।  
   **Romanized:** Ram mujhe roz rulata hai.  
   **English answer:** Ram makes me cry every day.  

76. **Hindi prompt:** तुम कब तक ये काम खत्म करवा दोगे?  
   **Romanized:** Tum kab tak ye kaam khatm karva doge?  
   **English answer:** Until when will you get this work finished?  

77. **Hindi prompt:** क्या तुम मुझे डाँस सिखवा सकते हो?  
   **Romanized:** Kya tum mujhe dance sikhva sakte ho?  
   **English answer:** Can you make me learn dance?  

78. **Hindi prompt:** हमने उसे भिजवाया पर उसने वहाँ काम नहीं किया।  
   **Romanized:** Humne use bhijvaya par usne vaha kaam nahi kiya.  
   **English answer:** We made him go but he didn’t work there.  

79. **Hindi prompt:** वे तुम्हें अमेरिका भिजवायेंगे बशर्ते तुम उन्हें साबित करो कि तुम सबसे अच्छे हो।  
   **Romanized:** Ve tumhen America bhijvayenge basharte tum unhen saabit karo ki tum sabse ache ho.  
   **English answer:** They will make you go America provided you prove them to be the best.  

80. **Hindi prompt:** बॉबी ने मुझे अच्छा खाना खिलाया, जो उसकी मम्मी ने पकाया था।  
   **Romanized:** Bobby ne mujhe achchha khana khilaya, jo uski mummy ne pakaya tha.  
   **English answer:** Bobby made me eat the delicious food, cooked by his mom.  

81. **Hindi prompt:** तुमने मुझे कम्प्यूटर सिखाया।  
   **Romanized:** Tumne mujhe computer sikhaya.  
   **English answer:** You made me learn computer.  

82. **Hindi prompt:** उसने हमें कोक पिलाई/पिलवाई।  
   **Romanized:** Usne hamein coke pilaee/pilvaee.  
   **English answer:** He made us drink coke. / He got us coke.  

83. **Hindi prompt:** राहुल ने हमें एक्सरसाइज कराई / करवाई।  
   **Romanized:** Rahul ne hamein exercise karaee/karvaee.  
   **English answer:** Rahul made us do the exercise.  

84. **Hindi prompt:** तुमने मुझे पिटवाया।  
   **Romanized:** Tumne mujhe pitvaya.  
   **English answer:** You made me be beaten. / You got me beaten.  

85. **Hindi prompt:** तुमने उसे मुझसे पिटवाया।  
   **Romanized:** Tumne use mujhse pitvaya.  
   **English answer:** You made me beat him. / You got him beaten by me.  

86. **Hindi prompt:** राहुल ने उससे मुझे कुछ पैसे दिलवाये।  
   **Romanized:** Rahul ne usse mujhe kuch paise dilvaye.  
   **English answer:** Rahul got me some money from him. / Rahul made me get some money from him.  

87. **Hindi prompt:** मैंने बाल कटवाए।  
   **Romanized:** Maine baal katavaye.  
   **English answer:** I got the hair cut.  

88. **Hindi prompt:** राहुल यहीं से बाल कटवाता है।  
   **Romanized:** Rahul yahi se baal katvata hai.  
   **English answer:** Rahul gets the hair cut from here itself.  

89. **Hindi prompt:** क्या तुम बाल कटवाओगे?  
   **Romanized:** Kya tum baal katvaoge?  
   **English answer:** Will you get the hair cut?  

90. **Hindi prompt:** मैं ये काम कैसे करवा सकता हूँ?  
   **Romanized:** Main ye kaam kaise karva sakta hoon?  
   **English answer:** How can I get this work done?  

91. **Hindi prompt:** मैं राहुल को खाना खिलवाऊँगा।  
   **Romanized:** Main Rahul ko khana khilvaunga.  
   **English answer:** I will make Rahul eat the food.  

92. **Hindi prompt:** वो मुझे घर जाने देता है।  
   **Romanized:** Vo mujhe ghar jaane deta hai.  
   **English answer:** He lets me go home.  

93. **Hindi prompt:** वो मुझे घर नहीं जाने देता है।  
   **Romanized:** Vo mujhe ghar nahi jaane deta hai.  
   **English answer:** He doesn’t let me go home. / He lets me not go home.  

94. **Hindi prompt:** मेरे भाई ने कल मुझे अपना मोबाइल लेने दिया।  
   **Romanized:** Mere brother ne kal mujhe apna mobile lene diya.  
   **English answer:** My brother let me take his mobile yesterday.  

95. **Hindi prompt:** उसने मुझे हमेशा वो करने दिया है जो मैं चाहता हूँ।  
   **Romanized:** Usne mujhe hamesha vo karane diya hai jo main chaahata hoon.  
   **English answer:** He has always let me do what I want.  

96. **Hindi prompt:** बच्चे को सोने दो।  
   **Romanized:** Bachche ko sone do.  
   **English answer:** Let the baby sleep.  

97. **Hindi prompt:** उसे खुद फैसला लेने दो।  
   **Romanized:** Use khud faisla lene do.  
   **English answer:** (You) Let him take the decision himself.  

98. **Hindi prompt:** मैंने विवेक को क्लासरूम वापस भिजवाया।  
   **Romanized:** Mene Vivek ko classroom vapas bhijvaya  
   **English answer:** I made Vivek go back to the classroom. / I made Vivek to go back to the classroom. / I got Vivek to go back to the classroom.  

99. **Hindi prompt:** मेरी मम्मी रोज़ मुझसे खाना बनवाती है।  
   **Romanized:** Meri mummy roz mujhse khana banwati hai.  
   **English answer:** My mom makes me cook food every day. / My mom gets me to cook food every day.  

100. **Hindi prompt:** तुम मुझसे अपना होमवर्क लिखवा रहे हो।  
   **Romanized:** Tum mujhse apna homework likhva rhe ho.  
   **English answer:** You are making me write your homework. / You are getting me to write your homework.  

101. **Hindi prompt:** मैंने अमन को भिजवाया।  
   **Romanized:** Maine Aman ko bhijvaya.  
   **English answer:** I made Aman go. / I got Aman to go.  

102. **Hindi prompt:** उसने अपना मोबाईल मैकेनिक से रिपेयर करवाया।  
   **Romanized:** Usne apna mobile mechanic se repair karvaya.  
   **English answer:** He had a mechanic repair his mobile. / He got a mechanic to repair his mobile.  

103. **Hindi prompt:** उसने अपना मोबाईल मैकेनिक से रिपेयर नहीं करवाया, उसने खुद किया।  
   **Romanized:** Usne apna mobile mechanic se repair nahi karvaya, usne khud kiya.  
   **English answer:** He didn’t have a mechanic repair his mobile, he himself did it. / He didn’t get a mechanic to repair his mobile, he himself did it.  

104. **Hindi prompt:** कृपया अपनी कम्पनी से किसी से मुझे कॉल करवा दीजिए।  
   **Romanized:** Kripya apni company se kisi se mujhe call karva dijiye.  
   **English answer:** Please have someone call me from your company. / Please get someone to call me from your company.  

105. **Hindi prompt:** मैं इलैक्ट्रिशियन से यहाँ पर इस ट्यूबलाइट को लगवाऊँगा।  
   **Romanized:** Main electrician se yahaan par is tubelight ko lagvaaunga.  
   **English answer:** I will have an electrician fix this tube light here. / I will get an electrician to fix this tube light here.  

106. **Hindi prompt:** मैं आज शाम को अपने इम्प्लॉइ से आपको कॉल करवाऊँगा।  
   **Romanized:** Main aaj shaam ko apne employee se aapko call karvaaunga.  
   **English answer:** I will have my employee call you in the evening today. / I will get my employee to call you in the evening today.  

107. **Hindi prompt:** मैं उदय से मिलने में आपकी मदद करूँगा।  
   **Romanized:** Main Uday se milne mein aapaki madad karoonga.  
   **English answer:** I will help you meet Uday. / I will help you to meet Uday.  

108. **Hindi prompt:** उसने वहाँ पहुँचने में मेरी मदद की।  
   **Romanized:** Usne vahaan pahunchane me meri madad ki.  
   **English answer:** She helped me reach there. / She helped me to reach there.  

109. **Hindi prompt:** अख़बार पढ़ने से मुझे नए शब्दों को याद करने में मदद मिलती है।  
   **Romanized:** Newspaper padhne se mujhe naye words ko yaad karne me madad milti hai.  
   **English answer:** Newspaper reading helps me learn new words. / Newspaper reading helps me to learn new words.  

110. **Hindi prompt:** मैंने अपने बाल कटवाए।  
   **Romanized:** Maine apne baal katvaye.  
   **English answer:** I got my hair cut. / I had my hair cut.  

111. **Hindi prompt:** उसने मुझसे एक पत्र लिखवाया।  
   **Romanized:** Usne mujhse ek patra likhvaya.  
   **English answer:** He got a letter written by me. / He had a letter written by me. / He made me write a letter. (Active Causative structure)  

112. **Hindi prompt:** मेरी बहन ने टीवी रिपेयर करवाया।  
   **Romanized:** Meri bahan ne TV repair karvaya.  
   **English answer:** My sister got the TV repaired. (by a mechanic). / My sister had the TV repaired. (by a mechanic).  

113. **Hindi prompt:** वो कल अपना घर पेन्ट करवायेगा।  
   **Romanized:** Vo kal apna ghar paint karvayega.  
   **English answer:** He will get his house painted tomorrow (by a painter). / He will have his house painted tomorrow (by a painter).  

114. **Hindi prompt:** तुम अर्जुन को उससे नहीं पिटवा सकते।  
   **Romanized:** Tum Arjun ko usse nahi pitva sakte.  
   **English answer:** You can’t make him beat Arjun. / You can't get him to beat Arjun.  

115. **Hindi prompt:** तुम अर्जुन से उसे नहीं पिटवा सकते।  
   **Romanized:** Tum Arjun se use nahi pitva sakte.  
   **English answer:** You can’t make Arjun beat him. / You can't get Arjun to beat him.  

116. **Hindi prompt:** उसने मुझसे कभी काम नहीं करवाया।  
   **Romanized:** Usne mujhse kabhi kaam nahi karvaya.  
   **English answer:** He never made me work. / He never got me to work.  

117. **Hindi prompt:** वो मुझसे अपनी बहन का होमवर्क लिखवाता है।  
   **Romanized:** Vo mujhse apni bahan ka homework likhvaata hai.  
   **English answer:** He makes me write his sister’s homework. / He gets me to write his sister’s homework.  

118. **Hindi prompt:** वो मुझे राहुल से लड़वाता है।  
   **Romanized:** Vo mujhe Rahul se ladvaata hai.  
   **English answer:** He makes me fight Rahul. / He gets me to fight Rahul.  

119. **Hindi prompt:** क्या तुम कल बाल कटवाओगे?  
   **Romanized:** Kya tum kal baal katvaoge?  
   **English answer:** Will you get the hair cut tomorrow? / Will you have the hair cut tomorrow?  

120. **Hindi prompt:** सही से नींद लेने की आदत आपको आराम दिलाने में मदद कर सकती हैं।  
   **Romanized:** Sahee se neend lene ki aadat aapko aaraam dilaane mein madad kar sakatee hain.  
   **English answer:** Proper sleep habits can help you relax. / Proper sleep habits can help you to relax.  

121. **Hindi prompt:** मैं तुम्हें जाने देता हूँ।  
   **Romanized:** Main tumhe jaane deta hu.  
   **English answer:** I let you go.  

122. **Hindi prompt:** मैं जाने देता हूँ।  
   **Romanized:** Main jaane deta hu.  
   **English answer:** I let go.  

123. **Hindi prompt:** मैं क्या करवाता हूँ?  
   **Romanized:** Main kya karvata hoon?  
   **English answer:** What do I get done?  

124. **Hindi prompt:** मैं क्यों करवाता हूँ?  
   **Romanized:** Main kyo karvata hoon?  
   **English answer:** Why do I get done?  

125. **Hindi prompt:** लोग तुम्हें जबरदस्ती उस जगह भिजवायेंगे।  
   **Romanized:** Log tumhein jabardastee us jagah bhijvayenge.  
   **English answer:** People will forcefully make you go to that place. / People will forcefully get you to go to that place.  

126. **Hindi prompt:** उसने मुझसे एक पत्र साइन करवाया।  
   **Romanized:** Usne mujhse ek letter sign karvaaya.  
   **English answer:** He made me sign a letter. / He got me to sign a letter.  

127. **Hindi prompt:** आप ये काम कैसे करवा सकता हैं?  
   **Romanized:** Aap ye kaam kaise karva sakta hain?  
   **English answer:** How can you get this work done? / How can you have this work done?  

128. **Hindi prompt:** वो मुझसे काम क्यों करवाती रहती है?  
   **Romanized:** Vo mujhse kaam kyo karvati rahti hai?  
   **English answer:** Why does she keep making me work? / Why does she keep getting me to work? / Why does she keep having me work?  

129. **Hindi prompt:** वह मुझे बेवकूफ बना रही थी।  
   **Romanized:** Vah mujhe bevakuf bana rahi thi.  
   **English answer:** She was making me fool.  

130. **Hindi prompt:** रवि यहीं से बाल कटवाता है।  
   **Romanized:** Ravi yahi se baal katvata hai.  
   **English answer:** Ravi gets the hair cut from here itself.  

131. **Hindi prompt:** उसने मुझे ये सब समझाया।  
   **Romanized:** Usne mujhe ye sab samjhaya.  
   **English answer:** She made me understand all this. / She got me understand all this.  

132. **Hindi prompt:** तुमने अपने बाल कहाँ से कटवाये?  
   **Romanized:** Tumne apne baal kaha se katvaye?  
   **English answer:** From where did you get your hair cut?  

133. **Hindi prompt:** मुझे ये काम करवाना है।  
   **Romanized:** Mujhe ye kaam karvana hai.  
   **English answer:** I have to get this work done.  

134. **Hindi prompt:** मुझे ये काम नहीं करवाना है।  
   **Romanized:** Mujhe ye kaam nahi karvana hai.  
   **English answer:** I have not to get this work done. / I don’t have to get this work done.  

135. **Hindi prompt:** मुझे ये काम आपसे करवाना है।  
   **Romanized:** Mujhe ye kaam aapse karvana hai.  
   **English answer:** I have to get this work done by you. / I have to make you do this work.  

136. **Hindi prompt:** मुझे ये काम आपसे नहीं करवाना है।  
   **Romanized:** Mujhe ye kaam aapse nahi karvana hai.  
   **English answer:** I have not to get this work done by you. (Passive – GET) / I don’t have to get this work done by you. (Passive – GET) / I have not to make you do this work. (Active – MAKE) / I have not to get you to do this work. (Active – GET TO) / I don’t have to get you to do this work. (Active – GET TO) / I don’t have to make you do this work. (Active – MAKE)  

137. **Hindi prompt:** मैं तुमसे ये काम करवाऊँगा।  
   **Romanized:** Main tumse ye kaam karvaoonga.  
   **English answer:** I will make you do this work. / I will get you to do this work. / I will have you do this work.  

138. **Hindi prompt:** तुम मुझे उससे बेवजह लड़वा रहे हो।  
   **Romanized:** Tum mujhe use bevajah ladva rahe ho.  
   **English answer:** You are making me fight him for no reason. / You are getting me to fight him for no reason.  

139. **Hindi prompt:** बच्चे आपको बेवकूफ बना रहे हैं।  
   **Romanized:** Bachche aapko bevakuf bana rahe hain.  
   **English answer:** Kids are making you fool.  

140. **Hindi prompt:** तुम हमें बहुत हँसाते थे।  
   **Romanized:** Tum hamein bahut hasate the.  
   **English answer:** You used to make us laugh a lot. / You used to get us to laugh a lot.  

141. **Hindi prompt:** वो ये किसी से भी करवा सकता है।  
   **Romanized:** Vo ye kisi se bhi karva sakta hai.  
   **English answer:** He can make anyone do it. / He can get anyone to do it. / He can get it done by anyone.  

142. **Hindi prompt:** मेरी बहन ने मैकेनिक से टीवी रिपेयर करवाया।  
   **Romanized:** Meri bahan ne mechanic se TV repair karvaya.  
   **English answer:** My sister got the TV repaired by a mechanic. (Passive) / My sister had the TV repaired by a mechanic. (Passive) / My sister got the mechanic to repair the TV. (Active) / My sister had the mechanic repair the TV. (Active)  

143. **Hindi prompt:** मैं तुम्हें जाने दे सकता हूँ।  
   **Romanized:** Main tumhein jaane de sakta hu.  
   **English answer:** I can let you go.  

144. **Hindi prompt:** मैं तुम्हें खाने को कुछ दिलवा देता हूँ।  
   **Romanized:** Main tumhein khane ko kuch dilva deta hoon.  
   **English answer:** I get you something to eat.  

145. **Hindi prompt:** क्या तुम मुझे एग्जाम में फेल करवा सकते हो?  
   **Romanized:** Kya tum mujhe exam mein fail karva sakte ho?  
   **English answer:** Can you make me fail the exam? / Can you get me to fail the exam?  

146. **Hindi prompt:** मैं तुम्हें पास नहीं करवा सकता।  
   **Romanized:** Main tumhein pass nahi karva sakta.  
   **English answer:** I cannot make you pass. / I cannot get you to pass.  

147. **Hindi prompt:** आप मुझे उन गलतियों का अहसास करवा रहे हो जो वास्तव में मैंने कभी की ही नहीं।  
   **Romanized:** Aap mujhe un galtiyon ka ahsaas karva rahe ho jo vaastav me maine kabhi ki hi nahi.  
   **English answer:** You are making me realize the mistakes that I never really did. / You are getting me to realize the mistakes that I never really did.  

148. **Hindi prompt:** आप हर किसी को खुश नहीं कर सकते।  
   **Romanized:** Aap har kisi ko khush nahi kar sakte.  
   **English answer:** You cannot make everyone happy.  

149. **Hindi prompt:** भैया तुझे कुछ नहीं दिलवा सकते क्योंकि उनके पास पैसे नहीं हैं।  
   **Romanized:** Bhaiya tujhe kuchh nahi dilva sakte kyoki unke pass paise nahi hai.  
   **English answer:** Bhaiya can’t get you anything as he doesn’t have money.  

150. **Hindi prompt:** क्या वो उस लड़की को हँसा सका?  
   **Romanized:** Kya vo us ladki ko hasaan saka?  
   **English answer:** Could he make that girl smile? / Could he get that girl to smile?  

151. **Hindi prompt:** क्या आप उसे घर जाने दोगे?  
   **Romanized:** Kya aap use ghar jaane doge?  
   **English answer:** Will you let him go home?  

152. **Hindi prompt:** तुम्हें ये किसी भी तरह करवाना पड़ेगा।  
   **Romanized:** Tumhein ye kisi bhi tarah karvaana padega.  
   **English answer:** You will have to get it done anyhow. / You will have to have it done anyhow.  

153. **Hindi prompt:** उसे आने दो।  
   **Romanized:** Use aane do.  
   **English answer:** Let him come.  

154. **Hindi prompt:** इस प्रश्न को हल करने में आपको मेरी मदद करनी चाहिए।  
   **Romanized:** Is question ko hal karne me aapko meri help karni chahiye.  
   **English answer:** You should help me solve this question. / You should help me to solve this question.  

155. **Hindi prompt:** वो मुझे अच्छा खाना खिलाता था।  
   **Romanized:** Vo mujhe acha khana khilata thaa.  
   **English answer:** He used to make me eat good food. / He used to get me to eat good food. / He used to get me good food.  

156. **Hindi prompt:** तुम मुझे दिल्ली कब भिजवाओगे?  
   **Romanized:** Tum mujhe Delhi kab bhijvaoge?  
   **English answer:** When will you make me go to Delhi? / When will you get me to go to Delhi?  

157. **Hindi prompt:** वो हमें पानी पिलवा रहा था।  
   **Romanized:** Vo hamein panee pilva raha tha.  
   **English answer:** He was making us drink water. / He was getting us to drink water. / He was getting us water.  

158. **Hindi prompt:** उस बच्ची ने हर किसी को हँसाया।  
   **Romanized:** Us bachchi ne har kisi ko hasaaya.  
   **English answer:** That girl made everyone laugh. / That girl got everyone to laugh.  

159. **Hindi prompt:** आपने मुझे रुलवाया/रुलाया है।  
   **Romanized:** Aapne mujhe rulvaaya/rulaya hai.  
   **English answer:** You have made me cry. / You have got me to cry.  

160. **Hindi prompt:** वो एक बेहतरीन हास्य कलाकार है। वो सबको हँसाता है।  
   **Romanized:** Vo ek behtareen haasya kalakaar hai. Vo sabko hansata hai.  
   **English answer:** He is a great comedian. He makes everyone laugh. / He is a great comedian. He gets everyone to laugh.  

161. **Hindi prompt:** उदय मुझसे अपना होमवर्क करवायेगा।  
   **Romanized:** Uday mujhse apna homework karavayega.  
   **English answer:** Uday will make me write (do) his homework. / Uday will get me to write (do) his homework.  

162. **Hindi prompt:** आप दोनों उससे अपना होमवर्क क्यों करवाते हो?  
   **Romanized:** Aap dono usse apna homework kyo karvate ho?  
   **English answer:** Why do you both make him write your homework? / Why do you both get him to write your homework?  

163. **Hindi prompt:** कोच ने हमें एक्सरसाइज कराई / करवाई।  
   **Romanized:** Coach ne hame exercise karaee/karvaee.  
   **English answer:** The coach made us do the exercise. / The coach got us to do the exercise.  

164. **Hindi prompt:** रंजन ने उससे मुझे कुछ पैसे दिलवाये।  
   **Romanized:** Ranjan ne usse mujhe kuch paise dilvaye.  
   **English answer:** Ranjan got me some money from him.  

165. **Hindi prompt:** हमने उस आदमी को बाहर भिजवाया।  
   **Romanized:** Humne us aadmi ko bahar bhijvaya.  
   **English answer:** We made that man go out. / We got that man to go out.  

166. **Hindi prompt:** उसने रवि से किसे कॉल करवाई?  
   **Romanized:** Usne Ravi se kise call karvaee?  
   **English answer:** Whom did he make Ravi call? / Whom did he get Ravi to call?  

167. **Hindi prompt:** उसने वो पैन तुम्हें कैसे दिलवाया?  
   **Romanized:** Usne vo pen tumhein kaise dilvaya?  
   **English answer:** How did he get you that pen?  

168. **Hindi prompt:** तुमने मुझे महसूस करवाया।  
   **Romanized:** Tumne mujhe mahsoos karvaya.  
   **English answer:** You made me realize. / You got me to realize.  

169. **Hindi prompt:** तुमने मुझे पैसे की कीमत समझायी।  
   **Romanized:** Tumne mujhe paise ki keemat samjhayee.  
   **English answer:** You made me understand the value of money. / You got me to understand the value of money.  

170. **Hindi prompt:** मैं तुम्हें समझा नहीं पाया।  
   **Romanized:** Main tumhein samjha nahi paaya.  
   **English answer:** I couldn’t make you understand. / I couldn't get you to understand.  

171. **Hindi prompt:** मैंने तुमसे बाल्टी कब भरवाई?  
   **Romanized:** Maine tumse baltee kab bharvai?  
   **English answer:** When did I make you fill the bucket? / When did I get you to fill the bucket?  

172. **Hindi prompt:** उसने तुमसे इतने पैसे क्यों खर्च करवाये?  
   **Romanized:** Usne tumse itne paise kyo kharch karvaye?  
   **English answer:** Why did he make you spend this much money? / Why did he get you to spend this much money?  

173. **Hindi prompt:** मैंने हर किसी को इस होटल में खाना खिलवाया।  
   **Romanized:** Maine har kisi ko is hotel me khana khilvaya.  
   **English answer:** I made everyone eat the food in this hotel.  

174. **Hindi prompt:** उसने मुझसे झूठ बुलवाया।  
   **Romanized:** Usne mujhse jhooth bulvaya.  
   **English answer:** He made me to tell a lie. / He got me to tell a lie.  

175. **Hindi prompt:** तुम ये काम कब तक खत्म करवा सकते हो?  
   **Romanized:** Tum ye kaam kab tak khatm karva sakte ho?  
   **English answer:** Until when can you get this work finished?  

176. **Hindi prompt:** हमने उसे वहाँ भिजवाया पर उसने काम नहीं किया।  
   **Romanized:** Humne use vahaan bhijvaya par usne kaam nahi kiya.  
   **English answer:** We made him go there but he didn’t work.  

177. **Hindi prompt:** उसने मुझे अच्छा खाना खिलाया, जो उसकी मम्मी ने पकाया था।  
   **Romanized:** Usne mujhe achchha khana khilaya, jo uski mummy ne pakaya tha.  
   **English answer:** He made me eat the delicious food, cooked by his mom. / He got me to eat the delicious food, cooked by his mom.  

178. **Hindi prompt:** उसने मुझे कम्प्यूटर सिखाया / सिखवाया।  
   **Romanized:** Usne mujhe computer sikhaya/sikhvaya.  
   **English answer:** He made me learn the computer. / He got me to learn the computer.  

179. **Hindi prompt:** उस आदमी ने हमें लस्सी पिलाई/पिलवाई।  
   **Romanized:** Us aadmi ne hamein lassi pilaee/pilvaee.  
   **English answer:** That man made us drink lassi. / That man got us to drink lassi.  

## Source-text and verification notes

- All 179 Hindi prompts on PDF pages 322–329 were OCRed from row crops and visually checked against the scans; all 179 printed Romanized lines were retained and checked. All 179 English answers on PDF pages 330–335 were visually reviewed and paired with same-number prompts; the sequence is complete and unique.
- Lesson 23 spans PDF pages 322–335 (printed pages 321–334). Prompts 1–179 are on PDF pages 322–329; the English answer key runs 1–179 on pages 330–335.
- All 179 Hindi prompts and Romanized lines were OCRed from scanned rows and visually checked; all 179 printed English answers were visually reviewed and paired by number. The numbering is continuous with no unreadable sections.
- The printed page footers are one lower than the PDF page numbers. Prompt 8 and prompt 37 repeat the same sentence in the source; both are retained as printed.
- Printed Romanized source forms are preserved except where row extraction was corrupted. In items 3–5 the source Romanized lines end with the abbreviated ‘h’/‘h.’; in items 55 and 68 ‘samiha’ is printed despite Hindi ‘समझा’; in item 87 ‘katavaye’ is printed beside Hindi ‘कटवाए’. These Romanized discrepancies are flagged, not silently rewritten.
- The English answer-key wording, alternatives, and source grammar are retained as printed.

**Unreadable text:** none identified.

