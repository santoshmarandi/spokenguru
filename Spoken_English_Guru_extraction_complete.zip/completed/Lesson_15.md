# Lesson 15 — Conditional Sentences – Type 0, 1, 2 & 3

**PDF pages:** 157–198 (printed pages 156–197)

The PDF prints the answer keys after the exercises. Each prompt below is paired with the answer carrying the same number in its own exercise key.

## Exercise 1 — Type 0

**Instruction:** Please translate the following conditional sentences (Type 0) into English.

### 1. अगर आप पढ़ाना सीख लेते हैं, तो आपको आसानी से टीचर की जॉब मिल जाती है।
**Romanized:** (Agar aap padhana seekh lete hain, to aapko aasani se teacher ki job mil jaati h.)
**English answer:** If you learn how to teach, you easily get a job as a teacher.

### 2. अगर मैं ऑफिस में ज़्यादा काम करता हूँ, तो मैं थक जाता हूँ।
**Romanized:** (Agar mein office mein zyada kaam karta hoon, to main thak jata hoon.)
**English answer:** If I work more in the office, I get tired.

### 3. अगर आप अपना सारा होमवर्क करते हैं, तो आपको पासिंग ग्रेड मिलता है।
**Romanized:** (Agar aap apna sara homework karte hai, to aapko passing grade milta hai.)
**English answer:** If you complete your homework, you get a passing grade.

### 4. अगर बारिश होती है, तो मेरी कार भीग जाती है।
**Romanized:** (Agar barish hoti hai, to meri car bheeg jaati hai.)
**English answer:** If it rains, my car gets drenched.

### 5. अगर कुत्तों को प्यार करो, तो वे अपनी पूँछ हिलाते हैं।
**Romanized:** (Agar kutton ko pyar karo, to ve apni poonch hilate hain.)
**English answer:** If we love the dogs, they move their tails.

### 6. अगर हिमानी देर से सोती है, तो उसे स्कूल जाने में देर हो जाती है।
**Romanized:** (Agar Himani der se soti hai, to use school jaane mein der ho jati hai.)
**English answer:** If Himani sleeps late, she gets late for school.

### 7. अगर मैं समाचार देखता हूँ, तो तनावग्रस्त हो जाता हूँ।
**Romanized:** (Agar main samachar dekhta hoon, to tanaavgrast ho jaata hoon.)
**English answer:** If I watch the news, I get tense.

### 8. अगर आप पानी को फ्रिज में रखते हैं, तो यह बर्फ में बदल जाता है।
**Romanized:** (Agar aap paani ko fridge me rakhte hain, to yah barf mein badal jaata hai.)
**English answer:** If you keep the water in the fridge, it becomes ice.

### 9. अगर आप धातु को गर्म करते हैं, तो यह फैलती है।
**Romanized:** (Agar aap dhatu ko garam karte hain, to yah failati hai.)
**English answer:** If you heat the metal, it expands.

### 10. अगर आपको कोई समस्या है, तो अपने डॉक्टर से बात करें।
**Romanized:** (Agar aapko koi samasya hai, to apne doctor se baat Karen.)
**English answer:** If you have some problem, talk to your doctor.

### 11. अगर हम बहुत ज़्यादा शोर करते हैं, तो बच्चा जग जाता है।
**Romanized:** (Agar hum bahut zyada shor karte hain, to bachcha jag jaata hai.)
**English answer:** If we make lots of noise, the child gets awake.

### 12. अगर आप बटन दबाते हैं, तो टेलीविजन चालू हो जाता है।
**Romanized:** (Agar aap button dabate hain, to television chaalu ho jata hai.)
**English answer:** If you press the switch, the TV gets switched on.

### 13. अगर आपको ज़्यादा पसीना आता है, तो आप डिहाइड्रेट हो जाते हैं।
**Romanized:** (Agar aapko zyada pasina aata hai, to aap dehydrate ho jaate hain.)
**English answer:** If you perspire a lot, you become dehydrated.

### 14. अगर आपको अपनी चाबी नहीं मिलती है, तो आप बाहर रहते हैं।
**Romanized:** (Agar aapko apni chabi nahi milti hai, to aap baahar rehte hain.)
**English answer:** If you don’t get your keys, you stay outside.

### 15. अगर पानी 100 डिग्री तक पहुँच जाता है, तो यह उबलता है।
**Romanized:** (Agar pani 100 degree tak pahunch jaata hai, to yah ubalta hai.)
**English answer:** If the water reaches 100 degrees, it boils.

### 16. अगर बादल गरजते हैं, तो बारिश आती है।
**Romanized:** (Agar baadal garajte hai, to baarish aati hai.)
**English answer:** If the clouds thunder, it rains.

### 17. अगर आप कहीं जॉब करते हो, तो आपको सैलरी भी मिलती है।
**Romanized:** (Agar aap kahin job karte ho, to aapko salary bhee milti hai.)
**English answer:** If you work somewhere, you also get a salary.

### 18. अगर बच्चे भूखे होते हैं, तो वह रोने लग जाते हैं।
**Romanized:** (Agar bachhe bhukhe hote hain, to vah rone lag jaate hain.)
**English answer:** If the kids are hungry, they start weeping.

### 19. अगर ठंड ज़्यादा होती है, तो बर्फ गिरने लगती है।
**Romanized:** (Agar thand jayaada hoti hai, to barf girane lagti hai.)
**English answer:** If it’s too cold, it starts snowing.

### 20. अगर पौधों को पर्याप्त पानी न मिले, तो वे मर जाते हैं।
**Romanized:** (Agar paudho ko paryapt paani na mile, to ve mar jaate hain.)
**English answer:** If the plants don’t get enough water, they die.

### 21. अगर आप लाल और नीले रंग को मिलाते हैं, तो बैंगनी रंग बनता है।
**Romanized:** (Agar aap laal or nile rang ko milaate hai, to baingani rang banta hai.)
**English answer:** If you mix red and blue, it becomes purple.

### 22. अगर आप आग को छूते हैं, तो आप जल जाते हैं।
**Romanized:** (Agar aap aag ko chhute hain, to aap jal jaate hai.)
**English answer:** If you touch the fire, you get burnt.

### 23. अगर मेरे पास बहुत काम है, तो मैं देर तक ऑफिस में रहता हूँ।
**Romanized:** (Agar mere paas bahut kaam hai, to main der tak office mein rehta hoon.)
**English answer:** If I have lots of work, I stay in the office till late.

### 24. अगर हमारे पास समय होता है, तो हम टहलने के लिए पार्क में जाते हैं।
**Romanized:** (Agar hamare paas samay hota hai, to hum tahalne ke liye park mein jaate hain.)
**English answer:** If we have time, we go to the park for a walk.

### 25. अगर छात्र अपना होमवर्क नहीं करते हैं, तो शिक्षक नाराज़ हो जाते हैं।
**Romanized:** (Agar chhatra apna homework nahi karte hain, to shikshak naraz ho jaate hain.)
**English answer:** If the students don’t do their homework, the teachers get annoyed.

### 26. अगर रात में बहुत ठंड होती है, तो कारों पर बर्फ जम जाती है।
**Romanized:** (Agar raat mein bahut thand hoti hai, to caro mein barf jam jati hai.)
**English answer:** If it’s too cold at night, snow freezes on the cars.

### 27. अगर आप बहुत ज़्यादा खाते हैं, तो आपका वजन बढ़ जाता है।
**Romanized:** (Agar aap bahut zyada khate hai to, aapka wajan badh jata hai.)
**English answer:** If you eat too much, you gain weight.

### 28. अगर वे मैच जीतते हैं, तो वे साथ में पार्टी करते हैं।
**Romanized:** (Agar ve match jeette, to ve saath mein party karte hain.)
**English answer:** If they win the match, they have a party together.

### 29. अगर आप फ्रीज़र से बर्फ निकालते हैं, तो वह पिघल जाती है।
**Romanized:** (Agar aap freezer se barf nikalte hai, to vah pighal jaati hai.)
**English answer:** If you take the ice out of the freezer, it melts.

### 30. अगर मैं ज़्यादा खाऊँ, तो मैं मोटा हो जाता हूँ।
**Romanized:** (Agar main zyada khaun, to main mota ho jata hoon.)
**English answer:** If I eat too much, I become fat.

### 31. अगर मैं दूध पीता हूँ, तो मुझे ऊर्जा मिलती है।
**Romanized:** (Agar main doodh peeta hoon, to mujhe urja milati hai.)
**English answer:** If I drink milk, I get energy.

### 32. अगर कार में तेल नहीं होता है, तो कार रुक जाती है।
**Romanized:** (Agar car mein tel nahi hota hai, to car ruk jati hai.)
**English answer:** If there is no oil in the car, the car stalls.

### 33. अगर धूप होती है, तो मैं जिम जाता हूँ।
**Romanized:** (Agar dhoop hoti hai, to main gym jata hoon.)
**English answer:** If it’s sunny, I go to the gym.

### 34. अगर वह ऑफिस से बाहर होता है, तो ही उसका फोन उठाता है।
**Romanized:** (Agar vah office se bahar hota hai, to hi uska phone uthata hai.)
**English answer:** If he is out of office, then only he picks up his phone. / Only if he is out of office, he picks up his phone.

### 35. अगर आप पहाड़ों में सैंडल पहनते हैं, तो आप चट्टानों पर फिसलते हैं।
**Romanized:** (Agar aap pahadon me sandal pehnate hain, to aap chattano par phisalte hain.)
**English answer:** If you wear sandals in the mountains, you slip on rocks.

### 36. अगर बैंक खुला होता है, तो मैं पैसे जमा करने बैंक में जाता हूँ।
**Romanized:** (Agar bank khula hota hai, to main paise jama karne bank main jata hoon.)
**English answer:** If the bank is open, then I go there to deposit money.

### 37. जब मेरे पास कार होती है, तो मैं पैदल नहीं जाता हूँ।
**Romanized:** (Jab mere paas car hoti hai, to main paidal nahi jaata hoon.)
**English answer:** When I have a car, I don’t go on foot.

### 38. जब बारिश ज़्यादा होती है, तो फसलें खराब हो जाती हैं।
**Romanized:** (Jab baarish zyada hoti hai, to fasalein kharaab ho jaati hain.)
**English answer:** When there is heavy rainfall, the crops get spoiled.

### 39. अगर वो बीमार नहीं होता है, तो स्कूल ज़रूर आता है।
**Romanized:** (Agar vo bimar nahi hota hai, to school zaroor aata hai.)
**English answer:** If he doesn't get sick, he definitely comes to school.

### 40. अगर उसको नींद आती है, तो वह सो जाता है।
**Romanized:** (Agar usko neend aati hai, to vah so jata hai.)
**English answer:** If he feels sleepy, he goes to sleep.

### 41. अगर बर्फ पिघलती है, तो वह पानी में बदल जाती है।
**Romanized:** (Agar barf pighalti hai, to vah paani mein badal jaati hai.)
**English answer:** If the ice melts, it turns into water.

### 42. अगर लाइट नहीं होती है, तो अंधेरा हो जाता है।
**Romanized:** (Agar light nahi hoti hai, to andhera ho jata hai.)
**English answer:** If there is no light, it becomes dark.

### 43. अगर जंगल नहीं होते हैं, तो जानवर भी नहीं होते हैं।
**Romanized:** (Agar jungle nahi hote hain, to janwar bhi nahi hote hain.)
**English answer:** If there are no forests, there are no animals.

### 44. अगर मेरे पास बाइक होती है, तो मैं जल्दी पहुँच जाता हूँ।
**Romanized:** (Agar mere pass bike hoti hai, to main jaldi pahuch jata hoon.)
**English answer:** If I have a bike, I reach early.

### 45. अगर मैं ध्यान देता हूँ, तो कोई गलती नहीं होती है।
**Romanized:** (Agar main dhyan deta hoon, to koi galti nahi hoti hai.)
**English answer:** If I pay attention, I make no mistakes.

### 46. अगर मेरे पास अच्छे जूते होते हैं, तो मैं रेस जीत जाता हूँ।
**Romanized:** (Agar mere paas achchhe joote hote hain, to main race jeet jata hoon.)
**English answer:** If I have good shoes, I win the race.

### 47. अगर पेपर आसान होता है, तो मैं पास हो जाता हूँ।
**Romanized:** (Agar paper aasan hota hai, to main pass ho jata hoon.)
**English answer:** If the paper is easy, I pass.

### 48. अगर तुम मेरा साथ देते हो, तो मैं हारता नहीं हूँ।
**Romanized:** (Agar tum mera saath dete ho, to main haarta nahi hoon.)
**English answer:** If you support me, I don't lose.

### 49. अगर मेरे पास पैसे होते हैं, तो मैं कहीं घूमने चला जाता हूँ।
**Romanized:** (Agar mere pass paise hote hain, to main kahin ghumne chala jata hoon.)
**English answer:** If I have money, I go somewhere on a visit.

### 50. अगर वह गर्म पानी पीता है, तो उसको जुकाम नहीं होता है।
**Romanized:** (Agar vah garam paani peeta hai, to usko jukham nahi hota hai.)
**English answer:** If he drinks warm water, he does not get cold.

## Exercise 2 — Type 1

**Instruction:** Please translate the following conditional sentences (Type 1) into English.

### 1. अगर आप तेज़ बहते पानी में जाओगे, तो आप बह जाओगे।
**Romanized:** (Agar aap tez bahate paani mein jaoge, to aap bah jaaoge.)
**English answer:** If you go in fast-flowing water, you will be swept away.

### 2. अगर आप पानी गर्म करेंगे, तो वह उबलेगा।
**Romanized:** (Agar aap paani garam karenge, to vah ublega.)
**English answer:** If you heat water, it will boil.

### 3. अगर आप पानी गर्म नहीं करेंगे, तो वह नहीं उबलेगा।
**Romanized:** (Agar aap paani garam nahi karenge, to vah nahi ublega.)
**English answer:** If you don’t heat water, it will not boil.

### 4. अगर आप बर्फ गर्म करेंगे तो वह पिघलेगी।
**Romanized:** (Agar aap barf garam karenge, to vah pighlegi.)
**English answer:** If you heat ice, it will melt.

### 5. अगर सूरज डूब जाएगा, तो रात हो जायेगी।
**Romanized:** (Agar suraj doob jayega, to raat ho jayegi.)
**English answer:** If the Sun sets, it will be night.

### 6. अगर आप बिजली की तार छुएंगे, तो आपको करंट लगेगा।
**Romanized:** (Agar aap bijali ki taar chuyenge, to aapko current lagega.)
**English answer:** If you touch an electric wire, you will feel an electric shock.

### 7. अगर आप गंदा पानी पियोगे, तो बीमार हो जाओगे।
**Romanized:** (Agar aap ganda paani piyoge, to bimaar ho jaaoge.)
**English answer:** If you drink dirty water, you will fall sick.

### 8. अगर एंबुलेंस समय पर पहुँच जाए, तो मरीज को बचाया जा सकता है।
**Romanized:** (Agar ambulance samay par pahunch jaaye, to marij ko bachaya ja sakta hai.)
**English answer:** If the ambulance reaches on time, the patient could be saved.

### 9. अगर वह आपको इन्वाइट करता है, तो आपको जाना चाहिए।
**Romanized:** (Agar vah aap ko invite karta hai, to aapko jana chahiye.)
**English answer:** If he invites you, you should go.

### 10. अगर वह मुझसे बात नहीं करेगा, तो मैं भी उससे बात नहीं करूँगा।
**Romanized:** (Agar vah mujhse baat nahi karega, to main bhi usse baat nahi karunga.)
**English answer:** If he doesn’t talk to me, I will not talk to him either.

### 11. अगर आप समय पर नहीं आओगे, तो हमें देर हो जाएगी।
**Romanized:** (Agar aap samay par nahi aaoge, to hamein der ho jayegi.)
**English answer:** If you don’t come on time, we will be late.

### 12. अगर आप शीशे पर पत्थर फेंकोगे, तो वो टूट जाएगा।
**Romanized:** (Agar aap sheeshe par pathar fekoge, to vo toot jayega.)
**English answer:** If you throw a stone at a glass, it will break.

### 13. अगर आपको भूख लगी है, तो आप एक सेब खा सकते हैं।
**Romanized:** (Agar aapko bhukh lagi hai, to aap ek apple kha sakte hai.)
**English answer:** If you are hungry, you could eat an apple.

### 14. अगर बारिश हुई, तो हम भीग सकते हैं।
**Romanized:** (Agar barish hui to ham bheeg sakte hain.)
**English answer:** If it rains, we may get wet.

### 15. अगर गर्मी जारी रही, तो पौधे और जानवर नष्ट हो जाएंगे।
**Romanized:** (Agar garmi jaari rahi, to podhe or janvar nasht ho jaayenge.)
**English answer:** If the heat continues, plants and animals will perish.

### 16. अगर वह प्रथम पुरस्कार जीत जाता है, तो उसकी माँ खुश होगी।
**Romanized:** (Agar vah pratham puraskar jeet jaata hai, to uski maa khush hogi.)
**English answer:** If he wins the first prize, his mother will be happy.

### 17. अगर आप विनग्रता से पूछेंगे, तो मैं आपके लिए एक बाइक खरीदूँगा।
**Romanized:** (Agar aap vinamrata se poochenge, to main aapke liye ek bike kharidunga.)
**English answer:** If you ask politely, I will buy you a bike.

### 18. अगर मुझे प्रमोशन मिलता है, तो मैं एक कार खरीदूँगा।
**Romanized:** (Agar mujhe promotion milta hai, to main ek car kharidunga.)
**English answer:** If I get a promotion, I will buy a car.

### 19. अगर उसको अच्छा उपचार मिल जाता है, तो वह जीवित रहेगा।
**Romanized:** (Agar usko accha upchar mil jata hai, to vah jeevit rahega.)
**English answer:** If he gets good treatment, he will live.

### 20. यदि आप अच्छा व्यवहार नहीं करते हैं, तो मैं आपको बाहर निकाल दूँगा।
**Romanized:** (Agar aap acha vyavahar nahi karte hain, to main apko bahar nikal dunga.)
**English answer:** If you don't behave well, I'll kick you out.

### 21. अगर आपको देर हो गई, तो हम आपके बिना ही चले जाएंगे।
**Romanized:** (Agar aapko der ho gayi, to hum apke bina hi chale jayenge.)
**English answer:** If you are late, we will leave without you.

### 22. अगर आज बारिश हो गयी, तो मैच रद्द हो जायेगा।
**Romanized:** (Agar aaj barish ho jaayegi, to match raddh ho jaayega.)
**English answer:** If it rains today, the match will be canceled.

### 23. अगर आप जल्दी से तैयार नहीं होते हैं, तो आपकी बस छूट जाएगी।
**Romanized:** (Agar aap jaldi se taiyaar nahi hote hai, to aapki bus choot jaayegi.)
**English answer:** If you don't get ready quickly, you will miss your bus.

### 24. अगर बारिश हुई, तो तुम भीग जाओगे।
**Romanized:** (Agar barish hui, to tum bheeg jaaoge.)
**English answer:** If it rains, you will get wet.

### 25. अगर मुझे 40 मिनट और मिलें, तो मैं उस पेपर को समाप्त कर दूँगा।
**Romanized:** (Agar mujhe 10 minute or milen, to main us paper ko samapt kar dunga.)
**English answer:** If I get 10 more minutes, I will finish that paper.

### 26. अगर आपका प्लेन छूट गया, तो आप कया करेंगे?
**Romanized:** (Agar aapka plane choot gaya, to aap kya karenge?)
**English answer:** If you miss your plane, what will you do?

### 27. अगर तुमने उस गिलास को गिराया, तो वह टूट सकता है।
**Romanized:** (Agar tumne us glass ko giraya, to vah toot sakta hai.)
**English answer:** If you drop that glass, it may break.

### 28. अगर आप नहीं जाते हैं, तो मैं पुलिस को फोन करूँगा।
**Romanized:** (Agar aap nahi jaate hain, to main police ko phone karunga.)
**English answer:** If you don't go, I'll call the police.

### 29. अगर वह आपको बुलाता है, तो आप जा सकते हो।
**Romanized:** (Agar vah aapko bulaata hai, to aap jaa sakte ho.)
**English answer:** If he calls you, you can go.

### 30. अगर मैं कठिन अध्ययन करता हूँ. तो मैं परीक्षा में सफल हो जाऊँगा।
**Romanized:** (Agar main kathin adhyayan karta hoon, to main pariksha me safal ho jaunga.)
**English answer:** If I study hard, I will pass the exam.

### 31. अगर मौसम अच्छा रहा, तो हमारी फसलें अच्छी होंगी।
**Romanized:** (Agar mosam acha raha, to hamari fasle achchhi hongi.)
**English answer:** If the weather is good, our crops will be good.

### 32. अगर आप अपनी पढ़ाई में मेहनती हैं, तो आप कॉलेज में सफल होंगे।
**Romanized:** (Agar aap apni padhai mein mehnati hain, to aap college mein safal honge.)
**English answer:** If you are diligent in your studies, you will be successful in college.

### 33. अगर ये फ़िल्म मेरी बहन देखेगी, तो वह रोने लगेगी।
**Romanized:** (Agar ye film meri behan dekhegi, to vah rone lagegi.)
**English answer:** If my sister watches this movie, she will start crying.

### 34. अगर मुझे आमंत्रित किया गया, तो मैं शादी में शामिल होऊँगा।
**Romanized:** (Agar mujhe aamantrit kiya gaya, to main shaadi mein shamil hounga.)
**English answer:** If I am invited, I will attend the wedding.

### 35. अगर बच्चे बहुत अधिक कैंडी खायेंगे, तो उन्हें पेट में दर्द होगा।
**Romanized:** (Agar bachhe bahut adhik candy khaayenge, to unhe pet mein dard hoga.)
**English answer:** If children eat too many candies, they will have a stomachache.

### 36. अगर मेरे पास पर्याप्त पैसा हो, तो मैं कुछ नए जूते खरीदूँगा।
**Romanized:** (Agar mere paas paryapt paisa ho, to main kuchh naye joote kharidunga.)
**English answer:** If I have enough money, I will buy some new shoes.

### 37. अगर मैं उसे मिलूगा, तो उसे बता दूँगा।
**Romanized:** (Agar mein use milunga, to use bata dunga.)
**English answer:** If I meet him, I’ll tell him.

### 38. अगर मैं अच्छी नौकरी करूँगा, तो मुझे बहुत सारे पैसे मिलेंगे।
**Romanized:** (Agar main achi naukri karunga, to mujhe bahut sare paise milenge.)
**English answer:** If I do a good job, I will get a lot of money.

### 39. अगर मुझे बहुत सारे पैसे मिल जाये, तो मैं एक लम्बी कार लूंगा।
**Romanized:** (Agar mujhe bahut sare paise mil jaaye, to main ek lambi car lunga.)
**English answer:** If I get a lot of money, I will buy a long car.

### 40. अगर तुम गाड़ी तेज़ चलाओ, तो हम जल्दी घर पहुँच सकते हैं।
**Romanized:** (Agar tum gaadi tez chalao, to hum jaldi ghar pahunch sakte hain.)
**English answer:** If you drive fast, we can reach home early.

### 41. अगर तुम बुलाओगे, तो मैं आ सकता हूँ।
**Romanized:** (Agar tum bulaoge to main aa sakta hoon.)
**English answer:** If you call, I can come.

### 42. अगर आप छात्रवृत्ति नहीं जीतते हैं, तो आपके पिता को बहुत दुख होगा।
**Romanized:** (Agar aap chatravriti nahi jitte hain, to aapke pita ko bahut dukh hoga.)
**English answer:** If you do not win the scholarship, your father will be very sad.

### 43. अगर बारिश हुई, तो हम सिनेमा जाएंगे।
**Romanized:** (Agar baarish hui, to hum cinema jaayenge.)
**English answer:** If it rains, we will go to the cinema.

### 44. अगर आप उसे पैसे उधार देते हैं, तो हो सकता है कि वह वापस न दे।
**Romanized:** (Agar aap use paise udhaar dete hain, to ho sakta hai ki vah wapas na de.)
**English answer:** If you lend him money, he may not give it back to you.

### 45. अगर वे ट्रेन से जाते हैं, तो यह सस्ता रहेगा।
**Romanized:** (Agar ve train se jaate hain, to yah sasta rahega.)
**English answer:** If they go by train, it will be cheaper.

### 46. अगर आप पार्टी देंगे, तो आप किस किस को आमंत्रित करेंगे?
**Romanized:** (Agar aap party denge, to aap kis kis ko aamantrit karenge?)
**English answer:** If you give a party, whom all will you invite?

### 47. यदि आप प्रतिदिन व्यायाम करें, तो आप बहुत फिट रहेंगे।
**Romanized:** (Yadi aap pratidin vyayam karein, to aap bahut fit rahenge.)
**English answer:** If you exercise daily, you will be very fit.

### 48. अगर कल बारिश नहीं हुई, तो हम पिकनिक पर जाएंगे।
**Romanized:** (Agar kal barish nahi hui, to hum picnic par jayenge.)
**English answer:** If it doesn't rain tomorrow, we will go for a picnic.

### 49. अगर मुझे उसका पता मिल गया, तो मैं उसे निमंत्रण भेजूँगा।
**Romanized:** (Agar mujhe uska pata mil gaya, to main use nimantran bhejoonga.)
**English answer:** If I find his address, I will send him an invitation.

### 50. इस गर्मियों में अगर मुझे कोई लड़की मिल गई, तो मैं उससे शादी कर लूंगा।
**Romanized:** (Is garmiyon mein agar mujhe koi ladki mil gayi, to main usse shadi kar loonga.)
**English answer:** If I find a girl this summer, I will marry her.

### 51. अगर मौसम बरसात का हो, तो हम घर पर रहेंगे।
**Romanized:** (Agar mausam barsaat ka ho, to hum ghar par rahenge.)
**English answer:** If the weather is rainy, we will stay at home.

### 52. अगर आप शरारत नहीं करोगे, तो मैं आपके लिये खिलौने लेकर आऊँगा।
**Romanized:** (Agar aap shararat nahi karoge, to mai apke liye khilone lekar aaunga.)
**English answer:** If you won't be mischievous, I'll bring you toys.

### 53. अगर आप स्कूल का काम समय पर नहीं करोगे, तो आपको डांट पड़ेगी।
**Romanized:** (Agar aap school ka kaam samay par nahi karoge to aapko daant padegi.)
**English answer:** If you don't do school work on time, you will get scolded.

### 54. अगर बारिश होगी, तो आप गीले हो जाओगे।
**Romanized:** (Agar barish hogi, to aap geele ho jaoge.)
**English answer:** If it rains, you will get wet.

### 55. अगर मैं उनसे मिलूँगा, तो उनके पैसे वापस दे दूँगा।
**Romanized:** (Agar main unse milunga, to unke paise vaapas de dunga.)
**English answer:** If I meet him, I will return his money.

### 56. अगर वो मुझे पैसे देगा, तो मैं उसको सामान दूँगा।
**Romanized:** (Agar vo mujhe paise dega, to main usko saamaan dunga.)
**English answer:** If he gives me money, I will give him the goods.

### 57. अगर आप अच्छा काम करोगे, तो आपकी सैलरी बढ़ेगी।
**Romanized:** (Agar aap acha kaam karoge, to aapki salary badhegi.)
**English answer:** If you do good work, your salary will increase.

### 58. पानी में जाओगे, तो डूब सकते हो।
**Romanized:** (Paani mein jaoge, to doob sakte ho.)
**English answer:** If you go into the water, you can drown.

### 59. अगर दुकान खुली होगी, तो सामान लेकर आऊँगा।
**Romanized:** (Agar dukan khuli hogi, to saman lekar aaunga.)
**English answer:** If the shop is open, I will bring the goods.

### 60. अगर आप बाद में खाली हैं, तो हम टहलने जा सकते हैं।
**Romanized:** (Agar aap baad mein khali hai, to hum tahalne ja sakte hain.)
**English answer:** If you're free later, we can go for a walk.

### 61. अगर उन्हें भूख लगेगी, तो मैं कुछ सैंडविच बनाऊँगी।
**Romanized:** (Agar unhen bhookh lagegi, to main kuchh sandwich banaungi.)
**English answer:** If they are hungry, I will make some sandwiches.

### 62. अगर आप शर्त हारोगे, तो मुझे एक गिफ़्ट दोगे।
**Romanized:** (Agar aap shart haroge, to mujhe ek gift doge.)
**English answer:** If you lose the bet, you will give me a gift.

### 63. अगर वह मन लगाकर पढ़ाई करेगा तो परीक्षा में अच्छा करेगा।
**Romanized:** (Agar vah man lagakar padhai karega to pareeksha mein acha karega.)
**English answer:** If he studies diligently, he will do well in the examination.

### 64. अगर हम देर से पहुँचते हैं, तो हमें टैक्सी लेनी होगी।
**Romanized:** (Agar ham der se pahunchate hain, to hamen taxi leni hogi.)
**English answer:** If we arrive late, we will have to take a taxi.

### 65. अगर उसे मदद की ज़रूरत होगी, तो वह फोन करेगा।
**Romanized:** (Agar use madad kee zaroorat hogi, to vah phone karega.)
**English answer:** If he needs help, he will call.

### 66. अगर बारिश हुई, तो मैं घर पर रहूँगा।
**Romanized:** (Agar barish hui, to main ghar par rahoonga.)
**English answer:** If it rains, I will stay at home.

### 67. अगर मैं देर से उठा, तो बस चली जाएगी।
**Romanized:** (Agar main der se utha, to bus chali jayegi.)
**English answer:** If I wake up late, the bus will leave.

### 68. अगर धूप रही, तो हम पार्क जाएंगे।
**Romanized:** (Agar dhoop rahi, to ham park jaenge.)
**English answer:** If it's sunny, we'll go to the park.

### 69. अगर मैं प्रतियोगिता जीतता हूँ, तो मैं अमीर हो जाऊँगा।
**Romanized:** (Agar main pratiyogita jeetta hoon, to main amir ho jaoonga.)
**English answer:** If I win the competition, I will become rich.

### 70. अगर मुझे आपका ईमेल मिल गया, तो मैं आपको तस्वीर भेजूंगा।
**Romanized:** (Agar mujhe aapka Email mil gaya, to main aapko tasveer bhejoonga.)
**English answer:** If I get your email, I will send you a picture.

### 71. अगर अरनवी घर आयी, तो मैं उसे परीक्षा के बरे में बता दूँगा।
**Romanized:** (Agar Arnavi ghar aayi, to main use pariksha ke baare mein bata dunga.)
**English answer:** If Arnavi comes home, I will tell her about the exam.

### 72. अगर आप रात का खाना पकाओगे, तो मैं बर्तन धो दूँगा।
**Romanized:** (Agar aap raat ka khana pakaoge, to main bartan dho doonga.)
**English answer:** If you cook dinner, I will wash the dishes.

### 73. अगर मेरे पास अच्छे कपड़े हों, तो मैं शादी में जाऊँगा।
**Romanized:** (Agar mere pass ache kapde hon, to main shaadi mein jaaunga.)
**English answer:** If I have nice clothes, I will go to the wedding.

### 74. अगर मेरे पास पैसे हुए, तो मैं उनके घर जाऊँगा।
**Romanized:** (Agar mere pass paise hua, to main unke ghar jaunga.)
**English answer:** If I have money, I will go to his house.

### 75. अगर मेरे दोस्त आयेंगे, तो मुझे बहुत खुशी होगी।
**Romanized:** (Agar mere dost aaenge, to mujhe bahut khushi hogi.)
**English answer:** If my friends come, I will be very happy.

### 76. अगर वह बहुत पैसा कमा लेती है, तो वह न्यूयॉर्क घूमने जायेगी।
**Romanized:** (Agar vah bahut paise kama leti hai, to vah New York ghoomne jayegi.)
**English answer:** If she earns a lot of money, she will go to New York to visit.

### 77. अगर कल बारिश नहीं हुई, तो हम समुद्र तट पर जाएंगे।
**Romanized:** (Agar kal baarish nahi hui, to ham samudra tat par jaenge.)
**English answer:** If it doesn't rain tomorrow, we'll go to the beach.

### 78. अगर वे जीत जाते हैं, तो भारत क्रिकेट लीग में शीर्ष पर होगा।
**Romanized:** (Agar ve jeet jaate hain to Bharat cricket league mein sheersh par hoga.)
**English answer:** If they win, India will top the cricket league.

### 79. अगर मैं काम खत्म कर लूंगा, तो तुम्हें फोन करँँचगा।
**Romanized:** (Agar main kaam khatm kar loonga, to tumhen phone karoonga.)
**English answer:** If I finish the work, I'll call you.

### 80. अगर मैं परीक्षा पास कर लेता हूँ, तो मैं एक पार्टी आयोजित करूँगा।
**Romanized:** (Agar main pariksha paas kar leta hoon, to main ek party aayojit karoonga.)
**English answer:** If I pass the exam, I will organize a party.

### 81. अगर मैं कल व्यस्त न रहा, तो मैं तुम्हारी मदद करूँगा।
**Romanized:** (Agar main kal vyast na raha, to main tumhari madad karoonga.)
**English answer:** If I'm not busy tomorrow, I'll help you.

### 82. अगर आप स्कूल नहीं जाते हैं, तो आप पूरे दिन घर पर ही रहेंगे।
**Romanized:** (Agar aap school nahi jaate hain, to aap poore din ghar par hee rahenge.)
**English answer:** If you don't go to school, you will stay at home all day.

### 83. अगर आपने चुनाव में हिस्सा लिया, तो लोग आपको चुनेंगे।
**Romanized:** (Agar aapne chunav mein hissa liya, to log aapko chunenge.)
**English answer:** If you take part in the election, people will choose you.

### 84. अगर हम समय का सही इस्तेमाल कर लें, तो हम अपना प्रोजेक्ट पूरा कर लेंगे।
**Romanized:** (Agar ham samay ka sahi istemal kar le, to hum apna project pura kar lenge.)
**English answer:** If we use the time properly, we will complete our project.

### 85. अगर वो मुझे इन्वाइट करेगा, तो मैं पार्टी में जाऊँगा।
**Romanized:** (Agar vo mujhe invite karega, to main party mein jaaunga.)
**English answer:** If he invites me, I will go to the party.

### 86. शिवम बहुत खुश होगा, अगर कोई उसे नौकरी की पेशकश करें।
**Romanized:** (Shivam bahut khush hoga, Agar koi use naukaree kee peshakash kare.)
**English answer:** Shivam will be very happy if someone offers him a job.

### 87. अगर शिक्षकों के पास समय बचे, तो उन्हें टॉपिक्स को दोहराना चाहिए।
**Romanized:** (Agar shikshakon ke paas samay bache, to unhe topics ko dohrana chahiye.)
**English answer:** If teachers have time left, they should revise the topics. / If teachers are left with time, they should revise the topics.

### 88. अगर उसने सांप देख लिया, तो वह घबरा जाएगी।
**Romanized:** (Agar usne saap dekh liya, to vah ghabra jaayegi.)
**English answer:** If she sees a snake, she will panic.

### 89. अगर कैमरा काम करे, तो मैं और तस्वीरें लूंगा।
**Romanized:** (Agar camera kaam kare, to main aur tasveere loonga.)
**English answer:** If the camera works, I'll take more pictures.

### 90. अगर मैंने अपने बेटे को बहुत सारा पैसा दिया, तो वह सब खर्च कर देगा।
**Romanized:** (Agar main ne apne bete ko bahut saara paisa diya, to vah sab kharch kar dega.)
**English answer:** If I give a lot of money to my son, he will spend it all.

### 91. अगर मैं अपनी नौकरी छोड़ दूँ तो मैं दुनिया भर में यात्रा करूँचगा।
**Romanized:** (Agar main apni naukari chhod doon, to main duniya bhar mein yatra karunga.)
**English answer:** If I quit my job, I will travel around the world.

### 92. अगर आप कहेंगे, तो मैं सबसे महंगी कार खरीदूँगा।
**Romanized:** (Agar aap kahenge, to main sabse mehngi car kharidunga.)
**English answer:** If you say, I will buy the most expensive car.

### 93. अगर मैं कल स्कूल देर से गया, तो मुझे फिर से सजा मिलेगी।
**Romanized:** (Agar mein kal school der se gaya, to mujhe fir se saja milegi.)
**English answer:** If I go to school late tomorrow, I will be punished again.

### 94. अगर आप कम खाएंगे तो आपका वजन कम होगा।
**Romanized:** (Agar aap kam khayenge to aapka vajan kam hoga.)
**English answer:** If you eat less, you will lose weight.

### 95. अगर कल मसूरी में बर्फ गिरेगी, तो हम मसूरी घूमने जायेंगे।
**Romanized:** (Agar kal mussoorie mein barf giregi, to hum mussoorie ghumne jayenge.)
**English answer:** If snow falls in Mussoorie tomorrow, we will go to Mussoorie.

### 96. अगर कल छुट्टी हुई, तो हम सब मूवी देखने चलेंगे।
**Romanized:** (Agar kal chhutti hui, to hum sab movie dekhne chalenge.)
**English answer:** If it’s a holiday tomorrow, we will all go to see a movie.

### 97. अगर वे इतने सारे कपड़े नहीं खरीदेंगे तो उनके पैसे बचेंगे।
**Romanized:** (Agar ve itne saare kapde nahi khareedenge, to unke paise bachenge.)
**English answer:** If they don't buy these many clothes they will save money.

### 98. अगर हमने यहाँ रहने का फैसला किया, तो हम एक घर खरीद लेंगे।
**Romanized:** (Agar humne yahan rahane ka faisla kiya, to hum ek ghar khareed lenge.)
**English answer:** If we decide to stay here, we will buy a house.

### 99. अगर आज बर्फबारी हुई, तो हम घर पर रहेंगे।
**Romanized:** (Agar aaj barfbaari hui, to hum ghar par rahenge.)
**English answer:** If it snows today, we will stay at home.

### 100. अगर हम यह मैच जीत जाते हैं, तो हम सेमीफाइनल के लिए क्वालीफाई कर लेंगे।
**Romanized:** (Agar ham yah match jeet jaate hain, to ham semifainal ke liye qualify kar lenge.)
**English answer:** If we win this match, we will qualify for the semi-finals.

### 101. अगर मैं राष्ट्रपति बना तो मैं सुरक्षा व्यवस्था को बदल दूँगा।
**Romanized:** (Agar main rashtrapati bana to main suraksha vyavastha ko badal dunga.)
**English answer:** If I become the president, I will change the security system.

### 102. अगर कल सचिन शतक मार दे, तो हम मैंच जीत जायेंगे।
**Romanized:** (Agar kal Sachin shatak maar de, to hum match jeet jaayenge.)
**English answer:** If Sachin scores a century tomorrow, we will win the match.

### 103. अगर पापा कल जल्दी आ गये, तो हम डिनर पर बाहर जायेंगे।
**Romanized:** (Agar papa kal jaldi aa gaye, to hum dinner par bahar jayenge.)
**English answer:** If Papa comes early tomorrow, we will go out to dinner.

### 104. अगर कल रोड़ में ज़्यादा जाम नहीं लगा, तो हम जल्दी पहुँच जायेंगे।
**Romanized:** (Agar kal road mein jada jaam nahi lga, to hum jaldi pahuch jaayenge.)
**English answer:** If there is not much traffic on the road tomorrow, we will reach early.

### 105. अगर कल मैं जल्दी नहीं उठा, तो मेरी गाड़ी छूट जायेगी।
**Romanized:** (Agar kal main jaldi nahi utha, to meri gadi choot jaayegi.)
**English answer:** If I don't get up early tomorrow, I will miss my bus.

### 106. अगर कल तेज़ धूप आएगी, तो मैं अपने सारे कपड़े धो दूँगा।
**Romanized:** (Agar kal tez dhoop aayegi, to main apne saare kapde dho doonga.)
**English answer:** If it's sunny tomorrow, I'll wash all my clothes.

### 107. अगर मैं कल का मैच जीत गया, तो मुझे बहुत से पैसे मिलेंगे।
**Romanized:** (Agar main kal ka match jeet gaya, to mujhe bahut sare paise milenge.)
**English answer:** If I win tomorrow's match, I will get a lot of money.

### 108. अगर मैं कल टॉस जीत गया, तो मैच भी जीत जाऊँगा।
**Romanized:** (Agar main kal Toss jeet gaya, to match bhi jeet jaunga.)
**English answer:** If I win the toss tomorrow, I will win the match too.

### 109. अगर धूप तेज़ होगी, तो गर्मी तेज़ हो जायेगी।
**Romanized:** (Agar dhoop tez hogi, to garmi tez ho jaayegi.)
**English answer:** If the sun is bright, the heat will be intense.

### 110. अगर लाल बटन दबाओगे, तो दरवाजा खुल जाएगा।
**Romanized:** (Agar laal button dabaoge, to darwaza khul jayega.)
**English answer:** If you press the red button, the door will open.

### 111. अगर खाना नहीं खाओगे, तो भूखे मर जाओगे।
**Romanized:** (Agar khaana nahin khaoge, to bhookhe mar jaaoge.)
**English answer:** If you do not eat food, you will die of hunger.

### 112. अगर रात को जल्दी सो जाओगे, तो सुबह जल्दी उठ जाओगे।
**Romanized:** (Agar raat ko jaldi so jaaoge, to subah jaldi uth jaaoge.)
**English answer:** If you go to sleep early at night, you will get up early in the morning.

### 113. अगर ट्रेन तेज़ दौड़ेगी, तो हम जल्दी पहुँच जायेंगे।
**Romanized:** (Agar train tez daudegi, to hum jaldi pahuch jaayenge.)
**English answer:** If the train runs faster, we will reach early.

### 114. अगर उसने और मदद माँगी, तो मैं उसे ठुकरा नहीं सकता।
**Romanized:** (Agar usne aur madad maangi, to main use thukra nahin sakta.)
**English answer:** If he asks for more help, I can't turn him down.

## Exercise 3 — Type 2

**Instruction:** Please translate the following conditional sentences (Type 2) into English.

### 1. अगर मेरे पास मेरी खुद की ज़मीन होती, तो मैं एक खूबसूरत घर बनाता।
**Romanized:** (Agar mere pass meri khud ki zameen hoti, to main ek khoobsurat ghar banata.)
**English answer:** If I had my own land, I would make a beautiful house.

### 2. अगर मेरे पास पैसा होता, तो मैं जापान घूमता।
**Romanized:** (Agar mere paas paisa hota, to main Japan ghoomta.)
**English answer:** If I had money, I would visit Japan.

### 3. अगर वह बीमार होती, तो वह मीटिंग में शामिल नहीं हो पाती।
**Romanized:** (Agar vah bimar hoti, to vah meeting mein shamil nahi ho paati.)
**English answer:** If she were ill, she could not attend the meeting.

### 4. अगर आपकी जगह मैं होता, तो मैं किसी वकील के पास जाता।
**Romanized:** (Agar aapki jagah main hota, to main kisi vakeel ke pass jata.)
**English answer:** If I were at your place, I would go to some lawyer.

### 5. अगर मैं करोड़पति होता, तो मैं गरीबों की मदद कर पाता।
**Romanized:** (Agar main crorepati hota, to main garibon ki madad kar pata.)
**English answer:** If I were a millionaire, I could help the poor.

### 6. अगर मैं इंग्लैंड की रानी से मिलता, तो उन्हें ये सब बताता।
**Romanized:** (Agar main England ki rani se milta, to unhe ye sab batata.)
**English answer:** If I had met the Queen of England, I would have told her all this.

### 7. अगर मैं एक मिलियन पाउन्ड जीत लेता, तो मैं लड़ना बंद कर देता।
**Romanized:** (Agar main ek million pound jeet leta, to main ladna band kar deta.)
**English answer:** If I had won a million pounds, I would have stopped fighting.

### 8. अगर आप छत से कूदते, तो आपका पैर टूट जाता।
**Romanized:** (Agar aap chhat se koodte, to aapka pair toot jaata.)
**English answer:** If you jumped off the roof, you would have broken your leg.

### 9. अगर मैं अध्यक्ष होता, तो मैं नए और अलग विचार पेश करता।
**Romanized:** (Agar main adhyaksh hota, to main naye aur alag vichar pesh karta.)
**English answer:** If I were the president, I would offer new and different ideas.

### 10. अगर वह बीमार नहीं होती, तो वह स्कूल जाती।
**Romanized:** (Agar vah bimar nahi hoti, to vah school jati.)
**English answer:** If she were not sick, she would go to school.

### 11. अगर तुम पूछते, तो मैं तुम्हारी मदद करता।
**Romanized:** (Agar tum poochhte, to main tumhari madad karata.)
**English answer:** If you asked, I would help you.

### 12. अगर मेरा घर जंगल में होता, तो मैं हरे-भरे इलाकों में घूमता रहता।
**Romanized:** (Agar mera ghar jungle me hota, to main hare-bhare ilakon me ghumta rahta.)
**English answer:** If my house were in the forest, I would walk in the green areas.

### 13. अगर मेरे पास कार होती, तो मैं स्कूल चला जाता।
**Romanized:** (Agar mere paas car hoti, to main school chala jaata.)
**English answer:** If I had a car, I would go to school.

### 14. अगर मैं लॉटरी जीत जाता, तो मैं आपको एक कार गिफ़्ट करता।
**Romanized:** (Agar main lottery jeet jata, to main aapko ek car gift karta.)
**English answer:** If I had won the lottery, I would gift you a car.

### 15. अगर वह अंग्रेज़ी बोलती, तो मैं समझ नहीं पाता।
**Romanized:** (Agar vah English bolti, to main samajh nahi pata.)
**English answer:** If she spoke English, I would not understand.

### 16. 46.अगर मेरे पास अपनी कार होती, तो मुझे हर दिन काम करने के लिए बस का इंतजार नहीं करना पड़ता।
**Romanized:** (Agar mere paas apanee car hotee, toh mujhe har din kaam karane ke liye bus ka intazaar nahi karna padta.)
**English answer:** If I had my own car, I wouldn't have to wait for the bus to work every day.

### 17. अगर वह धूम्रपान करना बंद कर दे, तो उसे इतनी खांसी नहीं होती।
**Romanized:** (Agar vah dhumrapan karna band kar de, to use itni khansi nahin hoti.)
**English answer:** If she stopped smoking, she would not cough so much.

### 18. अगर मेरे पास विश्वविद्यालय की डिग्री होती, तो मैं बेहतर नौकरी पाने की कोशिश करता।
**Romanized:** (Agar mere paas vishwavidyalaya ki degree hoti, to main behtar naukri paane ki koshish karta.)
**English answer:** If I had a university degree, I would try to get a better job.

### 19. अगर मुझे उसका ऐड़्स पता होता, तो मैं उसे निमंत्रण भेजता।
**Romanized:** (Agar mujhe uska address pata hota, to main use nimantran bhejta.)
**English answer:** If I knew his address, I would send him an invitation.

### 20. अगर मेरे पिताजी अधिक कमाते, तो हम अपनी छुट्टियाँ विदेश में बिताते।
**Romanized:** (Agar mere pitaji adhik kamate, to hum apni chuttiyan videsh mein bitate.)
**English answer:** If my father earned more, we would spend our holidays abroad.

### 21. अगर वह ऊंचाइयों से नहीं डरते, तो वह हवाई जहाज से यात्रा करते।
**Romanized:** (Agar vah unchaiyon se nahi darte, to vah havaaee jahaaj se yatra karte.)
**English answer:** If he were not afraid of heights, he would travel by plane.

### 22. अगर मैं लॉटरी जीतता, तो मैं करोड़पति होता।
**Romanized:** (Agar main lottery jeetta, to main crorepati hota.)
**English answer:** If I won the lottery, I would be a millionaire.

### 23. अगर मेरे पास लाखों डॉलर होते, तो मैं मतलबी नहीं होता।
**Romanized:** (Agar mere paas laakhon dollar hote, to main matlabi nahi hota.)
**English answer:** If I had millions of dollars, I would not be mean.

### 24. अगर मैं बहुत अमीर होता, तो मैं कुछ पैसे चैरिटी को देता।
**Romanized:** (Agar main bahut amir hote, to main kuch paise charity ko deta.)
**English answer:** If I were very rich, I would give some money to charity.

### 25. अगर मैं कहीं यात्रा करता, तो मैं सबसे शानदार होटलों में रहता।
**Romanized:** (Agar main kahin yatra karta, to main sabse shandar hotelo mein rahata.)
**English answer:** If I traveled somewhere, I would stay in the most luxurious hotels.

### 26. अगर मैं पहले घर पहुँचता, तो रात का खाना बना लेता।
**Romanized:** (Agar main pahle ghar pahunchta, to raat ka khana bana leta.)
**English answer:** If I reached earlier, I would cook dinner.

### 27. अगर वह मेरा दोस्त होता, तो मैं उसे अपनी जन्मदिन की पार्टी में आमंत्रित करता।
**Romanized:** (Agar vah mera dost hota, to main use apni janmdin ki party me aamantrit karta.)
**English answer:** If he were my friend, I would invite him to my birthday party.

### 28. अगर मैं सचिन से मिलता, तो मैं उनका ऑटोग्राफ माँगता।
**Romanized:** (Agar main sachin se milata, to main unka autograph maangata.)
**English answer:** If I met Sachin, I would ask for his autograph.

### 29. अगर अमन को पॉकेट मनी मिलती, तो वह मुझे डिनर पे ले जाता।
**Romanized:** (Agar Aman ko pocket money milati, to vah mujhe dinner pe le jata.)
**English answer:** If Aman got pocket money, he would take me to dinner.

### 30. अगर उनके पास पर्याप्त पैसा होता, तो वे एक नई कार खरीद लेते।
**Romanized:** (Agar unke paas paryapt paisa hota, to ve ek nai car khareed lete.)
**English answer:** If they had enough money, they would buy a new car.

### 31. अगर हम एक नई कार खरीदते, तो हमें फिर कभी देर नहीं होती।
**Romanized:** (Agar ham ek naee car khareedate, to hamein phir kabhi der nahi hoti.)
**English answer:** If we bought a new car, we were never late again.

### 32. अगर मैं एक फिल्म स्टार होता, तो मैं किसी प्रसिद्ध व्यक्ति से शादी करता।
**Romanized:** (Agar main ek film star hota, to main kisi prasiddh vyakti se shadi karata.)
**English answer:** If I were a movie star, I would marry some famous person.

### 33. अगर उन्हें गर्म मौसम पसंद होता, तो वे छुट्टी लेकर राजस्थान जाते।
**Romanized:** (Agar unhe garam mausam pasand hota, to ve chhutti lekar Rajasthan jaate.)
**English answer:** If they liked the hot weather, they would take a vacation to Rajasthan.

### 34. अगर उसे उसका नंबर पता होता, तो वह उसे कॉल करती।
**Romanized:** (Agar use uska number pata hota, to vah use call karti.)
**English answer:** If she knew his number, she would call him.

### 35. अगर हम दोस्त नहीं होते, तो मैं इस बात पर नाराज़ होता।
**Romanized:** (Agar ham dost nahin hote, to main is baat par naraz hota.)
**English answer:** If we weren't friends, I would be angry about this matter.

### 36. अगर हमारे पास समय होता तो हम खाना खाने आते।
**Romanized:** (Agar hamare paas samay hota to hum khana khaane aate.)
**English answer:** If we had time, we would come to eat the food.

### 37. अगर उसके और दोस्त होते, तो वह ज़्यादा खुश होती।
**Romanized:** (Agar uske aur dost hote, to vah zyada khush hoti.)
**English answer:** If she had more friends, she would be happier.

### 38. अगर मैं सही अंग्रेज़ी बोलता, तो मेरी नौकरी अच्छी होती।
**Romanized:** (Agar main sahi angreji bolta, to meri naukri achi hoti.)
**English answer:** If I spoke proper English, I would have a good job.

### 39. अगर हम अमेरिका में रहते, तो मैं इंग्लिश बोलता।
**Romanized:** (Agar hum America me rehte, to main English bolta.)
**English answer:** If we lived in America, I would speak English.

### 40. अगर मैं राष्ट्रपति होता, तो मैं लाल बत्ती की कार में नहीं घूमता।
**Romanized:** (Agar main rashtrapati hota, to main laal batti ki car me nahi ghumta.)
**English answer:** If I were the President, I would not drive around in a red light car.

### 41. अगर मेरे पास कार होती, तो मैं उसे रोज़ चलाता।
**Romanized:** (Agar mere paas car hoti, to main use roz chalata.)
**English answer:** If I had a car, I would drive it every day.

### 42. अगर मेरे पास पंख होते, तो मैं उड़ जाता।
**Romanized:** (Agar mere paas pankh hote, to main udd jata.)
**English answer:** If I had wings, I would fly.

### 43. अगर मेरे पास और पैसे होते, तो मैं एक नया बोर्ड खरीदता।
**Romanized:** (Agar mere paas aur paise hote, to main ek naya board kharidta.)
**English answer:** If I had more money, I would buy a new board.

### 44. अगर वह अमीर होता, तो वह एक द्वीप खरीद लेता।
**Romanized:** (Agar vah amir hota, to vah ek dweep khareed leta.)
**English answer:** If he were rich, he would buy an island.

### 45. अगर मुझे उसका नाम पता होता, तो मैं आपको बताता।
**Romanized:** (Agar mujhe uska naam pata hota, to main aapko batata.)
**English answer:** If I knew his name, I would tell you.

### 46. अगर मुझे कार चलानी आती, तो मैं खुद अपनी कार में जाता।
**Romanized:** (Agar mujhe car chalani aati, to main khud apni car mein jata.)
**English answer:** If I knew how to drive a car, I would go in my own car.

### 47. अगर मेरे पास अपना मोबाईल होता, तो मैं उसे रोज़ कॉल करता।
**Romanized:** (Agar mere pass apna mobile hota, to main use roz call karta.)
**English answer:** If I had my own mobile, I would call him every day.

### 48. अगर मैं बीमार न होता, तो पार्टी में जाता।
**Romanized:** (Agar main bimar na hota to party mein jata.)
**English answer:** If I were not ill, I would go to the party.

### 49. अगर मैं एक पौधा होता, तो मुझे बारिश अच्छी लगती।
**Romanized:** (Agar main ek paudha hota, to mujhe barish achi lagti.)
**English answer:** If I were a plant, I would love rain.

### 50. अगर मौसम अच्छा होता, तो वे फुटबॉल खेलते।
**Romanized:** (Agar mosam acha hota, to ve football khelate.)
**English answer:** If the weather were good, he would have played football.

### 51. अगर हम किसी अच्छे रेस्टोरेंट में जाते, तो बेहतर डिनर करते।
**Romanized:** (Agar ham kisi ache Restaurant mein jaate, to behatar dinner karte.)
**English answer:** If we went to a good restaurant, we would eat (have) a better dinner.

### 52. अगर बारिश न होती, तो बच्चे बाहर खेलते।
**Romanized:** (Agar baarish na hoti, to bache baahar khelte.)
**English answer:** If it did not rain, the children would play outside.

### 53. अगर मेरे पास 150 रू होते, तो मैं फॉर्म भर पाता।
**Romanized:** (Agar mere pass 150 rupee hote, to main form bhar pata.)
**English answer:** If I had Rs 150, I could fill the form. / If I had Rs 150, I would be able to fill the form.

### 54. अगर मुझे छुट्टी मिल जाती, तो मैं शादी में जा पाता।
**Romanized:** (Agar mujhe chutti mil jaati, to main shaadi mai jaa pata.)
**English answer:** If I got leave, I could go to the wedding. / If I got leave, I would be able to go to the wedding.

### 55. अगर मेरी आँखे ठीक होती, तो मैं गाड़ी चला पाता।
**Romanized:** (Agar meri aankhein theek hoti, to main gaadi chala paata.)
**English answer:** If I had good eyesight, I could drive the car. / If I had good eyesight, I would be able to drive the car.

### 56. अगर कोरोना के केस बढ़ते रहते, तो लॉकडाउन लग जाता।
**Romanized:** (Agar corona kai case badhte rahte, to lockdown lag jata.)
**English answer:** If the cases of corona kept increasing, then the lockdown would be imposed.

### 57. अगर मैंने बिजली का काम सीखा होता, तो मैं लाइट की समस्या ठीक कर पाता।
**Romanized:** (Agar maine bijli kaa kaam seekha hota, to main light ki samasya theek kar paata.)
**English answer:** If I learned electrical work, I could fix the problem of light.

### 58. अगर मेरे पास भी एटीएम होता, तो मैं भी पैसे निकाल पाता।
**Romanized:** (Agar mere paas bhi ATM hota, to main bhi paise nikal paata.)
**English answer:** If I also had an ATM, I could withdraw money too.

### 59. अगर मेरे घर पर टी.वी होता, तो मैं मूवी देख पाता।
**Romanized:** (Agar mere ghar par TV hota, to main movie dekh paata.)
**English answer:** If I had a TV at home, I would be able to watch movies.

### 60. अगर मेरे पास बाइक होती, तो मैं उसे साथ ला पाता।
**Romanized:** (Agar mere pass bike hoti, to mai use saath laa paata.)
**English answer:** If I had a bike, I could bring him along.

### 61. अगर मेरे पास फोन होता, तो मैं आपको उसका नंबर बता पाता।
**Romanized:** (Agar mere pass phone hota, to main aapko uska number bata pataa.)
**English answer:** If I had a phone, I could tell you his number.

### 62. अगर बस समय पर पहुँच जाती, तो मैं जल्दी पहुँचता।
**Romanized:** (Agar bus samay par pahunch jaati, to main jaldi pahunchta.)
**English answer:** If the bus reached on time, I would reach early.

### 63. अगर हमारे पास कार होती, तो हम उसमें घूमने जाते।
**Romanized:** (Agar hamare paas car hoti, to hum usme ghoomne jaate.)
**English answer:** If we had a car, we would go for a drive in it.

### 64. अगर हमारे पास टिकट होते, तो हम मूवी जा पाते।
**Romanized:** (Agar hamare paas ticket hote, to hum movie ja paate.)
**English answer:** If we had tickets, we could go to the movie.

### 65. अगर आप बिजनेस करते, आपके पास बहुत सारे पैसे होते।
**Romanized:** (Agar aap business karte, to aapke paas bahut saare paise hote.)
**English answer:** If you did business, you would have a lot of money.

## Exercise 4 — Type 3

**Instruction:** Please translate the following conditional sentences (Type 3) into English.

### 1. अगर वे उस दिन 40 मिनट और इंतजार करते, तो अनिल कपूर से मिल चुके होते।
**Romanized:** (Agar ve us din 10 minute aur intazaar karate, to Anil Kapoor se mil chuke hote.)
**English answer:** If they had waited ten more minutes that day, they would have met Anil Kapoor. / Had they waited ten more minutes that day, they would have met Anil Kapoor.

### 2. अगर एक-दो दिन बारिश और हुई होती, तो मसूरी में बर्फ पड़ चुकी होती।
**Romanized:** (Agar ek-do din baarish aur hui hoti, to mussoorie main barf pad chukee hoti.)
**English answer:** If it had rained more for a day or two, it would have snowed in Mussoorie. / Had it rained more for a day or two, it would have snowed in Mussoorie.

### 3. अगर तुमने समय पे मेरे पैसे लौटा दिये होते, तो मैं उसका उधार उतार चुका होता।
**Romanized:** (Agar tumne samay pe mere paise lauta diye hote, to main uska udhaar utaar chukka hota.)
**English answer:** If you had returned my money on time, I would have paid off his debt. / Had you returned my money on time, I would have paid off his debt.

### 4. अगर उस दिन आपकी जगह मैं होता, तो मैं ये काम कर चुका होता।
**Romanized:** (Agar us din aapki jagah main hota, to main ye kaam kar chuka hota.)
**English answer:** If I had been at your place that day, I would have done this work.

### 5. अगर मुझे हाथ में चोट नहीं लगी होती, तो मैंने कॉम्पिटिशन में भाग ले लिया होता।
**Romanized:** (Agar mujhe hath me chot nahi lagi hoti, to maine competition me bhaag le liya hota.)
**English answer:** If I had not suffered a hand injury, I would have participated in the competition.

### 6. अगर मुझे हाथ में चोट नहीं लगी होती, तो मैं कॉम्पिटिशन में भाग ले सकता था।
**Romanized:** (Agar mujhe hath me chot nahi lagi hoti, to main competition me bhaag le sakta tha.)
**English answer:** If I had not suffered a hand injury, I could have participated in the competition.

### 7. अगर पेपर थोड़ा और आसान आता, तो मेरे नम्बर अच्छे आ गये होते।
**Romanized:** (Agar paper thoda or aasan aata, to mere number achchhe aa gaye hote.)
**English answer:** If the paper had been a little easier, I would have scored better.

### 8. अगर मेरे पास थोड़ा खाली समय होता, तो मैं अपने दोस्तों से मिल चुका होता।
**Romanized:** (Agar mere paas thoda khali samay hota, to main apne doston se mil chuka hota.)
**English answer:** If I had a little free time, I would have met my friends.

### 9. अगर मैं होता, तो नौकरी छोड़ने से पहले ही बॉस से बात कर चुका होता।
**Romanized:** (Agar main hota, to naukari chhodane se pahle hi boss se baat kar chuka hota.)
**English answer:** If it had been me, I’d have already talked to the boss before leaving the job.

### 10. अगर मैंने पेपर निकाल दिया होता, तो मैं भी एक सरकारी ऑफिसर बन चुका होता।
**Romanized:** (Agar mene paper nikal diya hota, to main bhi ek sarkari officer ban chuka hota.)
**English answer:** Had I cleared the paper, I would have become a government officer too.

### 11. अगर आपने अंग्रेज़ी में बोला होता, तो वो समझ चुकी होती।
**Romanized:** (Agar aapne angrezee me bola hota, to vo samajh chuki hoti.)
**English answer:** If you had spoken in English, she would have understood.

### 12. अगर उन्होंने मेरी बात मानी होती, तो हम पहले ही घर आ गये होते।
**Romanized:** (Agar unhonne meri baat maani hoti, to hum pahle hee ghar aa gaye hote.)
**English answer:** If he had listened to me, we would have already come home.

### 13. अगर मेरे पास आपका पता होता, तो मैं अब तक आपको इन्विटेशन भेज चुका होता।
**Romanized:** (Agar mere pass apka pata hota, to mein ab tak apko invitation bhej chuka hota.)
**English answer:** If I had your address, I would have sent you the invitation by now. / Had I had your address, I would have sent you the invitation by now.

### 14. अगर बारिश शुरू नहीं हुई होती, तो हम दिल्ली के लिए निकल गये होते।
**Romanized:** (Agar baarish shuru nahi hui hoti, to hum Delhi ke liye nikal gaye hote.)
**English answer:** Had it not started raining, we would have left for Delhi.

### 15. अगर मेरे पास थोड़ा समय और होता, तो पूरा पेपर करके आ गया होता।
**Romanized:** (Agar mere pass thoda samay or hota, to poora paper karke aa gaya hota.)
**English answer:** If I had a little more time, I would have done the entire paper./ Had I had a little more time, I would have done the entire paper.

### 16. अगर चालक तेज़ गति से गाड़ी नहीं चला रहा होता तो हादसा नहीं होता।
**Romanized:** (Agar chaalak tez gati se gadi nahi chala raha hota to haadasa nahin hota.)
**English answer:** Had the driver not been driving at high speed, the accident would not have happened.

### 17. अगर आपने कड़ी मेहनत की होती, तो आप परीक्षा में उत्तीर्ण होते।
**Romanized:** (Agar aapne kadi mehanat kee hoti, to aap pareeksha mein utteern hote.)
**English answer:** If you had worked hard, you would have passed the exam.

### 18. अगर पिछले हफ्ते मौसम ठीक रहता, तो हम घूम के भी आ चुके होते।
**Romanized:** (Agar pichhle hafte mausam thik rahta, to hum ghoom ke bhi aa chuke hote.)
**English answer:** If the weather had been fine last week, we would have even come from the visit.

### 19. अगर आप लेट नहीं होते, तो आप छह बजे की ट्रेन पकड़ चुके होते।
**Romanized:** (Agar aap late nahi hote, to aap 6 baje ki train pakad chuke hote.)
**English answer:** If you had not been late, you would have caught the 6 o'clock train.

### 20. अगर पुलिस पहले आयी होती, तो चोर को गिरफ्तार कर सकती थी।
**Romanized:** (Agar Police pahle aayi hoti, to chor ko giraphtaar kar sakti thi.)
**English answer:** If the police had come earlier, they could have arrested the thief.

### 21. वे स्कूल के लिए बस से गए होते, तो समय पर पहुँच गये होते।
**Romanized:** (Ve school ke liye bus se gaye hote, to samay par pahunch gaye hote.)
**English answer:** Had he gone to school by bus, he would have reached on time.

### 22. अगर उसने ठीक से समझाया होता, तो मैं अब तक ये काम निपटा चुका होता।
**Romanized:** (Agar usne theek se samajhaaya hota, to main ab tak ye kaam nipta chuka hota.)
**English answer:** If he had explained properly, I would have completed this task by now.

### 23. अगर हमने शहर के नक्शे का इस्तेमाल किया होता, तो हम नहीं खोये होते।
**Romanized:** (Agar hamne shahar ke nakshe ka istemaal kiya hota, to ham nahi khoye hote.)
**English answer:** If we had used the city map, we would not have been lost.

### 24. अगर पुलिस ने मुझे नहीं रोका होता, तो मैं आज समय पर पहुँच गया होता।
**Romanized:** (Agar police ne mujhe nahi roka hota, to main aaj samay par pahunch gaya hota.)
**English answer:** Had the police not stopped me, I would have reached on time today.

### 25. अगर मैं उन दिनों अमीर बन गया होता, तो मैं बीएमडब्लू ले सकता था।
**Romanized:** (Agar main un dino ameer ban gaya hota, to main BMW le sakta tha.)
**English answer:** If I had become rich in those days, I could have bought (had) a BMW.

### 26. अगर उन दिनों मेरी तबियत ठीक होती, तो मैं गेम जीत सकती थी।
**Romanized:** (Agar un dino meri tabiyat thik hoti, to main game jeet sakti thi.)
**English answer:** Had I been in good health in those days, I could have won the game.

### 27. अगर कमल उस दिन टाइम पर आ गया होता, तो आज कैनेडा जा चुका होता।
**Romanized:** (Agar Kamal us din time par aa gaya hota, to aaj Canada jaa chukaa hota.)
**English answer:** If Kamal had arrived on time that day, he would have gone to Canada today.

### 28. अगर मैं थोड़ा पहले आया होता, तो उससे ज़रूर मिल सकता था।
**Romanized:** (Agar main thoda pehle aaya hota, to usse zaroor mil sakta tha.)
**English answer:** If I had come a little earlier, I would have definitely met him.

### 29. अगर विराट अभी तक खेल रहा होता, तो उसका शतक हो चुका होता।
**Romanized:** (Agar Virat abhi tak khel raha hota, to uska shatak ho chukaa hota.)
**English answer:** If Virat had yet been playing, he would have scored a century.

### 30. अगर तेज़ बारिश नहीं हुई होती, तो मैं ऑफिस पहुँच गया होता।
**Romanized:** (Agar tez baarish nahi hui hoti, to main office pahunch gaya hota.)
**English answer:** Had it not been heavy rainfall, I would have reached the office.

### 31. अगर तुमने पहले कहा होता, तो मैं तुम्हारी मदद कर सकता था।
**Romanized:** (Agar tumne pahle kaha hota, to main tumhaari madad kar sakta tha.)
**English answer:** If you had said earlier, I could have helped you.

### 32. अगर मैंने दो साल पहले एडमिशन कराया होता, तो मेरा एम. कॉम हो चुका होता।
**Romanized:** (Agar maine do saal pehle admission karaya hota, to mera M.com ho chukaa hota.)
**English answer:** Had I taken admission two years back, I would have completed my M.Com.

### 33. अगर पानी गरम हो गया होता, तो मैं अब तक नहा चुका होता।
**Romanized:** (Agar paani garam ho gaya hota, to main ab tak naha chuka hota.)
**English answer:** Had the water been hot, I would have taken a bath by now.

### 34. अगर पानी गुनगुना हो गया होता, तो मैं अब तक नहा चुका होता।
**Romanized:** (Agar paani gunguna ho gaya hota, to main ab tak naha chuka hota.)
**English answer:** Had the water been lukewarm, I would have taken a bath by now.

### 35. अगर उसने रिश्ते के लिए हाँ कर दिया होता, तो उसकी शादी हो चुकी होती।
**Romanized:** (Agar usne rishte kai liye haan kar diya hota, to uski shaadi ho chukee hoti.)
**English answer:** If he had said yes to the marriage proposal, he would have been (got) married.

### 36. अगर मैंने काली शर्ट नहीं ली होती, तो मैं फिर ये वाली शर्ट ले सकता था।
**Romanized:** (Agar maine kali shirt nahi lee hoti, to main fir ye wali shirt le sakta tha.)
**English answer:** If I had not bought the black shirt, then I could have bought this shirt.

### 37. अगर मेरी सैलरी मिल गयी होती, तो मैं आईफोन ले चुका होता।
**Romanized:** (Agar meri salary mil gayi hotee, to main Iphone le chukaa hota.)
**English answer:** If I had got my salary, I would have bought the iPhone.

### 38. अगर गैस जल्दी खत्म हो गयी होती, तो मैं बाहर से खाना मंगा सकता था।
**Romanized:** (Agar gas jaldi khatam ho gayi hoti, to main bahar se khaana manga sakta tha.)
**English answer:** If the gas had run out sooner, I could have ordered food from outside.

### 39. अगर उसे नौकरी नहीं मिली होती, तो वो गाँव जा चुका होता।
**Romanized:** (Agar use naukri nahi mili hoti, to vo gaon jaa chukaa hota.)
**English answer:** Had he not got a job, he would have gone to the village.

### 40. अगर तुम्हारा मिस कॉल मैंने नहीं देखा होता, तो मैं अकेले निकल चुका होता।
**Romanized:** (Agar tumhara miss call maine nahin dekha hota, to main akele nikal chuka hota.)
**English answer:** Had I not seen your missed call, I would have left alone.

### 41. अगर मम्मी ने दाल बनाई होती, तो मैं चावल बना सकता था।
**Romanized:** (Agar mummy ne daal banaai hoti, to main chawal bana sakta tha.)
**English answer:** If mom had cooked daal (pulse), I could have cooked rice.

### 42. अगर मैंने उस दिन क्लास ली होती, तो मैं इसे सॉल्व कर चुका होता।
**Romanized:** (Agar maine us din class lee hoti, to main ise solve kar chuka hota.)
**English answer:** If I had taken the class that day, I would have solved it.

### 43. अगर मैंने पढ़ाई पर ध्यान दिया होता, तो मैं कुछ बन चुका होता।
**Romanized:** (Agar maine padaai par dhyaan diyaa hota, to main kuch ban chukaa hota.)
**English answer:** If I had focused on my studies, I would have become something.

### 44. अगर उस दिन आपने मुझे पासवर्ड दिया होता, तो मैं पेमेंट कर चुका होता।
**Romanized:** (Agar us din aapne mujhe password diya hota, to main payment kar chuka hota.)
**English answer:** If you had given me the password that day, I would have made the payment.

### 45. अगर मैंने इतनी विडियोज़ देखी होती, तो मेरा नेट खत्म हो चुका होता।
**Romanized:** (Agar maine itni videos dekhi hoti, to mera net khatam ho chukaa hota.)
**English answer:** If I had seen so many videos, my net would have been exhausted.

### 46. अगर सच में घर में चोरी हुई होती, तो मैं लुट चुका होता।
**Romanized:** (Agar sach mai ghar mai chori hui hoti, to mai lut chukaa hota.)
**English answer:** If there had really been a burglary in the house, I would have been robbed.

### 47. अगर मुझे वहाँ नहीं जाना होता, तो मैं अब तक सो चुका होता।
**Romanized:** (Agar mujhe vahan nahi jaana hota, to main ab tak so chukaa hota.)
**English answer:** If I had not to go there, I would have slept by now.

### 48. अगर यह खबर सच होती, तो न्यूज़पेपर में छप चुकी होती।
**Romanized:** (Agar yah khabar sach hotee, to newspaper main chup chukee hoti.)
**English answer:** Had this news been true, it would have been published in the newspaper.

### 49. अगर मेरा नेट चल रहा होता, तो मैं फाइल भेज चुका होता।
**Romanized:** (Agar mera net chal raha hota, to main file bhej chukaa hota.)
**English answer:** If my net was up and running, I would have sent the file.

### 50. अगर मेरे और उनके बीच अच्छी डील होती, तो मैं वो घर खरीद चुका होता।
**Romanized:** (Agar mere or unke beech achi deal hoti, to main vo ghar khareed chukaa hota.)
**English answer:** If there had been a good deal between me and him, I would have bought that house.

### 51. अगर भारत पाकिस्तान को हरा देता, तो भारत सेमीफाइनल में पहुँच सकता था।
**Romanized:** (Agar Bharat Pakistan ko hara detaa, to Bharat semifinal main pahunch sakta thaa.)
**English answer:** If India had defeated Pakistan, India could have reached the semi-finals.

### 52. अगर दुकान बंद ना हुई होती, तो मैं मिठाई ले आया होता।
**Romanized:** (Agar dukaan band na hui hoti, to main mithaai le aaya hota.)
**English answer:** Had the shop not been closed, I would have brought sweets.

### 53. अगर मैंने जिम जाना बंद कर दिया होता, तो मेरा वजन 00 किलो पार हो चुका होता।
**Romanized:** (Agar maine gym jaana band kar diya hota, to mera vajan 100 kilo paar ho chukaa hota.)
**English answer:** If I had stopped going to the gym, I would have crossed 100 kg.

### 54. अगर राज ने मेरी बात ध्यान से सुनी होती, तो वो काम बिना गलती के कर चुका होता।
**Romanized:** (Agar Raj ne meri baat dhyan se suni hoti, to vo kaam bina galti ke kar paata.)
**English answer:** If Raj had listened to me carefully, he would have done that work without any mistake.

### 55. अगर तुमने तीन दिन पहले कहा होता, तो मैं पैसो का इन्तजाम कर सकता था।
**Romanized:** (Agar tumne teen din pehle kaha hota, to main paiso kaa intzaam kar sakta tha.)
**English answer:** If you had said three days earlier, I could have arranged the money.

### 56. अगर वो मोहन से मिल चुका होता, तो उसे सारी बात पता चल चुकी होती।
**Romanized:** (Agar vo mohan se mil chuka hota, to use saari baat pata chal chukee hoti.)
**English answer:** Had he met Mohan, he would have come to know everything.

### 57. अगर उस दिन मेरा मूड होता, तो मैं पार्टी में जा सकता था।
**Romanized:** (Agar us din mera mood hota, to main party main jaa sakta tha.)
**English answer:** If I had the mood that day, I could have gone to the party.

### 58. अगर हम सब लेट नहीं हुए होते, तो अब तक पूजा हो चुकी होती।
**Romanized:** (Agar hum sab late nahi hue hote, to ab tak Pooja ho chukee hoti.)
**English answer:** If all of us had not been late, the worship would have been done by now.

### 59. अगर मेरे पास टाइम होता, तो मैं तुमसे मिलने आ सकता था।
**Romanized:** (Agar mere paas time hota, to main tumse milne aa sakta tha.)
**English answer:** If I had time, I could have come to meet (see) you. / Had I had time, I could have come to meet (see) you.

### 60. अगर उस दिन मेरे पास पैन होता, तो मैं साइन कर सकता था।
**Romanized:** (Agar us din mere pass pen hota to, main sign kar sakta tha.)
**English answer:** If I had a pen that day, I could have signed. / Had I had a pen that day, I could have signed.

### 61. अगर तुमने इन दोस्तों का साथ छोड़ा होता, तो तुम लाइफ में कुछ कर चुके होते।
**Romanized:** (Agar tumne in dosto ka sath choda hota, to tum life main kuch kar chuke hote.)
**English answer:** If you had left these friends, you would have done something in life.

### 62. अगर आप दिल्ली चले जाते, तो आपकी नौकरी ज़रूर लग गयी होती।
**Romanized:** (Agar aap Delhi chale jaate, to aapki naukari zaroor lag gayi hoti.)
**English answer:** If you had gone to Delhi, you would have got a job.

### 63. अगर भारत टॉस जीतता, तो बैटिंग कर रहा होता।
**Romanized:** (Agar bharat toss jeetta, to batting kar raha hota.)
**English answer:** Had India won the toss, it would have been batting.

### 64. अगर ये दवाई एक्सपायर नहीं हुई होती, तो मैं इसे खा सकता था।
**Romanized:** (Agar ye dawaai expire nahi hui hoti, to main ise kha sakta tha.)
**English answer:** If this medicine had not (been) expired, I could have consumed it.

### 65. अगर वो चोर होता, तो कब का पकड़ा गया होता।
**Romanized:** (Agar vah chor hota, to kab ka pakda gaya hota.)
**English answer:** If he had been a thief, when would he have been caught?

### 66. अगर उस वक्त बाजार खुला होता, तो मैं घर का सामान ला सकता था।
**Romanized:** (Agar us waqt bazaar khula hota, to main ghar kaa samaan laa sakta tha.)
**English answer:** Had the market been open at that time, I could have brought household items.

### 67. अगर उस वक्त लाइट नहीं गयी होती, तो मैं टी.वी देख चुका होता।
**Romanized:** (Agar us waqt light nahi gayi hoti, to main T.V dekh chuka hota.)
**English answer:** If the light (power) had not gone out at that time, I would have watched TV.

### 68. अगर उस वक्त तुम मैसेज कर देते, तो मैं फोटो भेज सकता था।
**Romanized:** (Agar us waqt tum message kar dete, to main photo bhej sakta tha.)
**English answer:** If you had messaged at that time, I could have sent the photo.

### 69. अगर उस वक्त पापा भी साथ आये होते, तो आप उनसे भी मिल पाते।
**Romanized:** (Agar us waqt papa bhi saath aaye hote, to aap unse bhi mil paate.)
**English answer:** If Papa had also come with him at that time, you would have been able to meet him too. / If Papa had also come with him at that time, you could have met him too.

### 70. अगर उस वक्त दीपक ने कहा होता, तो मैं एक बार सोच सकता था।
**Romanized:** (Agar us waqt Deepak ne kaha hota, to main ek baar soch sakta tha.)
**English answer:** If Deepak had said at that time, I could have thought once.

### 71. अगर उस वक्त लोग बीच में नहीं आते, तो यह पेड़ कट चुके होते।
**Romanized:** (Agar us waqt log beech mai nahi aate, to yah ped kat chuke hote.)
**English answer:** If people had not intervened at that time, these trees would have been cut.

### 72. अगर उस वक्त पैसों की कमी नहीं होती, तो मैं कार ले चुका होता।
**Romanized:** (Agar us waqt paiso kee kami nahi hoti, to main car le chukaa hota.)
**English answer:** If there had been no shortage of money at that time, I’d have bought the car.

### 73. अगर उस दिन मम्मी ने हाँ कहा होता, तो मैं खेलने जा सकता था।
**Romanized:** (Agar us din mummy ne haan kaha hota, to main khelne jaa sakta tha.)
**English answer:** If mom had said yes that day, I could have gone to play.

### 74. अगर उस दिन मैं दस मिनट लेट जाता, तो बस निकल चुकी होती।
**Romanized:** (Agar us din main dus minute late jaata, to bus nikal chukee hoti.)
**English answer:** If I had lied for ten minutes that day, the bus would have left.

### 75. अगर मैं उस दिन रात को जल्दी सोया होता, तो सुबह जल्दी उठ पाता।
**Romanized:** (Agar main us din raat ko jaldi soya hota, to subah jaldi uth paata.)
**English answer:** If I had slept early that day, I would have gotten up early in the morning.

### 76. अगर मेरे पास पर्याप्त पैसा होता, तो मैं एक बड़ा घर खरीद चुका होता।
**Romanized:** (Agar mere paas paryapt paisa hota, to main ek bada ghar khareed chuka hota.)
**English answer:** If I had enough money, I would have bought a bigger house.

### 77. अगर वो हमेशा लेट नहीं आयी होती, तो आज उसे प्रमोट कर दिया गया होता।
**Romanized:** (Agar vo hamesha late nahi aayi hoti, to aaj use promote kar diya gaya hota.)
**English answer:** If she hadn’t always been late, she would have been promoted today.

### 78. अगर मैंने अपना होमवर्क पूरा नहीं किया होता, तो मैं अपने शिक्षक को नहीं बताता।
**Romanized:** (Agar maine apna homework pura nahi kiya hota, to main apne shikshak ko nahi batata.)
**English answer:** If I hadn't finished my homework, I wouldn't have told my teacher.

### 79. अगर वह पहले जागे होते, तो बस को मिस नहीं किया होता।
**Romanized:** (Agar vah pahale jaage hote, to bas ko mis nahin kiya hota.)
**English answer:** Had he been awake earlier, he would not have missed the bus.

### 80. अगर आपने ताजी हरी सब्जी खरीदी होती, तो आपका सलाद और अच्छा बना होता।
**Romanized:** (Agar aapne taji hari sabji kharedi hoti, to aapka salaad aur achchha bana hota.)
**English answer:** If you had bought fresh green vegetables, your salad would’ve tasted better.

## Miscellaneous Exercise

**Instruction:** Please translate the following conditional sentences into English.

### 1. अगर मैं आया/ आऊँगा, तो आपसे ज़रूर मिलूंगा |
**Romanized:** (Agar main aaya/aaunga, to aapse zaroor milunga.)
**English answer:** If I come, I will surely meet you.

### 2. अगर वो आया/ आएगा, तो आपसे ज़रूर मिलेगा।
**Romanized:** (Agar wo aaya/aayega, to aap se zaroor milega.)
**English answer:** If he comes, he will surely meet you.

### 3. अगर मैं आता, तो आप से मिलता।
**Romanized:** (Agar main aata to aap se milta.)
**English answer:** If I came, I would meet you.

### 4. अगर वो जाता, तो मैं क्यों आता?
**Romanized:** (Agar vo jata, to mai kyu aata?)
**English answer:** If he went, why would I come?

### 5. अगर तुम मुझे कॉल करते, तब तुम्हें मेरी परेशानियों के बारे में पता लगता।
**Romanized:** (Agar tum mujhe call karte tab tumhe meri pareshaniyon ke bare mai pata lgta.)
**English answer:** If you called me, you would get to know my problems.

### 6. अगर उसके पास कार होती, वो तुम्हें घर ज़रूर छोड़ता।
**Romanized:** (Agar uske paas car hoti, wo tumhe ghar zarur chhodta.)
**English answer:** If he had a car, he would definitely drop you home.

### 7. राहुल के पास अगर पैसे होते, वो मदद करता।
**Romanized:** (Rahul ke paas agar paise hote, wo madad karta.)
**English answer:** If Rahul had money, he would help.

### 8. अगर राहुल के पास पैसे होते, तो वह मदद क्यों नहीं करता?
**Romanized:** (Agar Rahul ke paas paise hote to wo madad kyun nahi karta?)
**English answer:** If Rahul had money, why would he not help?

### 9. अगर राहुल के पास पैसे नहीं होते, वो मदद कैसे करता?
**Romanized:** (Agar Rahul ke paas paise nahi hote wo madad kaise karta?)
**English answer:** If Rahul had no money, how would he help?

### 10. अगर मेरे पास कार होती, मैं तुम्हारे घर आ सकता था।
**Romanized:** (Agar mere paas car hoti, Mai tumhare ghar aa sakta tha.)
**English answer:** If I had a car, I could come your home.

### 11. अगर मेरे पास कार होती, मैं तुम्हारे घर आ चुका होता।
**Romanized:** (Agar mere pas car hoti mai tumhare ghar aa chuka Hota.)
**English answer:** If I had a car, I would have come your home.

### 12. अगर मैं प्रधानमंत्री होती, बात कुछ और होती।
**Romanized:** (Agar mai Pradhan Mantri hoti baat kuch aur hoti.)
**English answer:** If I were the PM, things would be different.

### 13. अगर मैंने देख लिया होता, तो उसे डांट चुका होता।
**Romanized:** (Agar maine dekh liya hota, To use daant chuka Hota.)
**English answer:** If I had seen, I would have scolded him. / Had I seen, I would have scolded him.

### 14. अगर अयांश खेलेगा, तो ही मैं खेलूँगा।
**Romanized:** (Agar ayansh khelega to hi mai khelunga.)
**English answer:** If Ayansh plays, then only I'll play.

### 15. अगर सब आयेंगे, तभी मैं आऊँगा।
**Romanized:** (Agar sab aayenge tabhi mai aaunga.)
**English answer:** If all come, then only I will.

### 16. अगर तुम नहीं आओगे, मैं भी नहीं आऊँगा।
**Romanized:** (Agar tum nahi aaoge mai bhi nahi aaunga.)
**English answer:** If you don't come, I will not come either.

### 17. अगर मैं गिटार बजाता, तो लोग मुझे सुनते।
**Romanized:** (Agar mai guitar bajata to log mujhe sunte.)
**English answer:** If I played guitar, people would listen to me.

### 18. अगर मैं वहाँ गया होता, तो उससे मिल चुका होता।
**Romanized:** (Agar main waha gaya hota, To usse mil chuka hota.)
**English answer:** If I had gone there, I would have met him. / Had I gone there, I would have met him.

### 19. अगर मैंने पढ़ा होता, तो मैं डॉक्टर बन गया/चुका होता।
**Romanized:** (Agar Maine padha hota, to mai doctor ban gaya/chuka Hota.)
**English answer:** If I had studied, I would have become a doctor. / Had I studied, I would have become a doctor.

### 20. अगर मैं प्रधानमंत्री होता, तो तुम्हें अपनी काबिलियत दिखा चुका होता।
**Romanized:** (Agar mai Pradhan Mantri hota to tumhe apni kabiliyat dikha chuka hota.)
**English answer:** If I had been the PM, I would have shown you my ability. / Had I been the PM, I would have shown you my ability.

### 21. अगर मैं वहाँ गया होता, उससे बात कर चुका होता।
**Romanized:** (Agar Mai waha gaya hota usse baat kar chuka Hota.)
**English answer:** If I had gone there, I would have talked to him. / Had I gone there, I would have talked to him.

### 22. अगर हमें पहले से पता हो, तो हम ऐसा क्यों करेंगे?
**Romanized:** (Agar hame pehle se pata ho To hum aisa kyun karenge?)
**English answer:** If we already know, why will we do so?

### 23. अगर हमें पहले से पता होता, तो हम ऐसा क्यों करते?
**Romanized:** (Agar hame pehle se pata hota to hum Aisa kyo karte?)
**English answer:** If we already knew, why would we do so?

### 24. अगर आपने मुझसे ना कहा होता, तो मैं घर से निकल चुका होता।
**Romanized:** (Agar aapne mujhse na kaha hota To mai ghar se nikal chuka hota.)
**English answer:** If you had not told me, I would have left from home. / Had you not told me, I would have left from home.

### 25. अगर आपका दिल टूटा ना होता तो शायद आपकी सोच भी ना बदली होती।
**Romanized:** (Agar aapka dil tuta na hota to shayad aap ki soch bhi na badli hoti.)
**English answer:** If your Heart had not been broken, your thinking would not have been changed. / Had your Heart not been broken; your thinking would not have been changed.

### 26. अगर आप सच बोलते हैं, तो हट कोई आपकी सराहना करता है।
**Romanized:** (Agar aap sach bolate hain, to har koi aapki saraahana karata hai.)
**English answer:** If you speak the truth, everyone appreciates you.

### 27. यदि हम 100 डिग्री से ऊपर पानी गर्म करते हैं, तो यह उबलता है।
**Romanized:** (Yadi ham 100 digree se oopar paanee garm karate hain, to yah ubalata hai.)
**English answer:** If we heat water above 100 degrees, it boils.

### 28. यदि आप हर रोज़ 2 घंटे काम करते हैं, तो आप थक जाते हैं।
**Romanized:** (yadi aap har roz 12 ghante kaam karate hain, to aap thak jaate hain.)
**English answer:** If you work for 12 hrs every day, you get tired.

### 29. अगर आज बारिश हुई, तो वह निश्चित रूप से बैठक को रद्द कर देगा।
**Romanized:** (agar aaj baarish hui, to vah nishchit roop se baithak ko radd kar dega.)
**English answer:** If it rains today, he will surely cancel the meeting.

### 30. यदि मैं ऑस्ट्रेलिया में रहता, तो मैं इस्कॉन मंदिर जाता।
**Romanized:** (yadi main ostreliya mein rahata, to main iskcon mandir jaata.)
**English answer:** If I lived in Australia, I would visit the Iskcon temple.

### 31. अगर उसने अच्छे से पढ़ाई की होती, तो वो डॉक्टर बन गया/चुका होता।
**Romanized:** (Agar usne achchhe se padhai ki hoti, to vo doctor ban gaya/chuka hota.)
**English answer:** If he had studied well, he would have become a doctor.

### 32. अगर वह मुझे पहले ही बता देती तो मैं उसकी मदद कर
**Romanized:** (pata)
**English answer:** If she had informed me earlier, I could have helped her.

### 33. अगर वह 947 में पीएम होते तो उन्होंने ये नहीं किया होता।
**Romanized:** (Agar vah 1947 mein PM hote to unhone ye nahi kiya hota.)
**English answer:** If he had been the PM in 1947, he wouldn't have done this.

### 34. अगर मैं मैनेजर होता, तो मैं इस बैठक में नहीं जाता।
**Romanized:** (Agar main manager hota, to main is baithak mein nahin jaata.)
**English answer:** If I were the manager, I would not go to this meeting.

### 35. अगर उसके पास इतना पैसा होता तो वो दिखावा नहीं करता।
**Romanized:** (Agar uske paas itna paisa hota to vo dikhaava nahi karta.)
**English answer:** If he had this much money, he wouldn't show off.

### 36. अगर मुझे ऑफिस पहुँचने में देर हो जाती है, तो मेरे बॉस मुझे सजा देते हैं।
**Romanized:** (agar mujhe office pahunchane me der ho jati hai, to mere boss mujhe saja dete hain.)
**English answer:** If I am late to reach the office, my boss punishes me.

### 37. यदि आपके पास अच्छी नौकरी हो, तो आप जीवन में सुरक्षित होते हैं।
**Romanized:** (yadi aapake paas achchhee naukaree ho, to aap jeevan mein surakshit hote hain.)
**English answer:** If you have a good job, you are secure in life.

### 38. यदि आप कठिन अध्ययन करते हैं, तो आप परीक्षा पास कर लेंगे।
**Romanized:** (yadi aap kathin adhyayan karate hain, to aap pareeksha paas kar lenge.)
**English answer:** If you study hard, you will pass the exam.

### 39. अगर मैं आपकी पार्टी में नहीं आऊँ, तो शायद वो आपका समर्थन न करे।
**Romanized:** (Agar main aapaki party mein nahin aaun, to shayad vo aapaka samarthan na kare.)
**English answer:** If I don't come to your party, he might not support you.

### 40. अगर मैं 2 करोड़ की लॉटरी जीत जाता, तो मैं मर्सिडीज 5560 खरीद पाता।
**Romanized:** (Agar main 2 crore kee lottery jeet jaata, to main Mercedes S560 khareed paata.)
**English answer:** If I won a lottery of ₹ 2 cr, I could buy Mercedes S560.

### 41. अगर आप इंग्लिश बोलना सीख लेते, तो आपको ये नौकरी मिल जाती।
**Romanized:** (Agar aap English bolna seekh lete, to aapko ye naukri mil jaati.)
**English answer:** If you learned to speak English, you would get this job.

### 42. अगर वह आपके साथ है, तो आप दुनिया जीत सकते हैं।
**Romanized:** (agar vah aapake saath hai, to aap duniya jeet sakate hain.)
**English answer:** If he is with you, you could win the world.

### 43. अगर मैं उस वक्त मैनेजर होता, तो मैंने इसकी अनुमति नहीं दी होती।
**Romanized:** (Agar main us waqt manager hota, to maine iski anumati nahi di hoti.)
**English answer:** If I had been the manager then, I wouldn't have allowed it.

### 44. अगर मैंने उसकी तस्वीर नहीं देखी होती, तो मैं उसे कभी पहचान नहीं सकता था / पाता।
**Romanized:** (agar mainne uski tasvir nahin dekhee hoti, to main use kabhi pahachaan nahin sakata tha/paata.)
**English answer:** If I hadn't seen his picture, I could have never identified him.

### 45. अगर मेरे पास अगले साल तक ₹ १0 लाख हों, तो मैं एक कार खरीद सकता हूँ।
**Romanized:** (Agar mere paas agale saal tak ₹ 10 laakh hon, to main ek car khareed sakta hun.)
**English answer:** If I have ₹10 lakh by next year, I may buy a car.

### 46. अंकल, अगर मैं संडे को आता तो आपसे ज़रूर मिलता पर छुट्टी नहीं मिल रही है।
**Romanized:** (Uncle, agar main Sunday ko aata to aapse zaroor milta par chhutti nahi mil rahi hai.)
**English answer:** Uncle, if I came on Sunday, I would surely/definitely meet you; but I’m not getting leave.
**Source annotation:** Still possible to happen - TYPE 2

### 47. अंकल, अगर मैं संडे को आता
**Romanized:** (Uncle, agar main Sunday ko aata to aapse zaroor milta par chhutti nahi mili.)
**English answer:** Uncle, if I had come on Sunday, I would have definitely met you; but I didn’t get leave.
**Source annotation:** Impossible to happen – TYPE 3

### 48. अगर मुझे उसका पता मिल जाता, तो मैं उसे निमंत्रण भेज देता।
**Romanized:** (agar mujhe usaka address mil jaata, to main use invitation bhej deta.)
**English answer:** If I found her address, I would send him an invitation. (If the event is not yet over) / If I had found her address, I would have sent him an invitation. (If the event is now over)

### 49. अगर मैं प्रधानमंत्री होता, तो कल
**Romanized:** (tomorrow)
**English answer:** If I were the Prime Minister, I would not attend tomorrow's meeting.

### 50. अगर मैं प्रधानमंत्री होता, तो कल
**Romanized:** (yesterday)
**English answer:** If I had been the Prime Minister, I would not have attended yesterday's meeting.

### 51. अगर आप उसे कॉल करते, तो वो आपकी मदद कर देता।
**Romanized:** (Agar aap use call karte, to vo aapki madad kar deta.)
**English answer:** If you called him, he would help you.

### 52. अगर आप उसे उस दिन कॉल कर देते, तो वो आपकी मदद कर देता।
**Romanized:** (Agar aap use us din call kar dete, to vo aapki madad kar deta.)
**English answer:** If you had called him that day, he would have helped you.

### 53. अगर उसने मेरी बात मानी होती, तो वो ये दिन नहीं देखता।
**Romanized:** (Agar usane meree baat maanee hotee, to vo ye din nahin dekhata.)
**English answer:** If he had listened to me, he would not have seen this day.

### 54. अगर उसने मेरी बात मानी होती, तो उसे ये दिन नहीं देखना पड़ता।
**Romanized:** (agar usane meree baat maanee hotee, to use ye din nahin dekhana padata.)
**English answer:** If he had listened to me, he would not have to see this day.

### 55. अगर वह मुझसे दिल्ली में मिले होते, तो मैं उन्हें इसकी जानकारी दे चुका होता।
**Romanized:** (agar vah mujhase Delhi mein mile hote, to main unhen isakee jaanakaaree de chuka hota.)
**English answer:** If he had met me in Delhi, I would have informed him about it.

### 56. अगर आपने मुझे पहले ही बुला लिया होता, तो उसने यह गलती नहीं की होती।
**Romanized:** (agar aapane mujhe pahale hee bula liya hota, to usane yah galatee nahin kee hoti.)
**English answer:** If you had called me beforehand, he wouldn’t have made this mistake.

### 57. अगर आप पार्टी में आओगे, तो मैं नहीं आऊँगा।
**Romanized:** (agar aap party mein aaoge, to main nahin aunga.)
**English answer:** If you come to the party, I will not.

### 58. अगर मैंने अच्छा काम नहीं किया होता, तो मुझे प्रमोशन नहीं मिला होता।
**Romanized:** (agar mainne achchha kaam nahin kiya hota, to mujhe promotion nahin mila hota.)
**English answer:** If I hadn’t worked well, I wouldn’t have been promoted.

### 59. अगर मैं आया/ आऊँगा, तो आपसे ज़रूर मिलूंगा।
**Romanized:** (Agar main aaya/aaunga, to aapse zaroor milunga.)
**English answer:** If I come, I will surely meet you.

### 60. अगर वो आया/ आएगा, तो आपसे ज़रूर मिलेगा।
**Romanized:** (Agar wo aaya/aayega, to aap se zaroor milega.)
**English answer:** If he comes, he will surely meet you.

### 61. अगर मैं पिछले साल आया होता, तो आप से मिल लेता।
**Romanized:** (agar main pichhale saal aaya hota, to aap se mil leta.)
**English answer:** If I had come last year, I would have met you.

### 62. अगर उसके पास बाइक होती, वो आपको घर ज़रूर छोड़ता।
**Romanized:** (Agar uske paas bike hoti, wo aapko ghar zarur chhodta.)
**English answer:** If he had a bike, he would definitely drop you home.

### 63. अगर रवि के पास पैसे होते, तो वो मदद कर देता।
**Romanized:** (Agar Ravi ke paas paise hote, to wo madad kar deta.)
**English answer:** If Ravi had money, he would help.

### 64. अगर रवि के पास पैसे होते, तो वह मदद क्यों नहीं करता?
**Romanized:** (Agar Ravi ke paas paise hote to wo madad kyun nahi karta?)
**English answer:** If Ravi had money, why would he not help?

### 65. अगर रवि के पास पैसे नहीं होते, वो मदद कैसे करता?
**Romanized:** (Agar Ravi ke paas paise nahi hote wo madad kaise karta?)
**English answer:** If Ravi had no money, how would he help? / If Ravi didn’t have money, how would he help?

### 66. अगर उस दिन मेरे पास कार होती, तो मैं तुम्हारे घर आ सकता था।
**Romanized:** (Agar us din mere paas car hoti, to main tumhare ghar aa sakta tha.)
**English answer:** If I had a car that day, I could have come to your home.

### 67. अगर उस दिन मेरे पास कार होती, तो मैं तुम्हारे घर आ चुका होता।
**Romanized:** (Agar us din mere pas car hoti, to main tumhare ghar aa chuka Hota.)
**English answer:** If I had a car that day, I would have come to your home.

### 68. अगर मैंने उसे देख लिया होता, तो उसे डांट दिया होता।
**Romanized:** (Agar maine use dekh liya hota, To use daant diya hota.)
**English answer:** If I had seen him, I would have scolded him. / Had I seen him, I would have scolded him.

### 69. अगर वो खेलेगा, तो ही मैं खेलूंगा।
**Romanized:** (Agar vo khelega to hi mai khelunga.)
**English answer:** If he plays, then only I'll.

### 70. अगर सब लोग आयेंगे, तभी मैं आऊँगा।
**Romanized:** (Agar sab log aayenge tabhi mai aaunga.)
**English answer:** If all people come, then only I will.

### 71. अगर आप नहीं आओगे, तो मैं भी नहीं आऊँगा।
**Romanized:** (Agar aap nahi aaoge, to main bhi nahi aaunga.)
**English answer:** If you don't come, I won’t come either.

### 72. अगर मैं वहाँ गया होता, तो उससे मिल लिया होता।
**Romanized:** (Agar main waha gaya hota, To usse mil liya hota.)
**English answer:** If I had gone there, I would’ve met him. / Had I gone there, I would’ve met him.

### 73. अगर मैं उसके घर गया होता, तो उससे बात कर चुका होता।
**Romanized:** (Agar main uske ghar gaya hota, to usse baat kar chuka Hota.)
**English answer:** If I had visited his house, I would have talked to him. / Had I visited his house, I would have talked to him.

### 74. अगर उन्हें पहले से पता हो, तो वो ऐसा क्यों करेंगे?
**Romanized:** (Agar unhe pehle se pata ho, to vo aisa kyun karenge?)
**English answer:** If they already know, why will they do so?

### 75. अगर उन्हें पहले से पता होता, तो वो ऐसा क्यों करते?
**Romanized:** (Agar unhe pehle se pata ho, to vo aisa kyun karenge?)
**English answer:** If they already know, why will they do so?

### 76. अगर आपने मुझे न बताया होता, तो मैं ऑफिस से निकल चुका होता।
**Romanized:** (Agar aapne mujhse na bataya hota, to main office se nikal chuka hota.)
**English answer:** If you had not told me, I would have left the office. / Had you not told me, I would have left the office.

## Source-text notes

- Hindi OCR corrections were checked against the page images, including Exercise 1 items 12, 15, 16, 18 and 20, Exercise 3 item 53, and Miscellaneous Exercise item 27; the missing leading 1 in “100”/“150” was restored where required. The OCR’s “ज़ल्दी” was normalized to “जल्दी.”
- Obvious Romanized typos were corrected against the bilingual text: Exercise 1 item 25; Exercise 2 items 11, 45, 96, 99, 102, 111 and 112; Exercise 4 items 8, 41, 44, 54, 70 and 73; and Miscellaneous Exercise item 63. The source omits an opening parenthesis on some Romanized lines; the paired output uses consistent parentheses.
- Miscellaneous Exercise item 75 has the same printed Romanized prompt and English answer as item 74 even though its Hindi prompt differs. The source text is preserved and the discrepancy is flagged rather than inferred or rewritten.

**Unreadable text:** none identified.

