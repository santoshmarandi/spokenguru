# Lesson 18 — Prepositions

**PDF pages:** 230–273 (printed pages 229–272)

Exercise 1 has 54 preposition groups and 303 prompts. Exercise 2 has 361 numbered translation prompts. The printed English answer for each prompt is paired below by its group and number.

## Exercise 1 — Translate the following sentences properly using the PREPOSITIONS as provided below

### From

1. **Hindi prompt:** मैं दिल्ली से आ रहा हूँ।  
   **Romanized:** Main Delhi se aa raha hun.  
   **English answer:** I am coming from Delhi.

2. **Hindi prompt:** मैं देहरादून से आ रहा हूँ।  
   **Romanized:** Main Dehradun se aa raha hun.  
   **English answer:** I am coming from Dehradun.

3. **Hindi prompt:** वे पार्क से आये।  
   **Romanized:** Ve park se aaye.  
   **English answer:** They came from park.

4. **Hindi prompt:** मैं कल से काम करूँगा।  
   **Romanized:** Main kal se kaam karunga.  
   **English answer:** I will work from tomorrow.

5. **Hindi prompt:** राम दस बजे से काम करेगा।  
   **Romanized:** Ram das baje se kam karega.  
   **English answer:** Ram will work from 10 'o’clock.

6. **Hindi prompt:** मैंनें राम से ये सुना।  
   **Romanized:** Maine Ram se ye suna.  
   **English answer:** I heard it from Ram.

7. **Hindi prompt:** मैंने ये किताब से लिखा।  
   **Romanized:** Maine ye kitab se likha.  
   **English answer:** I wrote it from the book.

8. **Hindi prompt:** हम उत्तराखण्ड से हैं।  
   **Romanized:** Hum Uttarakhand se hai.  
   **English answer:** We are from Uttarakhand.

9. **Hindi prompt:** मैं 10 से 5 बजे तक काम करता हूँ।  
   **Romanized:** Main 10 se 5 baje tak kaam karta hu.  
   **English answer:** I work from 10 to 5.

10. **Hindi prompt:** वो दुकान से ये खरीद रहा है।  
   **Romanized:** Wo dukan se ye khareed raha hai.  
   **English answer:** He is buying it from the shop.

### Off

1. **Hindi prompt:** मैंने मोबाइल को बिस्तर से उठाया।  
   **Romanized:** Maine mobile ko bistar se uthaya.  
   **English answer:** I picked the mobile off the bed.

2. **Hindi prompt:** मैं स्क्रीन से धूल हटा रहा हूँ।  
   **Romanized:** Main screen se dhool hata raha hun.  
   **English answer:** I am wiping the dust off the screen.

3. **Hindi prompt:** बन्दर पेड़ से कूदा।  
   **Romanized:** Bandar ped se kuda.  
   **English answer:** Monkey jumped off the tree.

4. **Hindi prompt:** टेबल से कप हटा दो।  
   **Romanized:** Table se cup hata do.  
   **English answer:** Move the cup off the table.

5. **Hindi prompt:** पत्ते पेड़ से गिर रहे हैं।  
   **Romanized:** Patte ped se gir rahe hai.  
   **English answer:** Leaves are falling off the tree.

6. **Hindi prompt:** वो बस से उतर रहा है।  
   **Romanized:** vo bus se utar raha hai.  
   **English answer:** He is getting off the bus.

### Since

1. **Hindi prompt:** मैं सुबह से पढ़ रहा हूँ।  
   **Romanized:** Main subah se padh raha hun.  
   **English answer:** I have been studying since morning.

2. **Hindi prompt:** वो सोमवार से कोशिश कर रहा है।  
   **Romanized:** Vo Somvar se koshish kar raha hai.  
   **English answer:** He has been trying since Monday.

3. **Hindi prompt:** राम 4 बजे से घूम रहा है।  
   **Romanized:** Ram 4 baje se ghum raha hai.  
   **English answer:** Ram has been walking since 4.

4. **Hindi prompt:** मैं सुबह से खेल रहा हूँ।  
   **Romanized:** Main subah se khel raha hun.  
   **English answer:** I have been playing since morning.

5. **Hindi prompt:** वो कल से यहाँ है।  
   **Romanized:** Vo kal se yaha hai.  
   **English answer:** He has been here since yesterday.

6. **Hindi prompt:** नेहा दोपहर से रो रही है।  
   **Romanized:** Neha dopahar se ro rahi hai.  
   **English answer:** Neha has been weeping since noon.

7. **Hindi prompt:** मैं तब से पढ़ रहा हूँ।  
   **Romanized:** Main tab se padh raha hun.  
   **English answer:** I have been studying since then.

8. **Hindi prompt:** मम्मी 5 बजे से घर पर हैं।  
   **Romanized:** Mummy 5 baje se ghar par hai.  
   **English answer:** Mom is at home since 5 o’clock.

### For

1. **Hindi prompt:** मैं दो घंटे से पढ़ रहा हूँ।  
   **Romanized:** Main do ghante se padh raha hun.  
   **English answer:** I have been studying for 2 hours.

2. **Hindi prompt:** वो कई दिनों से कोशिश कर रहा है।  
   **Romanized:** Vo kai dino se koshish kar raha hai.  
   **English answer:** He has been trying for many days.

3. **Hindi prompt:** मैंनें ये तुम्हारे लिए किया।  
   **Romanized:** Maine ye tumhare lie kiya.  
   **English answer:** I did it for you.

4. **Hindi prompt:** वो मेरे पास पैसे के लिए आया।  
   **Romanized:** Vo mere pas paise ke liye aaya.  
   **English answer:** He came to me for money.

5. **Hindi prompt:** मैंनें 500 रु में मोबाइल दिया।  
   **Romanized:** Maine 500 rupay mein mobile diya.  
   **English answer:** I gave a mobile for Rs. 500.

6. **Hindi prompt:** उसने 5 रु में एक पेन खरीदा।  
   **Romanized:** Usne 5 rupay mein ek pen kharida.  
   **English answer:** He bought a pen for Rs. 5.

7. **Hindi prompt:** राम 2 घंटे से घूम रहा है।  
   **Romanized:** Ram 2 ghante se ghum raha hai.  
   **English answer:** Ram has been walking for 2 hours.

8. **Hindi prompt:** मैं काफी देर से खेल रहा हूँ।  
   **Romanized:** Main kafi der se khel raha hun.  
   **English answer:** I’ve been playing for a long.

9. **Hindi prompt:** वो 10 मिनट से यहाँ थी।  
   **Romanized:** Wo 10 minute se yahan thi.  
   **English answer:** She had been here for 10 minutes.

10. **Hindi prompt:** नेहा 2 दिन से कह रही है।  
   **Romanized:** Neha 2 din se keh rahi hai.  
   **English answer:** Neha has been saying for 2 days.

11. **Hindi prompt:** मैं कई दिनों से पढ़ रहा हूँ।  
   **Romanized:** Main kai dino se padh raha hun.  
   **English answer:** I have been studying for many days.

12. **Hindi prompt:** मम्मी कुछ देर से घर पर हैं।  
   **Romanized:** Mummy Kuch der se ghar par hai.  
   **English answer:** Mom is at home for a while.

13. **Hindi prompt:** मैं पढ़ाई के लिए दिल्ली जा रहा हूँ।  
   **Romanized:** Main padhai ke liye Delhi ja raha hun.  
   **English answer:** I am going to Delhi for study.

14. **Hindi prompt:** वो पैसों के लिए यहाँ आया।  
   **Romanized:** Wo paiso ke liye yaha aaya.  
   **English answer:** He came here for money.

15. **Hindi prompt:** उस लड़के ने ये तुम्हारे लिए किया।  
   **Romanized:** Us ladke ne ye tumhare liye kiya.  
   **English answer:** That boy did it for you.

16. **Hindi prompt:** मैंने 500 रु में अपना मोबाईल दिया।  
   **Romanized:** Maine 500 rupay mein apna mobile diya.  
   **English answer:** I gave my mobile for Rs.500.

17. **Hindi prompt:** पापा ने काम के बदले मुझे पैसे दिए।  
   **Romanized:** Papa ne kaam ke badle mujhe paise diye.  
   **English answer:** Papa gave me money for work.

### In

1. **Hindi prompt:** मैं जनवरी में पैदा हुआ था।  
   **Romanized:** Main January mein paida hua tha.  
   **English answer:** I was born in January.

2. **Hindi prompt:** वो 2015 में घर आयेगा।  
   **Romanized:** Wo 2015 mein ghar aayega.  
   **English answer:** He will come home in 2015.

3. **Hindi prompt:** मैंने जून 2009 में कम्पनी छोड़ी।  
   **Romanized:** Maine june 2009 mein company chodi.  
   **English answer:** I left the company in June 2009.

4. **Hindi prompt:** मैं आधे घंटे में निकलूँगा।  
   **Romanized:** Main aadhe ghante mein niklunga.  
   **English answer:** I will leave in half an hour.

5. **Hindi prompt:** मैं दिल्ली में रहता हूँ।  
   **Romanized:** Main Delhi mein rehta hun.  
   **English answer:** I live in Delhi.

6. **Hindi prompt:** वो अमेरिका में पढ़ाई करेगा।  
   **Romanized:** Wo America mein padhai karega.  
   **English answer:** He will study in America.

7. **Hindi prompt:** मुझे इस मोबाइल में गाने नहीं मिले।  
   **Romanized:** Mujhe is mobile mein gane nahi mile.  
   **English answer:** I found no songs in this mobile.

8. **Hindi prompt:** हमने ये किताब में पढ़ा है।  
   **Romanized:** Hamne ye kitab mein padha hai.  
   **English answer:** We have read it in the book.

9. **Hindi prompt:** अयांश आधे घंटे में निकलेगा।  
   **Romanized:** Ayansh aadhe ghante mein niklega.  
   **English answer:** Ayansh will leave in half an hour.

10. **Hindi prompt:** मैं बैंक में काम करता हूँ।  
   **Romanized:** Main bank mein kaam karta hun.  
   **English answer:** I work in a bank.

11. **Hindi prompt:** मैंने कम्प्यूटर में फोटो देखी।  
   **Romanized:** Maine computer mein photo dekhi.  
   **English answer:** I saw the pic in the computer.

12. **Hindi prompt:** ये गाना तुम्हारे मोबाईल में है।  
   **Romanized:** Ye gaana tumhare mobile mein hai.  
   **English answer:** This song is there in your mobile.

### Into

1. **Hindi prompt:** कॉफी को कप में डालो।  
   **Romanized:** Coffee ko cup mein dalo.  
   **English answer:** Pour the coffee into the cup.

2. **Hindi prompt:** वो कमरे में जा रहा है।  
   **Romanized:** Wo kamre mein ja raha hai.  
   **English answer:** He is going into the room.

### Before

1. **Hindi prompt:** यह ट्रेन समय से पहले पहुँचेगी।  
   **Romanized:** Yeh train samay se pahale pahunchegi.  
   **English answer:** This train will reach before time.

2. **Hindi prompt:** मैं तुम्हारे निकलने से पहले आऊँगा।  
   **Romanized:** Main tumhare nikalne se pehle aunga.  
   **English answer:** I will come before you leave.

3. **Hindi prompt:** अब मैं आपके सामने खड़ा हूँ।  
   **Romanized:** Ab Main aapke samne khada hun.  
   **English answer:** Now I am standing before you.

4. **Hindi prompt:** वो अपने पापा के सामने बैठा था।  
   **Romanized:** Wo apne papa ke samne baitha tha.  
   **English answer:** He was sitting before his dad.

5. **Hindi prompt:** वो मेरे सामने खड़ा था।  
   **Romanized:** Wo mere samne khada tha.  
   **English answer:** He was standing before me. / He was standing in front of me.

6. **Hindi prompt:** वो मेरे सामने टिक नहीं सकता।  
   **Romanized:** Wo mere saamne tik nahi sakta.  
   **English answer:** He can’t stand in front of me. / He can’t stand before me.

### After

1. **Hindi prompt:** मैं तुमसे 10 बजे के बाद मिलूँगा।  
   **Romanized:** Main tumse 10 baje ke baad milunga.  
   **English answer:** I will meet you after 10.

2. **Hindi prompt:** मैं उनके बाद पहुँचा।  
   **Romanized:** Main unke baad pahucha.  
   **English answer:** I reached after them.

3. **Hindi prompt:** मैं मदद पाने के लिए अपने प्रोफेसर के पीछे पड़ गया था।  
   **Romanized:** Main madad pane ke liye apne professor ke piche pad gaya tha.  
   **English answer:** I was after my professor for getting help.

4. **Hindi prompt:** वो बेवजह उस लड़की के पीछे पड़ा हुआ था।  
   **Romanized:** Wo bewajah us ladki ke piche pada hua tha.  
   **English answer:** He was unnecessarily after that girl.

5. **Hindi prompt:** मेरे पापा ने तीन बार मना कर दिया है पर मैं अभी भी उनके पीछे पड़ा हुआ हूँ।  
   **Romanized:** Mere papa ne teen bar mana kar diya hai par Main abhi bhi unke piche pada hua hun.  
   **English answer:** My father has denied thrice but I am still after him.

6. **Hindi prompt:** ट्रेन समय के बाद पहुँचेगी।  
   **Romanized:** Train samay ke baad pahuchegi.  
   **English answer:** The train will reach after time.

7. **Hindi prompt:** मैं तुम्हारे जाने के बाद आऊँगा।  
   **Romanized:** Main tumhare jane ke baad aunga.  
   **English answer:** I will come after you leave.

8. **Hindi prompt:** वो राहुल से 10 बजे के बाद मिला।  
   **Romanized:** Wo Rahul se 10 baje ke baad mila.  
   **English answer:** He met Rahul after 10.

9. **Hindi prompt:** वो उस लड़की के पीछे पड़ा हुआ था।  
   **Romanized:** Wo us ladki ke piche pada hua tha.  
   **English answer:** He was after that girl.

10. **Hindi prompt:** पुलिस चोर के पीछे पड़ी हुई है।  
   **Romanized:** Police chor ke piche padi hui hai.  
   **English answer:** The police are after the thief.

11. **Hindi prompt:** मैं पापा के पीछे पड़ा हुआ हूँ।  
   **Romanized:** Main papa ke piche pada hua hun.  
   **English answer:** I am after dad.

### By

1. **Hindi prompt:** मुझे किसी के द्वारा रोका गया।  
   **Romanized:** Mujhe kisi ke dwara roka gaya.  
   **English answer:** I was stopped by someone.

2. **Hindi prompt:** उसे अपने पापा द्वारा भेजा जा सकता है।  
   **Romanized:** Use apne papa dwara bheja ja sakata hai.  
   **English answer:** He can be sent by his father.

3. **Hindi prompt:** मैनें बस से यात्रा की।  
   **Romanized:** Maine bus se yatra ki.  
   **English answer:** I travelled by bus.

4. **Hindi prompt:** वो दोपहर की फ्लाइट से आ रहा है।  
   **Romanized:** Wo dopahar ki flight se aa raha hai.  
   **English answer:** He is coming by noon flight.

5. **Hindi prompt:** मैं 4 बजे तक निकल जाऊँगा।  
   **Romanized:** Main 4 baje tak nikal jaunga.  
   **English answer:** I will leave by 4 o’clock.

6. **Hindi prompt:** हम सुबह तक ये खत्म कर देंगे।  
   **Romanized:** Hum subah tak ye khatam kar denge.  
   **English answer:** We will finish it by morning.

7. **Hindi prompt:** मैं उसके बगल में खड़ा था।  
   **Romanized:** Main uske bagal mein khada tha.  
   **English answer:** I was standing by him.

8. **Hindi prompt:** हमें मैनेजर के द्वारा सूचित किया गया।  
   **Romanized:** Hume manager ke dwara suchit kiya gaya.  
   **English answer:** We were informed by the manager.

9. **Hindi prompt:** उसे मम्मी के द्वारा डाँटा गया।  
   **Romanized:** Use mummy ke dwara danta gaya.  
   **English answer:** He was scolded by mom.

10. **Hindi prompt:** मैं बाइक से जिम जा रहा था।  
   **Romanized:** Main bike se gym ja raha tha.  
   **English answer:** I was going to gym by bike.

11. **Hindi prompt:** मैं 4 बजे तक निकलूँगा।  
   **Romanized:** Main 4 baje tak niklunga.  
   **English answer:** I will leave by 4 o’clock.

12. **Hindi prompt:** हम ये सुबह तक निपटा लेंगे।  
   **Romanized:** Hum ye subah tak nipta lenge.  
   **English answer:** We will finish it by morning.

13. **Hindi prompt:** मैं शाम 7 बजे तक जिम जाता हूँ।  
   **Romanized:** Main shaam 7 baje tak gym jata hun.  
   **English answer:** I go to gym by 7 pm.

### With

1. **Hindi prompt:** मैंनें चाकू से केक काटा।  
   **Romanized:** Maine chaku se cake kata.  
   **English answer:** I cut the cake with a knife.

2. **Hindi prompt:** उसने नीले पैन से पत्र लिखा।  
   **Romanized:** Usne neele pen se patr likha.  
   **English answer:** He wrote the letter with a blue pen.

3. **Hindi prompt:** उसने पत्थर से चिड़िया मारी।  
   **Romanized:** Usne patthar se chidiya mari.  
   **English answer:** He killed the bird with a stone.

4. **Hindi prompt:** इस मामले में मैं राम के साथ हूँ।  
   **Romanized:** Is mamle mein Main Ram ke saath hun.  
   **English answer:** I am with Ram in this matter.

5. **Hindi prompt:** हम आपके साथ रहेंगे।  
   **Romanized:** Hum aapke saath rahenge.  
   **English answer:** We will be with you. / We will stay with you. / We will support you.

6. **Hindi prompt:** मेरे पापा अपने ऑफिस लैपटॉप ले के गये।  
   **Romanized:** Mere papa apne office laptop le ke gaye.  
   **English answer:** My dad went to his office with the laptop.

7. **Hindi prompt:** तुम ईमानदारी के साथ जीते हो।  
   **Romanized:** Tum imandari ke saath jeete ho.  
   **English answer:** You live with honesty.

### At

1. **Hindi prompt:** मैं 2 बजे पैदा हुआ था।  
   **Romanized:** Main 2 baje paida hua tha.  
   **English answer:** I was born at 2 o’clock.

2. **Hindi prompt:** वो सुबह 10 बजे घर आयेगा।  
   **Romanized:** Wo subah 10 baje ghar aayega.  
   **English answer:** He will come home at 10 AM.

3. **Hindi prompt:** मैं एक होटल में रुका।  
   **Romanized:** Main ek hotel mein ruka.  
   **English answer:** I stayed at/in a hotel.

4. **Hindi prompt:** वो बस स्टॉप पर खड़ा था।  
   **Romanized:** Wo bus stop par khada tha.  
   **English answer:** He was standing at the bus stop.

5. **Hindi prompt:** राहुल एक स्टोर में काम करता है।  
   **Romanized:** Rahul ek store mein/ par kam karta hai.  
   **English answer:** Rahul works at/in a store.

6. **Hindi prompt:** मैं दोपहर में वहाँ था।  
   **Romanized:** Main dopahar mein wahan tha.  
   **English answer:** I was there in the afternoon.

7. **Hindi prompt:** हम रात में पढ़ते हैं।  
   **Romanized:** Hum raat mein padhte hain.  
   **English answer:** We study at night.

8. **Hindi prompt:** यह फल 10 रु किलो बिक रहा है।  
   **Romanized:** Yeh fruit 10 rs kilo bik raha hai.  
   **English answer:** This fruit is selling at Rs. 10 a kg. / This fruit is being sold at Rs. 10 a kg.

9. **Hindi prompt:** मैं प्याज 10 रु किलो खरीद रहा हूँ।  
   **Romanized:** Main pyaaj 10 rs kilo khareed raha hun.  
   **English answer:** I am buying onion at Rs. 10 a kg.

10. **Hindi prompt:** मैं होली पर घर आऊँगा।  
   **Romanized:** Main Holi par ghar aunga.  
   **English answer:** I will come home at Holi.

11. **Hindi prompt:** मैं दीवाली पर घर आऊँगा।  
   **Romanized:** Main Diwali par ghar aunga.  
   **English answer:** I will come home at Diwali.

12. **Hindi prompt:** वो उसके जन्मदिन पर वहाँ जायेगा।  
   **Romanized:** Wo uske janmdin par wahan jayega.  
   **English answer:** He will go there at his birthday.

13. **Hindi prompt:** अयांश अब 10 बजे सोता है।  
   **Romanized:** Ayansh ab 10 baje sota hai.  
   **English answer:** Ayansh sleeps at 10 now.

14. **Hindi prompt:** वह रात में हॉस्पिटल गया।  
   **Romanized:** Wah raat mein hospital gaya.  
   **English answer:** He went to hospital at night.

15. **Hindi prompt:** पापा दीपावली में वहाँ जाएँगे।  
   **Romanized:** Papa deepawali mein wahan jaenge.  
   **English answer:** Papa will go there at Diwali.

16. **Hindi prompt:** हम जन्मदिन पर आये थे।  
   **Romanized:** Ham janamdin par aaye the.  
   **English answer:** We had come at birthday.

### Through

1. **Hindi prompt:** मैं ग्लास से देख सकता हूँ।  
   **Romanized:** Main glass se dekh sakta hun.  
   **English answer:** I can see through the glass.

2. **Hindi prompt:** मैं इस छेद के जरिए अंदर देख सकता हूँ।  
   **Romanized:** Main is ched ke jariye andar dekh sakta hun.  
   **English answer:** I can see inside through this hole.

3. **Hindi prompt:** मैं एक गली से गुजर रहा था।  
   **Romanized:** Main ek gali se gujar raha tha.  
   **English answer:** I was passing through a street.

4. **Hindi prompt:** हम भूमिगत रास्ते से गये।  
   **Romanized:** Ham bhumigat raste se gaye.  
   **English answer:** We went through the underpass.

5. **Hindi prompt:** पानी इस पाइप से गुजर रहा है।  
   **Romanized:** Paani is pipe se gujar raha hai.  
   **English answer:** Water is passing through this pipe.

6. **Hindi prompt:** मैं खिड़की से तुम्हें देख सकती हूँ।  
   **Romanized:** Main khidki se tumhe dekh sakti hun.  
   **English answer:** I can see you through the window.

7. **Hindi prompt:** उसने मुझे इस छेद से देखा।  
   **Romanized:** Usne mujhe is chhed se dekha.  
   **English answer:** He saw me through this hole.

8. **Hindi prompt:** हम सुरंग से गये।  
   **Romanized:** Hum surang se gaye.  
   **English answer:** We went through an underpass.

9. **Hindi prompt:** अमन खिड़की से झाँक रहा है।  
   **Romanized:** Aman khidki se jhank raha hai.  
   **English answer:** Aman is peeing through the window.

10. **Hindi prompt:** पानी इस पाइप से गुजरा।  
   **Romanized:** Paani is pipe se gujra.  
   **English answer:** Water passed through this pipe.

### Beyond

1. **Hindi prompt:** इस पहाड़ के उस पार एक मंदिर है।  
   **Romanized:** Is pahaad ke us paar ek mandir hai.  
   **English answer:** There is a temple beyond this mountain.

2. **Hindi prompt:** उस नदी के पार क्या है?  
   **Romanized:** Us nadi ke paar kya hai?  
   **English answer:** What is there beyond that river?

3. **Hindi prompt:** इस ब्रहमाण्ड के पार कुछ है।  
   **Romanized:** Is Brahmand ke paar kuchh hai.  
   **English answer:** There is something beyond this universe.

4. **Hindi prompt:** प्यार के पार कुछ नहीं है या प्यार के बराबर कुछ नहीं है।  
   **Romanized:** Pyaar ke paar kuchh nahi hai ya pyaar ke barabar kuch nahi hai.  
   **English answer:** There is nothing beyond love.

5. **Hindi prompt:** हमारी सोच से परे भी चीजें हैं।  
   **Romanized:** Hamari soch se pare bhi chije hai.  
   **English answer:** There are things beyond our imagination.

6. **Hindi prompt:** इसके पार एक जंगल था।  
   **Romanized:** Iske paar ek jungle tha.  
   **English answer:** There was a forest beyond it.

### Via

1. **Hindi prompt:** यह ट्रेन कानपुर से होते हुए दिल्ली जायेगी।  
   **Romanized:** Yeh train kanpur se hote hue Delhi jayegi.  
   **English answer:** This train will go to Delhi via Kanpur.

2. **Hindi prompt:** मैंनें उसे अपनी फोटो ब्लूटूथ से भेजी।  
   **Romanized:** Maine use apni photo bluetooth se bheji.  
   **English answer:** I sent him my picture via Bluetooth.

3. **Hindi prompt:** बस कोटद्वार से होते हुए आती है।  
   **Romanized:** Bas kotdwara se hote hue aati hai.  
   **English answer:** Bus comes via Kotdwara.

4. **Hindi prompt:** मैं दुबई के रास्ते मॉरीशस गया।  
   **Romanized:** Main Dubai ke raste Mauritius gaya.  
   **English answer:** I went to Mauritius via Dubai.

5. **Hindi prompt:** उसे ब्लूटूथ से भेज दो।  
   **Romanized:** Use bluetooth se bhej do.  
   **English answer:** Send him via Bluetooth.

### Opposite

1. **Hindi prompt:** मेरा घर तुम्हारी दुकान के ठीक सामने है।  
   **Romanized:** Mera ghar tumhari dukan ke thik samne hai.  
   **English answer:** My house is just opposite your shop.

2. **Hindi prompt:** वो तुम्हारे सामने खड़ा था।  
   **Romanized:** Wo tumhare samne khada tha.  
   **English answer:** He was standing opposite you.

3. **Hindi prompt:** जो तुम कहते हो राम उसका उल्टा करता है।  
   **Romanized:** Jo tum kehte ho Ram uska ulta karta hai.  
   **English answer:** Ram does opposite of what you say.

4. **Hindi prompt:** उसकी सोच तुम्हारी सोच से ठीक उल्टी है।  
   **Romanized:** Uski soch tumhari soch se thik ulti hai.  
   **English answer:** His thinking is opposite yours.

5. **Hindi prompt:** वो आपके कहे का उल्टा करता है।  
   **Romanized:** Wo aapke kahe ka ulta karta hai.  
   **English answer:** He does opposite of what you say.

6. **Hindi prompt:** उसकी सोच मेरी सोच के विपरीत है।  
   **Romanized:** Uski soch meri soch ke vipreet hai.  
   **English answer:** His thinking is opposite mine.

7. **Hindi prompt:** तुम मेरे ठीक सामने बैठोगे।  
   **Romanized:** Tum mere thik samne baithoge.  
   **English answer:** You will sit opposite to me.

8. **Hindi prompt:** वो पक्का इसका उल्टा ही करेगा।  
   **Romanized:** Wo pakka iska ulta hi karega.  
   **English answer:** He must do its opposite.

### Above

1. **Hindi prompt:** मेरा नाम लिस्ट में तुम्हारे नाम के ऊपर है।  
   **Romanized:** Mera naam list mein tumhare nam ke upar hai.  
   **English answer:** My name is above your name is the list.

2. **Hindi prompt:** पैसा प्यार से ऊपर है।  
   **Romanized:** Paisa pyar se upar hai.  
   **English answer:** Money is above love.

3. **Hindi prompt:** केवल उसकी आँखे पानी के ऊपर थी।  
   **Romanized:** kewal uski ankhe pani ke upar thi.  
   **English answer:** Only his eyes were above water.

4. **Hindi prompt:** मेरा देश सबसे पहले है।  
   **Romanized:** Mera desh sabse pehle hai.  
   **English answer:** My country is above all.

5. **Hindi prompt:** भूकम्प की तीव्रता रिक्टर स्केल में 8 से ऊपर है।  
   **Romanized:** Bhukamp ki tivrata Richter scale mein 8 se upar hai.  
   **English answer:** The magnitude of the earthquake is above 8 in Richter scale.

### Under

1. **Hindi prompt:** राम बिस्तर के नीचे छिपा हुआ है।  
   **Romanized:** Ram bistar ke niche chhipa hua hai.  
   **English answer:** Ram is hidden under the bed.

2. **Hindi prompt:** राम छत के नीचे रहता है पर श्याम के पास तो घर ही नहीं है।  
   **Romanized:** Ram chhat ke niche rahta hai par Shyam ke paas to ghar hi nahi hai.  
   **English answer:** Ram lives under the roof but Shyam doesn’t even have a house.

3. **Hindi prompt:** मम्मी जी पेड़ के नीचे बैठी हैं।  
   **Romanized:** Mummy ji ped ke niche baithi hai.  
   **English answer:** Mom is sitting under the tree.

4. **Hindi prompt:** वो पुल के नीचे था।  
   **Romanized:** Wo pul ke niche tha.  
   **English answer:** He was under the bridge.

### Beneath/ underneath

1. **Hindi prompt:** मेरा घर आपके घर के नीचे है।  
   **Romanized:** Mera ghar aapke ghar ke niche hai.  
   **English answer:** My house is underneath your house.

2. **Hindi prompt:** उसकी तस्वीर मेरी किताब के नीचे है।  
   **Romanized:** Uski tasvir meri kitab ke niche hai.  
   **English answer:** Her photograph is beneath my book.

3. **Hindi prompt:** पत्र मेरी किताब के नीचे है।  
   **Romanized:** Patr meri kitab ke niche hai.  
   **English answer:** The letter is underneath the book.

4. **Hindi prompt:** मोबाईल तकिए के नीचे है।  
   **Romanized:** Mobile takiye ke niche hai.  
   **English answer:** The mobile is beneath/underneath the pillow.

### Below

1. **Hindi prompt:** मेरा नाम लिस्ट में तुम्हारे नाम के नीचे हैं।  
   **Romanized:** Mera name list mein tumhare naam ke niche hai.  
   **English answer:** My name is below your name in the list.

2. **Hindi prompt:** उसका मुँह पानी के नीचे था पर नाक ऊपर।  
   **Romanized:** Uska muhh pani ke niche tha par naak upar.  
   **English answer:** His mouth was below water but nose was above.

3. **Hindi prompt:** मेरे दसवीं में 70 से नीचे हैं।  
   **Romanized:** Mere dasvi mein 70 se niche hai.  
   **English answer:** I scored below 70% in 10th.

4. **Hindi prompt:** भूकम्प की तीव्रता रिक्टर स्केल में 9 से नीचे है।  
   **Romanized:** Bhukamp ki tivrata Richter scale mein 9 se niche hai.  
   **English answer:** The magnitude of the earthquake is below 9 in Richter scale.

5. **Hindi prompt:** मेरा नाम राम के नाम के नीचे है।  
   **Romanized:** Mera nam Ram ke nam ke niche hai.  
   **English answer:** My name is below Ram’s.

6. **Hindi prompt:** उसका स्तर तुमसे नीचे है।  
   **Romanized:** Uska star tumse niche hai.  
   **English answer:** His level is below yours.

### Down

1. **Hindi prompt:** कीमतें नीचे जा रही हैं।  
   **Romanized:** Kimate niche ja rahi hai.  
   **English answer:** Prices are going down.

2. **Hindi prompt:** पानी का स्तर नीचे जा रहा है।  
   **Romanized:** Paani ka star niche ja raha hai.  
   **English answer:** Water level is going down.

3. **Hindi prompt:** गुब्बारा नीचे जा रहा है।  
   **Romanized:** Gubbara niche ja raha hai.  
   **English answer:** Balloon is going down.

### Between

1. **Hindi prompt:** वो यश और वैभव के बीच में बैठी है।  
   **Romanized:** Wo Yash aur Vaibhav ke beech mein baithi hai.  
   **English answer:** She is sitting between Yash and Vaibhav.

2. **Hindi prompt:** पेन दो कम्प्यूटरों के बीच में पड़ा हुआ है।  
   **Romanized:** Pen do computeron ke beech mein pada hua hai.  
   **English answer:** The pen is lying between two computers.

3. **Hindi prompt:** वो यश और राम के बीच में है।  
   **Romanized:** Wo Yash aur Ram ke beech mein hai.  
   **English answer:** He is between Yash and Ram.

4. **Hindi prompt:** मैंने दो किताबों के बीच में फोन रखा।  
   **Romanized:** Maine do kitabon ke beech mein phone rakha.  
   **English answer:** I kept the phone between two books.

### Among

1. **Hindi prompt:** मैं 50 लोगों के बीच में था।  
   **Romanized:** Main 50 logon ke beech mein tha.  
   **English answer:** I was among 50 people.

2. **Hindi prompt:** उसकी तस्वीर तीन और चीजों के बीच रखी हुई थी।  
   **Romanized:** Uski tasvir teen aur chijo ke beech rakhi hui thi.  
   **English answer:** Her photograph was kept among 3 other items.

3. **Hindi prompt:** अमन 4 लोगों के बीच है।  
   **Romanized:** Aman 4 logo ke beech hai.  
   **English answer:** Aman is among 4 people.

### Amongst

1. **Hindi prompt:** मैं भीड़ के बीच था।  
   **Romanized:** Main bheed ke beech tha.  
   **English answer:** I was amongst the crowd.

2. **Hindi prompt:** मेरे पापा कई लोगों के बीच थे।  
   **Romanized:** Mere papa kai logo ke beech the.  
   **English answer:** My dad was amongst many people.

3. **Hindi prompt:** वो कई लोगों के बीच था।  
   **Romanized:** Wo kai logo ke beech tha.  
   **English answer:** He was amongst many people.

### Out of

1. **Hindi prompt:** मैं घर से बाहर निकल रहा हूँ।  
   **Romanized:** Main ghar se bahar nikal raha hun.  
   **English answer:** I am getting out of my home.

2. **Hindi prompt:** वह दिल्ली से बाहर जा चुका है।  
   **Romanized:** Wah Delhi se bahar ja chuka hai.  
   **English answer:** He has gone out of Delhi.

3. **Hindi prompt:** राहुल ने 100 में से 90 नंबर प्राप्त किये।  
   **Romanized:** Rahul ne 100 mein se 90 number praapt kiye.  
   **English answer:** Rahul scored 90 out of 100.

4. **Hindi prompt:** 15 में से केवल 2 ही विद्यार्थी हैं।  
   **Romanized:** 15 mein se keval 2 hi vidharthi hain.  
   **English answer:** There are only 2 students out of 15.

5. **Hindi prompt:** यहाँ से बाहर निकलो।  
   **Romanized:** Yahan se bahar niklo.  
   **English answer:** Get out of here!

6. **Hindi prompt:** वहाँ 8 में से केवल 1 ही विद्यार्थी है।  
   **Romanized:** Wahan 8 mein se keval 1 hi vidharthi hai  
   **English answer:** There is only 1 student out of 8.

7. **Hindi prompt:** 10 में से 3 के पास मोबाईल थे।  
   **Romanized:** 10 mein se 3 ke pas mobile the.  
   **English answer:** 3 out of 10 had mobiles.

### On

1. **Hindi prompt:** पेन टेबल पर रखा हुआ है।  
   **Romanized:** Pen table par rakha hua hai.  
   **English answer:** The pen is kept on the table.

2. **Hindi prompt:** रोहित हाथी के ऊपर बैठा हुआ है।  
   **Romanized:** Rohit hathi ke upar baitha hua hai.  
   **English answer:** Rohit is sitting on the elephant.

3. **Hindi prompt:** मैं संडे को गया।  
   **Romanized:** Main Sunday ko gaya.  
   **English answer:** I went on Sunday.

4. **Hindi prompt:** वह 20 दिसम्बर 2012 को आया।  
   **Romanized:** Vah 20 December 2012 ko aaya.  
   **English answer:** He came on 20th December 2012.

5. **Hindi prompt:** मैं दायीं ओर खड़ा था।  
   **Romanized:** Main dayin or khada tha.  
   **English answer:** I was standing on the right.

6. **Hindi prompt:** मैं बाँयी ओर खड़ा था।  
   **Romanized:** Main banyi or khada tha.  
   **English answer:** I was standing on the left.

7. **Hindi prompt:** किताब लैपटॉप पर रखी है।  
   **Romanized:** Kitab laptop par rakhi hai.  
   **English answer:** The book is kept on the laptop.

8. **Hindi prompt:** हम लोग सोमवार को आयेंगे।  
   **Romanized:** Hamlog somvaar ko aayenge.  
   **English answer:** We all will come on Monday.

### Upon / Onto

1. **Hindi prompt:** मैं कूद कर घोड़े पर बैठ गया।  
   **Romanized:** Main kood kar ghode par baith gaya.  
   **English answer:** I jumped upon/onto the horse.

2. **Hindi prompt:** झाडू अपने आप टेबल पर आ गया।  
   **Romanized:** Jhadu apne aap table par aa gaya.  
   **English answer:** The broom came upon the table by itself.

3. **Hindi prompt:** वो हाथी के ऊपर कूदेगा।  
   **Romanized:** Wo hathi ke upar kudega.  
   **English answer:** He will jump onto the Elephant.

4. **Hindi prompt:** मैं घोड़े के ऊपर कूदा।  
   **Romanized:** Main ghode ke upar kudaa.  
   **English answer:** I jumped onto the horse.

### Against

1. **Hindi prompt:** राम तुम्हारे विरुद्ध क्यों हैं?  
   **Romanized:** Ram tumhare viruddh kyon hain?  
   **English answer:** Why is Ram against you?

2. **Hindi prompt:** वो मेरे खिलाफ उसे भड़का रहा है।  
   **Romanized:** Wo mere khilaaf use bhadka raha hai.  
   **English answer:** He is provoking him against me.

3. **Hindi prompt:** क्या तुम मेरे विरोधी हो?  
   **Romanized:** Kya tum mere virodhi ho?  
   **English answer:** Are you against me?

4. **Hindi prompt:** अमन मेरे विरुद्ध नहीं हो सकता।  
   **Romanized:** Aman mere viruddh nahi ho sakta.  
   **English answer:** Aman can’t be against me.

### About

1. **Hindi prompt:** वो मेरे बारे में बात कर रहा है।  
   **Romanized:** Wo mere bare mein baat kar raha hai.  
   **English answer:** He is talking about me.

2. **Hindi prompt:** पापा मेरे बारे में जानते हैं।  
   **Romanized:**   
   **English answer:** Papa knows about me.)

3. **Hindi prompt:** उसके बारे में बात मत करो।  
   **Romanized:** Uske bare mein baat mat karo.  
   **English answer:** Don’t talk about him.

### Of

1. **Hindi prompt:** वो राम का भाई है।  
   **Romanized:** Wo Ram ka bhai hai.  
   **English answer:** He is Ram’s brother.

2. **Hindi prompt:** वो तीन भाइयों की बहन है।  
   **Romanized:** Wo teen bhaiyo ki behan hai.  
   **English answer:** She is the sister of 3 brothers.

3. **Hindi prompt:** यह कुर्सी उस दुकान की है।  
   **Romanized:** Yeh kursi us dukan ki hai.  
   **English answer:** This chair is of that shop. / This chair belongs to that shop.

### To

1. **Hindi prompt:** मैं स्कूल जा रहा हूँ।  
   **Romanized:** Main school ja raha hun.  
   **English answer:** I am going to school.

2. **Hindi prompt:** सीता हमारे घर आ रही है।  
   **Romanized:** Seeta hamare ghar aa rahi hai.  
   **English answer:** Seeta is coming to our home.

3. **Hindi prompt:** यशी हमारे घर आ रही है।  
   **Romanized:** Yashi hamare ghar aa rahi hai.  
   **English answer:** Yashi is coming to our home.

4. **Hindi prompt:** वो हॉस्पिटल जा रहा है।  
   **Romanized:** Wo hospital ja raha hai.  
   **English answer:** He is going to hospital.

### Towards

1. **Hindi prompt:** मैं स्कूल की तरफ जा रहा हूँ।  
   **Romanized:** Main school ki taraf ja raha hun.  
   **English answer:** I am going towards school.

2. **Hindi prompt:** वो तुम्हारी तरफ आ रहा था।  
   **Romanized:** Wo tumhari taraf aa raha tha.  
   **English answer:** He was coming towards you.

3. **Hindi prompt:** यशी हमारे घर की तरफ आ रही है।  
   **Romanized:** Yashi hamare ghar ki taraf aa rahi hai.  
   **English answer:** Yashi is coming towards our home.

4. **Hindi prompt:** वो हॉस्पिटल की ओर जा रहा है।  
   **Romanized:** Wo hospital ki or ja raha hai.  
   **English answer:** He is going towards hospital.

### Over

1. **Hindi prompt:** मैं रस्सी के ऊपर से कूदा।  
   **Romanized:** Main rassi ke upar se kuda.  
   **English answer:** I jumped over the rope.

2. **Hindi prompt:** हमारे सिर के ऊपर छत है।  
   **Romanized:** Hamare sir ke upar chhat hai.  
   **English answer:** There is a roof over our heads.

3. **Hindi prompt:** नदी के ऊपर एक पुल है।  
   **Romanized:** Nadi ke upar ek pul hai.  
   **English answer:** There is a bridge over the river.

4. **Hindi prompt:** अयांश रस्सी के ऊपर से कूदा।  
   **Romanized:** Ayansh rassi ke upar se kuda.  
   **English answer:** Ayansh jumped over the rope.

5. **Hindi prompt:** उसका भाषण मेरे सिर के ऊपर से गया।  
   **Romanized:** Uska bhashan mere sir ke upar se gaya.  
   **English answer:** His lecture passed over my head.

### Within

1. **Hindi prompt:** मैं 5 मिनट में आ जाऊँगा।  
   **Romanized:** Main 5 minute mein aa jaunga.  
   **English answer:** I will come within 5 minutes.

2. **Hindi prompt:** वो 2 दिन में ही वापस आ गया है।  
   **Romanized:** Wo 2 din mein hi wapas aa gaya hai.  
   **English answer:** He has come back within just 2 days.

3. **Hindi prompt:** राम 10 मिनट के अंदर पहुँचेगा।  
   **Romanized:** Ram 10 minute ke andar pahuchega.  
   **English answer:** Ram will reach within 10 minute.

4. **Hindi prompt:** वो 2 दिन के अंदर आ रहा है।  
   **Romanized:** Wo 2 din ke andar aa raha hai.  
   **English answer:** He is coming within 2 days.

### Than

1. **Hindi prompt:** मैं तुमसे बेहतर हूँ।  
   **Romanized:** Main tumse behtar hun.  
   **English answer:** I am better than you.

2. **Hindi prompt:** हम उससे लम्बे हैं।  
   **Romanized:** Hum usse lambe hai.  
   **English answer:** We are taller than him.

### Throughout

1. **Hindi prompt:** मैंनें जिंदगी भर उसे प्यार किया।  
   **Romanized:** Maine zindagi bhar use pyaar kiya.  
   **English answer:** I loved him / her throughout my life.

2. **Hindi prompt:** हमने रात भर काम किया।  
   **Romanized:** Humne raat bhar kam kiya.  
   **English answer:** We worked throughout the night.

3. **Hindi prompt:** हमने सारी रात काम किया।  
   **Romanized:** Humne sari raat kam kiya.  
   **English answer:** We worked throughout the night.

### Without

1. **Hindi prompt:** तुम्हारे बिना कुछ नहीं हूँ।  
   **Romanized:** Main tumhare bina kuchh nahi hun.  
   **English answer:** I am nothing without you.

2. **Hindi prompt:** राम मेरे बिना नहीं जायेगा।  
   **Romanized:** Ram mere bina nahi jayega.  
   **English answer:** Ram will not go without me.

3. **Hindi prompt:** उसके बिना हम अकेले हैं।  
   **Romanized:** Uske bina ham akele hai.  
   **English answer:** We are alone without him.

### Up

1. **Hindi prompt:** कीमतें बढ़ रही हैं।  
   **Romanized:** Keematein badh rahi hain.  
   **English answer:** Prices are rising up.

2. **Hindi prompt:** गुब्बारा ऊपर जा रहा है।  
   **Romanized:** Gubbara upar ja raha hai.  
   **English answer:** Balloon is going up.

3. **Hindi prompt:** पानी का स्तर बढ़ रहा है।  
   **Romanized:** Pani ka star badh raha hai.  
   **English answer:** Water level is going up. / Water level is rising.

### Upwards

1. **Hindi prompt:** उसने पत्थर ऊपर की तरफ फेंका।  
   **Romanized:** Usne pathar upar ki taraf phenka.  
   **English answer:** He threw the stone upwards.

2. **Hindi prompt:** मैं ऊपर की ओर जा रहा हूँ।  
   **Romanized:** Main upar ki or jaa raha hun.  
   **English answer:** I am going upwards.

3. **Hindi prompt:** पत्थर को ऊपर की ओर फेंको।  
   **Romanized:** Pathar ko upar ki or phenko.  
   **English answer:** Throw the stone upwards.

4. **Hindi prompt:** गुब्बारा ऊपर की ओर गया।  
   **Romanized:** Gubbara upar ki or gaya.  
   **English answer:** Balloon went upwards.

### Downwards

1. **Hindi prompt:** उसने पत्थर नीचे की तरफ फेंका।  
   **Romanized:** Usne pathar niche ki taraf phenka.  
   **English answer:** He threw the stone downwards.

2. **Hindi prompt:** उसने नीचे की ओर देखा।  
   **Romanized:** Usne niche ki or dekha.  
   **English answer:** He looked downwards.

### Ago

1. **Hindi prompt:** वो दो साल पहले आया।  
   **Romanized:** Wo do saal pehle aaya.  
   **English answer:** He came 2 years ago.

2. **Hindi prompt:** राम ने बी.टेक 6 साल पहले किया था।  
   **Romanized:** Ram ne B Tech 6 saal pahle kiya tha.  
   **English answer:** Ram had done B.Tech 6 years ago.

3. **Hindi prompt:** मैं दो साल पहले यहाँ था।  
   **Romanized:** Main do saal pehle yahaan tha.  
   **English answer:** I was here 2 years ago. / I had been here 2 years ago.

4. **Hindi prompt:** पापा चार दिन पहले आये थे।  
   **Romanized:** Papa char din pehle aaye the.  
   **English answer:** Papa had come 4 days ago.

5. **Hindi prompt:** वो 36 साल पहले अवार्ड जीता।  
   **Romanized:** Wo 36 sal pahle award jita.  
   **English answer:** He won the award 36 years ago.

### Inside

1. **Hindi prompt:** कंप्यूटर के अंदर क्या है?  
   **Romanized:** Computer ke andar kya hai?  
   **English answer:** What is inside the computer?

2. **Hindi prompt:** वह अंदर था और मैं बाहर था।  
   **Romanized:** Wah andar tha aur Main bahar tha.  
   **English answer:** He was inside and I was outside.

3. **Hindi prompt:** उसने घर के अंदर देखा।  
   **Romanized:** Usne ghar ke andar dekha.  
   **English answer:** He looked inside the house.

4. **Hindi prompt:** मैं घर के अंदर था।  
   **Romanized:** Main ghar ke andar tha.  
   **English answer:** I was inside the house.

### Outside

1. **Hindi prompt:** वो घर के बाहर खड़ा था।  
   **Romanized:** Wo ghar ke bahar khada tha.  
   **English answer:** He was standing outside the house.

2. **Hindi prompt:** वो स्कूल परिसर के बाहर था।  
   **Romanized:** Wo school parisar ke bahar tha.  
   **English answer:** He was outside the school premises.

3. **Hindi prompt:** वो हॉस्पिटल परिसर के बाहर है।  
   **Romanized:** Wo school parisar ke bahar hai.  
   **English answer:** He is outside the hospital premises.

### Next to, Adjacent, Beside, By

1. **Hindi prompt:** वह मेरे बगल में खड़ा था।  
   **Romanized:** Vah mere bagal mein khada tha.  
   **English answer:** He was standing next to me. / He was standing adjacent to me. / He was standing beside me. / He was standing by me.

2. **Hindi prompt:** वो राम के बगल में बैठा है।  
   **Romanized:** Wo ram ke bagal mein baitha hai.  
   **English answer:** He is sitting next to Ram. / He is sitting adjacent Ram. / He is sitting beside Ram. / He is sitting by Ram.

3. **Hindi prompt:** पापा अयांश के बगल में बैठे हैं।  
   **Romanized:** Papa Ayansh ke bagal mein baithe hai.  
   **English answer:** Papa is sitting next to Ayansh.

4. **Hindi prompt:** रश्मि दिव्या के बगल में बैठी है।  
   **Romanized:** Rashmi Divya ke bagal mein baithi hai.  
   **English answer:** Rashmi is sitting adjacent Divya.

5. **Hindi prompt:** मसूद तरुण के बगल में खड़ा है।  
   **Romanized:** Masood Tarun ke bagal mein khada hai.  
   **English answer:** Masood is standing by Tarun.

6. **Hindi prompt:** राम मयंक के बगल में बैठा है।  
   **Romanized:** Ram Mayank ke bagal mein baitha hai.  
   **English answer:** Ram is sitting beside Mayank.

### Behind

1. **Hindi prompt:** मैं लाइन में राम के पीछे था।  
   **Romanized:** Main line mein Ram ke piche tha.  
   **English answer:** I was behind Ram in the queue.

2. **Hindi prompt:** उसके पीछे कोई नहीं खड़ा है।  
   **Romanized:** Uske piche koi nahi khada hai.  
   **English answer:** There is nobody standing behind him.

3. **Hindi prompt:** अविरत अयांश के पीछे पड़ा है।  
   **Romanized:** Avirat Ayansh ke piche pada hai.  
   **English answer:** Avirat is sitting behind Ayansh.

4. **Hindi prompt:** राम मयंक के पीछे बैठा है।  
   **Romanized:** Ram Mayank ke piche baitha hai.  
   **English answer:** Ram is sitting behind Mayank.

### Ahead of

1. **Hindi prompt:** मैं लाइन में राम के आगे था।  
   **Romanized:** Main line mein Ram ke aage tha.  
   **English answer:** I was ahead of Ram in the queue.

2. **Hindi prompt:** उसके आगे कोई नहीं खड़ा है।  
   **Romanized:** Uske aage koi nahi khada hai.  
   **English answer:** There is no one standing ahead of him.

3. **Hindi prompt:** अयांश अविरत के आगे बैठा है।  
   **Romanized:** Ayansh Avirat ke aage baitha hai.  
   **English answer:** Ayansh is sitting ahead of Avirat.

4. **Hindi prompt:** रश्मि दिव्या के आगे बैठी है।  
   **Romanized:** Rashmi Divya ke aage baithi hai.  
   **English answer:** Rashmi is sitting ahead of Divya.

5. **Hindi prompt:** मसूद तरुण के आगे बैठा है।  
   **Romanized:** Masood Tarun ke aage baitha hai.  
   **English answer:** Masood is sitting ahead of Tarun.

6. **Hindi prompt:** शालिनी राम के आगे बैठी है।  
   **Romanized:** Shalini Ram ke aage baithi hai.  
   **English answer:** Shalini is sitting ahead of Ram.

### Except

1. **Hindi prompt:** यह दुकान रविवार को छोड़कर सभी दिन खुलती है।  
   **Romanized:** Yeh dukaan Ravivar ko chhodkar sabhi din khulti hai.  
   **English answer:** This shop opens every day except Sunday.

2. **Hindi prompt:** तुम्हारे अलावा मैं किसी को भी डाँट सकता हूँ।  
   **Romanized:** Tumhare alawa Main kisi ko bhi dant sakta hun.  
   **English answer:** I can scold anyone except you.

3. **Hindi prompt:** मेरे पास सैमसंग के अलावा कई कम्पनियों के मोबाईल हैं।  
   **Romanized:** Mere pas Samsung ke alawa kai companiyo ke mobile hai.  
   **English answer:** Except Samsung, I have mobiles of many companies.

4. **Hindi prompt:** इसे छोड़कर मुझे कुछ भी दे दो।  
   **Romanized:** Ise chhodkar mujhe kuch bhi de do.  
   **English answer:** Give me anything except it.

### Besides

1. **Hindi prompt:** इसके अतिरिक्त कुछ और खाते हो क्या?  
   **Romanized:** Iske atirikt kuch aur khate ho kya?  
   **English answer:** Do you eat anything else besides this?

2. **Hindi prompt:** इस पैन के अलावा मेरे पास दो पैन हैं।  
   **Romanized:** Is pen ke alawa mere pas do pen hai.  
   **English answer:** Besides this pen, I have two more pens. / I have two more pens besides this pen.

3. **Hindi prompt:** अमन के अलावा मेरे पास आशीष भी तो है।  
   **Romanized:** Aman ke alawa mere pas Ashish bhi to hai.  
   **English answer:** Besides Aman, I have Ashish as well.

4. **Hindi prompt:** तुम्हारे अतिरिक्त मेरे पास कौन है?  
   **Romanized:** Tumhare atirikt mere pas kaun hai?  
   **English answer:** Who do I have besides you?

### During

1. **Hindi prompt:** छुट्टियों के दौरान मैं दिल्ली में था।  
   **Romanized:** Chhuttiyon ke dauran Main Delhi mein tha.  
   **English answer:** I was in Delhi during the vacation.

2. **Hindi prompt:** हम ब्रेक के दौरान सचिन से मिल सकते हैं।  
   **Romanized:** Hum break ke dauran Sachin se mil sakate hai.  
   **English answer:** We can meet Sachin during the break.

3. **Hindi prompt:** मैंने पढ़ाई के दौरान नौकरी की।  
   **Romanized:** Maine padhai ke dauran naukari ki.  
   **English answer:** I worked during studies.

4. **Hindi prompt:** वे दिल्ली के दौरे के दौरान आये।  
   **Romanized:** We Delhi ke daure ke dauran aaye.  
   **English answer:** He came during the visit of Delhi.

### Till / Until

1. **Hindi prompt:** मैं 9 बजे तक काम करूँगा।  
   **Romanized:** Main 9 baje tak kam karunga.  
   **English answer:** I will work till/until 9.

2. **Hindi prompt:** हम सोमवार तक ठहरे।  
   **Romanized:** Hum somvaar tak thahare.  
   **English answer:** We stayed till/until Monday.

3. **Hindi prompt:** मैं शनिवार तक वहाँ था।  
   **Romanized:** Main shanivaar tak wahan tha.  
   **English answer:** I was there till/until Saturday.

4. **Hindi prompt:** मैं 2009 तक वहाँ था।  
   **Romanized:** Main 2009 tak wahan tha.  
   **English answer:** I was there till/until 2009.

5. **Hindi prompt:** मैं जनवरी तक वहाँ था।  
   **Romanized:** Main January tak wahan tha.  
   **English answer:** I was there till/until January.

6. **Hindi prompt:** मैं यहाँ सोमवार तक हूँ।  
   **Romanized:** Main wahan somvaar tak hun.  
   **English answer:** I am here till/until Monday.

7. **Hindi prompt:** मैं 2013 तक दिल्ली में रहा।  
   **Romanized:** Main 2013 tak Delhi mein raha.  
   **English answer:** I lived in Delhi till/until 2013.

8. **Hindi prompt:** मैं 5 बजे तक घर पर था।  
   **Romanized:** Main 5 baje tak ghar par tha.  
   **English answer:** He was at home till/until 5.

9. **Hindi prompt:** उसने 3 बजे तक टीवी देखा।  
   **Romanized:** Usne 3 baje tak TV dekha.  
   **English answer:** He watched TV till/until 3 o’clock.

### Up to

1. **Hindi prompt:** मैं बस से देहरादून तक गया।  
   **Romanized:** Main bas se Dehradun tak gaya.  
   **English answer:** I just went up to Dehradun.

2. **Hindi prompt:** सीता 5 किलोमीटर तक दौड़ी।  
   **Romanized:** Sita 5 kilometer tak daudi.  
   **English answer:** Seeta ran up to 5 kilometers.

3. **Hindi prompt:** तुम्हें 18 की उम्र तक मोबाईल नहीं रखना चाहिए।  
   **Romanized:** Tumhe 18 ki umar tak mobile nahi rakhna chahiye.  
   **English answer:** You should not keep mobile up to the age of 18.

4. **Hindi prompt:** ये आप पर निर्भर है कि आप जायें या नहीं।  
   **Romanized:** Ye aap par nirbhar hai ki aap jayein ya nahi  
   **English answer:** It’s up to you whether you go or not.

5. **Hindi prompt:** ये सब आप पर है, आप देख लीजिए।  
   **Romanized:** Ye sab aap par hai, aap dekh lijiye.  
   **English answer:** It’s all up to you.

6. **Hindi prompt:** वो इस जॉब के लायक नहीं है।  
   **Romanized:** Wo is job ke layak nahi hai.  
   **English answer:** He is not up to this job.

7. **Hindi prompt:** उसका प्रदर्शन आपकी उम्मीद के मुताबिक नहीं है।  
   **Romanized:** Uska pradarshan aapke ummeed ke mutaabik nahin hai.  
   **English answer:** His performance is not up to your expectations.

### Around

1. **Hindi prompt:** लोग मेरे चारों ओर थे, फिर भी मैं तन्हा था।  
   **Romanized:** Log mere chaaron or the, fir bhi Main tanha tha.  
   **English answer:** People were there around me, yet I was lonely.

2. **Hindi prompt:** पृथ्वी सूर्य के चारों ओर घूम रही है।  
   **Romanized:** Prithvi surya ke charo or ghum rahi hai.  
   **English answer:** The Earth is revolving around the Sun.

3. **Hindi prompt:** मम्मी आस पास नहीं दिख रही हैं।  
   **Romanized:** Mummy aas paas nahi dikh rahi hai.  
   **English answer:** Mom is not being seen around. / Mom is not seen around.

4. **Hindi prompt:** तुम आस पास ही रहना मुझे तुम्हारी जरूरत पड़ सकती है।  
   **Romanized:** Tum aas pas hi rahna mujhe tumhari zarurat pad sakti hai.  
   **English answer:** You stick around! I may need you.

### Along

1. **Hindi prompt:** क्या तुम साथ आओगे?  
   **Romanized:** Kya tum saath aaoge?  
   **English answer:** Will you come along?

2. **Hindi prompt:** तुम्हें यह पैन मोबाईल के साथ मिलेगा।  
   **Romanized:** Tumhe yeh pen mobile ke saath milega.  
   **English answer:** You will get this pen along the mobile.

3. **Hindi prompt:** मेरा ऑफिस गली के बगल में है।  
   **Romanized:** Mera office gali ke bagal mein hai.  
   **English answer:** My office is along the street.

### Alongside

1. **Hindi prompt:** नदी के साथ साथ एक रोड है।  
   **Romanized:** Nadi ke saath saath ek road hai.  
   **English answer:** There is a road along the river. / There is a road alongside the river.

2. **Hindi prompt:** रोड के किनारे एक ट्रक खड़ा है।  
   **Romanized:** Road ke kinare ek truck khada hai.  
   **English answer:** A truck is parked alongside the road.

### Across

1. **Hindi prompt:** क्या तुम नदी तैर कर पार कर सकते हो?  
   **Romanized:** Kya tum nadi tair kr paar kar sakte ho?  
   **English answer:** Can you swim across the river?

2. **Hindi prompt:** एक आदमी सड़क के पार खड़ा था।  
   **Romanized:** Ek aadmi sadak ke par khada tha.  
   **English answer:** There was a person standing across the road.

3. **Hindi prompt:** मेरी दुकान सड़क के उस पार है।  
   **Romanized:** Mere dukaan sadak ke us par hai.  
   **English answer:** My shop is across the road. / There is my shop across the road.

4. **Hindi prompt:** मैं तैर के नदी पार कर सकता हूँ।  
   **Romanized:** Main tair ke nadi par kar sakata hun.  
   **English answer:** I can swim across the river.

5. **Hindi prompt:** मेरा घर सड़क के उस पार है।  
   **Romanized:** Mera ghar sadak ke us paar hai.  
   **English answer:** My house is across the road. / There is my house across the road.

6. **Hindi prompt:** वो सड़क के पार खड़ा है।  
   **Romanized:** Wo sadak ke paar khada hai.  
   **English answer:** He is standing across the road.

## Exercise 2 — Please translate the following conditional sentences into English

1. **Hindi prompt:** मेरा लैपटॉप किताब के नीचे था।  
   **Romanized:** Mera laptop kitab ke niche tha.  
   **English answer:** My laptop was beneath my notebook.

2. **Hindi prompt:** टेबल के नीचे चूहा छुपा है।  
   **Romanized:** Table ke niche chooha chupa hai.  
   **English answer:** A mouse is hiding under the table.

3. **Hindi prompt:** ये किताब दिखने में उस किताब से बेहतर है।  
   **Romanized:** Ye kitaab dikhne me us kitaab se behtar hai.  
   **English answer:** This book is above that book in looks.

4. **Hindi prompt:** खाँसते वक्त अपने हाथ से मुँह ढका करो।  
   **Romanized:** Khaanste vakt apne haath se muh dhaka karo.  
   **English answer:** Put a hand over your mouth when you cough.

5. **Hindi prompt:** मैं अध्यापक के सामने खड़ा था।  
   **Romanized:** Main adhyapak ke samne khada tha.  
   **English answer:** I was standing opposite the teacher.

6. **Hindi prompt:** इस जगह के उस पार कुछ दिखाई नहीं देगा।  
   **Romanized:** Iss jagah ke uss paar kuch dikhayi nahi dega.  
   **English answer:** There is nothing visible beyond this point.

7. **Hindi prompt:** खेत के पार एक शहर बसा है।  
   **Romanized:** Khet ke paar ek shahar bsa hai.  
   **English answer:** A city is established across this field.

8. **Hindi prompt:** चूहा छेद से चुपके से निकल रहा है।  
   **Romanized:** Chooha ched se chupke se nikal rha hai.  
   **English answer:** The mouse is sneaking through the hole.

9. **Hindi prompt:** आज रात मेरे घर पे खाने का प्रोग्राम बनाते हैं।  
   **Romanized:** Aaj raat mere ghar pe khane ka program banate hain.  
   **English answer:** Let’s plan a dinner tonight at my place.

10. **Hindi prompt:** वह मेरे बगल में खड़ी थी।  
   **Romanized:** Wah mere bagal me khadi thi.  
   **English answer:** She was standing by me.

11. **Hindi prompt:** वह कल तक चेन्नई पहुँच जाएगी।  
   **Romanized:** Wah kal tak Chennai jayegi.  
   **English answer:** She will reach Chennai by tomorrow.

12. **Hindi prompt:** गरीब को हवाईजहाज से सफर करने की सौभाग्य नहीं है।  
   **Romanized:** Gareeb ko hawaijahaj se safar kane ka saubhagya nahi hai.  
   **English answer:** The poor don’t have the privilege to travel by airplane.

13. **Hindi prompt:** अपराधियों को पुलिस द्वारा रोका गया।  
   **Romanized:** Apradhiyon ko police dwara roka gaya.  
   **English answer:** Criminals were stopped by the police.

14. **Hindi prompt:** उसकी हिम्मत नहीं कि वह यह मेरे सामने बोल दे।  
   **Romanized:** Uski himmat nahi ki wah yeh mere saamne bol de.  
   **English answer:** She dare not speak this before me.

15. **Hindi prompt:** गेंद अब तुम्हारे पाले में है।  
   **Romanized:** Gend ab tumhare pale mein hai.  
   **English answer:** The ball is in your court.

16. **Hindi prompt:** गंगा नदी हिमालय से निकलती हैं।  
   **Romanized:** Ganga nadi Himalaya se nikalti hain.  
   **English answer:** The Ganges originate from the Himalayas.

17. **Hindi prompt:** उसने अपने पुराने कपड़ों के बदले में सिलाई की मशीन ले ली।  
   **Romanized:** Usne apne purane kapdon ke badle me silai ki machine le li.  
   **English answer:** He exchanged his old clothes for a sewing machine.

18. **Hindi prompt:** देश ने आज़ादी के बाद से बहुत ही शानदार विकास किया।  
   **Romanized:** Desh ne azaadi ke baad se bahut hi shaandar vikaas kiya.  
   **English answer:** The country has seen great development since independence.

19. **Hindi prompt:** यह गलती अब से दोबारा नहीं होनी चाहिए।  
   **Romanized:** Yeh galti ab se dobara nahi honi chahiye.  
   **English answer:** This mistake should not be repeated from now onwards.

20. **Hindi prompt:** मेट्रो से कभी जल्दबाज़ी में मत उतरा करो।  
   **Romanized:** Metro se kabhi jaldbazi mein mat utra karo.  
   **English answer:** Never get off the metro in a hurry.

21. **Hindi prompt:** उसके ग्रेजुएशन करने के बाद से ही मंदी शुरू हो गयी।  
   **Romanized:** Uske graduation karne ke saath hi mandi shuru ho gayi.  
   **English answer:** There has been a recession since he completed graduation.

22. **Hindi prompt:** सैनिक देश के लिए अपनी जान न्योछावर कर देते हैं।  
   **Romanized:** Sainik desh ke liye apni jaan nyochavar kar dete hain.  
   **English answer:** Soldiers sacrifice their lives for the nation.

23. **Hindi prompt:** मेसी जून में पैदा हुआ था।  
   **Romanized:** Messi june mein paida hua tha.  
   **English answer:** Messi was born in June.

24. **Hindi prompt:** मैं आज शाम को अपना जन्मदिन अपने दोस्तों के साथ मनाऊँगी।  
   **Romanized:** Main aaj shaam ko apna janmdin apne doston ke saath manaungi.  
   **English answer:** I will celebrate my birthday with my friends in the evening.

25. **Hindi prompt:** वह एक पांच सितारा होटल में पार्टी की व्यवस्था करवा रहा है।  
   **Romanized:** Wah ek paanch sitara hotel mein party ki vyavastha karva raha hai.  
   **English answer:** He is hosting a party in a five-star hotel.

26. **Hindi prompt:** किसी भी विषय की गहराई में जाना चाहिए।  
   **Romanized:** Kisi bhi vishya ki gehrai mein jaana chahiye.  
   **English answer:** Try to go into the depth of a topic.

27. **Hindi prompt:** तुम ऑफिस में 30 मिनट पहले ही आ गए।  
   **Romanized:** Tum office mein thirty minute pehle hi aa gaye.  
   **English answer:** You arrived in the office 30 minutes before time.

28. **Hindi prompt:** मैं पार्क से आने के बाद अपना होम वर्क पूरा करुँगा।  
   **Romanized:** Main park se aane ke baad apna home work pura karunga.  
   **English answer:** I'll complete my homework after I come back from the park.

29. **Hindi prompt:** उपहार उसकी बहन द्वारा भेजा गया था।  
   **Romanized:** Uphar uski behen dwara bheja gaya tha.  
   **English answer:** The gift had been sent by his sister.

30. **Hindi prompt:** हम शाम तक ये काम खत्म कर देंगे।  
   **Romanized:** Hum shaam tak ye kaam khatm kar denge.  
   **English answer:** We will complete this task by the evening.

31. **Hindi prompt:** मेरा भाई माँ के बगल में खड़ा है।  
   **Romanized:** Mera bhai maan ke bagal me khada hai.  
   **English answer:** My brother is standing by my mom.

32. **Hindi prompt:** वह काँटे चम्मच से मैग्गी खा रहा था।  
   **Romanized:** Wah kaante chammach se maggi kha raha tha.  
   **English answer:** He was eating Maggi with a fork.

33. **Hindi prompt:** मैं अपना पूरा जीवन तुम्हारे साथ बिताना चाहती हूँ।  
   **Romanized:** Main apna pura jeevan tumhare saath bitana chaahti hoon.  
   **English answer:** I want to spend my entire life with you.

34. **Hindi prompt:** विनोद एक कारखाने में काम करता है।  
   **Romanized:** Vinod ek karkhane mein kaam karta hai.  
   **English answer:** Vinod works in a factory.

35. **Hindi prompt:** यह सब्ज़ी चालीस रूपए किलो में बिक रही है।  
   **Romanized:** Yeh sabzi chaalis rupay kilo mein bik rahi hai.  
   **English answer:** This vegetable is selling at Rs. 40 per kg.

36. **Hindi prompt:** पेट्रोल इतने ज़्यादा दाम पर बिक रहा है।  
   **Romanized:** Petrol itne zyada daam par bik raha hai.  
   **English answer:** The petrol is being sold at such a high rate.

37. **Hindi prompt:** कार टनल से गुज़र रही है।  
   **Romanized:** Car tunnel se guzar rhi hai.  
   **English answer:** The Car is passing through a tunnel.

38. **Hindi prompt:** क्या तुम कभी उन पहाड़ियों के उस पार गए हो?  
   **Romanized:** Kya tum kabhi unn pahadiyon ke us par gaye ho?  
   **English answer:** Have you ever gone beyond those hills?

39. **Hindi prompt:** माँ से रिश्ता बाकी सब चीज़ों से बढ़कर होता है।  
   **Romanized:** Maa se rishta baki sb chizon se badhkar hota hai.  
   **English answer:** The relationship with the mother is beyond all other things.

40. **Hindi prompt:** तुम वाई फाई के द्वारा सन्देश भेज सकते हो।  
   **Romanized:** Tum wifi ke dwara sandesh bhej skte ho.  
   **English answer:** You can send messages via wifi.

41. **Hindi prompt:** मैं जैसा सोचता हूँ उसका उल्टा ही हो जाता है।  
   **Romanized:** Main jaisa sochta hun uska ulta hee ho jata hai.  
   **English answer:** The opposite happens regardless of whatever I plan or think.

42. **Hindi prompt:** उसने मेरी उम्मीद से बेहतर प्रदर्शन किया।  
   **Romanized:** Usne meri umeed se behtar pradarshan kiya.  
   **English answer:** He performed above my expectation.

43. **Hindi prompt:** उसके दोस्त का घर एक अभिनेता के घर के नीचे है।  
   **Romanized:** Uske dost ka ghar ek abhineta ke ghar ke niche hai.  
   **English answer:** His friend’s house is underneath an actor’s house.

44. **Hindi prompt:** बारिश की बूँदें ज़मीन पर गिर रही हैं।  
   **Romanized:** Baarish ki boondein zameen par gir rahi hain.  
   **English answer:** Raindrops are falling down on the ground.

45. **Hindi prompt:** अमीर लोग छत के नीचे रहते हैं लेकिन गरीब के पास छत भी नहीं है।  
   **Romanized:** Ameer log chat ke niche rehte hain lekin gareeb ke paas chhat bhi nhi hai.  
   **English answer:** The Rich live under the roof but the poor don't even have a house.

46. **Hindi prompt:** हुगली नदी के ऊपर हावड़ा ब्रिज है।  
   **Romanized:** Hoogli nadi ke upar Howrah bridge hai.  
   **English answer:** Howrah bridge is over the Hooghly river.

47. **Hindi prompt:** मेरी बहन बरगद के पेड़ के नीचे बैठी है।  
   **Romanized:** Meri bhen bargad ke ped ke niche baithi hai.  
   **English answer:** My sister is sitting under the Banyan tree.

48. **Hindi prompt:** मेरा शहर समुद्र तल से 2000 मीटर ऊपर स्थित है।  
   **Romanized:** Mera shahar samudra tal se 2000 meter upar sthit hai.  
   **English answer:** My city is 2000 meters above sea level.

49. **Hindi prompt:** वो 2 साल से ज़्यादा समय से यहाँ पर है।  
   **Romanized:** Vo do saal se zyada samay se yahaan par hai.  
   **English answer:** He has been here for over 2 years.

50. **Hindi prompt:** पानी की सतह के नीचे क्या छुपा है?  
   **Romanized:** Pani ki satah ke niche kya chhupa hai?  
   **English answer:** What is hidden beneath the surface of the water?

51. **Hindi prompt:** तुम्हारा प्रदर्शन उम्मीद से कम था।  
   **Romanized:** Tumhara pradarshan umeed se kam tha.  
   **English answer:** Your performance was below expectations.

52. **Hindi prompt:** भविष्य, सिद्धार्थ और मयंक के बीच में बैठा है।  
   **Romanized:** Bhavishya, Siddharth aur Mayank ke beech me betha hai.  
   **English answer:** Bhavishya is sitting between Siddharth & Mayank.

53. **Hindi prompt:** इस प्लेट पर कोई कपड़ा रख दो।  
   **Romanized:** Is plate par koi kapda rakh do.  
   **English answer:** Put some cloth over this plate.

54. **Hindi prompt:** उसका नाम स्मृति के नाम से लिस्ट में ऊपर है।  
   **Romanized:** Uska naam samriti ke naam se list me upar hai.  
   **English answer:** His name is above Smriti’s name on the list.

55. **Hindi prompt:** मेरा बेटा अपनी माँ की कही बात का उल्टा काम ही करता है।  
   **Romanized:** Mera beta apni maa ki kahi baat ka ulta kaam hi krta hai.  
   **English answer:** My son does the opposite of what her mother says.

56. **Hindi prompt:** हम नागपुर से होते हुए मुंबई आये।  
   **Romanized:** Hum Nagpur se hote hue Mumbai aaye.  
   **English answer:** We came to Mumbai via Nagpur.

57. **Hindi prompt:** यह विज्ञान से परे है। (यानि विज्ञान के पास भी इसका जवाब नहीं है)  
   **Romanized:** Yeh vigyaan se pare hai. {Yaani vigyaan ke paas bhi iska jawab nahi hai.}  
   **English answer:** This is something beyond science.

58. **Hindi prompt:** यह बस कानपुर से होते हुए सहारनपुर जाएगी।  
   **Romanized:** Yeh bus Kanpur se hote hue Saharanpur jayegi.  
   **English answer:** This bus will go to Kanpur via Saharanpur.

59. **Hindi prompt:** मैं खिड़की से झाँक रहा हूँ।  
   **Romanized:** Main khidki se jhaank rha hun.  
   **English answer:** I am peeping through the window.

60. **Hindi prompt:** मुझे दोपहर बारह बजे मिलो।  
   **Romanized:** Mujhe dopahar barah baje milo.  
   **English answer:** Meet me at 12 noon.

61. **Hindi prompt:** कोशिश करना की मुझसे 5 बजे मिलो।  
   **Romanized:** Koshish karna ki mujh se 5 baje milo.  
   **English answer:** Try to meet me at 5 pm.

62. **Hindi prompt:** वह स्कूल 7 बजे आएगी।  
   **Romanized:** Wah school 7 baje aayegi.  
   **English answer:** She will come to school at 7 AM.

63. **Hindi prompt:** सेना ने आतंकवादियों को मशीन गन से मारा।  
   **Romanized:** Sena ne aatankvadiyon ko machine gun se maara.  
   **English answer:** The army killed terrorists with a machine gun.

64. **Hindi prompt:** घर की सफाई नौकर द्वारा की जा चुकी है।  
   **Romanized:** Ghar ki safai naukar dwara ki ja chuki hai.  
   **English answer:** The house has been cleaned by the servant.

65. **Hindi prompt:** मेरे पापा ने तीन बार मना कर दिया है, पर मैं अभी भी उनके पीछे पड़ा हुआ हूँ।  
   **Romanized:** Mere papa ne teen baar mna kar diya hai, par main abhi bhi unke piche pada hua hoon.  
   **English answer:** My father has denied me permission thrice, but I'm still after him.

66. **Hindi prompt:** सर आपसे मीटिंग खत्म होने के बाद ही बात करेंगे।  
   **Romanized:** Sir aapse meeting khatm hone ke baad hi baat karenge.  
   **English answer:** Sir will talk to you only after the meeting gets over.

67. **Hindi prompt:** तुम्हारा चचेरे भाई का जन्म तुम्हारे इस दुनिया में आने से पहले हुआ था।  
   **Romanized:** Tumhare chachere bhai ka janm tumhare is duniya mein aane se pehle hua tha.  
   **English answer:** Your cousin was born before you came into this world.

68. **Hindi prompt:** महान वैज्ञानिक अल्बर्ट आइंस्टीन का जन्म जर्मनी में हुआ था।  
   **Romanized:** Mahan vaigyanik Albert Einstein ka janm Germany mein hua tha.  
   **English answer:** The great scientist Albert Einstein was born in Germany.

69. **Hindi prompt:** आई पी एल के सबसे महंगे खिलाड़ी को बैंगलोर ने 16 करोड़ में ख़रीदा था।  
   **Romanized:** IPL ke sabse mehange khilaadi ko Bangalore ne 16 karod me khareeda tha.  
   **English answer:** The costliest player in IPL was bought by Bangalore for 16 crores.

70. **Hindi prompt:** रणवीर पैराग्लाइडिंग करने के लिए हवाईजहाज से कूदा।  
   **Romanized:** Ranveer paragliding karne ke liye hawaijahaj se kooda.  
   **English answer:** Ranveer jumped off the plane for paragliding.

71. **Hindi prompt:** तुम किस स्कूल से आये हो?  
   **Romanized:** Tum kis school se aaye ho?  
   **English answer:** Which school have you come from?

72. **Hindi prompt:** वे जिम से कसरत करने के बाद आये।  
   **Romanized:** We gym se kasrat karne ke baad aaye.  
   **English answer:** They came after doing exercise from the gym.

73. **Hindi prompt:** मैं दोपहर से लिख रहा हूँ।  
   **Romanized:** Main dopahar se likh raha hoon.  
   **English answer:** I have been writing since afternoon.

74. **Hindi prompt:** रोहन ने लैपटॉप को अपने डेस्क से उठाया।  
   **Romanized:** Rohan ne laptop ko apne desk se uthaya.  
   **English answer:** Rohan picked his laptop off his desk.

75. **Hindi prompt:** फुटबॉल की प्रैक्टिस अगले सप्ताह से शुरू होगी।  
   **Romanized:** Football ki practice agle saptah se shuru hogi.  
   **English answer:** The football practice will start from the next week.

76. **Hindi prompt:** मैंने राहुल से दुर्घटना के बारे में सुना।  
   **Romanized:** Maine Rahul se durghatna ke baare mein suna.  
   **English answer:** I got to know about the accident from Rahul.

77. **Hindi prompt:** राकेश ऑफिस के लिए आधे घंटे में निकलेगा।  
   **Romanized:** Rakesh office ke liye aadhe ghante me niklega.  
   **English answer:** Rakesh will leave for office in half an hour.

78. **Hindi prompt:** वह बुद्धिमान है इसके लक्षण उसने बचपन से ही दिखाना शुरू कर दिए थे।  
   **Romanized:** Wah buddhimaan hai iske lakshan usne bachpan se hi dikhana shuru kar diye the.  
   **English answer:** He showed signs of being a prodigy since he was a child.

79. **Hindi prompt:** इतने लम्बे समय से गेम क्यों खेल रहे हो?  
   **Romanized:** Itne lambe samay se game kyon khel rahe ho?  
   **English answer:** Why have you been playing games for this long?

80. **Hindi prompt:** एक माँ अपने बच्चों के लिए सर्वश्रेष्ठ देने की कोशिश करती है।  
   **Romanized:** Ek maa apne bacche ke liye sarvshresth dene ki koshish karti hai.  
   **English answer:** A mother tries to do her best for her children.

81. **Hindi prompt:** मैंने सब्ज़ी फल की दुकान से ताज़े फल बहुत ही कम दाम में ले लिए।  
   **Romanized:** Maine sabzi-fal ki dukaan se taaze fal bahut hi kam daam me le liye.  
   **English answer:** I purchased fresh fruits from the grocery store for just a few bucks.

82. **Hindi prompt:** उसने मार्च 2014 में नौकरी छोड़ दी थी।  
   **Romanized:** Usne march 2014 mein naukri chhor di thi.  
   **English answer:** She left the job in march 2014.

83. **Hindi prompt:** भारत एक महाद्वीप में स्थित है जिसका नाम एशिया है।  
   **Romanized:** Bharat ek mahadweep me sthit hai jiska naam Asia hai.  
   **English answer:** India is situated in the continent named Asia.

84. **Hindi prompt:** यह विमान मुंबई अपने निर्धारित समय से पहले पहुँच जायेगा।  
   **Romanized:** Yeh wiman mumbai apne nirdharit samay se pehle pahunch jayega.  
   **English answer:** This flight will reach Mumbai before its scheduled time.

85. **Hindi prompt:** मयंक के जाने से पहले विस्मय आ जायेगा।  
   **Romanized:** Mayank ke jaane se pehle Vismay aa jayega.  
   **English answer:** Vismay will come before Mayank leaves.

86. **Hindi prompt:** गरिमा अपनी माँ के सामने बैठी थी।  
   **Romanized:** Garima apni maa ke samne baithi thi.  
   **English answer:** Garima was sitting before her mother.

87. **Hindi prompt:** विराट अपने दोस्तों के बाद पहुँचा।  
   **Romanized:** Virat apne doston ke baad pahuncha.  
   **English answer:** Virat reached after his friends.

88. **Hindi prompt:** शौर्य एक प्रोजेक्ट में मदद के लिए अपने अध्यापक के पीछे पड़ा था।  
   **Romanized:** Shaurya ek project mein madad ke liye adhyapak ke piche pada tha.  
   **English answer:** Shaurya was after her professor for getting some help regarding a project.

89. **Hindi prompt:** जब उस लड़के ने पत्थर मारा तो कुत्ते उसके पीछे पड़ गए।  
   **Romanized:** Jab us ladke ne pathar maara to kutte uske piche pad gaye.  
   **English answer:** The dogs were after the boy when he threw a stone at them.

90. **Hindi prompt:** यह कविता शेक्सपियर द्वारा लिखी गयी थी।  
   **Romanized:** Ye kavita Shakespeare dwara likhi gayi thi.  
   **English answer:** The poem had been written by Shakespeare.

91. **Hindi prompt:** यह तस्वीर एक अनजान व्यक्ति ने ली।  
   **Romanized:** Yeh tasveer ek anjaan vyakti ne li.  
   **English answer:** The picture was taken by a stranger.

92. **Hindi prompt:** उसकी बेटी बस से स्कूल जाती है।  
   **Romanized:** Uski beti bus se school jaati hai.  
   **English answer:** His daughter goes to school by bus.

93. **Hindi prompt:** तुम खत को स्पीड पोस्ट से भेज सकते हो।  
   **Romanized:** Tum khat ko speed post se bhej sakte ho.  
   **English answer:** You can send a letter via speed post.

94. **Hindi prompt:** वह घर पहाड़ी के सामने है।  
   **Romanized:** Veh ghar pahadi ke samne hai.  
   **English answer:** That house is opposite the hill.

95. **Hindi prompt:** रोहन की सोच मेरे बिलकुल विपरीत है।  
   **Romanized:** Rohan ki soch mere bilkul viprit hai.  
   **English answer:** Rohan’s thinking is opposite mine.

96. **Hindi prompt:** यह मेरी पहुँच में नहीं है।  
   **Romanized:** Yeh meri pahunch me nahi hai.  
   **English answer:** This is beyond my reach.

97. **Hindi prompt:** प्यार पैसे से ऊपर है। यानि प्यार पहले, पैसा बाद में।  
   **Romanized:** Pyar paise se upar hai. Yani pyar pehle, paisa baad me.  
   **English answer:** Love is above all. It means love first, then money.

98. **Hindi prompt:** वह अपने छाते के नीचे रहकर बारिश से बच गया।  
   **Romanized:** Veh apne chhate ke niche rehkar baarish se bach gya.  
   **English answer:** He escaped from the rain by staying under his umbrella.

99. **Hindi prompt:** सब्जियों के दाम कम हो रहे हैं।  
   **Romanized:** Sabziyon ke daam kam ho rahe hain.  
   **English answer:** Rates of the vegetables are going down.

100. **Hindi prompt:** उसका नाम मेरिट लिस्ट में मेरे नाम के नीचे है।  
   **Romanized:** Uska naam merit list me mere naam ke niche hai.  
   **English answer:** His name is below my name in the merit list.

101. **Hindi prompt:** वह लकड़ी के ऊपर से कूद गया।  
   **Romanized:** Veh lakdi ke upar se kood gya.  
   **English answer:** He jumped over the wood.

102. **Hindi prompt:** कारखाना हॉस्पिटल के सामने है।  
   **Romanized:** Carkhana hospital ke samne hai.  
   **English answer:** The car factory is opposite to the hospital.

103. **Hindi prompt:** हवाईजहाज पहाड़ों के बीच से गुज़र रहा था।  
   **Romanized:** Hawaijahaj pahadon ke beech se guzar raha tha.  
   **English answer:** The airplane was going through the mountains.

104. **Hindi prompt:** जिस क्षण से वह स्कूल में आया है उस समय से उसने नाक में दम कर रखा है।  
   **Romanized:** Jis kshan se wah school me aaya hai us samay se usne naak me dam kar rakha hai.  
   **English answer:** He has been a constant nuisance from the moment he joined the school.

105. **Hindi prompt:** मैंने ये ज़रूरी जानकारी गूगल से ली।  
   **Romanized:** Maine ye zaroori jankari google se li.  
   **English answer:** I got the required details from Google.

106. **Hindi prompt:** सरकार को ग़रीबों के लिए कुछ करना चाहिए।  
   **Romanized:** Sarkaar ko gareebon ke liye kuch karna chahiye.  
   **English answer:** The government should do something for the poor.

107. **Hindi prompt:** मैं अगले सप्ताह से अपना काम करूँगा।  
   **Romanized:** Main agle saptah se kaam karunga.  
   **English answer:** I will start my work from the next week.

108. **Hindi prompt:** शेर की पूँछ पानी के नीचे थे लेकिन आँखें ऊपर थी।  
   **Romanized:** Sher ki poonch paani ke niche thi lekin aankhein upar thi.  
   **English answer:** Lion’s tail was below water but his eyes were above.

109. **Hindi prompt:** डैम में पानी का स्तर नीचे जा रहा है।  
   **Romanized:** Dam mein pani ka star niche ja raha hai.  
   **English answer:** The water level in the dam is going down.

110. **Hindi prompt:** हमारे सर के ऊपर छत है।  
   **Romanized:** Hamare sar ke upar chhat hai.  
   **English answer:** We have a roof over our heads.

111. **Hindi prompt:** मैं मुश्किल वक़्त से गुज़रा हूँ।  
   **Romanized:** Main mushkil waqt se guzara hoon.  
   **English answer:** I have gone through tough times.

112. **Hindi prompt:** उसने अपनी आवाज़ से सबका दिल जीत लिया।  
   **Romanized:** Usne apni aawaz se sabka dil jeet liya.  
   **English answer:** She won hearts with her voice.

113. **Hindi prompt:** मैंने हवाईजहाज से यात्रा की।  
   **Romanized:** Maine hawaijahaj se yatra ki.  
   **English answer:** I travelled by Aeroplane.

114. **Hindi prompt:** इस झरझरी दीवार से पानी जा रहा है।  
   **Romanized:** Iss jhajhre deewar se paani ja rha hai.  
   **English answer:** The water is passing through this porous wall.

115. **Hindi prompt:** उसके विचार हमसे बिलकुल उलट हैं।  
   **Romanized:** Uske vichar humse bilkul ulat hain.  
   **English answer:** Her thoughts are opposite to ours.

116. **Hindi prompt:** पहाड़ के उस पार नदी बहती है।  
   **Romanized:** Pahad ke uss paar nadi behti hai.  
   **English answer:** A river flows across the hills.

117. **Hindi prompt:** नदी के उस पार एक गाँव है।  
   **Romanized:** Nadi ke uss paar ek gaanv hai.  
   **English answer:** There is a village across the river.

118. **Hindi prompt:** मैं तुम्हारा स्वागत करने के लिए हवाईअड्डे पे रहूँगा।  
   **Romanized:** Main tumhare swagat karne ke liye hawaiadde pe rahunga.  
   **English answer:** I’ll be at the airport to welcome you.

119. **Hindi prompt:** मैं आलू 30 रु किलो खरीद रहा हूँ।  
   **Romanized:** Main aloo 30 rupay kilo khareed raha hoon.  
   **English answer:** I am buying potatoes at Rs 30 per kg.

120. **Hindi prompt:** मैं बारह बजे तक आने की कोशिश करूँ ूगा।।  
   **Romanized:** Main barah baje tak aane ki koshish karunga.  
   **English answer:** I’ll try to reach you by 12 pm.

121. **Hindi prompt:** मैं लोकल ट्रेन से आऊँगा।  
   **Romanized:** Main local train se aaunga.  
   **English answer:** I’ll come by the local train.

122. **Hindi prompt:** उसने नदी में डुबकी लगाई।  
   **Romanized:** Usne nadi mein dubki lagai.  
   **English answer:** She dived into the river.

123. **Hindi prompt:** यह वह दुकान है जहाँ से मैं दूध लेता हूँ।  
   **Romanized:** Yeh wah dukaan hai jahan se main doodh leta hoon.  
   **English answer:** That is the shop from where I generally buy milk.

124. **Hindi prompt:** वो मेरे पास सुझाव के लिए आयी।  
   **Romanized:** Wo mere pas sujhav ke liye aayi.  
   **English answer:** She came to me for a suggestion.

125. **Hindi prompt:** भविष्य तीन घंटे से खेल रहा है।  
   **Romanized:** Bhavishya teen ghante se khel raha hai.  
   **English answer:** Bhavishya has been playing for 3 hours.

126. **Hindi prompt:** वह शनिवार से इस पर काम कर रहा है।  
   **Romanized:** Wah shanivaar se is par kaam kar raha hai.  
   **English answer:** He has been working on it since Saturday.

127. **Hindi prompt:** मैं यूरोप में इंजीनियरिंग की पढ़ाई करूँ ल्ूगा।।  
   **Romanized:** Main Europe mein engineering ki padhai karunga.  
   **English answer:** I will study engineering in Europe.

128. **Hindi prompt:** वह इस मामले में नंदिनी के साथ है।  
   **Romanized:** Wah is maamle mein nandini ke saath hai.  
   **English answer:** He is with Nandini in this matter.

129. **Hindi prompt:** हम आपके साथ रहेंगे।  
   **Romanized:** Hum aapke saath rahenge.  
   **English answer:** We will be/stay with you.

130. **Hindi prompt:** मैं 7 बजे तक निकल जाउंगी।  
   **Romanized:** Main 7 baje tak nikal jaungi.  
   **English answer:** I will leave by 7 o’clock.

131. **Hindi prompt:** तुम्हें जाना चाहिए इससे पहले की तुम्हारी ट्रैन छूट जाए।  
   **Romanized:** Tumhe jaana chahiye isse pehle tumhari train chhoot jaye.  
   **English answer:** You should leave before you miss your train.

132. **Hindi prompt:** मुझे तुम्हारे लैपटॉप में कोई गेम नहीं मिला।  
   **Romanized:** Mujhe tumhare laptop mein koi game nahi mila.  
   **English answer:** I found no games on your laptop.

133. **Hindi prompt:** उदित ने Rs 4000 में साइकिल खरीदी।  
   **Romanized:** Udit ne Rs 4000 mein bicycle khareedi.  
   **English answer:** Udit purchased a bicycle for Rs 4000.

134. **Hindi prompt:** दूध को गिलास में डालो।  
   **Romanized:** Doodh ko gilas me daalo.  
   **English answer:** Pour the milk into the glass.

135. **Hindi prompt:** उसने 105 रूपए में एक किताब खरीदी।  
   **Romanized:** Usne 105 rupay me ek kitaab khareedi.  
   **English answer:** She bought a book for Rs. 105.

136. **Hindi prompt:** काम वाली टेबल से धूल हटा रही है।  
   **Romanized:** Kaam wali table se dhool hata rahi hai.  
   **English answer:** Maid is wiping the dust off the table.

137. **Hindi prompt:** इसके बाद मुझे कोई परेशानी मत बताना।  
   **Romanized:** Iske baad mujhe koi pareshani mat batana.  
   **English answer:** Don’t tell me the problem after this.

138. **Hindi prompt:** उसे किताब में एक वाक्य मिला है।  
   **Romanized:** Use kitab mein ek vakya mila hai.  
   **English answer:** He has found a sentence in the book.

139. **Hindi prompt:** वो यह ब्रेक के बाद खायेगी।  
   **Romanized:** Woh yeh break ke baad khayegi.  
   **English answer:** She will eat it after the break.

140. **Hindi prompt:** वह अमेरिका से आये हैं।  
   **Romanized:** Wah America se aaye hain.  
   **English answer:** They have arrived from the United States.

141. **Hindi prompt:** वह लम्बे समय से एक रिश्ते में है।  
   **Romanized:** Wah lambe samay se ek rishte me hai.  
   **English answer:** He has been in a relationship for a long.

142. **Hindi prompt:** इस व्यंजन में नमक मत डालो।  
   **Romanized:** Is vyanjan mein namak mat dalo.  
   **English answer:** Don’t mix salt in this dish.

143. **Hindi prompt:** डाइनिंग टेबल से प्लेट हटा दो।  
   **Romanized:** Dining table se plate hata do.  
   **English answer:** Move the plate off the dining table.

144. **Hindi prompt:** रोहित बारह बजे से पढ़ाई करेगा।  
   **Romanized:** Rohit barah baje se padhai karega.  
   **English answer:** Rohit will start studying from 12 o’clock.

145. **Hindi prompt:** वो कमरे में जा रहा है।  
   **Romanized:** Woh kamre mein ja raha hai.  
   **English answer:** He is going into the room.

146. **Hindi prompt:** मैं यह फिल्म दो घंटे से देख रहा हूँ।  
   **Romanized:** Main yeh film do ghante se dekh raha hoon.  
   **English answer:** I have been watching this movie for 2 hours.

147. **Hindi prompt:** रोहन बच्चे के बगल में खड़ा था।  
   **Romanized:** Rohan bacche ke bagal mein khada tha.  
   **English answer:** Rohan was standing by the kid.

148. **Hindi prompt:** दुकान पर ठीक 9 बजे पहुँच जाना।  
   **Romanized:** Dukan par theek 9 baje pahunch jaana.  
   **English answer:** Reach the Shop at sharp 9 am.

149. **Hindi prompt:** तकिया दो कुशन के बीच में है।  
   **Romanized:** Takiya do cushion ke beech mein hai.  
   **English answer:** Pillow is lying between two cushions.

150. **Hindi prompt:** यह मेरी प्रतिष्ठा से नीचे का काम है।  
   **Romanized:** Yeh meri pratishtha se niche ka kam hai.  
   **English answer:** This work is below my dignity.

151. **Hindi prompt:** यह गेंद सर के ऊपर से निकल गयी।  
   **Romanized:** Yeh gend sar ke upar se nikal gayi.  
   **English answer:** This ball went over my head.

152. **Hindi prompt:** तुम मेरे अंडर/ नीचे काम करते हो।  
   **Romanized:** Tum mere under/niche kaam karte ho.  
   **English answer:** You work under me.

153. **Hindi prompt:** उस ढक्कन के नीचे कुछ है।  
   **Romanized:** Uss dhakkan ke niche kuch hai.  
   **English answer:** There is something beneath the lid.

154. **Hindi prompt:** स्टॉक बाजार गिर रहा है।  
   **Romanized:** Stock bazar gir raha hai.  
   **English answer:** The stock market is falling down.

155. **Hindi prompt:** केवल उसका सिर पानी के ऊपर था।  
   **Romanized:** Kewal uska sir pani ke upar tha.  
   **English answer:** Only her head was above water.

156. **Hindi prompt:** ख़ुशी के पार कुछ नहीं है या ख़ुशी के बराबर कुछ नहीं है।  
   **Romanized:** Khushi ke paar kuch nhi hai ya khushi ke barabar kuch nhi hai.  
   **English answer:** There is nothing beyond happiness

157. **Hindi prompt:** वहाँ 50 से ज़्यादा लोग खड़े थे।  
   **Romanized:** Vahaan 50 se zyada log khade the.  
   **English answer:** There were over 50 people standing there.

158. **Hindi prompt:** ज्ञान सबसे ऊपर है।  
   **Romanized:** Gyan sabse upar hai.  
   **English answer:** Knowledge is above all.

159. **Hindi prompt:** खेल का मैदान तुम्हारे घर के सामने है।  
   **Romanized:** Khel ka maidan tumhare ghar ke samne hai.  
   **English answer:** The playground is opposite your house.

160. **Hindi prompt:** आपकी सोच पूरी दुनिया से उलट है।  
   **Romanized:** Apki soch puri duniya se ulat hai.  
   **English answer:** Your thoughts are opposite to the entire world.

161. **Hindi prompt:** पत्थरों के नीचे पानी है।  
   **Romanized:** Pattharon ke niche paani hai.  
   **English answer:** There is water, beneath the rocks.

162. **Hindi prompt:** इस घर के उस पार एक गुफा है।  
   **Romanized:** Iss ghar ke uss paar ek gufa hai.  
   **English answer:** There is a cave beyond this house.

163. **Hindi prompt:** विक्रेता इस ज़मीन को खरीदने लायक दाम पे बेचेगा।  
   **Romanized:** Vikreta is zameen ko khareedne layak daam pe bechega.  
   **English answer:** The vendor will sell this land at an affordable rate.

164. **Hindi prompt:** यह मेरी कल्पना से परे है।  
   **Romanized:** Yeh meri kalpana se pare hai.  
   **English answer:** This is beyond my imagination.

165. **Hindi prompt:** उसकी गाड़ी स्कूल के सामने खड़ी है।  
   **Romanized:** Uski gadi school ke samne khadi hai.  
   **English answer:** His car is parked opposite the school.

166. **Hindi prompt:** उस दीवार के उस पार क्या है?  
   **Romanized:** Uss diwar ke uss paar kya hai?  
   **English answer:** What is there beyond that wall?

167. **Hindi prompt:** मैं इस सामान को सस्ते में लेके आऊँगा।  
   **Romanized:** Main is samaan ko saste mein leke aaunga.  
   **English answer:** I’ll get this product at a cheap rate.

168. **Hindi prompt:** मैं आपके सामने अपना काम पेश करूँ ूगा।।  
   **Romanized:** Main aapke saamne apna kaam pesh karunga.  
   **English answer:** I am going to present my work before you.

169. **Hindi prompt:** इस समस्या का हल निकालिये।  
   **Romanized:** Is samasya ka hal nikaliye.  
   **English answer:** Please look into the matter.

170. **Hindi prompt:** उसने ये अपने बेटे के लिए किया।  
   **Romanized:** Usne ye apne bete ke liye kiya.  
   **English answer:** He did it for his son.

171. **Hindi prompt:** अब मैं आपके सामने बोल रहा हूँ।  
   **Romanized:** Ab main aapke saamne bol raha hoon.  
   **English answer:** Now, I am speaking before you.

172. **Hindi prompt:** सुबह तक काम ख़त्म करो।  
   **Romanized:** Subah tak kaam khatm karo.  
   **English answer:** Finish the work by early morning.

173. **Hindi prompt:** पापा दीदी के बगल में खड़े हैं।  
   **Romanized:** Papa didi ke bagal me khade hain.  
   **English answer:** Dad is standing by my sister.

174. **Hindi prompt:** वह मेरा मेट्रो में इंतज़ार कर रही थी।  
   **Romanized:** Wah mera metro mein intzaar kar rahi thi.  
   **English answer:** She was waiting for me at the metro.

175. **Hindi prompt:** मैं रात में वहाँ था।  
   **Romanized:** Main raat me wahan tha.  
   **English answer:** I was there at night.

176. **Hindi prompt:** मेरी माँ अपने ऑफिस लैपटॉप ले के गयी।  
   **Romanized:** Meri maa apne office laptop leke gaye.  
   **English answer:** My mother went to her office with a laptop.

177. **Hindi prompt:** रोड के उस पार मेरी दुकान है।  
   **Romanized:** Road ke uss paar meri dukan hai.  
   **English answer:** There is my shop across the road.

178. **Hindi prompt:** वह कई दिनों से यह कर रहा है।  
   **Romanized:** Wah kai dinon se yeh kar raha hai.  
   **English answer:** He has been doing this for days.

179. **Hindi prompt:** मैं न्यूयॉर्क से आ रहा हूँ।  
   **Romanized:** Main New york se aa raha hoon.  
   **English answer:** I am coming from New York.

180. **Hindi prompt:** वह लंदन में रहता है।  
   **Romanized:** Wah London me rehta hai.  
   **English answer:** He lives in London.

181. **Hindi prompt:** वह बिहार से है।  
   **Romanized:** Wah bihar se hai.  
   **English answer:** He is from Bihar.

182. **Hindi prompt:** भीड़ के सामने घबराना मत।  
   **Romanized:** Bheed ke saamne ghabrana mat.  
   **English answer:** Don’t get nervous before the audience.

183. **Hindi prompt:** पुलिस चोर के पीछे पड़ी थी।  
   **Romanized:** Police chor ke piche padi thi.  
   **English answer:** The police were after the thief.

184. **Hindi prompt:** वो शाम की फ्लाइट से आ रहे हैं।  
   **Romanized:** Wo shaam ki flight se aa rahe hain.  
   **English answer:** They are coming by evening flight.

185. **Hindi prompt:** मैंने गेंद को बल्ले से मारा।  
   **Romanized:** Maine gend ko balle se maara.  
   **English answer:** I hit the ball with a bat.

186. **Hindi prompt:** मैं रात को खाना बनाऊँगा।  
   **Romanized:** Main raat ko khana banaunga.  
   **English answer:** I’ll cook dinner at night.

187. **Hindi prompt:** मैं खिड़की से देख सकता हूँ क्योंकि ये पारदर्शी है।  
   **Romanized:** Main khidki se dekh skta hun kyunki vo pardarshi hai.  
   **English answer:** I can see through the window as it is transparent.

188. **Hindi prompt:** मैं इस पाइप में से तेरे को देख सकता हूँ।  
   **Romanized:** Main iss pipe me se dekh skta hun.  
   **English answer:** I can see you through this pipe.

189. **Hindi prompt:** हम भूमि-गत रास्ते से गये।  
   **Romanized:** Hum bhoomigat raaste se gaye.  
   **English answer:** We went through the subway.

190. **Hindi prompt:** इस बाधा को पार करना बहुत कठिन है।  
   **Romanized:** Iss badha ko paar karna bahut kathin hai.  
   **English answer:** It’s so difficult to go across this hurdle.

191. **Hindi prompt:** आसमान के उस पार क्या है?  
   **Romanized:** Aasman ke uss paar kya hai?  
   **English answer:** What is beyond the sky?

192. **Hindi prompt:** मैंने एयरड्रॉप से उसे एक तस्वीर भेजी।  
   **Romanized:** Mene airdrop se usse ek tasveer bheji.  
   **English answer:** I sent him a picture via airdrop.

193. **Hindi prompt:** मैं एक गली से गुज़र रहा था।  
   **Romanized:** Main ek gali se guzar raha tha.  
   **English answer:** I was passing through a street.

194. **Hindi prompt:** वह एक कैफ़े में मिले।  
   **Romanized:** Wah ek cafe mein mile.  
   **English answer:** They met at a cafe.

195. **Hindi prompt:** वह केवल रात में ही पढ़ता है।  
   **Romanized:** Wah keval raat me padhta hai.  
   **English answer:** He studies only at night.

196. **Hindi prompt:** वह मेरे साथ बहस कर रही है।  
   **Romanized:** Wah mere saath bahas kar rahi hai.  
   **English answer:** She is arguing with me.

197. **Hindi prompt:** मैं उसके बगल में खड़ा था।  
   **Romanized:** Main uske bagal me khada tha.  
   **English answer:** I was standing by her.

198. **Hindi prompt:** उसने काले कलम से लेख लिखा।  
   **Romanized:** Usne kaale kalam se lekh likha.  
   **English answer:** He wrote the article with a black pen

199. **Hindi prompt:** मैं 2020 में घर आऊँगा।  
   **Romanized:** Main 2020 mein ghar aaunga.  
   **English answer:** I will come home in 2020.

200. **Hindi prompt:** वो 5 बजे पैदा हुआ था।  
   **Romanized:** Wo 5 baje paida hua tha.  
   **English answer:** He was born at 5.

201. **Hindi prompt:** मेरा आईफोन पांच और मोबाइल फ़ोन्स के बीच रखा हुआ था।  
   **Romanized:** Mera iPhone paanch aur mobile phones ke bich rakha hua tha.  
   **English answer:** My iPhone was kept among/amongst 5 other mobile phones.

202. **Hindi prompt:** दोस्तों के बीच कोई गलतफ़हमी नहीं होनी चाहिए।  
   **Romanized:** Doston ke beech koi galtfehmi nhi honi chahiye.  
   **English answer:** There must be no misunderstanding among/amongst friends.

203. **Hindi prompt:** मेरा पार्सल सामान के बीच में था।  
   **Romanized:** Mera parcel saman ke bich mein tha.  
   **English answer:** My parcel was among/amongst other items.

204. **Hindi prompt:** क्या तुम अपने घर से बाहर आओगे?  
   **Romanized:** Kya tum apne ghar se bahar aaoge?  
   **English answer:** Would you come out of your house?

205. **Hindi prompt:** मुझे 90 में से बस 30 चीज़ें याद हैं।  
   **Romanized:** Mujhe 90 mein se bas 30 chizein hi yaad hain.  
   **English answer:** I only remember 30 things out of 90.

206. **Hindi prompt:** रमेश सोफे पे बैठा है।  
   **Romanized:** Ramesh sofe pe baitha hai.  
   **English answer:** Ramesh is sitting on the Sofa.

207. **Hindi prompt:** मेरी कुर्सी पे मत कूदो।  
   **Romanized:** Meri kursi pe mat kudo.  
   **English answer:** Don’t jump on my chair.

208. **Hindi prompt:** बाईं ओर आओ।  
   **Romanized:** Baayin aur aao.  
   **English answer:** Come on the left.

209. **Hindi prompt:** दीक्षांत अभिनव के खिलाफ क्यों है?  
   **Romanized:** Deekshant Abhinav ke khilaf kyon hai?  
   **English answer:** Why is Deekshant against Abhinav?

210. **Hindi prompt:** मुझे विज्ञान के बारे में जानना है।  
   **Romanized:** Mujhe vigyan ke baare mein jaana hai.  
   **English answer:** I want to know about science.

211. **Hindi prompt:** वह भारत के राष्ट्रपति हैं।  
   **Romanized:** Veh Bharat ke rashtrapati hain.  
   **English answer:** He is the President of India.

212. **Hindi prompt:** वह मेरे भाई का लड़का है।  
   **Romanized:** Veh mere bhai ka ladka hai.  
   **English answer:** He is the son of my brother.

213. **Hindi prompt:** मैं प्रमोद के घर की तरफ जा रहा हूँ।  
   **Romanized:** Main Pramod ke ghar ki taraf ja raha hoon.  
   **English answer:** I am going towards Pramod’s house.

214. **Hindi prompt:** मैं एक घंटे में आया।  
   **Romanized:** Main ek ghante me aya.  
   **English answer:** I’ll come within an hour.

215. **Hindi prompt:** मैच भारत की तरफ जा रहा है।  
   **Romanized:** Match Bharat ki taraf ja raha hai.  
   **English answer:** The match is going towards India.

216. **Hindi prompt:** कुछ सप्ताह के अन्दर ही इसका परिणाम आ जायेगा।  
   **Romanized:** Kuch saptah ke andar hi iska parinam aa jayega.  
   **English answer:** Its result will come just within a few weeks.

217. **Hindi prompt:** धोनी उससे बेहतर है।  
   **Romanized:** Dhoni usse behtar hai.  
   **English answer:** Dhoni is better than him.

218. **Hindi prompt:** हमने साल भर काम किया।  
   **Romanized:** Humne saal bhar kaam kiya.  
   **English answer:** We worked throughout the year.

219. **Hindi prompt:** उसने पूरे साल मन लगाकर पढ़ाई की।  
   **Romanized:** Usne poore saal man lagakar padhai ki.  
   **English answer:** He studied sincerely throughout the year.

220. **Hindi prompt:** सूरज के बिना धरती नहीं है।  
   **Romanized:** Suraj ke bina dharti nhi hai.  
   **English answer:** Earth won’t exist without the Sun.

221. **Hindi prompt:** नौकरी के बिना पैसा कहाँ से आयेगा।  
   **Romanized:** Naukri ke bina paisa kahan se aayega.  
   **English answer:** How will the money come without a job?

222. **Hindi prompt:** गर्म हवा ऊपर क्यों जाती है?  
   **Romanized:** Garm hawa upar kyon jati hai?  
   **English answer:** Why does the hot air go up?

223. **Hindi prompt:** दाम बढ़ रहे हैं।  
   **Romanized:** Daam badh rahe hain.  
   **English answer:** Prices have soared up.

224. **Hindi prompt:** ऊपर की तरफ मत जाओ।  
   **Romanized:** Upar ki taraf mat jao.  
   **English answer:** Don’t go upwards.

225. **Hindi prompt:** पहाड़ से नीचे की तरफ आना है।  
   **Romanized:** Pahad se niche ki taraf aana hai.  
   **English answer:** Come downwards from the hill.

226. **Hindi prompt:** कपड़े बक्से के बाहर हैं।  
   **Romanized:** Kapde bakse ke bahar hain.  
   **English answer:** Clothes are outside the box.

227. **Hindi prompt:** स्कूल के बगल में अस्पताल है।  
   **Romanized:** School ke bagal me hospital hai.  
   **English answer:** There is a hospital beside the school.

228. **Hindi prompt:** मीना रोहित के बगल में बैठी है।  
   **Romanized:** Meena Rohit ke bagal me baithi hai.  
   **English answer:** Meena is sitting adjacent to Rohit.

229. **Hindi prompt:** पेड़ के पीछे क्या है?  
   **Romanized:** Ped ke piche kya hai?  
   **English answer:** What’s behind that tree?

230. **Hindi prompt:** वह सबसे आगे है।  
   **Romanized:** Veh sabse aage hai.  
   **English answer:** She is ahead of everyone.

231. **Hindi prompt:** मैं पिज़्ज़ा छोड़कर सब खा लूँगा।  
   **Romanized:** Main pizza chodkar sab kha lunga.  
   **English answer:** I can eat everything except pizza.

232. **Hindi prompt:** वह इसके अतिरिक्त कुछ और नहीं चाहती।  
   **Romanized:** Veh iske atirikt kuch aur nhi chaahti.  
   **English answer:** She doesn’t want anything besides this.

233. **Hindi prompt:** गर्मी के दौरान खूब सारा पानी पीना चाहिए।  
   **Romanized:** Garmi ke dauran khub sara paani pina chahiye.  
   **English answer:** Drink lots of water during summers.

234. **Hindi prompt:** अभय चेन्नई तक गया।  
   **Romanized:** Abhay Chennai tak gaya.  
   **English answer:** Abhay went up to Chennai.

235. **Hindi prompt:** सारे ग्रह सूर्य के चारों ओर चक्कर लगाते हैं।  
   **Romanized:** Sare greh Suraj ke charon or chakkar lagate hain.  
   **English answer:** All the planets revolve around the sun.

236. **Hindi prompt:** इस किताब के साथ एक पैन मुफ्त मिलेगा।  
   **Romanized:** Iss kitab ke sath ek pen muft milega.  
   **English answer:** A pen is free along with this book.

237. **Hindi prompt:** अस्पताल से लगकर एक दवा की दुकान है।  
   **Romanized:** Hospital se lagkar ek dawa ki dukaan hai.  
   **English answer:** There is a chemist shop alongside the hospital.

238. **Hindi prompt:** उस रंगोली पे पैर मत रखना।  
   **Romanized:** Uss rangoli pe pair mat rakhna.  
   **English answer:** Don’t step on that rangoli.

239. **Hindi prompt:** उसने मेरे जन्मदिन पर तोहफ़ा दिया।  
   **Romanized:** Usne mere janmdin par tohfa diya.  
   **English answer:** He gave me a present on my birthday.

240. **Hindi prompt:** वह नए साल के दिन पैदा हुआ था।  
   **Romanized:** Veh naye saal ke din paida hua tha.  
   **English answer:** He was born on new year's eve.

241. **Hindi prompt:** निखिल बिस्तर पर कूद गया।  
   **Romanized:** Nikhil bistar par kood gaya.  
   **English answer:** Nikhil jumped onto the bed.

242. **Hindi prompt:** मंत्री ने राजा के खिलाफ साजिश रची।  
   **Romanized:** Mantri ne raja ke khilaf saajish rachi.  
   **English answer:** The minister conspired against the king.

243. **Hindi prompt:** यह सब किसके बारे में है?  
   **Romanized:** Yeh sab kiske baare mein hai?  
   **English answer:** Who is this all about?

244. **Hindi prompt:** मैं कॉलेज जा रहा हूँ।  
   **Romanized:** Main college jaa rha hun.  
   **English answer:** I am going to college.

245. **Hindi prompt:** वह चिड़िया-घर की तरफ जा रहा है।  
   **Romanized:** Veh chidiya ghar ki taraf ja raha hai.  
   **English answer:** He is going towards the zoo.

246. **Hindi prompt:** वह मुझसे बेहतर है।  
   **Romanized:** Veh mujhse behtar hai.  
   **English answer:** She is better than me.

247. **Hindi prompt:** मिर्ची से तीखा कुछ नहीं।  
   **Romanized:** Mirchi se tikha kuch nahin.  
   **English answer:** Nothing is spicier than chilly.

248. **Hindi prompt:** बल्ले के बिना विराट कुछ नहीं है।  
   **Romanized:** Balle ke bina Virat kuch nahi hain.  
   **English answer:** Virat is nothing without his bat.

249. **Hindi prompt:** यह फिल्म दस साल पहले आयी थी।  
   **Romanized:** Yeh film das saal pehle ayi thi.  
   **English answer:** This movie had come ten years ago.

250. **Hindi prompt:** व्यापार बढ़ रहा है।  
   **Romanized:** Vyapar badh raha hai.  
   **English answer:** Business is going up. / Business is growing.

251. **Hindi prompt:** उसने ऊपर की तरफ बोतल फेंकी।  
   **Romanized:** Usne upar ki taraf bottle fenki.  
   **English answer:** She threw the bottle upwards.

252. **Hindi prompt:** मैं नीचे की तरफ जा रहा हूँ।  
   **Romanized:** Main niche ki taraf jaa rha hun.  
   **English answer:** I am going downwards.

253. **Hindi prompt:** गुरुत्वाकर्षण बल नीचे की तरफ लगता है।  
   **Romanized:** Gurutwakarshan bal niche ki taraf lagta hai.  
   **English answer:** Gravitational force acts downwards.

254. **Hindi prompt:** लैपटॉप के बगल में किताब रखी है।  
   **Romanized:** Laptop ke bagal mein kitab rakhi hai.  
   **English answer:** The book is kept next to my laptop.

255. **Hindi prompt:** दरवाज़े के पीछे कोई छुपा है।  
   **Romanized:** Darwaze ke piche koi chupa hai.  
   **English answer:** Someone is hidden behind the door.

256. **Hindi prompt:** लाइन में मैं सचिन से आगे था।  
   **Romanized:** Line me main Sachin se aage tha.  
   **English answer:** I was ahead of Sachin in the line.

257. **Hindi prompt:** यह दुकान सोमवार के अलावा हर दिन खुली रहती है।  
   **Romanized:** Yeh dukan somvaar ke alawa har din khuli rehti hai.  
   **English answer:** This shop opens every day except Monday.

258. **Hindi prompt:** मेरे अलावा यहाँ कोई नहीं रहता।  
   **Romanized:** Mere alawa yahan koi nahi rehta.  
   **English answer:** No one lives here except me.

259. **Hindi prompt:** इसके अतिरिक्त कुछ और खाओगे?  
   **Romanized:** Iske atirikt kuch aur khaoge?  
   **English answer:** Would you have something to eat besides this?

260. **Hindi prompt:** मैच के दौरान बारिश हुई थी।  
   **Romanized:** Match ke dauran baarish hui thi.  
   **English answer:** It rained during the match.

261. **Hindi prompt:** बच्चे रूम के बगल में खड़े हैं।  
   **Romanized:** Bache room ke bagal mein khade hain.  
   **English answer:** Kids are standing alongside the room.

262. **Hindi prompt:** तुम इस मोबाइल को अपने साथ ले जाओ।  
   **Romanized:** Tum iss mobile ko apne sath le jao.  
   **English answer:** Take this mobile along with you.

263. **Hindi prompt:** प्रज्ञा हमारे साथ आएगी।  
   **Romanized:** Pragya humare sath aayegi.  
   **English answer:** Pragya will come along with us.

264. **Hindi prompt:** हमारे बीच आने की कोशिश मत करो।  
   **Romanized:** Humare beech aane ki koshish mat karo.  
   **English answer:** Don’t try to come in between us.

265. **Hindi prompt:** तुम्हारा स्थान मेरे और वेणु के बीच में है।  
   **Romanized:** Tumhara sthaan mere aur Venu ke beech mein hai.  
   **English answer:** Your place is in between me and Venu.

266. **Hindi prompt:** सबने मिलकर पिज़्ज़ा खाया।  
   **Romanized:** Sabne milkar pizza khaya.  
   **English answer:** The pizza was shared among/amongst all.

267. **Hindi prompt:** वह भीड़ के बीच में थी।  
   **Romanized:** Veh bheed ke bich me thi.  
   **English answer:** She was among/amongst the gathering.

268. **Hindi prompt:** तुम ऑफ़िस से बाहर निकल रहे हो।  
   **Romanized:** Tum office se bahar nikal rhe ho.  
   **English answer:** You are getting out of your office.

269. **Hindi prompt:** मेरा कॉलेज से बाहर घूमना मना है।  
   **Romanized:** Mera college se bahar ghumna mana hai.  
   **English answer:** I am not supposed to go out of college.

270. **Hindi prompt:** पृथ्वी ने 100 में से 97 नम्बर प्राप्त किये।  
   **Romanized:** Prithvi ne 100 mein se 97 number prapt kiye.  
   **English answer:** Prithvi scored 97 out of 100.

271. **Hindi prompt:** तुम्हें इनमें से कितने सामान पसंद आये।  
   **Romanized:** Tumhe inme se kitne saman pasand aaye.  
   **English answer:** How many items out of these did you like?

272. **Hindi prompt:** वह 10th दिसंबर 2018 को आयी।  
   **Romanized:** Veh 10th December 2018 ko aayi.  
   **English answer:** She came on 10th Dec’18.

273. **Hindi prompt:** मेरे दाईं ओर बैठ जाओ।  
   **Romanized:** Mere daayin aur baith jao.  
   **English answer:** Sit on my right.

274. **Hindi prompt:** मैं शाकाहारियों के खिलाफ नहीं हूँ।  
   **Romanized:** Main shakahariyon ke khilaf nhi hun.  
   **English answer:** I am not against vegetarians.

275. **Hindi prompt:** मुझे इस बारे में जानना है।  
   **Romanized:** Mujhe iss baare mein jaana hai.  
   **English answer:** I want to know about this.

276. **Hindi prompt:** मैं बाजार जा रहा हूँ।  
   **Romanized:** Main bazar jaa rha hun.  
   **English answer:** I am going to market.

277. **Hindi prompt:** वह अस्पताल जा रहा है।  
   **Romanized:** Veh Hospital jaa raha hai.  
   **English answer:** He is going to the hospital.

278. **Hindi prompt:** सीमा दुकान की तरफ मुड़ रही है।  
   **Romanized:** Seema dukan ki taraf mud rhi hai.  
   **English answer:** Seema is turning towards the shop.

279. **Hindi prompt:** हमें दिन भर पानी पीते रहना चाहिए।  
   **Romanized:** Hume din bhar pani pite rehna chahiye.  
   **English answer:** We should drink water throughout the day.

280. **Hindi prompt:** मैं अपनी माँ के बिना कुछ नहीं हूँ।  
   **Romanized:** Main apni maa ke bina kuch nhi hoon.  
   **English answer:** I am nothing without my mother.

281. **Hindi prompt:** घर बने हुए साल हो गए।  
   **Romanized:** Ghar bane hue saal ho gaye.  
   **English answer:** The house was made a year ago.

282. **Hindi prompt:** बहुत पहले यहाँ जंगल हुआ करता था।  
   **Romanized:** Bahut pehle yahan jungle hua karta tha.  
   **English answer:** There used to be a jungle here long ago.

283. **Hindi prompt:** वहाँ ऊपर आसमान में क्या है?  
   **Romanized:** Vahan upar aasman mein kya hai?  
   **English answer:** What is there up in the sky?

284. **Hindi prompt:** कागज़ नीचे की तरफ आ रहा है।  
   **Romanized:** Kagaz niche ki taraf aa rha hai.  
   **English answer:** Paper is coming downwards.

285. **Hindi prompt:** मछली पानी से बाहर नहीं रह सकती है।  
   **Romanized:** Machli pani se bahar nahi reh sakti hai.  
   **English answer:** Fish cannot live outside water.

286. **Hindi prompt:** इसके पीछे मेरा हाथ है।  
   **Romanized:** Iske piche mera haath hai.  
   **English answer:** I am behind all this.

287. **Hindi prompt:** इधर उधर मत घूमो।  
   **Romanized:** Idhar udhar mat ghumo.  
   **English answer:** Don’t roam around.

288. **Hindi prompt:** सृजन के चारों ओर धुआँ है।  
   **Romanized:** Srijan ke charo aur dhuan hai.  
   **English answer:** There is smoke all around Srijan.

289. **Hindi prompt:** गाड़ी घर के बगल में खड़ी है।  
   **Romanized:** Gadi ghar ke bagal mein khadi hai.  
   **English answer:** The car is parked alongside the house.

290. **Hindi prompt:** नदी के बगल से एक पूल निकलता है।  
   **Romanized:** Nadi ke bagal se ek pool nikalta hai.  
   **English answer:** A pool starts alongside the river.

291. **Hindi prompt:** क्या तुम हमारे साथ आओगे?  
   **Romanized:** Kya tum humare sath aaoge?  
   **English answer:** Will you come along with us?

292. **Hindi prompt:** मेरी चारों ओर एक गोला बनाओ।  
   **Romanized:** Mere charon aur ek gola bnao.  
   **English answer:** Form a circle around me.

293. **Hindi prompt:** स्कूल के बगल में एक पतली गली है।  
   **Romanized:** School ke bagal mein ek patli gali hai.  
   **English answer:** There is a narrow street alongside the school.

294. **Hindi prompt:** अभिषेक के घर के चारों ओर हरियाली है।  
   **Romanized:** Abhishek ke ghar ke charon or hariyali hai.  
   **English answer:** There is greenery all around Abhishek’s house.

295. **Hindi prompt:** मुझे उसके साथ नहीं जाना।  
   **Romanized:** Mujhe uske sath nahin jaana.  
   **English answer:** I don’t want to go along with him.

296. **Hindi prompt:** हम हमारे बीच की इन दूरियों को मिटा देते हैं।  
   **Romanized:** Hum humare beech ki in dooriyon ko mita dete hain.  
   **English answer:** We should get rid of the differences between us.

297. **Hindi prompt:** मैं उन सर्वश्रेष्ठ प्रतिश्पर्धियों में था जिनका चयन हो गया।  
   **Romanized:** Main un sarvshresth pratishpardhiyon me tha jinka chayan ho gya hai.  
   **English answer:** I was among/amongst the top candidates who were selected.

298. **Hindi prompt:** वह मुंबई से बाहर जा चुकी है।  
   **Romanized:** Veh Mumbai se bahar jaa chuki hai.  
   **English answer:** She has gone out of Mumbai.

299. **Hindi prompt:** 40 में से केवल 7 ही विद्यार्थी हैं।  
   **Romanized:** 40 mein se kewal 7 hi vidhyarthi hain.  
   **English answer:** There are only 7 students out of 40.

300. **Hindi prompt:** भाइयों के बीच कोई दरार नहीं आनी चाहिए।  
   **Romanized:** Bhaiyon ke bich koi drar nahi aani chahiye.  
   **English answer:** There should be no differences among/amongst brothers.

301. **Hindi prompt:** उसकी माँ कुछ लोगों के बीच थीं।  
   **Romanized:** Uski maa kuch logon ke bich thin.  
   **English answer:** His mom was among/amongst a few people.

302. **Hindi prompt:** मेरा देश से बाहर जाने का मन नहीं है।  
   **Romanized:** Mera desh se bahar jaane ka man nahi hai.  
   **English answer:** I don't want to go out of the country.

303. **Hindi prompt:** सीट पर गन्दगी मत फैलाओ।  
   **Romanized:** Seat par gandagi mat failao.  
   **English answer:** Don’t litter the seat.

304. **Hindi prompt:** वह बाईं ओर खड़ी थी।  
   **Romanized:** Veh baayin aur khadi thi.  
   **English answer:** She was standing on the left.

305. **Hindi prompt:** उसने मुझे बाईं ओर खड़े होने को कहा।  
   **Romanized:** Usne mujhe baayin aur khade hone ko kaha.  
   **English answer:** She told me to stand on the left.

306. **Hindi prompt:** मैंने कुर्सी पर कदम रखा।  
   **Romanized:** Maine kursi par kadam rakha.  
   **English answer:** I stepped onto the chair.

307. **Hindi prompt:** तुम लोग किसके बारे में बात कर रहे हो?  
   **Romanized:** Tum log kiske baare mein baat kar rahe ho?  
   **English answer:** What are you people talking about?

308. **Hindi prompt:** राम सोहन का छोटा भाई है।  
   **Romanized:** Ram Sohan ka chhota bhai hai.  
   **English answer:** Ram is Sohan's younger brother. / Ram is the younger brother of Sohan.

309. **Hindi prompt:** प्लेट्स टेबल पर अपने आप आ गईं।  
   **Romanized:** Plates table par apne aap aa gai.  
   **English answer:** Plates came upon the table by themselves.

310. **Hindi prompt:** डाइनिंग टेबल पर मोमबत्तियां रखी हैं।  
   **Romanized:** Dining table par mombatiyan rakhi hain.  
   **English answer:** Candles are kept on the dining table.

311. **Hindi prompt:** उसने मुझे शादी पर बधाई दी।  
   **Romanized:** Usne mujhe shadi par badhai di.  
   **English answer:** She congratulated me on my marriage.

312. **Hindi prompt:** वह चुनाव में मेरे खिलाफ खड़ा है।  
   **Romanized:** Veh chunav mein mere khilaf khada hai.  
   **English answer:** He is standing against me in the elections.

313. **Hindi prompt:** यह लेख सचिन तेंदुलकर के बारे में है।  
   **Romanized:** Yeh lekh SachinTendulkar ke baare mein hai.  
   **English answer:** This article is about Sachin Tendulkar.

314. **Hindi prompt:** नंदिनी हमारे घर आ रही है।  
   **Romanized:** Nandini humare ghar aa rahi hai.  
   **English answer:** Nandini is coming to our home.

315. **Hindi prompt:** कुछ साल में इसका इलाज संभव होगा।  
   **Romanized:** Kuch saal mein iska ilaaj sambhav hoga.  
   **English answer:** Its cure will be possible within a few years.

316. **Hindi prompt:** वह पूरे दिन परेशान थी।  
   **Romanized:** Veh pure din pareshan thi.  
   **English answer:** She was worried throughout the day.

317. **Hindi prompt:** मैं तुमसे कई साल पहले मिला था।  
   **Romanized:** Main tumse kayi saal pehle mila tha.  
   **English answer:** I met you many years ago.

318. **Hindi prompt:** गुब्बारा ऊपर की तरफ गया।  
   **Romanized:** Gubara upar ki taraf gaya.  
   **English answer:** The balloon went upwards.

319. **Hindi prompt:** उसने पत्थर को ऊपर की तरफ धकेला।  
   **Romanized:** Usne pathar ko upar ki taraf dhakela.  
   **English answer:** She pushed the rock upwards.

320. **Hindi prompt:** होस्टल कॉलेज के बाहर है।  
   **Romanized:** Hostel college ke bahar hai.  
   **English answer:** The hostel is outside the college.

321. **Hindi prompt:** पक्षी पिंजरे से बाहर हैं।  
   **Romanized:** Pakshi pinjare se bahar hain.  
   **English answer:** Birds are outside the cage.

322. **Hindi prompt:** उसने तुम्हें पीछे छोड़ दिया।  
   **Romanized:** Usne tumhe piche chhod diya.  
   **English answer:** He left you behind.

323. **Hindi prompt:** रीना के आगे मोहन है।  
   **Romanized:** Reena ke aage Mohan hai.  
   **English answer:** Mohan is ahead of Reena.

324. **Hindi prompt:** वह मोहित को छोड़कर किसी से भी बात कर लेगी।  
   **Romanized:** Veh Mohit ko chodkar kisi se bhi baat kar legi.  
   **English answer:** She can talk to everyone except Mohit.

325. **Hindi prompt:** नित्या सोमवार तक काम करेगी।  
   **Romanized:** Nitya somvaar tak kam karegi.  
   **English answer:** Nitya will work till Monday.

326. **Hindi prompt:** मैं बाज़ार तक चले जाऊँगा।  
   **Romanized:** Main bazar tak chale jaunga.  
   **English answer:** I’ll go up to the market.

327. **Hindi prompt:** मैं थोड़ी दूर तक और चल पाऊँगा।  
   **Romanized:** Main thodi door tak aur chal paaunga.  
   **English answer:** I’ll be able to walk up to a few more miles.

328. **Hindi prompt:** प्रत्युष दस किलोमीटर तक दौड़ा।  
   **Romanized:** Pratyush das kilometer tak dauda.  
   **English answer:** Pratyush ran up to ten kilometers.

329. **Hindi prompt:** शुभम पांच बजे तक घर पर ही रहेगा।  
   **Romanized:** Shubham paanch baje tak ghar par hi rahega.  
   **English answer:** Shubham will stay indoors till 5 pm.

330. **Hindi prompt:** विस्मय नौ बजे तक रुकेगा।  
   **Romanized:** Vismay nau baje tak rukega.  
   **English answer:** Vismay will stay till 9.

331. **Hindi prompt:** वह दस बजे तक पढ़ेगी।  
   **Romanized:** Veh das baje tak padhegi.  
   **English answer:** She will study till 10.

332. **Hindi prompt:** इसके अतिरिक्त और क्या उपाय है?  
   **Romanized:** Iske atirikt aur kya upaye hai?  
   **English answer:** What options do you have besides this?

333. **Hindi prompt:** इस काम के अतिरिक्त तुम और क्या करते हो?  
   **Romanized:** Iss kam ke atirikt tum aur kya karte ho?  
   **English answer:** What else do you do besides this work?

334. **Hindi prompt:** काम के दौरान मुझे भूख लग रही थी।  
   **Romanized:** Kam ke dauran mujhe bhookh lg rahi thi.  
   **English answer:** I was feeling hungry during my work.

335. **Hindi prompt:** भागने के दौरान मेरी साँस फूल गयी।  
   **Romanized:** Bhagne ke dauran meri sans phool gayi.  
   **English answer:** I was short of breath during the sprint.

336. **Hindi prompt:** आप सुबह के दौरान कसरत करें।  
   **Romanized:** Aap subah ke dauran kasrat karen.  
   **English answer:** You should exercise during the morning.

337. **Hindi prompt:** भोजन के अतिरिक्त मैं कुछ नहीं लेता।  
   **Romanized:** Bhojan ke atirikt main kuch nahi leta.  
   **English answer:** I don’t have anything besides dinner.

338. **Hindi prompt:** इसके अलावा तुम्हारे पास और क्या रास्ता है?  
   **Romanized:** Iske alawa tumhare paas aur kya raasta hai?  
   **English answer:** What option do you have except this?

339. **Hindi prompt:** तुम 60 साल तक यही करोगे।  
   **Romanized:** Tum 60 saal tak yehi kroge.  
   **English answer:** You will do this up to 60 years of age.

340. **Hindi prompt:** वह रेस में मुझसे आगे है।  
   **Romanized:** Veh race me mujhse aage hai.  
   **English answer:** He is ahead of me in the race.

341. **Hindi prompt:** मैं आगे रहना चाहता हूँ।  
   **Romanized:** Main aage rehna chahta hun.  
   **English answer:** I want to be ahead.

342. **Hindi prompt:** यह काम कुछ घंटों के अन्दर ख़त्म हो जायेगा।  
   **Romanized:** Yeh kam kuch ghanton ke andar khatam ho jayega.  
   **English answer:** This work will be finished within a few hours.

343. **Hindi prompt:** हम इसके खिलाफ हैं।  
   **Romanized:** Hum iske khilaf hain.  
   **English answer:** We are against it.

344. **Hindi prompt:** यह शर्मा जी का बेटा है।  
   **Romanized:** Yeh Sharma ji ka beta hai.  
   **English answer:** He is the son of Mr.Sharma.

345. **Hindi prompt:** मेरे तुमसे ज़्यादा नंबर आये।  
   **Romanized:** Mere tumse zyada number aye.  
   **English answer:** I got more marks than you.

346. **Hindi prompt:** जिराफ शेर से लम्बा होता है।  
   **Romanized:** Giraffe sher se lamba hota hai.  
   **English answer:** A giraffe is taller than a lion.

347. **Hindi prompt:** दोस्ती के बिना दुनिया नहीं चलेगी।  
   **Romanized:** Dosti ke bina duniya nhi chalegi.  
   **English answer:** The world won’t exist without friendship.

348. **Hindi prompt:** मैं मुंबई आठ साल पहले आया था।  
   **Romanized:** Main Mumbai aath saal pehle aaya tha.  
   **English answer:** I came to Mumbai eight years ago.

349. **Hindi prompt:** सीढ़ियां ऊपर की तरफ है।  
   **Romanized:** Sidhiyan upar ki taraf hain.  
   **English answer:** Stairs are upwards.

350. **Hindi prompt:** घर के बाहर मेहमान हैं।  
   **Romanized:** Ghar ke bahar mehman hain.  
   **English answer:** Guests are outside the house.

351. **Hindi prompt:** वह मेरे बगल में खड़ी थी।  
   **Romanized:** Veh mere bagal me khadi hai.  
   **English answer:** She was standing by me.

352. **Hindi prompt:** मैं शाम तक आऊँगा।  
   **Romanized:** Main shaam tak aunga.  
   **English answer:** I’ll come till the evening.

353. **Hindi prompt:** वह सोमवार को आया।  
   **Romanized:** Veh Somvar ko aaya.  
   **English answer:** He came on Monday.

354. **Hindi prompt:** वह दायीं ओर बैठी थी।  
   **Romanized:** Veh daayin aur baithi thi.  
   **English answer:** She was sitting on the right.

355. **Hindi prompt:** वह कूड़े के ऊपर गिर गया।  
   **Romanized:** Veh kude ke upar gir gaya.  
   **English answer:** He fell upon the garbage.

356. **Hindi prompt:** वह किसी काम का नहीं है।  
   **Romanized:** Veh kisi kaam ka nahi hai.  
   **English answer:** He is of no use.

357. **Hindi prompt:** वह उत्तर दिशा की ओर जा रहा है।  
   **Romanized:** Veh uttar disha ki aur jaa raha hai.  
   **English answer:** He is going to the North.

358. **Hindi prompt:** उसने रात भर पार्टी की।  
   **Romanized:** Usne raat bhar party ki.  
   **English answer:** She partied throughout the entire night.

359. **Hindi prompt:** ऊपर देखो।  
   **Romanized:** Upar dekho.  
   **English answer:** Look up.

360. **Hindi prompt:** नीचे की तरफ धक्का दो।  
   **Romanized:** Niche ki taraf dhakka do.  
   **English answer:** Push downwards.

361. **Hindi prompt:** कोई तुम्हारे पीछे है।  
   **Romanized:** Koi tumhare piche hai.  
   **English answer:** There is someone behind you.

## Source-text and verification notes

- Exercise 1 prompts (PDF pages 230–242) and answer keys (PDF pages 242–252) are complete. The “Alongside” and “Across” answer keys are at the top of PDF page 252, before Exercise 2 begins.
- Exercise 1 Hindi was checked against all prompt pages; 269 of 303 entries required clear OCR/glyph/spacing corrections. No Exercise 1 items were unreadable.
- The “Besides” group has four prompts and five printed English key entries: key entries 2 and 3 are alternative translations for prompt 2; entries 4 and 5 pair with prompts 3 and 4. All source wording is retained.
- Exercise 2 prompts (PDF pages 252–264) were OCRed from scans and visually checked. Its English answer key on PDF pages 264–273 contains a unique, continuous sequence from 1 through 361, paired by number. No unreadable Exercise 2 items were identified.
- The printed Romanized lines for Exercise 2 items 67 and 298 omit their opening parenthesis in the source; they are preserved as separate Romanized lines rather than supplied with guessed punctuation.
- Source wording and grammar oddities are retained; only clear OCR/spelling/spacing errors were corrected.
- Corrections are limited to clear scan-confirmed OCR, number, spelling, line-end punctuation, and crop-boundary artifacts. Romanized lines were checked against the printed lines; no conservative Romanized correction was required. Rows 67 and 298 visibly print the Romanized line without an opening parenthesis, so that source fact is recorded rather than repaired. No source grammar was normalized.

**Unreadable text:** none identified.

