# Lesson 2 — What is the time?

**PDF pages:** 13–20  
**Printed page numbers:** 12–19

## Exercise and answer pairs

Hindi text was OCR-read from the page images; Romanized readings and English answers are from the PDF’s text layer. Where OCR misread a printed numeral, the adjacent Romanized reading was used to restore only the number.

### 1

- **Hindi:** 7 बजकर 5 मिनट हो जाए तो बुला देना।
- **Romanized:** 7 bajkar 5 minute ho jaye to bula dena.
- **Answer:** If it is 5 past 7 then call me.

### 2

- **Hindi:** 9 बजकर 15 मिनट पर मैच शुरू होगा।
- **Romanized:** 9 bajkar 15 minute par match shuru hoga.
- **Answer:** Match will be start at 15 past 9.

### 3

- **Hindi:** 2 बजकर 20 मिनट पर पापा आएँगे।
- **Romanized:** 2 bajkar 20 minute par papa aaenge.
- **Answer:** Papa will come at 20 past 2.

### 4

- **Hindi:** 12 बजकर 10 मिनट पर लाइट चली गयी।
- **Romanized:** 12 bajkar 10 minute par light chali gayi.
- **Answer:** The light (power) was gone (cut) at 10 past 12.

### 5

- **Hindi:** 8 बजने में 10 मिनट है |
- **Romanized:** 8 bajne main 10 minute hai.
- **Answer:** It’s 10 to 8.

### 6

- **Hindi:** 6 बजने में 10 मिनट थे जब वो आई।
- **Romanized:** 6 bajne main 10 minute the jab vo aayi.
- **Answer:** It was 10 to 6 when she came.

### 7

- **Hindi:** अच्छा हुआ अभी 8 बजने में 15 मिनट है |
- **Romanized:** Acha huwa abhi 8 bajne mai 15 minute hai.
- **Answer:** It’s good that it’s still 15 to 8.

### 8

- **Hindi:** अगर 9 बजने में 20 मिनट होते तो काम हो जाता।
- **Romanized:** Agar 9 bajne me 20 minute hote to kaam ho jata.
- **Answer:** If it were 20 to 9, it would be great.

### 9

- **Hindi:** सवा 6 बजे हैं।
- **Romanized:** Sava 6 baje hain.
- **Answer:** It’s quarter past 6.

### 10

- **Hindi:** सवा 8 बजे स्कूल के बाहर मिलना।
- **Romanized:** Sava 8 baje school ke bahar milana.
- **Answer:** Meet outside the school at quarter past 8.

### 11

- **Hindi:** सवा 9 बजे तक मैं खाना खा लूँगा |
- **Romanized:** Sava 9 baje tak mai khana kha loonga.
- **Answer:** I will have dinner by quarter past 9.

### 12

- **Hindi:** सवा 3 बजे तक गैस ऑन रखना।
- **Romanized:** Sava 3 baje tak gas on rakhna.
- **Answer:** Keep the gas on till quarter past 3.

### 13

- **Hindi:** ये शो सवा 5 बजे खत्म होगा।
- **Romanized:** Ye show sava 5 baje khatam hoga.
- **Answer:** This show will end at quarter past 5.

### 14

- **Hindi:** मेरी सवा 10 की ट्रेन है |
- **Romanized:** Meri sava 10 ki train hai.
- **Answer:** I have a train at quarter past 10.

### 15

- **Hindi:** ढाई बजे हैं |
- **Romanized:** Dhai baje hain.
- **Answer:** It’s half past 2.

### 16

- **Hindi:** कल से मेरी छुट्टी ढाई बजे होगी।
- **Romanized:** Kal se meri chutti dhai baje hogi.
- **Answer:** From tomorrow my leave will be at half past 2.

### 17

- **Hindi:** ढाई बजे सबसे ज़्यादा धूप होती है।
- **Romanized:** Dhai baje sabse zyada dhoop hoti hai.
- **Answer:** At half past 2, the Sun is the brightest.

### 18

- **Hindi:** ढाई बजे हम सब लंच करेंगे।
- **Romanized:** Dhai baje hum sab lunch karenge.
- **Answer:** We all will have lunch at quarter past 2.

### 19

- **Hindi:** उसकी कॉल ढाई बजे आई।
- **Romanized:** Uski call dhai baje aaee.
- **Answer:** His call came at quarter past 2. / He called at quarter past 2.

### 20

- **Hindi:** पौने 4 बजे है।
- **Romanized:** Pone 4 baje hai.
- **Answer:** It’s quarter to 4.

### 21

- **Hindi:** मैने उसे वहाँ पौने 5 बजे देखा।
- **Romanized:** Maine use vahan pone 5 baje dekha.
- **Answer:** I saw him there at quarter to 5.

### 22

- **Hindi:** मैने उसे पौने 9 का टाइम दे रखा है |
- **Romanized:** Maine use pone 9 ka time de rakha hai.
- **Answer:** I have given him time of quarter to 9.

### 23

- **Hindi:** दूध वाला पौने 6 बजे आता है।
- **Romanized:** Dhoodh wala paune 6 baje aata hai.
- **Answer:** The milk man comes at quarter to 6.

### 24

- **Hindi:** पौने 7 तक कर देना ये।
- **Romanized:** Pone 7 tak kar dena ye.
- **Answer:** Do this till quarter to 7.

### 25

- **Hindi:** पौने 4 बजे चाय बना देना।
- **Romanized:** Pone 4 baje chai bana dena.
- **Answer:** Make tea at quarter to 4.

### 26

- **Hindi:** साढ़े 8 बजे है |
- **Romanized:** Saade 8 baje hai.
- **Answer:** It’s half past 8.

### 27

- **Hindi:** साढ़े 11 बजे चले जाने वहाँ।
- **Romanized:** Saade 11 baje chale jaana vahan.
- **Answer:** Go there at half past 11.

### 28

- **Hindi:** अब तो साढ़े 6 बजे ही अँधेरा होने लगा है |
- **Romanized:** Ab to saade 6 baje hi andhera hone lga h.
- **Answer:** Now it is getting dark at half past 6.

### 29

- **Hindi:** मेरा साढ़े 4 बजे का ट्यूशन है।
- **Romanized:** Mera saade 4 baje ka tuition hai.
- **Answer:** I have my tuition at half past 4.

### 30

- **Hindi:** हम साढ़े 9 तक सो जाते है |
- **Romanized:** Hum saade 9 tak so jaate hai.
- **Answer:** We sleep till half past 9.

### 31

- **Hindi:** साढ़े 8 पे मेरा फेवरेट सिरियल आता है |
- **Romanized:** Saade 8 pe mera favourite serial aata hai.
- **Answer:** My favourite serial comes at half past 8.

### 32

- **Hindi:** मेरी शिफ्ट साढ़े 6 से साढ़े 3 तक है।
- **Romanized:** Meri shift saade 6 se saade 3 tak hai.
- **Answer:** My shift is from half past 6 to half past 3.

### 33

- **Hindi:** 7 बजकर 1 मिनट भी नहीं होना चाहिए।
- **Romanized:** 7 bajkar 1 minute bhi nahi hona chahiye.
- **Answer:** It should not be even 1 past 7.

### 34

- **Hindi:** मैं 5 बजकर 10 मिनट पर जिम जाऊँगा।
- **Romanized:** Main 5 bajkar 10 minute par gym jaunga.
- **Answer:** I will go to gym at 10 past 5.

### 35

- **Hindi:** टेंशन मत लो अभी 9 बजने में 15 मिनट है |
- **Romanized:** Tension mat lo abhi 9 bajne me 15 min h
- **Answer:** Don’t worry, its 15 to 9 left.

### 36

- **Hindi:** 6 बजने में 30 मिनट का अलार्म लगा दो।
- **Romanized:** 6 bajne mai 30 minute ka alarm laga do.
- **Answer:** Set an alarm for 30 to 6.

### 37

- **Hindi:** सवा 3 बजे बुलाया है पासबुक लेने।
- **Romanized:** Sava 3 baje bulaya hai passbook lene.
- **Answer:** Called at quarter past 3 to collect the passbook.

### 38

- **Hindi:** सवा 6 बजे मेरे दोस्त आयेंगे।
- **Romanized:** Sava 6 baje mere dost aaenge.
- **Answer:** My friend will come at quarter past 6.

### 39

- **Hindi:** पौने 5 बजे दुकान चले जाना।
- **Romanized:** Pone 5 baje dukaan chale jaana.
- **Answer:** Go to the shop at quarter to 5.

### 40

- **Hindi:** हम सब आज 10 बजकर 30 मिनट पर घूमने जायेंगे।
- **Romanized:** Hum sab aaj 10 bajkar 30 minute per ghoomne jaayenge.
- **Answer:** We will all go for a walk at 30 past 10 today.

### 41

- **Hindi:** स्कूल बस का आने का समय 8 बजकर 30 मिनट का है।
- **Romanized:** School Bus ka aane ka samay 8 bajkar 30 minute ka hai.
- **Answer:** The arrival time of the school bus is 30 past 8.

### 42

- **Hindi:** हमें स्कूल बस 2 बजकर 45 मिनट पर घर छोड़ती है।
- **Romanized:** Hamein school bus 2 bajkar 45 minute par ghar chhodti hai.
- **Answer:** The school bus leaves us home at 45 past 2.

### 43

- **Hindi:** कल हम 7 बजकर 15 मिनट पर शादी मे जायेंगे।
- **Romanized:** Kal hum 7 bajkar 15 minute per Shaadi mein jaayenge.
- **Answer:** Tomorrow we will go to the wedding at 15 past 7.

### 44

- **Hindi:** हमने डीजे में रात के 12 बजकर 15 मिनट तक डांस किया।
- **Romanized:** Humne DJ mein raat ke 12 bajkar 15 minute tak dance kiya.
- **Answer:** We danced on the DJ till quarter past 12 at night.

### 45

- **Hindi:** कल बारात 7 बजकर 45 मिनट पर पहुँची |
- **Romanized:** kal baaraat 7 bajkar 45 minute par pahuchee.
- **Answer:** Yesterday the procession reached at 45 past 7.

### 46

- **Hindi:** मैं सुबह 9 बजकर 15 मिनट पर ऑफिस के लिये निकलता हूँ।
- **Romanized:** Main subah 9 bajkar 15 minute par office ke liye nikalta hoon.
- **Answer:** I leave for office 15 past 9 am.

### 47

- **Hindi:** मेरी छुट्टी 6 बजकर 15 मिनट पर होती है।
- **Romanized:** Meri chhutti 6 bajkar 15 minute pr hoti h.
- **Answer:** I leave office at quarter past 6.

### 48

- **Hindi:** 4 बजने के लिये 15 मिनट बाकी है।
- **Romanized:** 4 bajne ke liye 15 minute baki hai.
- **Answer:** It’s 15 minutes left to 4.

### 49

- **Hindi:** 3 बजने के लिये 7 मिनट बाकी है।
- **Romanized:** 3 bajne ke liye 7 minute baaki hai.
- **Answer:** It’s 7 minutes left to 3.

### 50

- **Hindi:** 6 बजने के लिये 3 मिनट बाकी है।
- **Romanized:** 6 bajne ke liye 3 minute baki hai.
- **Answer:** It’s 3 minutes left to 6.

### 51

- **Hindi:** 11 बजने के लिये 19 मिनट बाकी है।
- **Romanized:** 11 bajne ke liye 19 minute baaki hai.
- **Answer:** It’s 19 minutes left to 11.

### 52

- **Hindi:** 1 बजने के लिये 22 मिनट बाकी है।
- **Romanized:** 1 bajne ke liye 22 minute baaki hai.
- **Answer:** It’s 22 minutes left to 1.

### 53

- **Hindi:** 8 बजने के लिये 9 मिनट बाकी है।
- **Romanized:** 8 bajne ke liye 9 minute baaki hai.
- **Answer:** It’s 9 minutes left to 8.

### 54

- **Hindi:** 3 बजने के लिये 28 मिनट बाकी है।
- **Romanized:** 3 bajne ke liye 28 minute baaki hai.
- **Answer:** It’s 28 minutes left to 3.

### 55

- **Hindi:** रात के पौने दो बजे है।
- **Romanized:** Raat ke pone 2 baje hai.
- **Answer:** It’s quarter to 2 in the night.

### 56

- **Hindi:** रात के पौने 9 बजे है।
- **Romanized:** Raat ke pone 9 baje hai.
- **Answer:** It’s quarter to 9 in the night.

### 57

- **Hindi:** रात के पौने 11 बजे है।
- **Romanized:** Raat ke pone 11 baje hai.
- **Answer:** It’s quarter to 11 in the night.

### 58

- **Hindi:** सुबह के पौने 6 बजे है।
- **Romanized:** Subah ke pone 6 baje hai.
- **Answer:** It’s quarter to 6 in the morning.

### 59

- **Hindi:** सुबह के पौने 7 बजे है।
- **Romanized:** Subah ke pone 6 baje hai.
- **Answer:** It’s quarter to 7 in the morning.

### 60

- **Hindi:** सुबह के पौने 9 बजे है।
- **Romanized:** Subah ke pone 9 baje hai.
- **Answer:** It’s quarter to 9 in the morning.

### 61

- **Hindi:** साढ़े 2 बजे हैं।
- **Romanized:** Saade 2 baje hai.
- **Answer:** It’s half past 2.

### 62

- **Hindi:** साढ़े 7 बजे हैं।
- **Romanized:** Saade 7 baje hai.
- **Answer:** It’s half past 7.

### 63

- **Hindi:** साढ़े 9 बजे है |
- **Romanized:** Saade 9 baje hai.
- **Answer:** It’s half past 9.

### 64

- **Hindi:** साढ़े 4 बजे हैं।
- **Romanized:** Saade 4 baje hai.
- **Answer:** It’s half past 4.

### 65

- **Hindi:** साढ़े 6 बजे है |
- **Romanized:** Saade 6 baje hai.
- **Answer:** It’s half past 6.

### 66

- **Hindi:** हम साढ़े 4 बजे मूवी देखने जायेंगे।
- **Romanized:** Hum saade 4 baje movie dekhene jaayenge.
- **Answer:** We will go to see a movie at half past 4.

### 67

- **Hindi:** हम साढ़े 6 बजे खेलने जायेंगे।
- **Romanized:** Hum Saade 6 baje khelne jaayenge.
- **Answer:** We will go to play half past 6.

### 68

- **Hindi:** हम साढ़े 9 बजे खाना खाते है |
- **Romanized:** Hum Saade 9 baje khana khate hai.
- **Answer:** We have dinner half past 9 pm.

### 69

- **Hindi:** हम साढ़े 10 बजे सोते हैं।
- **Romanized:** Hum Saade 10 baje sote hai.
- **Answer:** We sleep half past 10.

### 70

- **Hindi:** हमारा स्कूल पौने 8 बजे से लगता है।
- **Romanized:** Hamara school pone 8 baje lagta hai.
- **Answer:** Our school starts from quarter to 8.

### 71

- **Hindi:** हम शाम को पौने 6 बजे घूमने जाते हैं।
- **Romanized:** Hum sham ko pone 6 baje ghoomne jate h.
- **Answer:** We go for a walk at quarter to 8 in the evening.

### 72

- **Hindi:** हम सुबह पौने 5 बजे उठते हैं |
- **Romanized:** Hum subah pone 5 baje uthate hain.
- **Answer:** We get up quarter to 5 in the morning.

### 73

- **Hindi:** हमारा ट्यूशन पौने 4 बजे से है।
- **Romanized:** Hamara tution pone 4 baje se hai.
- **Answer:** Our tuition is from quarter to 4.

### 74

- **Hindi:** पौने 9 बजे से हम टीवी देखना शुरु करते है।
- **Romanized:** Pone 9 baje se ham TV dekhna shuru karte hai.
- **Answer:** We start watching TV at quarter to 4.

### 75

- **Hindi:** कल लाइट 2 बजकर 15 मिनट पर आयी।
- **Romanized:** Kal light 2 bajkar 15 minute per aayi.
- **Answer:** Yesterday the light came at 15 past 2.

### 76

- **Hindi:** कल बस 4 बजकर 20 मिनट पर निकली।
- **Romanized:** Kal bus 4 bajkar 20 minute per nikali.
- **Answer:** Yesterday the bus left 20 past 4.

### 77

- **Hindi:** दिल्‍ली की बस साढ़े 3 बजे मिलती है |
- **Romanized:** Delhi ki bus Saade 3 baje milti hai.
- **Answer:** The bus to Delhi is available half past 3.

### 78

- **Hindi:** हम कल साढ़े 6 बजे आपके घर आयेंगे।
- **Romanized:** Hum kal Saade 6 baje aapke ghar aayenge.
- **Answer:** We will come to your house tomorrow at half past 6.

### 79

- **Hindi:** हम आपके घर से साढ़े 4 बजे निकलेंगे।
- **Romanized:** Hum apke ghar se Saade 4 baje niklege.
- **Answer:** We will leave your house at half past 4.

### 80

- **Hindi:** कल हमारी 2 बजकर 35 मिनट पर फ्लाइट है।
- **Romanized:** Kal hamari 2 bajkar 35 minute per flight hai.
- **Answer:** Tomorrow we have a flight at 35 past 2.

### 81

- **Hindi:** कल हम पौने 9 बजे मामा के घर जायेंगे।
- **Romanized:** Kal hum pone 9 baje mama ke ghar jaayenge.
- **Answer:** Tomorrow we will go to maternal uncle's house at quarter to 9.

### 82

- **Hindi:** हम शादी से पौने 10 बजे से पहले निकल गये थे।
- **Romanized:** Hum saadi se pone 10 baje se pahle nikal gaye the.
- **Answer:** We had left the wedding before quarter to 10.

### 83

- **Hindi:** कल का पहला शो 11 बजकर 35 मिनट से शुरू है।
- **Romanized:** Kal ka phela show 11 bajkar 35 minute se suru hai.
- **Answer:** Tomorrow's first show starts at 35 past 11.

### 84

- **Hindi:** कल हम मात्र साढ़े 4 घंटे में देहरादून से दिल्ली पहुँच गया।
- **Romanized:** Kal hum maatar Saade 4 ghante mein Dehradun se Delhi pahunch gaya.
- **Answer:** Yesterday we reached Delhi from Dehradun in just half past 4.

### 85

- **Hindi:** कल मैं पौने 2 बजे देहरादून से निकल जाऊँगा।
- **Romanized:** Kal main pone 2 baje Dehradun se nikal jaaoga.
- **Answer:** Tomorrow I will leave Dehradun at quarter to 3.

### 86

- **Hindi:** सुबह पानी सवा 4 बजे आता है।
- **Romanized:** Subah paani sava 4 baje aata hai.
- **Answer:** Water comes at quarter past 4 in the morning.

### 87

- **Hindi:** आज रात को 2 बजकर 22 मिनट से बहुत तेज़ बारिश हो रही है।
- **Romanized:** Aaj raat ko 2 bajkar 22 minute se bahut tez baarish ho rahi hai.
- **Answer:** It’s been raining very heavily since 22 past 2 tonight.

### 88

- **Hindi:** आज पौने 3 बजे मैच का लाइव सीधा प्रसारण होगा।
- **Romanized:** Aaj pone 3 baje match ka live sidha parasaaran hoga.
- **Answer:** There will be a live telecast of the match today from quarter to 3.

### 89

- **Hindi:** मेरी कार मुझे साढ़े 6 बजे लेने आयेगी।
- **Romanized:** Meri car mujhe Saade 6 baje lene aayegi.
- **Answer:** My car will come to pick me up at half past 6.

### 90

- **Hindi:** साढ़े 3 बजे से मेरी मीटिंग है |
- **Romanized:** Saade 3 baje se meri meeting hai.
- **Answer:** I have a meeting from half past 3.

### 91

- **Hindi:** उसने मुझे 5 बजकर 35 मिनट पर बुलाया है।
- **Romanized:** Usne mujhe 5 bajkar 35 minute per bulaya hai.
- **Answer:** He has called me at 35 past 4.

### 92

- **Hindi:** मैं ढाई घंटे से ठंड में काँप रहा हूँ।
- **Romanized:** Main dhai ghante se thand me kaanp raha hoon.
- **Answer:** I have been shivering in the cold for half past 2.

### 93

- **Hindi:** यहाँ सवा तीन घंटे से बर्फ गिर रही है।
- **Romanized:** Yaha sava teen ghante se barf gir rahi hai.
- **Answer:** It has been snowing here for quarter past 3.

### 94

- **Hindi:** मेरा पार्सल 2 बजकर 58 मिनट पर आया था।
- **Romanized:** Mera parcel 2 bajkar 58 minute per aayaa tha.
- **Answer:** My parcel arrived at 58 past 2.

### 95

- **Hindi:** 8 बजकर 55 मिनट पर मनीषा की मिस कॉल आयी थी।
- **Romanized:** 8 Bajkar 55 minute per Manisha ki miss call aayi thi.
- **Answer:** Manisha's missed call was received at 55 past 8.

### 96

- **Hindi:** सवा 11 बजे तक शायद वो आ जाए।
- **Romanized:** Sava 11 baje tak shayad vo aa jaye.
- **Answer:** He might come by quarter past 11

### 97

- **Hindi:** 10 बजकर 1 मिनट भी हुआ तो मत आना।
- **Romanized:** 10 bajkar 1 minute bhi huwa to mat aana.
- **Answer:** If it is even 1 minute after 10 then don’t come.

### 98

- **Hindi:** पौने 10 बजे तक तो मैं आराम से आ जाऊँगा।
- **Romanized:** Pone 10 baje tak to mai aaram se aa jaunga.
- **Answer:** By quarter to 10, I will come easily.

### 99

- **Hindi:** 6 बजने में 10 मिनट थे जब वो आई।
- **Romanized:** 6 bajne main 10 minute the jab vo aayi.
- **Answer:** It was 10 to 6 when she came.

### 100

- **Hindi:** 7 बजकर 10 मिनट तक रुक जाओ मेरे पास।
- **Romanized:** 7 bajkar 10 minute tak ruk jao mere pass.
- **Answer:** Stay with me till 10 past 7.

---
**Verification:** 100 prompts on PDF pages 13–17 and 100 answers on pages 18–20; question and answer sequences 1–100 are paired in order. OCR numeral items manually corrected from the page: 23. Source Hindi/Romanized numeral discrepancies: 1; unresolved numeral OCR items: 0.
- **Source discrepancy, item 59:** Hindi reads `सुबह के पौने 7 बजे है ।`; Romanized reading reads `Subah ke pone 6 baje hai.`. Both are retained as printed.
- **Printed answer-key mismatch, item 18:** Hindi/Romanized prompt says 2:30; the printed English answer says “quarter past 2.” The printed answer has been retained.
- **Printed answer-key mismatch, item 19:** Hindi/Romanized prompt says 2:30; the printed English answer says “quarter past 2.” The printed answer has been retained.
- **Printed answer-key mismatch, item 71:** Hindi/Romanized prompt says quarter to 6; the printed English answer says quarter to 8. The printed answer has been retained.
- **Printed answer-key mismatch, item 74:** Hindi/Romanized prompt says quarter to 9; the printed English answer says quarter to 4. The printed answer has been retained.
- **Printed answer-key mismatch, item 85:** Hindi/Romanized prompt says quarter to 2; the printed English answer says quarter to 3. The printed answer has been retained.
- **Printed answer-key mismatch, item 91:** Hindi/Romanized prompt says 5:35; the printed English answer says 35 past 4. The printed answer has been retained.
- **Printed answer-key mismatch, item 92:** Hindi/Romanized prompt says “for two and a half hours”; the printed English answer says “for half past 2.” The printed answer has been retained.
- **Spelling correction:** Answer item 3: the printed source says “wil”; corrected to “will” without changing meaning.
