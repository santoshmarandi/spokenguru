# Lesson 25 — Passive Voice

**PDF pages:** 347–355 (printed pages 346–354)

## Please translate the following PASSIVE VOICE sentences into English:

1. **Hindi prompt:** तुम्हें डाँटा जाता है।  
   **Romanized:** Tumhein daanta jata hai.  
   **English answer:** You are scolded.  

2. **Hindi prompt:** हमें पीटा जा रहा था।  
   **Romanized:** Humein peeta ja raha tha.  
   **English answer:** We were being beaten.  

3. **Hindi prompt:** मुझे एक किताब दी जायेगी।  
   **Romanized:** Mujhe ek kitaab dee jayegee.  
   **English answer:** I will be given a book.  

4. **Hindi prompt:** इस पुरस्कार के लिए केवल एक आदमी चुना जाता है।  
   **Romanized:** Is puraskaar ke liye keval ek aadmi chuna jata hai.  
   **English answer:** Only one person is selected for this prize.  

5. **Hindi prompt:** मुझे तुम्हारे बारे में बताया गया है।  
   **Romanized:** Mujhe tumhare bare mein bataya gaya hai.  
   **English answer:** I have been told about you.  

6. **Hindi prompt:** भारत को शांतिप्रिय देश के रूप में जाना जाता है।  
   **Romanized:** Bharat ko shantipriya desh ke roop me jana jata hai.  
   **English answer:** India is known as a peaceful nation.  

7. **Hindi prompt:** क्या उसे भेजा गया?  
   **Romanized:** Kya use bheja gaya?  
   **English answer:** Was he sent?  

8. **Hindi prompt:** तुम्हारे लिए स्पेशल खाना बनाया जा रहा है।  
   **Romanized:** Tumhare liye special khana banaya ja raha h  
   **English answer:** A special food is being prepared for you.  

9. **Hindi prompt:** उनके साथ वहाँ बुरा बर्ताव किया गया।  
   **Romanized:** Unke saath vaha bura bartaav kiya gaya.  
   **English answer:** They were treated badly there.  

10. **Hindi prompt:** उसे एक महान योद्धा के रूप में जाना जाता था।  
   **Romanized:** Use ek mahan yoddha ke roop mein jana jata tha.  
   **English answer:** He was known as a great warrior.  

11. **Hindi prompt:** ये लिखा जा चुका है।  
   **Romanized:** Ye likha ja chuka hai.  
   **English answer:** It has been written.  

12. **Hindi prompt:** क्या उसे प्यार किया जाता है?  
   **Romanized:** Kya use pyar kiya jata hai?  
   **English answer:** Is he loved?  

13. **Hindi prompt:** फिल्म के मेगा हिट होने की घोषणा हो चुकी है।  
   **Romanized:** Film ke mega hit hone ki ghoshna ho chuki hai.  
   **English answer:** The movie has been declared a mega hit.  

14. **Hindi prompt:** गैंग के मुखिया को 2:00 बजे मार्केट में देखा गया है।  
   **Romanized:** Gang ke mukhiya ko 2:00 baje market mein dekha gaya hai.  
   **English answer:** The chief of the gang has been seen in the market at 2.  

15. **Hindi prompt:** क्या उन्हें इस शरारत के लिए डाँटा गया?  
   **Romanized:** Kya unhe is shrarat ke liye daanta gaya?  
   **English answer:** Were they scolded for this mischief?  

16. **Hindi prompt:** दोनों दोषियों की पहचान की जा चुकी है।  
   **Romanized:** Dono doshiyo ki pahchan kee ja chukee hai.  
   **English answer:** Both the culprits have been identified.  

17. **Hindi prompt:** चाय हर सुबह पी जाती है।  
   **Romanized:** Chai har subah pee jatee hai.  
   **English answer:** Tea is taken every morning.  

18. **Hindi prompt:** उसे किसके साथ भेजा गया?  
   **Romanized:** Use kiske saath bheja gaya?  
   **English answer:** Whom was he sent with?  

19. **Hindi prompt:** उसे मर्डर के बारे में क्यों नहीं पूछा जाता?  
   **Romanized:** Use murder ke bare me kyo ni pochha jata?  
   **English answer:** Why is he not asked about the murder?  

20. **Hindi prompt:** 4 टिकटें बुक कर ली गयी हैं।  
   **Romanized:** 4 tickten book kar lee gayi hai.  
   **English answer:** 4 Tickets have been booked.  

21. **Hindi prompt:** किस्मत से मुझे वहाँ भेजा गया और मैं तुमसे मिला।  
   **Romanized:** Kismat se mujhe vaha bheja gaya aur main tumse mila.  
   **English answer:** Fortunately, I was sent there and I met you.  

22. **Hindi prompt:** मुझे एक अध्यापक के रूप में जाना जाता है।  
   **Romanized:** Mujhe ek teacher ke roop me jana jata h.  
   **English answer:** I am known as a teacher.  

23. **Hindi prompt:** बच्चों को बाहर भेजा गया।  
   **Romanized:** Bachchon ko bahar bheja gaya.  
   **English answer:** Children were sent outside.  

24. **Hindi prompt:** मुझे इसके बारे में सूचित नहीं किया गया।  
   **Romanized:** Mujhe iske bare me soochit nahi kiya gaya.  
   **English answer:** I was not informed about this.  

25. **Hindi prompt:** किताबें छापी जा रही हैं।  
   **Romanized:** Kitabein chhapee ja rahee hai.  
   **English answer:** Books are being printed.  

26. **Hindi prompt:** इस जगह से कुछ कुर्सियाँ हटाई गई हैं।  
   **Romanized:** Is jagah se kuch kursiyaan hataee gai hai.  
   **English answer:** Few/Some chairs have been moved from this place.  

27. **Hindi prompt:** इस इलाके में कारें नहीं चलाई जाती।  
   **Romanized:** Is ilaake mein carey nahi chlai jati.  
   **English answer:** Cars are not driven in this area.  

28. **Hindi prompt:** उसे कब तक नहीं पूछा गया?  
   **Romanized:** Use kab tak nahi puchha gaya?  
   **English answer:** Until when was he not asked?  

29. **Hindi prompt:** हर जगह मिठाइयां बाँटी जा रही हैं।  
   **Romanized:** Har jagah mithiyaan batee ja rahee hai.  
   **English answer:** Sweets are being distributed everywhere.  

30. **Hindi prompt:** वहाँ एक बिल्डिंग बनाई जा चुकी है।  
   **Romanized:** Waha ek building banai ja chuki hai.  
   **English answer:** A building has been constructed there.  

31. **Hindi prompt:** वो पुलिस के द्वारा पकड़ा गया।  
   **Romanized:** Vo police ke dwara pakda gaya.  
   **English answer:** He was caught by the police.  

32. **Hindi prompt:** प्याज और आलू अधिक मात्रा में काटे गये।  
   **Romanized:** Pyaaj aur aaloo adhik matra me kate gaye.  
   **English answer:** Onions and potatoes were cut in huge quantity.  

33. **Hindi prompt:** अपराधियों को ढूँढा जा रहा है।  
   **Romanized:** Apradhiyo ko dhoondha ja raha hai.  
   **English answer:** The criminals are being tracked.  

34. **Hindi prompt:** उसे गोली से मार दिया गया।  
   **Romanized:** Use goli se maar diya gaya.  
   **English answer:** He was shot dead.  

35. **Hindi prompt:** बारिश के कारण मीटिंग रद्द कर दी गयी।  
   **Romanized:** Barish ke karan meeting radd kar di gayee.  
   **English answer:** Meeting was cancelled due to rain.  

36. **Hindi prompt:** घड़ी ठीक कराई गयी।  
   **Romanized:** Ghadee theek karaee gayee.  
   **English answer:** The watch was repaired.  

37. **Hindi prompt:** हमें ऐसा कुछ नहीं दिया गया है।  
   **Romanized:** Hamein aisa kuch nahi diya gaya hai.  
   **English answer:** We have not been given anything as such.  

38. **Hindi prompt:** हमें वहाँ फालतू में क्यों भेजा जाता है?  
   **Romanized:** Hamein vaha faltu mein kyo bheja jata hai?  
   **English answer:** Why are we unnecessarily sent there?  

39. **Hindi prompt:** मुझे कहीं भेजा गया।  
   **Romanized:** Mujhe kahi bheja gaya.  
   **English answer:** I was sent somewhere.  

40. **Hindi prompt:** क्या तुम्हें बताया गया है कि हम कहाँ हैं?  
   **Romanized:** Kya tumhein bataya gaya hai ki hum kaha h?  
   **English answer:** Have you been told where we are?  

41. **Hindi prompt:** एक विद्यार्थी को उसके सहपाठी द्वारा प्रताड़ित किया गया।  
   **Romanized:** ek vidyarthee ko uske sahpathee dwara pratadit kiya gaya.  
   **English answer:** A student was tortured by his classmate.  

42. **Hindi prompt:** उसे ट्रक की ओर धक्का दिया गया ताकि वो मर जाए।  
   **Romanized:** Use truck ki or dhakka diya gaya taki vo mar jaye.  
   **English answer:** He was pushed towards a truck so that he dies.  

43. **Hindi prompt:** दीवाली खुशी से मनाई गई।  
   **Romanized:** Diwali khushi se manaee gai.  
   **English answer:** Diwali was celebrated with joy.  

44. **Hindi prompt:** क्या तुम्हें तुम्हारी लापरवाही के लिए दंड दिया जाएगा?  
   **Romanized:** Kya tumhein tumhari laparvahee ke liye dand diya jaega?  
   **English answer:** Will you be punished for your negligence?  

45. **Hindi prompt:** हमें कहीं और भेजा जा रहा है।  
   **Romanized:** Hamein kahi aur bheja ja raha hai.  
   **English answer:** We are being sent somewhere else.  

46. **Hindi prompt:** पेन उठा लिया गया है।  
   **Romanized:** Pen utha liya gaya hai.  
   **English answer:** The pen has been picked.  

47. **Hindi prompt:** उसे यह क्यों दिया गया?  
   **Romanized:** Use yah kyo diya gaya?  
   **English answer:** Why was he given this?  

48. **Hindi prompt:** हमें क्या बताया गया?  
   **Romanized:** Hamein kya bataya gaya?  
   **English answer:** What were we told?  

49. **Hindi prompt:** उन्हें कहाँ भेजा गया था?  
   **Romanized:** Unhein kaha bheja gaya tha?  
   **English answer:** Where had they been sent?  

50. **Hindi prompt:** उसे घसीट कर पुलिस स्टेशन ले जाया गया।  
   **Romanized:** Use ghasit kar police station le jaya gaya.  
   **English answer:** He was dragged to police station.  

51. **Hindi prompt:** हमारी किताबों को फाड़ा गया और कूड़ेदान में फेंक दिया गया।  
   **Romanized:** Hamari kitabo ko fada gaya aur koodedaan mein phenk diya gaya.  
   **English answer:** Our books were torn & thrown into the dustbin.  

52. **Hindi prompt:** हमें 6 क्लास तक अंग्रेजी नहीं पढ़ाई जाती।  
   **Romanized:** Hame 6 class tak English nahi padhai jati.  
   **English answer:** We are not taught English up to the 6th standard.  

53. **Hindi prompt:** इस साल केवल कुछ विद्यार्थियों को लैपटॉप दिये गये हैं।  
   **Romanized:** Is saal keval kuch vidyarthiyo ko lapatop diye gaye hai.  
   **English answer:** Only a few students have been given laptops this year.  

54. **Hindi prompt:** 25 प्रतिशत सीटें गरीब स्टूडेंट्स के लिए आरक्षित हैं।  
   **Romanized:** 25 pratishat seetein gareeb students ke liye aarakshit hai.  
   **English answer:** 25% seats are reserved for poor students.  

55. **Hindi prompt:** इंसान को स्वर्ग भेजा जाता है अगर वो अच्छे कर्म करे।  
   **Romanized:** Insaan ko swarg bheja jata hai agar vo achchhe karm kare.  
   **English answer:** Human is sent to heaven if he does good deeds.  

56. **Hindi prompt:** राम को भेजा जा सकता है।  
   **Romanized:** Ram ko bheja ja sakta hai.  
   **English answer:** Ram can be sent.  

57. **Hindi prompt:** उसे पूछा जाना चाहिए था।  
   **Romanized:** Use puchha jana chaahiye tha.  
   **English answer:** He should have been asked.  

58. **Hindi prompt:** हमें भेजा जाना है।  
   **Romanized:** Hamein bheja jana hai.  
   **English answer:** We have to be sent.  

59. **Hindi prompt:** तुम्हें बुलाया जाना था पर नहीं बुलाया जा सका।  
   **Romanized:** Tumhein bulaya jana tha par nahi bulaya ja saka.  
   **English answer:** You had to be called but couldn’t be.  

60. **Hindi prompt:** ये काम हो जाना चाहिए था।  
   **Romanized:** Ye kaam ho jana chahiye tha.  
   **English answer:** This work should have been done.  

61. **Hindi prompt:** मम्मी को पूछा जाता था।  
   **Romanized:** Mummy ko puchha jata tha.  
   **English answer:** Mom used to be asked.  

62. **Hindi prompt:** क्या राम को किताब दी जा सकती है?  
   **Romanized:** Kya Ram ko kitaab dee ja sakti hai?  
   **English answer:** Can Ram be given the book?  

63. **Hindi prompt:** तुम्हें क्यों नहीं पढ़ाया जा सका?  
   **Romanized:** Tumhein kyo nahi padhaya ja saka?  
   **English answer:** Why could you not be taught?  

64. **Hindi prompt:** उसे क्या दिया गया?  
   **Romanized:** Use kya diya gaya?  
   **English answer:** What was he given?  

65. **Hindi prompt:** राम को किसके साथ भेजा जाना चाहिए?  
   **Romanized:** Ram ko kiske saath bheja jana chahiye?  
   **English answer:** With whom should Ram be sent?  

66. **Hindi prompt:** मोबाइल का प्रयोग क्यों होना चाहिए?  
   **Romanized:** Mobile ka prayog kyo hona chahiye?  
   **English answer:** Why should mobile be used?  

67. **Hindi prompt:** हमें क्या पढ़ाया जाता था?  
   **Romanized:** Hamein kya padhaya jata tha?  
   **English answer:** What were we taught?  

68. **Hindi prompt:** मुझे मोबाइल दिया जा सकता है।  
   **Romanized:** Mujhe mobile diya ja sakta hai.  
   **English answer:** I can be given a mobile.  

69. **Hindi prompt:** अगला प्रश्न क्या होना चाहिए?  
   **Romanized:** Agla prashn kya hona chahiye?  
   **English answer:** What should be the next question?  

70. **Hindi prompt:** तुम्हें सजा मिलनी चाहिए।  
   **Romanized:** Tumhein saja milni chahiye.  
   **English answer:** You must be punished.  

71. **Hindi prompt:** हमें कुछ पैसे खर्च के लिए मिलने चाहिए।  
   **Romanized:** Hame kuch paise kharch k liye milne chahie  
   **English answer:** We should be given some money to spend.  

72. **Hindi prompt:** हमारी तनख्वाह बढ़ाई जानी है।  
   **Romanized:** Hamari tankhvah badhai jani hai.  
   **English answer:** Our salary is to be increased.  

73. **Hindi prompt:** उससे पूछा जाना था।  
   **Romanized:** Usse puchha jana tha.  
   **English answer:** He had to be asked.  

74. **Hindi prompt:** होमवर्क ज़रूर करना चाहिए।  
   **Romanized:** Homework jaroor karna chahiye.  
   **English answer:** Homework must be done.  

75. **Hindi prompt:** सारे प्रश्न हल किये जा सकते हैं।  
   **Romanized:** Saare prashn hal kiye ja sakte hai.  
   **English answer:** All the questions can be solved.  

76. **Hindi prompt:** खाने का तरीका सुधारा जा सकता है।  
   **Romanized:** khane ka tareeka sudhara ja sakta hai.  
   **English answer:** The way of eating can be improved.  

77. **Hindi prompt:** उसे राम की वजह से बुलाया गया।  
   **Romanized:** use Ram kee vajah se bulaya gaya.  
   **English answer:** He was called due to Ram.  

78. **Hindi prompt:** मुझे कंपनी से बाहर नहीं निकाला जा सका।  
   **Romanized:** Mujhe company se bahar ni nikala ja saka.  
   **English answer:** I could not be fired from the company.  

79. **Hindi prompt:** किसी का भी दिल दुखाया जा सकता है।  
   **Romanized:** kisi ka bhi dil dukhaya ja sakta hai.  
   **English answer:** Anybody can be hurt.  

80. **Hindi prompt:** हर किसी का दिल नहीं जीता जा सकता।  
   **Romanized:** Har kisi ka dil nahi jeeta ja sakta.  
   **English answer:** One can’t win everyone’s heart.  

81. **Hindi prompt:** मेरे साथ किसी को भेजा नहीं जाना चाहिए।  
   **Romanized:** Mere saath kisi ko bheja nahi jana chahie.  
   **English answer:** No one should be sent with me. / I should not be sent with anyone.  

82. **Hindi prompt:** उसे कहाँ भेजा जाना चाहिए।  
   **Romanized:** Use kaha bheja jana chahiye.  
   **English answer:** Where should he be sent?  

83. **Hindi prompt:** उसका नाम कुछ देर बाद पुकारा जाना है।  
   **Romanized:** uska naam kuch der baad pukara jana hai.  
   **English answer:** His name is to be called after a while.  

84. **Hindi prompt:** यहाँ पर पैन से लिखा जाना है।  
   **Romanized:** Yaha par pen se likha jana hai.  
   **English answer:** Pen is to be used here.  

85. **Hindi prompt:** तुम्हें ये नहीं दिया जाना।  
   **Romanized:** Tumhein ye nahi diya jana.  
   **English answer:** You are not to be given this.  

86. **Hindi prompt:** मछलियों को कहीं और भेजा जा सकता है।  
   **Romanized:** Machhliyo ko kahi aur bheja ja sakta hai.  
   **English answer:** Fishes can be sent somewhere else.  

87. **Hindi prompt:** ये पानी पिया नहीं जा सकता क्योंकि यह खारा है।  
   **Romanized:** Ye pani piya nahi ja sakta kyoki yah khara hai.  
   **English answer:** This water is not drinkable as it is saline.  

88. **Hindi prompt:** इसे किसी भी हाल में बेच दिया जाना चाहिए।  
   **Romanized:** Ise kisi bhi haal me bech diya jana chahiye  
   **English answer:** It should be sold at any cost.  

89. **Hindi prompt:** मुझे पढ़ने नहीं दिया जाता।  
   **Romanized:** Mujhe padhne nahi diya jata.  
   **English answer:** I am not let study.  

90. **Hindi prompt:** हमसे पूछा जा रहा है कि हम कौन हैं।  
   **Romanized:** Humse poocha jaa raha hai ki hum kaun hain.  
   **English answer:** We are being asked who we are.  

91. **Hindi prompt:** आपको भेजा जा सकता है।  
   **Romanized:** Aapko bheja jaa sakta hai.  
   **English answer:** You may/can be sent.  

92. **Hindi prompt:** मुझे रोज़ पीटा जाता था।  
   **Romanized:** Mujhe roz peeta jaata tha.  
   **English answer:** I used to be beaten daily.  

93. **Hindi prompt:** उसे घसीटकर घर से बाहर कर दिया गया।  
   **Romanized:** Use ghasitkar ghar se bahar kr diya gaya.  
   **English answer:** He was dragged out of the house.  

94. **Hindi prompt:** राम को प्रतिदिन अस्पताल ले जाया जाता है।  
   **Romanized:** Ram ko pratinin aspatal le jaya jaata hai.  
   **English answer:** Ram is taken to hospital daily.  

95. **Hindi prompt:** हमें आज कुछ नया सिखाया जाना चाहिए।  
   **Romanized:** Hume aaj kuch naya sikhaya jaana chahiye.  
   **English answer:** We should be taught something new today.  

96. **Hindi prompt:** तुम चोर हो। क्या आपको पीटा नहीं जाना चाहिए?  
   **Romanized:** Tum chor ho. Kya tumhe peeta nahi jaana chahiye.  
   **English answer:** You are a thief. Should you not be beaten?  

97. **Hindi prompt:** यह काम राम ने करवाया था।  
   **Romanized:** Yah kaam ram nai karwaya tha.  
   **English answer:** This work was got done by Ram.  

98. **Hindi prompt:** मुझे भी किताब दी जा सकती थी लेकिन तुमने नहीं दी।  
   **Romanized:** Mujhe bhi kitaab dee jaa sakti thi lekin tumne nahi dee.  
   **English answer:** Even I could have been given the book but you didn’t.  

99. **Hindi prompt:** मुझे यहाँ भेजा गया है।  
   **Romanized:** Mujhe yahaan bheja gaya.  
   **English answer:** I have been sent here.  

100. **Hindi prompt:** बच्चों को क्या दिया जाएगा?  
   **Romanized:** Bachon ko kya diya jaega.  
   **English answer:** What will children be given?  

101. **Hindi prompt:** मुझे वहाँ जाने नहीं दिया गया।  
   **Romanized:** Mujhe vahaan jaane nahi diya gya.  
   **English answer:** I was not let go there.  

102. **Hindi prompt:** मुझे पीटा जाएगा।  
   **Romanized:** Mujhe peeta jaega.  
   **English answer:** I will be beaten.  

103. **Hindi prompt:** उसे बेवजह वहाँ भिजवाया गया।  
   **Romanized:** Use bewajah vahan bhijwaya gya.  
   **English answer:** He was unnecessarily made go there.  

104. **Hindi prompt:** तुम्हें भिजवाया जा रहा है।  
   **Romanized:** Tumhe bhijwaya jaa raaha hai.  
   **English answer:** You are being made go.  

105. **Hindi prompt:** जब तुम गलत काम करते हो, क्या तुम्हें डाँटा नहीं जाता।  
   **Romanized:** Jab tum galat kaam karte ho, kya tumhe daanta nahi jaata.  
   **English answer:** When you do wrong, are you not scolded?  

106. **Hindi prompt:** उसे बताया जा रहा था।  
   **Romanized:** Use bataya jaa rahaa tha.  
   **English answer:** He was being told.  

107. **Hindi prompt:** उसे वहाँ क्यों भेजा जाता है?  
   **Romanized:** Use vahaan kyun bheja jaata hai.  
   **English answer:** Why is he sent there?  

108. **Hindi prompt:** खूनी को तिहाड़ जेल ले जाया गया।  
   **Romanized:** Khooni ko tihar jail le jaaya gaya.  
   **English answer:** The criminal was taken to the Tihar Jail.  

109. **Hindi prompt:** राम को नहीं भेजा जाएगा।  
   **Romanized:** Ram ko nahi bheja jaaega.  
   **English answer:** Ram will not be sent.  

110. **Hindi prompt:** तुम्हें स्कूल में क्या सिखाया जाता है?  
   **Romanized:** Tumhein school main kya sikhaaya jaata hai.  
   **English answer:** What are you taught in school?  

111. **Hindi prompt:** मुझसे चार प्रश्न पूछे गये  
   **Romanized:** Mujhse chaar prashn pooche gye.  
   **English answer:** I was asked four questions.  

112. **Hindi prompt:** उसे कभी नहीं पीटा गया।  
   **Romanized:** Use kabhi nahi peeta gaya.  
   **English answer:** He was never beaten.  

113. **Hindi prompt:** राम की मम्मी को बाजार में देखा गया था।  
   **Romanized:** Ram kee mummy ko bazaar main dekha gaya tha.  
   **English answer:** Ram’s mother had been seen in the market.  

114. **Hindi prompt:** क्या उसे बुलाया गया?  
   **Romanized:** Kya use bulaaya gya?  
   **English answer:** Was he called?  

115. **Hindi prompt:** उसके पिता को जान से मार दिया गया।  
   **Romanized:** Uske pita ko jaan se maar diya gaya.  
   **English answer:** His father was killed.  

116. **Hindi prompt:** उन्हें कहाँ भेजा जा रहा है?  
   **Romanized:** Unhe kahan bheja jaa raha hai?  
   **English answer:** Where are they being sent?  

117. **Hindi prompt:** अब हमारी सैलेरी बढ़ाई जानी चाहिए।  
   **Romanized:** Ab humari salary badaai jaani chahiye.  
   **English answer:** Now, our salary must be increased.  

118. **Hindi prompt:** राहुल को कहा गया था कि उसे 2 घंटे पढ़ना है।  
   **Romanized:** Rahul ko kaha gaya tha ki use 2 ghante padhna hai.  
   **English answer:** Ram had been told that he had to study for 2 hours.  

119. **Hindi prompt:** हमे भिजवाया जाएगा।  
   **Romanized:** Hume bhijwayaa jaega.  
   **English answer:** We will be made go.  

120. **Hindi prompt:** मुझे कुछ भी नहीं दिया गया।  
   **Romanized:** Mujhe kuch bhi nahin diya gaya.  
   **English answer:** I was not given anything.  

121. **Hindi prompt:** राहुल को स्कूल से निकाल दिया गया होगा।  
   **Romanized:** Rahul ko school se nikal diya gaya hoga.  
   **English answer:** Rahul will have been expelled from the school.  

122. **Hindi prompt:** बच्चों को आज कुछ नहीं पढ़ाया गया।  
   **Romanized:** Bachon ko aaj kuch nahin padaya gaya.  
   **English answer:** Children were not taught anything today.  

123. **Hindi prompt:** राहुल को सुलाया जा रहा है।  
   **Romanized:** Rahul ko sulaaya jaa raha hai.  
   **English answer:** Rahul is being made sleep.  

124. **Hindi prompt:** मुझे सब कुछ दिया गया जो मैंने माँगा।  
   **Romanized:** Mujhe sab kuch diya gaya jo maine manga.  
   **English answer:** I was given everything that I demanded.  

125. **Hindi prompt:** हमें किसी और के साथ भेजा गया।  
   **Romanized:** Humein kisi or kai saath bheja gaya.  
   **English answer:** We were sent with someone else.  

126. **Hindi prompt:** उसे खाना नहीं दिया जाता था।  
   **Romanized:** Use khaana nahi diya jaata tha.  
   **English answer:** He didn’t use to be given the food.  

127. **Hindi prompt:** क्या उसे कोई अवार्ड दिया जाना है?  
   **Romanized:** Kya use koi award diya jaana hai?  
   **English answer:** Has he to be given an award?  

128. **Hindi prompt:** तुम्हें उसके साथ कहाँ भेजा गया था?  
   **Romanized:** Tumhe uske saath kahan bheja gaya tha?  
   **English answer:** Where had you been sent with him?  

129. **Hindi prompt:** पापा को अमेरिका भेजा जा सकता है।  
   **Romanized:** Papa ko America bheja jaa sakta hai.  
   **English answer:** Dad can be sent to America.  

130. **Hindi prompt:** दिल की बात को भी पढ़ा जा सकता है।  
   **Romanized:** Dil kee baat ko bhi pada jaa sakta hai.  
   **English answer:** Even, the heart can be read.  

131. **Hindi prompt:** सब बच्चों को चॉकलेट दी गयी हैं।  
   **Romanized:** Sab bachchon ko chocolate dee gayi hain.  
   **English answer:** All the children have been given chocolates.  

132. **Hindi prompt:** मुझसे एक गाना गवाया गया।  
   **Romanized:** Mujhse ek gana gawaya gaya.  
   **English answer:** I was made sing a song.  

133. **Hindi prompt:** उसे किसके साथ बिठाया गया?  
   **Romanized:** Use kiske saath bithaaya gaya?  
   **English answer:** With whom was he made sit?  

134. **Hindi prompt:** पापा को मेरे बारे मे गलत बताया गया।  
   **Romanized:** Papa ko mere bare mai galat bataya gaya.  
   **English answer:** Dad was told wrong about me.  

135. **Hindi prompt:** वहाँ एक पुल बनाया जायेगा।  
   **Romanized:** Vahaan ek pul banaya jaaega.  
   **English answer:** A bridge will be constructed there.  

136. **Hindi prompt:** हमें अगले महीने सूचना दी जायेगी।  
   **Romanized:** Hume agle mahine soochna dee jayegi.  
   **English answer:** We will be informed next month.  

137. **Hindi prompt:** क्या तुम्हें पैसे दिये जाते हैं स्कूल में?  
   **Romanized:** Kya tumhe paise diye jaate hain school me?  
   **English answer:** Are you given money in school?  

138. **Hindi prompt:** बच्चों को क्या दिया गया?  
   **Romanized:** Bachon ko kya diya gaya?  
   **English answer:** What were children given?  

## Source-text and verification notes

- All 138 Hindi prompts and their printed Romanized lines were OCRed from row crops and visually checked against the scans; all 138 English answers were visually reviewed and paired by number. The prompt and answer sequences are complete and unique.
- Lesson 25 spans PDF pages 347–355 (printed pages 346–354). Hindi/Romanized prompts 1–138 are on PDF pages 347–352; the English answer key runs 1–138 on pages 352–355. PDF page 352 contains prompt 138, then the Answers heading and answers 1–12.
- All 138 Hindi prompts and their printed Romanized lines were OCRed from row crops and visually checked against the scanned pages; all 138 English answers were visually reviewed and paired by number. The numbering is continuous and complete; no unreadable sections were found.
- Printed page footer numbers are one lower than PDF page numbers.
- Romanized source spellings are retained rather than normalized. Printed quirks include the abbreviated ‘h’ at items 8 and 22; ‘tickten’ at 20; singular/plural mismatches at 25, 26, and 29; ‘carey’ and ‘chlai’ at 27; ‘hum kaha h’ at 40; lowercase ‘ek’ at 41; ‘pratinin’ at 94; and source spellings such as ‘ram’, ‘nai’, ‘gya’, ‘jaa raaha’, ‘main’, ‘gye’, ‘humari’, ‘bhijwayaa’, ‘or kai’, and ‘mai’ in later items. These are documented and kept as printed. Item 88 Romanized ‘chahiye’ is restored from the scan where the text layer dropped the ‘y’.
- The English answer-key grammar, alternatives, and wording are retained as printed.

**Unreadable text:** none identified.

