# Lesson 4 — Three Forms of Verbs

**PDF pages:** 33–49 (printed pages 32–48)

## Exercise 1 — Write the three forms of the following verbs

### 1. Admit
**Hindi:** स्वीकार करना
**Answer:** Admit (स्वीकार करना) – Admitted – Admitted

### 2. Aid
**Hindi:** सहायता देना
**Answer:** Aid (सहायता देना) – Aided – Aided

### 3. Agree
**Hindi:** सहमति देना
**Answer:** Agree (सहमति देना) – Agreed – Agreed

### 4. Annoy
**Hindi:** चिढ़ा देना
**Answer:** Annoy (चिढ़ा देना) – Annoyed - Annoyed

### 5. Apologize
**Hindi:** क्षमा माँगना
**Answer:** Apologize (क्षमा माँगना) – Apologized – Apologized

### 6. Applaud
**Hindi:** प्रशंसा करना
**Answer:** Applaud (प्रशंसा करना) – Applauded – Applauded

### 7. Apply
**Hindi:** आवेदन करना
**Answer:** Apply (आवेदन करना)- Applied - Applied

### 8. Approve
**Hindi:** अनुमोदन करना
**Answer:** Approve (अनुमोदन करना) - Approved - Approved

### 9. Attract
**Hindi:** आकर्षित करना
**Answer:** Attract (आकर्षित करना)- Attracted - Attracted

### 10. Arrive
**Hindi:** पहुँचना
**Answer:** Arrive (पहुँचना)– Arrived - Arrived

### 11. Attend
**Hindi:** उपस्थित होना
**Answer:** Attend (उपस्थित होना) - Attended - Attended

### 12. Ask
**Hindi:** पूछना
**Answer:** Ask (पूछना) – Asked – Asked

### 13. Bake
**Hindi:** पकाना
**Answer:** Bake (पकाना) – Baked - Baked

### 14. Beg
**Hindi:** माँगना
**Answer:** Beg (माँगना)- Begged - Begged

### 15. Blame
**Hindi:** दोष लगाना
**Answer:** Blame (दोष लगाना) – Blamed - Blamed

### 16. Boast
**Hindi:** शेखी बघारना
**Answer:** Boast (शेखी बघारना) – Boasted - Boasted

### 17. Borrow
**Hindi:** उधार लेना
**Answer:** Borrow (उधार लेना) – Borrowed - Borrowed

### 18. Breathe
**Hindi:** सांस लेना
**Answer:** Breathe (सांस लेना) – Breathed - Breathed

### 19. Bribe
**Hindi:** रिश्वत देना
**Answer:** Bribe (रिश्वत देना) – Bribed - Bribed

### 20. Bathe
**Hindi:** नहाना
**Answer:** Bathe (नहाना) – Bathed - Bathed

### 21. Bark
**Hindi:** भौंकना
**Answer:** Bark (भौंकना) – Barked - Barked

### 22. Calculate
**Hindi:** गणना करना
**Answer:** Calculate (गणना करना) – Calculated - Calculated

### 23. Carry
**Hindi:** ले जाना
**Answer:** Carry (ले जाना) – Carried - Carried

### 24. Cheat
**Hindi:** धोखा देना
**Answer:** Cheat (धोखा देना) – Cheated - Cheated

### 25. Cheer
**Hindi:** प्रसन्न होना
**Answer:** Cheer (प्रसन्न होना)– Cheered - Cheered

### 26. Claim
**Hindi:** दावा करना
**Answer:** Claim (दावा करना) – Claimed - Claimed

### 27. Clean
**Hindi:** साफ करना
**Answer:** Clean (साफ करना) – Cleaned - Cleaned

### 28. Close
**Hindi:** बंद करना
**Answer:** Close (बंद करना) – Closed - Closed

### 29. Combine
**Hindi:** मिलाना
**Answer:** Combine (मिलाना) – Combined - Combined

### 30. Concern
**Hindi:** संबंध रखना
**Answer:** Concern (संबंध रखना) – Concerned - Concerned

### 31. Confess
**Hindi:** स्वीकार करना
**Answer:** Confess (स्वीकार करना) – Confessed - Confessed

### 32. Confuse
**Hindi:** भ्रमित करना
**Answer:** Confuse (भ्रमित करना) – Confused - Confused

### 33. Control
**Hindi:** नियंत्रण करना
**Answer:** Control (नियंत्रण करना) – Controlled- Controlled

### 34. Copy
**Hindi:** नकल करना
**Answer:** Copy (नकल करना) – Copied -Copied

### 35. Cultivate
**Hindi:** खेत जोतना
**Answer:** Cultivate (खेत जोतना) –Cultivated - Cultivated

### 36. Dare
**Hindi:** हिम्मत करना
**Answer:** Dare (हिम्मत करना) – Dared - Dared

### 37. Decay
**Hindi:** सड़ना
**Answer:** Decay (सड़ना) – Decayed - Decayed

### 38. Decrease
**Hindi:** घटना
**Answer:** Decrease (घटना) – Decreased -Decreased

### 39. Defend
**Hindi:** रक्षा करना
**Answer:** Defend (रक्षा करना) – Defended- Defended

### 40. Delay
**Hindi:** देरी करना
**Answer:** Delay (देरी करना) - Delayed - Delayed

### 41. Determine
**Hindi:** निश्चित करना
**Answer:** Determine (निश्चित करना) – Determined - Determined

### 42. Die
**Hindi:** मरना
**Answer:** Die (मरना) – Died -Died

### 43. Dip
**Hindi:** डूबा कर निकालना
**Answer:** Dip (डूबा कर निकालना) – Dipped - Dipped

### 44. Disturb
**Hindi:** बाधा पहुँचाना
**Answer:** Disturb (बाधा पहुँचाना) – Disturbed - Disturbed

### 45. Divide
**Hindi:** बांटना
**Answer:** Divide (बांटना) – Divided - Divided

### 46. Drag
**Hindi:** घसीटना
**Answer:** Drag (घसीटना) – Dragged - Dragged

### 47. Earn
**Hindi:** कमाना
**Answer:** Earn (कमाना) – Earned - Earned

### 48. Employ
**Hindi:** नियुक्त करना
**Answer:** Employ (नियुक्त करना) – Employed - Employed

### 49. Encourage
**Hindi:** उत्साहित करना
**Answer:** Encourage (उत्साहित करना) – Encouraged - Encouraged

### 50. Entertain
**Hindi:** मनोरंजन करना
**Answer:** Entertain (मनोरंजन करना) – Entertained -Entertained

### 51. Excite
**Hindi:** उत्तेजित करना
**Answer:** Excite (उत्तेजित करना) – Excited - Excited

### 52. Explode
**Hindi:** विस्फोट करना
**Answer:** Explode (विस्फोट करना) –Exploded - Exploded

### 53. Explore
**Hindi:** अनुसंधान करना
**Answer:** Explore (अनुसंधान करना) – Explored - Explored

### 54. Extend
**Hindi:** बढ़ाना
**Answer:** Extend (बढ़ाना) – Extended - Extended

### 55. Enter
**Hindi:** प्रवेश करना
**Answer:** Enter (प्रवेश करना) – Entered - Entered

### 56. Face
**Hindi:** सामना करना
**Answer:** Face (सामना करना) -Faced - Faced

### 57. Fade
**Hindi:** मुरझाना
**Answer:** Fade (मुरझाना) – Faded - Faded

### 58. Float
**Hindi:** तैरना
**Answer:** Float (तैरना) –Floated - Floated

### 59. Fold
**Hindi:** मोड़ना
**Answer:** Fold (मोड़ना) – Folded - Folded

### 60. Fry
**Hindi:** तलना
**Answer:** Fry (तलना) – Fried - Fried

### 61. Fail
**Hindi:** असफल होना
**Answer:** Fail (असफल होना) – Failed - Failed

### 62. Gather
**Hindi:** इकट्ठा करना
**Answer:** Gather (इकट्ठा करना) – Gathered - Gathered

### 63. Grant
**Hindi:** स्वीकार करना
**Answer:** Grant (स्वीकार करना)–Granted - Granted

### 64. Guess
**Hindi:** अनुमान लगाना
**Answer:** Guess (अनुमान लगाना) – Guessed - Guessed

### 65. Heal
**Hindi:** घाव भरना
**Answer:** Heal (घाव भरना) - Healed - Healed

### 66. Hear
**Hindi:** सुनना
**Answer:** Hear (सुनना) – Heard - Heard

### 67. Hesitate
**Hindi:** संकोच करना
**Answer:** Hesitate (संकोच करना)– Hesitated - Hesitated

### 68. Hinder
**Hindi:** विघ्न डालना
**Answer:** Hinder (विघ्न डालना)– Hindered - Hindered

### 69. Hire
**Hindi:** भाड़े पर लेना
**Answer:** Hire (भाड़े पर लेना) – Hired - Hired

### 70. Hate
**Hindi:** घृणा करना
**Answer:** Hate (घृणा करना) – Hated - Hated

### 71. Help
**Hindi:** मदद करना
**Answer:** Help (मदद करना) – Helped - Helped

### 72. Imitate
**Hindi:** नकल करना
**Answer:** Imitate (नकल करना) – Imitated - Imitated

### 73. Include
**Hindi:** सम्मिलित करना
**Answer:** Include (सम्मिलित करना) – Included - Included

### 74. Increase
**Hindi:** बढ़ाना
**Answer:** Increase (बढ़ाना) – Increased - Increased

### 75. Intend
**Hindi:** इरादा करना
**Answer:** Intend (इरादा करना) – Intended - Intended

### 76. Interrupt
**Hindi:** रोकना
**Answer:** Interrupt (रोकना) – Interrupted - Interrupted

### 77. Join
**Hindi:** सम्मिलित करना
**Answer:** Join (सम्मिलित करना) – Joined - Joined

### 78. Jump
**Hindi:** कूदना
**Answer:** Jump (कूदना) – Jumped - Jumped

### 79. Knit
**Hindi:** बुनना
**Answer:** Knit (बुनना) – Knitted - Knitted

### 80. Knot
**Hindi:** गांठ लगाना
**Answer:** Knot (गांठ लगाना) – Knotted - Knotted

### 81. Kill
**Hindi:** जान से मारना
**Answer:** Kill (जान से मारना) – Killed - Killed

### 82. Learn
**Hindi:** सीखना
**Answer:** Learn (सीखना) - Learned/learnt - Learned/learnt

### 83. Listen
**Hindi:** सुनना
**Answer:** Listen (सुनना) – Listened - Listened

### 84. Live
**Hindi:** जीना
**Answer:** Live (जीना) – Lived - Lived

### 85. Lead
**Hindi:** ले जाना
**Answer:** Lead (ले जाना) – Led - Led

### 86. Leave
**Hindi:** छोड़ना
**Answer:** Leave (छोड़ना) – Left - Left

### 87. Like
**Hindi:** पसंद करना
**Answer:** Like (पसंद करना) – Liked - Liked

### 88. Manage
**Hindi:** व्यवस्था करना
**Answer:** Manage (व्यवस्था करना) – Managed - Managed

### 89. Melt
**Hindi:** पिघलना
**Answer:** Melt (पिघलना) – Melted - Melted

### 90. Mix
**Hindi:** मिलाना
**Answer:** Mix (मिलाना) – Mixed - Mixed

### 91. Multiply
**Hindi:** गुणा करना
**Answer:** Multiply (गुणा करना) – Multiplied - Multiplied

### 92. Make
**Hindi:** बनाना
**Answer:** Make (बनाना) – Made - Made

### 93. Need
**Hindi:** आवश्यकता होना
**Answer:** Need (आवश्यकता होना) – Needed - Needed

### 94. Obey
**Hindi:** आज्ञा मानना
**Answer:** Obey (आज्ञा मानना) – Obeyed - Obeyed

### 95. Omit
**Hindi:** छोड़ देना
**Answer:** Omit (छोड़ देना) – Omitted - Omitted

### 96. Owe
**Hindi:** ऋणी होना
**Answer:** Owe (ऋणी होना) – Owed - Owed

### 97. Pay
**Hindi:** चुकाना
**Answer:** Pay (चुकाना) – Paid – Paid

### 98. Please
**Hindi:** प्रसन्न करना
**Answer:** Please (प्रसन्न करना) – Pleased - Pleased

### 99. Play
**Hindi:** खेलना
**Answer:** Play (खेलना) – Played - Played

### 100. Prefer
**Hindi:** अधिक पसंद करना
**Answer:** Prefer (अधिक पसंद करना) – Perferred - Perferred

### 101. Publish
**Hindi:** प्रकाशित करना
**Answer:** Publish (प्रकाशित करना) – Published - Published

### 102. Rain
**Hindi:** वर्षा होना
**Answer:** Rain (वर्षा होना) – Rained - Rained

### 103. Reach
**Hindi:** पहुँचना
**Answer:** Reach (पहुँचना) – Reached - Reached

### 104. Reduce
**Hindi:** कम करना
**Answer:** Reduce (कम करना) – Reduced - Reduced

### 105. Refer
**Hindi:** संदर्भित करना
**Answer:** Refer (सोंदप्रभित करना – Referred - Referred

### 106. Regret
**Hindi:** खेद प्रकट करना
**Answer:** Regret (खेद प्रकट करना) – Regretted - Regretted

### 107. Repair
**Hindi:** सुधारना
**Answer:** Repair (सुधारना) – Repaired- Repaired

### 108. Reply
**Hindi:** उत्तर देना
**Answer:** Reply (उत्तर देना) – Replied - Replied

### 109. Roar
**Hindi:** दहाड़ना
**Answer:** Roar (दहाड़ना) – Roared - Roared

### 110. Rob
**Hindi:** लूटना
**Answer:** Rob (लूटना) – Robbed –Robbed

### 111. Roll
**Hindi:** लुढ़कना
**Answer:** Roll (लुढ़कना) – Rolled - Rolled

### 112. Say
**Hindi:** कहना
**Answer:** Say (कहना) – Said - Said

### 113. Seize
**Hindi:** जप्त करना
**Answer:** Seize (जप्त करना) – Seized - Seized

### 114. Serve
**Hindi:** सेवा करना
**Answer:** Serve (सेवा करना) – Served – Served

### 115. Sign
**Hindi:** हस्ताक्षर करना
**Answer:** Sign (हस्ताक्षर करना) – Signed - Signed

### 116. Slip
**Hindi:** फिसलना
**Answer:** Slip (फिसलना) - Slipped - Slipped

### 117. Smell
**Hindi:** सूंघना
**Answer:** Smell (सूंघना) - Smelled/smelt - Smelled/smelt

### 118. Study
**Hindi:** अध्ययन करना
**Answer:** Study (अध्ययन करना) – Studied – Studied

### 119. Supply
**Hindi:** आपूर्ति करना
**Answer:** Supply (आपूर्ति करना) – Supplied - Supplied

### 120. Talk
**Hindi:** बात करना
**Answer:** Talk (बात करना) – Talked - Talked

### 121. Travel
**Hindi:** यात्रा करना
**Answer:** Travel (यात्रा करना) – Travelled - Travelled

### 122. Try
**Hindi:** कोशिश करना
**Answer:** Try (कोशिश करना) – Tried - Tried

### 123. Unite
**Hindi:** संगठित करना
**Answer:** Unite (संगठित करना) – United -United

### 124. Vary
**Hindi:** बदलना
**Answer:** Vary (बदलना) – Varied - Varied

### 125. Verify
**Hindi:** जांच करना
**Answer:** Verify (जांच करना) – Verified - Verified

### 126. Visit
**Hindi:** देखने जाना
**Answer:** Visit (देखने जाना) – Visited - Visited

### 127. Wash
**Hindi:** धोना
**Answer:** Wash (धोना) – Washed - Washed

### 128. Wave
**Hindi:** हिलाना
**Answer:** Wave (हिलाना) – Waved - Waved

### 129. Work
**Hindi:** कार्य करना
**Answer:** Work (कार्य करना) – Worked - Worked

### 130. Worry
**Hindi:** चिंता करना
**Answer:** Worry (चिंता करना) – Worried - Worried

### 131. Watch
**Hindi:** निगरानी रखना
**Answer:** Watch (निगरानी रखना) – Watched – Watched

### 132. Wish
**Hindi:** चाहना
**Answer:** Wish (चाहना) – Wished - Wished

### 133. Weigh
**Hindi:** तौलना
**Answer:** Weigh (तौलना) –Weighed - Weighed

### 134. Awake
**Hindi:** जगाना
**Answer:** Awake (जगाना) – Awoke - Awoken

### 135. Bend
**Hindi:** झुकाना
**Answer:** Bend (झुकाना) – Bent - Bent

### 136. Burn
**Hindi:** जलाना
**Answer:** Burn (जलाना) – Burnt - Burnt

### 137. Bring
**Hindi:** लाना
**Answer:** Bring (लाना) – Brought - Brought

### 138. Build
**Hindi:** निर्माण करना
**Answer:** Build (निर्माण करना) – Built - Built

### 139. Buy
**Hindi:** खरीदना
**Answer:** Buy (खरीदना) – Bought - Bought

### 140. Catch
**Hindi:** पकड़ना
**Answer:** Catch (पकड़ना) – Caught - Caught

### 141. Come
**Hindi:** आना
**Answer:** Come (आना)– Came - Come

### 142. Creep
**Hindi:** रेंगना
**Answer:** Creep (रेंगना)– Crept - Crept

### 143. Feel
**Hindi:** महसूस करना
**Answer:** Feel (महसूस करना) – Felt - Felt

### 144. Fight
**Hindi:** लड़ना
**Answer:** Fight (लड़ना) – Fought - Fought

### 145. Keep
**Hindi:** रखना
**Answer:** Keep (रखना) – Kept - Kept

### 146. Lend
**Hindi:** उधार देना
**Answer:** Lend (उधार देना) – Lent - Lent

### 147. Send
**Hindi:** भेजना
**Answer:** Send (भेजना)– Sent - Sent

### 148. Spend
**Hindi:** खर्च करना
**Answer:** Spend (खर्च करना) – Spent - Spent

### 149. Bleed
**Hindi:** रक्त बहाना
**Answer:** Bleed (रक्त बहाना) – Bled - Bled

### 150. Feed
**Hindi:** खिलाना
**Answer:** Feed (खिलाना) – Fed - Fed

### 151. Meet
**Hindi:** मिलना
**Answer:** Meet (मिलना) – Met - Met

### 152. Shoot
**Hindi:** गोली मारना
**Answer:** Shoot (गोली मारना) – Shot - Shot

### 153. Lose
**Hindi:** खोना
**Answer:** Lose (खोना) – Lost - Lost

### 154. Mean
**Hindi:** अर्थ होना
**Answer:** Mean (अर्थ होना) – Meant - Meant

### 155. Sweep
**Hindi:** झाड़ना
**Answer:** Sweep (झाड़ना) – Swept - Swept

### 156. Teach
**Hindi:** पढ़ाना
**Answer:** Teach (पढ़ाना) – Taught - Taught

### 157. Think
**Hindi:** सोचना
**Answer:** Think (सोचना) – Thought - Thought

### 158. Weep
**Hindi:** रोना
**Answer:** Weep (रोना) – Wept - Wept

### 159. Seek
**Hindi:** तलाशना
**Answer:** Seek (तलाशना) – Sought - Sought

### 160. Sell
**Hindi:** बेचना
**Answer:** Sell (बेचना) – Sold -Sold

### 161. Tell
**Hindi:** कहना
**Answer:** Tell (कहना) – Told - Told

### 162. Burst
**Hindi:** फूटना
**Answer:** Burst (फूटना) – Burst - Burst

### 163. Cast
**Hindi:** फेंकना
**Answer:** Cast (फेंकना) – Cast - Cast

### 164. Cost
**Hindi:** मूल्य होना
**Answer:** Cost (मूल्य होना) – Cost - Cost

### 165. Cut
**Hindi:** काटना
**Answer:** Cut (काटना) – Cut -Cut

### 166. Hit
**Hindi:** चोट पहुँचाना
**Answer:** Hit (चोट पहुँचाना) – Hit - Hit

### 167. Hurt
**Hindi:** दुख देना
**Answer:** Hurt (दुख देना) – Hurt - Hurt

### 168. Let
**Hindi:** अनुमति देना
**Answer:** Let (अनुमति देना) – Let - Let

### 169. Put
**Hindi:** रखना
**Answer:** Put (रखना)– Put - Put

### 170. Quit
**Hindi:** छोड़ना
**Answer:** Quit (छोड़ना) – Quit - Quit

### 171. Rid
**Hindi:** मुक्त करना
**Answer:** Rid (मुक्त करना) – Rid - Rid

### 172. Read
**Hindi:** पढ़ना
**Answer:** Read (पढ़ना) – Read - Read

### 173. Set
**Hindi:** अस्त होना
**Answer:** Set (अस्त होना) – Set - Set

### 174. Shut
**Hindi:** बंद करना
**Answer:** Shut (बंद करना) – Shut - Shut

### 175. Split
**Hindi:** विभाजित करना
**Answer:** Split (विभाजित करना) – Split - Split

### 176. Spread
**Hindi:** फैलाना
**Answer:** Spread (फैलाना) – Spread - Spread

### 177. Thrust
**Hindi:** घुसाना
**Answer:** Thrust (घुसाना) – Thrust - Thrust

### 178. Blow
**Hindi:** हवा का बहना
**Answer:** Blow (हवा का बहना) – Blew - Blown

### 179. Break
**Hindi:** तोड़ना
**Answer:** Break (तोड़ना) – Broke - Broken

### 180. Choose
**Hindi:** चुनना
**Answer:** Choose (चुनना) – Chose - Chosen

### 181. Draw
**Hindi:** खींचना
**Answer:** Draw (खींचना) – Drew - Drawn

### 182. Drive
**Hindi:** चलाना
**Answer:** Drive (चलाना) – Drove - Driven

### 183. Eat
**Hindi:** खाना
**Answer:** Eat (खाना) – Ate - Eaten

### 184. Do
**Hindi:** करना
**Answer:** Do (करना) – Did - Done

### 185. Fall
**Hindi:** गिरना
**Answer:** Fall (गिरना) – Fell - Fallen

### 186. Fly
**Hindi:** उड़ना
**Answer:** Fly (उड़ना) – Flew -Flown

### 187. Forbid
**Hindi:** निषेध करना
**Answer:** Forbid (निषेध करना) – Forbade - Forbidden

### 188. Forget
**Hindi:** भूलना
**Answer:** Forget (भूलना) – Forgot - Forgot/Forgotten

### 189. Give
**Hindi:** देना
**Answer:** Give (देना) – Gave - Given

### 190. Go
**Hindi:** जाना
**Answer:** Go (जाना) – Went - Gone

### 191. Grow
**Hindi:** उगाना
**Answer:** Grow (उगाना) – Grew - Grown

### 192. Hide
**Hindi:** छिपाना
**Answer:** Hide (छिपाना) – Hid - Hidden

### 193. Know
**Hindi:** जानना
**Answer:** Know (जानना) – Knew - Known

### 194. Ride
**Hindi:** सवारी करना
**Answer:** Ride (सवारी करना) – Rode - Ridden

### 195. Rise
**Hindi:** उदय होना
**Answer:** Rise (उदय होना) – Rose - Risen

### 196. See
**Hindi:** देखना
**Answer:** See (देखना) – Saw - Seen

### 197. Shake
**Hindi:** मिलाना
**Answer:** Shake (मिलाना) – Shook - Shaken

### 198. Speak
**Hindi:** बोलना
**Answer:** Speak (बोलना) – Spoke - Spoken

### 199. Steal
**Hindi:** चोरी करना
**Answer:** Steal (चोरी करना) – Stole – Stolen

### 200. Swear
**Hindi:** शपथ लेना
**Answer:** Swear (शपथ लेना) - Swore – Sworn

### 201. Take
**Hindi:** लेना
**Answer:** Take (लेना) – Took – Taken

### 202. Tear
**Hindi:** फाड़ना
**Answer:** Tear (फाड़ना) – Tore – Torn

### 203. Throw
**Hindi:** फेंकना
**Answer:** Throw (फेंकना) – Threw – Thrown

### 204. Become
**Hindi:** होना
**Answer:** Become (होना) – Became – Become

### 205. Begin
**Hindi:** शुरू होना
**Answer:** Begin (शुरू होना) – Began – Begun

### 206. Come
**Hindi:** आना
**Answer:** Come (आना) – Came – Come

### 207. Dig
**Hindi:** खोदना
**Answer:** Dig (खोदना) – Dug – Dug

### 208. Drink
**Hindi:** पीना
**Answer:** Drink (पीना) – Drank- Drunk

### 209. Fight
**Hindi:** लड़ना
**Answer:** Fight (लड़ना) – Fought - Fought

### 210. Find
**Hindi:** पाना
**Answer:** Find (पाना) – Found - Found

### 211. Get
**Hindi:** प्राप्त करना
**Answer:** Get (प्राप्त करना) – Got - Got/Gotten

### 212. Ring
**Hindi:** बजाना
**Answer:** Ring (बजाना) – Rang - Rung

### 213. Shrink
**Hindi:** सिकुड़ना
**Answer:** Shrink (सिकुड़ना) – Shrank - Shrunk

### 214. Sing
**Hindi:** गाना
**Answer:** Sing (गाना) - Sang - Sung

### 215. Sink
**Hindi:** डूबना
**Answer:** Sink (डूबना) – Sank - Sunk

### 216. Stand
**Hindi:** खड़ा होना
**Answer:** Stand (खड़ा होना) – Stood - Stood

### 217. Stick
**Hindi:** चिपकना
**Answer:** Stick (चिपकना) – Stuck - Stuck

### 218. Swim
**Hindi:** तैरना
**Answer:** Swim (तैरना) – Swam - Swum

### 219. Win
**Hindi:** जीतना
**Answer:** Win (जीतना) – Won - Won

### 220. Beat
**Hindi:** पीटना
**Answer:** Beat (पीटना) - Beat - Beaten

### 221. Show
**Hindi:** देखना
**Answer:** Show (देखना) – Showed – Shown

### 222. Sow
**Hindi:** बोना
**Answer:** Sow (बोना) – Sowed - Sown

## Exercise 2 — Write the three forms of the following IRREGULAR verbs

### 1. Weave
**Hindi:** बुनना
**Answer:** Weave (बुनना) – Wove/Weaved – Woven/Weaved

### 2. Seek
**Hindi:** ढूंढना / खोजना
**Answer:** Seek – (ढूंढना / खोजना) – Sought - Sought

### 3. Swim
**Hindi:** तैरना
**Answer:** Swim – (तैरना) – Swam - Swum

### 4. Freeze
**Hindi:** जमना
**Answer:** Freeze – (जमना) - Froze - Frozen

### 5. Lend
**Hindi:** देना
**Answer:** Lend – (देना) - Lent - Lent

### 6. Rise
**Hindi:** उगना
**Answer:** Rise – (उगना) - Rose - Risen

### 7. Wear
**Hindi:** पहनना
**Answer:** Wear – (पहनना) - Wore - Worn

### 8. Fly
**Hindi:** उड़ना
**Answer:** Fly – (उड़ना) – Flew - Flown

### 9. Swear
**Hindi:** कसम खाना
**Answer:** Swear – (कसम खाना) - Swore (स्व र) - Sworn (स्व नि )

### 10. Begin
**Hindi:** शुरू करना
**Answer:** Begin – (शुरू करना) – Began - Begun

### 11. Dig
**Hindi:** खोदना
**Answer:** Dig – (खोदना) - Dug- Dug

### 12. Read
**Hindi:** पढ़ना
**Answer:** Read – (पढ़ना) - Read (रै ड) - Read (रै ड)

### 13. Leave
**Hindi:** छोड़ना
**Answer:** Leave – (छोड़ना) - Left - Left

### 14. Dream
**Hindi:** सपना
**Answer:** Dream – (सपना) – Dreamt - Dreamt

### 15. Drink
**Hindi:** पीना
**Answer:** Drink – (पीना) - Drank - Drunk

### 16. Eat
**Hindi:** खाना
**Answer:** Eat – (खाना) - Ate - Eaten

### 17. Fight
**Hindi:** लड़ाई करना
**Answer:** Fight – (लड़ाई करना) – Fought - Fought

### 18. Choose
**Hindi:** चुनना
**Answer:** Choose – (चुनना) – Chose - Chosen

### 19. Buy
**Hindi:** खरीदना
**Answer:** Buy – (खरीदना) - Bought - Bought

### 20. Catch
**Hindi:** पकड़ना
**Answer:** Catch – (पकड़ना) - Caught - Caught

### 21. Tell
**Hindi:** कहना
**Answer:** Tell – (कहना) - Told - Told

### 22. Grow
**Hindi:** बढ़ना
**Answer:** Grow – (बढ़ना) - Grew - Grown

### 23. Hear
**Hindi:** सुनना
**Answer:** Hear – (सुनना) – Heard - Heard

### 24. Hide
**Hindi:** छिपना/छिपाना
**Answer:** Hide – (छिपना/छिपाना) – Hid - Hidden

### 25. Come
**Hindi:** आना
**Answer:** Come – (आना) – Came - Come

### 26. Build
**Hindi:** निर्माण करना
**Answer:** Build – (निर्माण करना) - Built - Built

### 27. Fall
**Hindi:** गिरना
**Answer:** Fall – (गिरना) – Fell - Fallen

### 28. Hold
**Hindi:** पकड़ना
**Answer:** Hold – (पकड़ना)- Held - Held

### 29. Know
**Hindi:** जानना
**Answer:** Know – (जानना) – Knew - Known

### 30. Sleep
**Hindi:** सोना
**Answer:** Sleep – (सोना) – Slept - Slept

### 31. Lose
**Hindi:** खोना
**Answer:** Lose – (खोना) – Lost - Lost

### 32. Pay
**Hindi:** चुकाना
**Answer:** Pay – (चुकाना) - Paid - Paid

### 33. Think
**Hindi:** सोचना
**Answer:** Think – (सोचना) – Thought - Thought

### 34. Run
**Hindi:** दौड़ना
**Answer:** Run – (दौड़ना) – Ran - Run

### 35. Say
**Hindi:** कहना
**Answer:** Say – (कहना) – Said - Said

### 36. Sell
**Hindi:** बेचना
**Answer:** Sell – (बेचना) - Sold - Sold

### 37. Shake
**Hindi:** हिलाना
**Answer:** Shake – (हिलाना) - Shook - Shaken

### 38. Write
**Hindi:** लिखना
**Answer:** Write – (लिखना) – Wrote - Written

### 39. Shine
**Hindi:** चमकना
**Answer:** Shine – (चमकना) - Shone/Shined - Shone/Shined

### 40. Sink
**Hindi:** डूबना
**Answer:** Sink – (डूबना) – Sank - Sunk

### 41. Sit
**Hindi:** बैठना
**Answer:** Sit – (बैठना) – Sat - Sat

### 42. Stand
**Hindi:** खड़े रहना
**Answer:** Stand – (खड़े रहना) – Stood - Stood

### 43. Ride
**Hindi:** सवारी करना/चलाना
**Answer:** Ride – (सवारी करना/चलाना) – Rode - Ridden

### 44. Spread
**Hindi:** फैलाना
**Answer:** Spread – (फैलाना) – Spread - Spread

### 45. Steal
**Hindi:** चुराना
**Answer:** Steal – (चुराना) – Stole - Stolen

### 46. Quit
**Hindi:** छोड़ना
**Answer:** Quit – (छोड़ना) – Quit - Quit

### 47. Sing
**Hindi:** गाना
**Answer:** Sing – (गाना) – Sang - Sung

### 48. Send
**Hindi:** भेजना
**Answer:** Send – (भेजना) – Sent - Sent

### 49. Teach
**Hindi:** सिखाना
**Answer:** Teach – (सिखाना) – Taught - Taught

### 50. Spend
**Hindi:** बिताना/खर्च करना
**Answer:** Spend – (बिताना/खर्च करना) – Spent - Spent

### 51. Lay
**Hindi:** रखना
**Answer:** Lay – (रखना) – Laid - Laid

### 52. Lie
**Hindi:** लेटना
**Answer:** Lie – (लेटना) – Lay - Lain

### 53. Lie
**Hindi:** झूठ बोलना
**Answer:** Lie – (झूठ बोलना) – Lied - Lied

### 54. Hang
**Hindi:** कोई चीज लटकना/ लटकाना
**Answer:** Hang – (कोई चीज लटकना/ लटकाना) – Hung – Hung

### 55. Hang
**Hindi:** फाँसी पर लटकाना
**Answer:** Hang – (फाँसी पर लटकाना) – Hanged – Hanged

## Exercise 3 — Write the three forms of the following IMPORTANT verbs

### 1. Sob
**Hindi:** सिसकी लेना
**Answer:** Sob (सिसकी लेना) – Sobbed – Sobbed

### 2. Trample
**Hindi:** रौंदना
**Answer:** Trample (रौंदना) - Trampled - Trampled

### 3. Sting
**Hindi:** डंक मारना
**Answer:** Sting (डंक मारना) – Stung - Stung

### 4. Sneeze
**Hindi:** छींकना
**Answer:** Sneeze (छींकना) – Sneezed - Sneezed

### 5. Squeeze
**Hindi:** निचोड़ना
**Answer:** Squeeze (निचोड़ना) - Squeezed - Squeezed

### 6. Dig
**Hindi:** गड्ढा करना / खोदना
**Answer:** Dig (गड्ढा करना / खोदना) – Dug - Dug

### 7. Swallow
**Hindi:** निगलना
**Answer:** Swallow (निगलना) – Swallowed - Swallowed

### 8. Uproot
**Hindi:** जड़ से उखाड़ना
**Answer:** Uproot (जड़ से उखाड़ना) – Uprooted – Uprooted

### 9. Blow
**Hindi:** फूंक मारना
**Answer:** Blow (फूंक मारना) – Blew - Blown

### 10. Blush
**Hindi:** शरमाना
**Answer:** Blush (शरमाना) – Blushed - Blushed

### 11. Sniff
**Hindi:** सूंघना
**Answer:** Sniff (सूंघना) – Sniffed – Sniffed

### 12. Spoil
**Hindi:** बिगाड़ देना
**Answer:** Spoil (बिगाड़ देना) - Spoiled/Spoilt - Spoiled/Spoilt

### 13. Strive
**Hindi:** प्रयास करना
**Answer:** Strive (प्रयास करना) - Strove - Striven

### 14. Conspire
**Hindi:** षड्यंत्र रचना
**Answer:** Conspire (षड्यंत्र रचना) – Conspired - Conspired

### 15. Console
**Hindi:** सांत्वना देना
**Answer:** Console (सांत्वना देना) – Consoled - Consoled

### 16. Beautify
**Hindi:** सुन्दर बनाना
**Answer:** Beautify (सुन्दर बनाना) – Beautified - Beautified

### 17. Snatch
**Hindi:** छीनना
**Answer:** Snatch (छीनना) – Snatched – Snatched

### 18. Wring
**Hindi:** मरोड़ना
**Answer:** Wring (मरोड़ना) – Wrung - Wrung

### 19. Thrive
**Hindi:** फलना फूलना / पनपना
**Answer:** Thrive (फलना फूलना / पनपना) – Throve - Thriven

### 20. Tie
**Hindi:** बांधना
**Answer:** Tie (बांधना) – Tied - Tied

### 21. Split
**Hindi:** विभाजित करना /बाँटना
**Answer:** Split (विभाजित करना /बाँटना) - Split - Split

### 22. Breathe
**Hindi:** साँस लेना
**Answer:** Breathe (साँस लेना) – Breathed - Breathed

### 23. Stare
**Hindi:** एकटक देखना
**Answer:** Stare (एकटक देखना) – Stared - Stared

### 24. Yell
**Hindi:** चिल्लाना
**Answer:** Yell (चिल्लाना) – Yelled - Yelled

### 25. Chase
**Hindi:** पीछा करना
**Answer:** Chase (पीछा करना) – Chased - Chased

### 26. Beat
**Hindi:** पीटना / हराना
**Answer:** Beat (पीटना / हराना) – Beat - Beaten

### 27. Contradict
**Hindi:** खंडन करना / विरोध करना
**Answer:** Contradict (खंडन करना / विरोध करना) – Contradicted - Contradicted

### 28. Become
**Hindi:** बनना
**Answer:** Become (बनना) – Became - Become

### 29. Cut
**Hindi:** काटना
**Answer:** Cut (काटना) – Cut- Cut

### 30. Bite
**Hindi:** दाँत से काटना
**Answer:** Bite (दाँत से काटना) – Bit – Bitten

---
**Verification:** 307 prompts and 307 answer entries across three exercises, paired by exercise and item number. Hindi glosses were OCR-read from each prompt row using its PDF text coordinates; the 17 lesson pages and answer ranges were checked for sequence and completeness. No unreadable text.

- Source answer-key spelling correction, Exercise 1 item 79: the printed third form is “Kintted”; corrected to “Knitted”.
