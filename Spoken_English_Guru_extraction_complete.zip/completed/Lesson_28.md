# Lesson 28 — WH + Ever

**PDF pages:** 365–379 (printed pages 364–378)

## Please translate the following sentences into English:

1. **Hindi prompt:** जो कुछ भी तुम्हारे पास है, मेरा है।  
   **Romanized:** Jo kuch bhi tumhare pass hai, mera hai.  
   **English answer:** Whatever you have is mine.  

2. **Hindi prompt:** जो कुछ भी तुम्हारे पास है, मुझे दे दो।  
   **Romanized:** Jo kuch bhi tumhare pass hai, mujhe de do.  
   **English answer:** Give me, whatever you have.  

3. **Hindi prompt:** जो कुछ उसने कहा, सच नहीं है।  
   **Romanized:** Jo kuch usne kaha, sach nahi hai.  
   **English answer:** Whatever he said, is not true.  

4. **Hindi prompt:** मैं जो कुछ भी चाहता हूँ, वह कर सकता हूँ या कह सकता हूँ।  
   **Romanized:** Main jo kuch bhi chaahata hoon, vah kar sakata hoon ya kah sakata hoon.  
   **English answer:** I can do or say, whatever I want.  

5. **Hindi prompt:** जो भी मैं कहता हूँ, वो एकदम से मान लेता है।  
   **Romanized:** Jo bhi mai kehta hoon, vo ekdum se maan leta hai.  
   **English answer:** Whatever I say, he accepts immediately.  

6. **Hindi prompt:** जो कुछ भी तुम खाना चाहते हो, खा लो।  
   **Romanized:** Jo kuch bhi tum khana chahte ho, kha lo.  
   **English answer:** Whatever you want to eat, eat.  

7. **Hindi prompt:** जब कभी अगले साल तुम यहाँ आओ, मुझे कॉल ज़रूर करना।  
   **Romanized:** Jab kabhi agle saal tum yahan aao, mujhe call zaroor karna.  
   **English answer:** Whenever you come here next year, do call me.  

8. **Hindi prompt:** इंग्लिश में बात ज़रूर किया करो, जब भी आपको मौका मिलता है।  
   **Romanized:** English mai bat zaroor kiya karo, jab bhi aapko mauka milta hai.  
   **English answer:** Do speak in English, whenever you get an opportunity.  

9. **Hindi prompt:** जब कभी मैं तुम्हें देखता हूँ, मुझे अपने भाई की याद आती है। वो बिल्कुल तुम्हारे जैसा था।  
   **Romanized:** Jab kabhi mai tumhe dekhta hun, mujhe apne bhaee ki yaad aati hai. Wo bilkul tumhare jaisa tha.  
   **English answer:** Whenever I see you, I remember my brother. He was just like you.  

10. **Hindi prompt:** जब कभी भी मुझे उसकी ज़रूरत पड़ी, उसने साथ दिया।  
   **Romanized:** Jab kabhi bhi mujhe uski zaroorat padi, usne sath diya.  
   **English answer:** Whenever I needed him, he helped.  

11. **Hindi prompt:** वो सारी यादें ताजा हो जाती हैं, जब कभी मैं उसका नाम सुनता हूँ।  
   **Romanized:** vo sari yadein taaza ho jati hain, jab kabhi mai uska naam sunta hun.  
   **English answer:** All sweet memories get afresh, whenever I hear his name.  

12. **Hindi prompt:** जब कभी भी तुमको पैसों की ज़रूरत हो, शर्माना मत।  
   **Romanized:** Jab kabhi bhi tumko paiso ki zaroorat ho, sharmana mat.  
   **English answer:** Whenever you need money, don’t hesitate.  

13. **Hindi prompt:** जहाँ कहीं भी मैं रहा, मेरे मकान मालिक बहुत ही सहयोग करने वाले थे।  
   **Romanized:** Jahaan kahi bhi mai raha, mere makaan malik bahut hi sahyog karne wale the.  
   **English answer:** Wherever I lived, my landlords were very cooperative.  

14. **Hindi prompt:** जहाँ कहीं भी तुम जाओगे, मुझे वहाँ पाओगे।  
   **Romanized:** Jahan kahi bhi tum jaoge, mujhe vahan paoge.  
   **English answer:** Wherever you go, you will find me there.  

15. **Hindi prompt:** जहाँ कहीं भी तुम जाना चाहते हो, तुम जा सकते हो।  
   **Romanized:** Jahan kahi bhi tum jana chahte ho, tum ja skte ho.  
   **English answer:** Wherever you want to go, you can.  

16. **Hindi prompt:** जहाँ कहीं भी वो जायेगा, वो मुझे वहाँ पायेगा।  
   **Romanized:** Jahan kahi bhi vo jayega, vo mujhe vahan payega.  
   **English answer:** Wherever he goes, he will find me there.  

17. **Hindi prompt:** जहाँ कहीं भी देखो, हर जगह कूडा है।  
   **Romanized:** Jahaan kahi bhi dekho har jagah kooda fenka huwa hai.  
   **English answer:** Wherever you see, there's garbage everywhere.  

18. **Hindi prompt:** वो जहाँ कहीं भी छुप जाए, मैं उसे खोज निकालूँगा।  
   **Romanized:** vo jahaan kahin chup jaye, mai use khoz nikalunga.  
   **English answer:** Wherever he is hidden, I will find him.  

19. **Hindi prompt:** इस मैच के लिए आप जिसको भी सिलेक्ट करें, मैं उसके साथ खेलने को तैयार हूँ।  
   **Romanized:** Is match ke liye aap jisko bhi select karein, mai uske sath khelne ko taiyar hun.  
   **English answer:** I am ready to play with, whoever/whomever you select for this match.  

20. **Hindi prompt:** जिसको भी आप मेरे साथ भेजना चाहते हैं, आप भेज सकते हैं। मुझे कोई परेशानी नहीं है।  
   **Romanized:** Jisko bhi aap mere sath bhejna chahte hai, aap bhej sakte hai. Mujhe koi pareshani nahi hai.  
   **English answer:** Whoever/whomever you want to send with me, you can. I’ve no issues at all.  

21. **Hindi prompt:** चोर जो कोई भी हो, बच नहीं पायेगा।  
   **Romanized:** Chor jo koi bhi ho, bach nahi payega.  
   **English answer:** Whoever is the thief, will not be able to escape.  

22. **Hindi prompt:** जिसको भी खाना है, वहाँ जा सकता है।  
   **Romanized:** Jisko bhi khana hai, vahan ja sakta hai.  
   **English answer:** Whoever wants to eat, can go there.  

23. **Hindi prompt:** जो कोई भी इस बॉल को पहले ढूँढेगा, वो पहले बैटिंग करेगा।  
   **Romanized:** Jo koi bhi is ball ko pehle dhoondega, wo pehle batting karega.  
   **English answer:** Whoever finds this ball first, will bat first.  

24. **Hindi prompt:** तुम्हारा भाई या जो कोई भी उस दिन उस घर में वहाँ था, दोषी है।  
   **Romanized:** Tumhara bhai ya jo koi bhi us din us ghar mai vahan tha, doshi hai.  
   **English answer:** Your brother or whoever was there in that house that day is culprit.  

25. **Hindi prompt:** जो कोई भी किताब आपको सबसे ज़्यादा पसंद है, आपको वो खरीद लेनी चाहिए।  
   **Romanized:** Joi koi bhi kitaab aapko sabse zyada pasand hai, apko wo khareed leni chahiye.  
   **English answer:** Whichever the book you like the most, you should buy that.  

26. **Hindi prompt:** इनमें से कोई भी तरीका आप चुनो, आपको इस प्रॉब्लम का सॉल्यूशन नहीं मिलेगा।  
   **Romanized:** Inme se koi bhi tareeka aap chuno, aapko is problem ka solution nahi milega.  
   **English answer:** Whichever method out of these you adopt; you will not get the solution of this problem.  

27. **Hindi prompt:** आप जैसे भी हैं, पर आप उसकी रक्षा करेंगे।  
   **Romanized:** Aap jaise bhi hain, par aap uski rakhsha karenge.  
   **English answer:** Whoever you are, you will protect him.  

28. **Hindi prompt:** जो भी आपको लगता है सबसे ज़्यादा अच्छा प्लेयर है, आप उसे अपनी टीम में ले सकते हैं।  
   **Romanized:** Jo bhi apko lagta hai sabse zyada acha player hai, aap use apni team me le sakte hai.  
   **English answer:** Whichever/whoever you think is the best player, you can take him in your team.  

29. **Hindi prompt:** आप में से जो भी पहले यहाँ आयेगा, वह पुरस्कार प्राप्त करेगा।  
   **Romanized:** Aap mein se jo bhi pahale yahaan aayega, vah puraskaar praapt karega.  
   **English answer:** Whichever/whoever of you comes here first, will get the prize.  

30. **Hindi prompt:** जो भी पक्ष जीतता है, मैं संतुष्ट रहूँगा।  
   **Romanized:** Jo bhi paksh jeetata hai, main santusht rahoonga.  
   **English answer:** Whichever side wins, I will be satisfied.  

31. **Hindi prompt:** जो भी आप खरीदते हैं, छह महीने की गारंटी होती है।  
   **Romanized:** Jo bhi aap khareedate hain, chhe maheene kee gaarantee hoti hai.  
   **English answer:** Whatever you buy, that has a six-month guarantee.  

32. **Hindi prompt:** जैसा भी आप उसके साथ व्यवहार करो, वो बुरा नहीं मानेगा।  
   **Romanized:** Jaisa bhi aap uske sath vyavahar karo, wo bura nahi manega.  
   **English answer:** However you behave with him, he will not feel bad.  

33. **Hindi prompt:** वो जैसे भी कपडे पहन ले, दिखता वैसे ही है।  
   **Romanized:** Wo jaise bhi kapde pahen le, dikhata vaise hi hai.  
   **English answer:** However clothes he wears; it makes no different.  

34. **Hindi prompt:** आपको इस प्रॉब्लम को हल करना चाहिए, जैसे भी आप कर पाओ।  
   **Romanized:** Apko is problem ko hal karna chahiye, jaise bhi aap kar pao.  
   **English answer:** You should solve this problem, however you can.  

35. **Hindi prompt:** मुझे वो बुक चाहिए, जैसे भी दो।  
   **Romanized:** Mujhe vo book chahiye, jaise bhi do.  
   **English answer:** I want you to give me that book, however you can.  

36. **Hindi prompt:** मैं जानता हूँ कि आपने इस प्रॉजेक्ट को महीनों दिए हैं। लेकिन फिर भी, मुझे लगता है कि यह फायदे का सौदा नहीं है।  
   **Romanized:** Mai janta hun ki apne is project ko mahine diye hai. Lekin fir bhi, mujhe lagta hai ki yah fayda ka soda nahi hai.  
   **English answer:** I know you have given months to this project. However, I think it’s not worthwhile.  

37. **Hindi prompt:** मैंने उसे इतना पढाया. लेकिन फिर भी वो फेल हो गया।  
   **Romanized:** Maine use itna padaya. Lekin fir bhi, vo fail ho gaya.  
   **English answer:** I taught him so much. Still/However, he failed.  

38. **Hindi prompt:** मैंने इस टॉपिक पर आपके लिए पहले भी वीडियो बनाई है।लेकिन फिर भी, मुझे लगता है मुझे इसे थोड़ा विस्तार से आपको समझाना चाहिए।  
   **Romanized:** Maine is topic par apke liye pehle bhi video banayi hai. Lekin fir bhi, mujhe esa lagta hai, mujhe ese thoda vistar se aapko samjhana chahiye.  
   **English answer:** I have already developed a video on this topic. However I feel I should explain it to you a little more in detail.  

39. **Hindi prompt:** जिस किसी भी गाडी में पंचर है, ठीक करवाओ।  
   **Romanized:** Jis kisi bhi gadi mai panchar hai, thik karwao.  
   **English answer:** Whichever vehicles have got punctured tires, please get them fixed/repaired.  

40. **Hindi prompt:** आप जितना भी वहाँ खेलना चाहते हो, जाओ और खेलो।  
   **Romanized:** Aap jitna bhi vahan khelna chahte ho, jao or khelo.  
   **English answer:** However you want to play there, go and play.  

41. **Hindi prompt:** जिस किसी का भी होमवर्क पूरा नहीं है, कृपया अपने हाथ उठाईए।  
   **Romanized:** Jis kisi ka bhi homework poora nahi hai, kirpaya apne hath uthaeye.  
   **English answer:** Whosever/whoever’s homework is not complete, please raise your hands.  

42. **Hindi prompt:** जिस किसी का भी पैन आपने लिया है, उसे अभी रिटर्न कर दो।  
   **Romanized:** Jis kisi ka bhi pen aapne liya hai, use abhi return kar do.  
   **English answer:** Whosever/whoever’s pen you have taken, return him right now.  

43. **Hindi prompt:** इंग्लिश सीखना जितना भी डिफिकल्ट हो, मैं इसे कर के रहूँगा।  
   **Romanized:** English seekhna jitna bhi dificult ho, mai ese kar ke rahunga.  
   **English answer:** However difficult it is to learn English, I will do it for sure.  

44. **Hindi prompt:** जिस किसी की सैलरी नहीं आयी है, यहाँ आओ।  
   **Romanized:** Jis kisi ki salary nahi aayi hai, yahaan aao.  
   **English answer:** Whoever’s salary is not credited yet, please come here.  

45. **Hindi prompt:** जो भी राजा को श्राप देता है, उसे पत्थर मार दिया जाता है।  
   **Romanized:** Jo bhi raja ko sharap deta hai, use pathar mar diya jata hai.  
   **English answer:** Whoever curses the king gets stones thrown at him.  

46. **Hindi prompt:** जिस किसी भी बिल्डिंग की दीवारों को रिपेयरिंग की ज़रूरत है, लिस्ट बनाइए और मुझे दीजिए।  
   **Romanized:** Jis kisi bhi building ki deewaro ko repairing ki zaroorat hai, list bnaeye aur mujhe dijiye.  
   **English answer:** The walls of whichever buildings need repairing; please make a list and handover to me.  

47. **Hindi prompt:** जिस किसी भी मोबाइल की टचस्क्रीन्स खराब हैं, कृपया उन्हें रिपेयर करवाईए।  
   **Romanized:** Jis kisi bhi mobile ki touchscreens kharab hai, kirpaya unhe repair karwaeye.  
   **English answer:** The touch screens of whichever mobiles are faulty; please get them repaired.  

48. **Hindi prompt:** जिस किसी भी स्टूडेंट के पास लैपटॉप नहीं है, दिलवाइए।  
   **Romanized:** Jis kisi bhi student ke paas laptop nahi hai, dilwaiye.  
   **English answer:** Whichever student does not have a laptop, get him one.  

49. **Hindi prompt:** जब कभी ये होगा, तुम हैरान हो जाओगे।  
   **Romanized:** Jab kabhi ye hoga, tum hairan ho jaaoge.  
   **English answer:** Whenever it happens, you will get shocked.  

50. **Hindi prompt:** जो कुछ भी आप चाहते है, मुझे अपना समझ कर मुझे बताइए।  
   **Romanized:** Jo Kuch bhi aap chahte hai, mujhe apna samajh kar mujhe bataiye.  
   **English answer:** Whatever you want, consider me yours and tell me.  

51. **Hindi prompt:** जो कुछ भी आपके समझ में आ रहा है आप यहाँ पर लिख सकते हो।  
   **Romanized:** Jo kuch bhi aapke samajh mein aa raha hai aap yaha par likh sakte ho.  
   **English answer:** Whatever you understand, you can write here.  

52. **Hindi prompt:** आपको जो कुछ भी खाना है मुझे बताइए मैं आपके लिए आर्डर कर देता हूँ।  
   **Romanized:** Aapko jo kuch bhee khana hai, mujhe bataiye mein apke liye order kar deta hoon.  
   **English answer:** Tell me whatever you want to eat, I'll order it for you.  

53. **Hindi prompt:** उसने आपको जो कुछ भी कहा, आप उसकी बातों का बिल्कुल भी बुरा मत मानो।  
   **Romanized:** Usne aapko jo kuch bhee kaha, aap uski baaton ka bilkul bhee bura mat maano.  
   **English answer:** Whatever he told you, do not take offense at his words at all.  

54. **Hindi prompt:** वो तो पागल है, जो कुछ भी उसके मुँह में आता है बोल देता है।  
   **Romanized:** Vo to pagal hai, jo kuch bhee uske muh mein aata hai bol deta hai.  
   **English answer:** He is a madman, he speaks whatever comes in his mouth.  

55. **Hindi prompt:** जो कुछ भी उसने आपके लिए बुरा-भला बोला है, मैं उसके लिए माँफ़ी माँगता हूँ।  
   **Romanized:** Jo kuch bhee usne aapke liye bura-bhala bola hai, main uske liye maafi maangta hoon.  
   **English answer:** I beg your apologies for whatever he has spoken ill of you.  

56. **Hindi prompt:** जो कुछ भी होता है, कभी- कभी अच्छे होने के लिए ही होता है।  
   **Romanized:** Jo kuch bhee hota hai, kabhi-kabhi acche hone ke liye hee hota hai.  
   **English answer:** Whatever happens, sometimes happens for the better.  

57. **Hindi prompt:** तुमने जो कुछ भी उसको कहा, मैंने उसको कुछ भी नहीं बताया।  
   **Romanized:** Tumne jo kuch bhee usko kaha, maine usko kuch bhee nahi bataya.  
   **English answer:** Whatever you told him, I did not tell him anything.  

58. **Hindi prompt:** जो कुछ भी तुम ये कर रहे हो न, एक दिन बहुत पछताओगे।  
   **Romanized:** Jo kuch bhee tum ye kar rahe ho na, ek din bahut pachtaoge.  
   **English answer:** Whatever you are doing, you will regret a lot one day.  

59. **Hindi prompt:** आप पहले जल्दी घर आ जाओ, फिर जो कुछ भी खाना है मुझे बता देना।  
   **Romanized:** Aap pahale jaldi ghar aa jao, phir jo kuch bhee khaana hai mujhe bata dena.  
   **English answer:** You come home early first, then tell me whatever you want to eat.  

60. **Hindi prompt:** जब कभी भी मैं आपको देखता हूँ, तो मुझे अपनी मम्मी की याद आ जाती है।  
   **Romanized:** Jab kabhi bhee main aapko dekhta hoon to, mujhe apni mummy ki yaad aa jaati hai.  
   **English answer:** Whenever I see you, I miss my mother.  

61. **Hindi prompt:** मैंने जब कभी आपको रोते देखता हूँ, तो मुझे भी रोना आ जाता है।  
   **Romanized:** Maine jab kabhi aapko rote dekhta hoon, to mujhe bhee rona aa jata hai.  
   **English answer:** Whenever I see you crying, I also cry.  

62. **Hindi prompt:** जब कभी भी आपके घर आओ हमेशा सोते ही रहते हो।  
   **Romanized:** Jab kabhi bhee aapke ghar aao hamesha sote hee rahte ho.  
   **English answer:** Whenever you come to your house, you always keep sleeping.  

63. **Hindi prompt:** आपको याद है, जब कभी आपने मेरा दिल को तोड़ा था मैं बहुत रोया था।  
   **Romanized:** Aapko yaad hai, jab kabhi aapne mera dil toda tha, main bahut roya thaa.  
   **English answer:** You remember, whenever you broke my heart, I cried a lot.  

64. **Hindi prompt:** जब कभी भी मेरी याद आये मुझे फ़ोन कर दिया करो।  
   **Romanized:** Jab kabhi bhee meri yaad aaye mujhe phone kar diya karo.  
   **English answer:** Call me whenever you remember me.  

65. **Hindi prompt:** जब कभी भी तुम छुट्टी आओ तो मुझसे मिलने ज़रूर आया करो।  
   **Romanized:** Jab kabhi bhee tum chhutti aao to mujhse milane Zaroor aaya karo.  
   **English answer:** Whenever you come on holiday, do come to see me.  

66. **Hindi prompt:** तुम्हारा अपना घर है, जब कभी भी मन करें बिना पूछे आ जाया करो।  
   **Romanized:** Tumhara apna ghar hai, jab kabhi bhee man karen bina puchhe aa jaaya karo.  
   **English answer:** You have your own home, whenever you want, come without asking.  

67. **Hindi prompt:** मैंने जब कभी भी वहाँ जाना ही नहीं है तो मैं वहाँ की बात क्यों करूँ।  
   **Romanized:** Maine jab kabhi bhee wahan jaana hee nahin hai to main wahan kee baat kyon karun.  
   **English answer:** Whenever I have never wanted to go there then why should I talk about there.  

68. **Hindi prompt:** मैं जब कभी भी गाँव जाता हूँ, तो अपने स्कूल के दोस्तों से ज़रूर मिलता हूँ।  
   **Romanized:** Main jab kabhi bhee gaon jaata hoon, to apne school ke doshton se zaroor milta hoon.  
   **English answer:** Whenever I go to the village, I definitely meet my school friends.  

69. **Hindi prompt:** जब कभी भी हम सारे दोस्त मिलते है, तो पुराने दिनों को बहुत याद करते हैं।  
   **Romanized:** Jab kabhi bhee hum saare dost milate hai, to purane dino ko bahut yaad karte hain.  
   **English answer:** Whenever we all meet friends, we remember the old days a lot.  

70. **Hindi prompt:** जब-जब बादल गरजते हैं, तब ज़रूर तेज़ बारिश होती है।  
   **Romanized:** Jab-jab baadal garajate hain, tab zaroor tez baarish hoti hai.  
   **English answer:** Whenever the clouds thunder, then there is definitely a heavy rain.  

71. **Hindi prompt:** जब- जब मैं सुबह ज़ल्दी उठता हूँ वो दिन मेरा बहुत अच्छा जाता है।  
   **Romanized:** Jab jab main subah jaldi uthta hoon vo din mera bahut achha jaata hai.  
   **English answer:** Whenever I wake up early in the morning, that day goes very well for me.  

72. **Hindi prompt:** जब- जब आपने मिलने बुलाया है मैं उसी समय आपसे मिलने आया हूँ।  
   **Romanized:** Jab- jab aapne milne bulaaya hai main usi samay aap se milne aaya hoon.  
   **English answer:** Whenever you have called to meet me, I’ve come to meet you at the same time.  

73. **Hindi prompt:** जब-जब वो झूठ बोलता है, हमेशा पकड़ा जाता है।  
   **Romanized:** Jab-jab vo jhooth bolata hai, hamesha pakda jaata hai.  
   **English answer:** Whenever he tells a lie, he is always caught.  

74. **Hindi prompt:** जब-जब मैंने उसकी पैसों से मदद की है, तब से वो मेरा शुक्रिया अदा करना नहीं भूलता है।  
   **Romanized:** Jab-jab maine uski paiso se madad kee hai, tab se vo mera shukriya ada karna nahi bhulta hai.  
   **English answer:** Whenever I have helped him with money, he never forgets to thank me.  

75. **Hindi prompt:** जब-जब तुम मन लगा के पढ़ाई करते हो, तुम्हारें मार्क्स बहुत अच्छे आते हैं।  
   **Romanized:** Jab-jab tum man laga ke padhai karte ho, tumharen marks bahut achhe aate hain.  
   **English answer:** Whenever you study diligently, you get very good marks.  

76. **Hindi prompt:** जब-जब आप हँसते हो तो, आप बहुत ही सुन्दर लगती हो।  
   **Romanized:** Jab -jab aap haste ho to, aap bahut hee sundar lagti ho.  
   **English answer:** Whenever you laugh, you look very beautiful.  

77. **Hindi prompt:** जब-जब धोनी तेज़ रन बनाने की कोशिश करता है, ज़ल्दी ऑउट हो जाता है।  
   **Romanized:** Jab- jab dhoni tez run banaane kee koshish karta hai, jaldi out ho jaata hai.  
   **English answer:** Whenever Dhoni tries to score quick runs, he gets out quickly.  

78. **Hindi prompt:** तुम जब-जब मेरे घर आते हो कुछ न कुछ सामान तोड़ के ही जाते हो।  
   **Romanized:** Tum jab jab mere ghar aate ho kuch na kuch saamaan tod ke hee jaate ho.  
   **English answer:** Whenever you come to my house, you go away breaking some things.  

79. **Hindi prompt:** जब-जब तुम अपने दिल की बातें इन कविताओं में दर्शाते हो पढ़ने वाले हैरान हो जाते है।  
   **Romanized:** Jab-jab tum apne dil kee baaten in kavitaon mein darshaate ho padhne vaale hairaan ho jaate hai.  
   **English answer:** The readers are amazed whenever you reflect the words of your heart in these poems.  

80. **Hindi prompt:** जहाँ-जहाँ नज़र जारी है, तुमने वहाँ कूड़ा फैला रखा है।  
   **Romanized:** jahaan-jahaan nazar jaari hai, tumane vahaan kooda faila rakha hai.  
   **English answer:** Wherever the eye continues, you have spread garbage there.  

81. **Hindi prompt:** जहाँ-जहाँ दूर तक नज़र जा रही है, सुन्दर-सुन्दर पहाड़ दिख रहे है।  
   **Romanized:** Jahaan-jahaan door tak nazar jaa rahi hai sundar-sundar pahaad dikh rahe hai.  
   **English answer:** Wherever one is looking far, beautiful mountains are visible.  

82. **Hindi prompt:** जहाँ-जहाँ धुआँ है, वहाँ अग्नि है।  
   **Romanized:** Jahaan-jahaan dhuaan hai, vahan agni hai.  
   **English answer:** Wherever there is smoke, there is fire.  

83. **Hindi prompt:** सफ़र में जहाँ-जहाँ कार रूकती है आप सेल्फ़ी लेना शुरू कर देती हो।  
   **Romanized:** Safar mein Jahaan-Jahaan car rukti hai, aap selfi lena shuru kar deti ho.  
   **English answer:** Wherever the car stops in the journey, you start taking selfies.  

84. **Hindi prompt:** सरकारी नौकरी के लिए मुझे जहाँ-जहाँ जाना पड़े मैं जाऊँगा।  
   **Romanized:** Sarkaari naukri ke liye mujhe jahaan-jahaan jaana padhe mein jaaoonga.  
   **English answer:** I will go wherever I have to go for a government job.  

85. **Hindi prompt:** जहाँ-जहाँ मैं जा रहा हूँ ,आप मेरे पीछे क्यों आ रही हो।  
   **Romanized:** Jahaan-jahaan mein jaa raha hoon, aap mere peeche kyon aa rahi hoo.  
   **English answer:** Why are you following me wherever I am going?  

86. **Hindi prompt:** जहाँ-जहाँ देख रहा हूँ, सिर्फ आपकी ही फोटो दिख रही हैं।  
   **Romanized:** Jahaan-jahaan dekh raha hoon, sirf aapki hee photo dikh rahi hain.  
   **English answer:** Wherever I am looking, only your photo is visible.  

87. **Hindi prompt:** जहाँ-जहाँ आप घूमने जाते हो वो सारी जगह मुझे पता है।  
   **Romanized:** Jahaan-jahaan aap ghoomane jaate ho vo saari jagah mujhe pata hai.  
   **English answer:** I know all the places whereever you go to visit.  

88. **Hindi prompt:** जहाँ-जहाँ आप जाते हो वहाँ सिर्फ आपकी ही तारीफ़ होती हैं।  
   **Romanized:** Jahaan-jahaan aap jate ho vahaan sirf aapki hee tariff hoti hain.  
   **English answer:** Wherever you go, you are the only one to be admired.  

89. **Hindi prompt:** गाँव में जहाँ-जहाँ रोड़े जा रही है वहाँ विकास हो रहा है।  
   **Romanized:** Gaon mein jahaan-jahaan roaden jaa rahi hai, vahaan vikash ho rahaa hai.  
   **English answer:** Wherever obstacles are being raised in the village, development is taking place.  

90. **Hindi prompt:** जो कोई भी बात है, मुझे चुपचाप बता दो।  
   **Romanized:** Jo koi bhee baat hai, mujhe chupchap bata do.  
   **English answer:** Whatever it is, tell me quietly.  

91. **Hindi prompt:** तुमने ये जो कोई भी बातें मुझे बताई है, प्लीज़ किसी और को जाकर मत बताना।  
   **Romanized:** Tumane ye jo koi bhee baaten mujhe bataee hai, please kisi aur ko jaakar mat bataana.  
   **English answer:** Whatever these things you’ve told me, please do not go and tell anyone else.  

92. **Hindi prompt:** जो कोई देखो आपको पीट के चला जाता है।  
   **Romanized:** Jo koi dekho aapko peet ke chala jata hai.  
   **English answer:** Whoever looks at you goes to beat you.  

93. **Hindi prompt:** जो कोई भी प्रश्न आपको नहीं आता आप अभी पूछ सकते हैं।  
   **Romanized:** Jo koi bhee prashna aapko nahi aata aap abhi poochh sakte hain.  
   **English answer:** Whatever question you don't know you can ask now.  

94. **Hindi prompt:** जो कोई देखो मेरी ही नकल कर रहा है।  
   **Romanized:** Jo koi dekho meri hee nakal kar raha hai.  
   **English answer:** Whoever looks is copying me  

95. **Hindi prompt:** जो कोई भी आता है, यहाँ अपनी अर्जी लगा के ज़रूर जाता है।  
   **Romanized:** Jo koi bhee aata hai, yahaan apni arjee lagaa ke zaroor jaata hai.  
   **English answer:** Whoever comes, definitely goes here with his request.  

96. **Hindi prompt:** तुम जो कोई भी हो, यहाँ पर शोर मत मचाओ।  
   **Romanized:** Tum jo koi bhi ho, yahan par shor mat machao.  
   **English answer:** Whoever you are, don't make noise here.  

97. **Hindi prompt:** जो कोई नहीं कर पाया मैं वही कर के दिखाऊँगा।  
   **Romanized:** Jo koi nahin kar paya main vahi kar ke dikhaunga.  
   **English answer:** Whatever anyone could not do, I will show it by doing.  

98. **Hindi prompt:** जो कोई भी नहीं समझा आप एक सेकंड में समझ गए।  
   **Romanized:** Jo koi bhi nahi samjha aap ek second mein samajh gaye.  
   **English answer:** Whoever didn't understand you understood in a second.  

99. **Hindi prompt:** तुमने जो कोई भी बाइक खरीदी है एकदम बेकार बाइक है।  
   **Romanized:** Tumne jo koi bhee bike kharidi hai, ekdam bekar bike hai.  
   **English answer:** Whichever bike you have bought is a completely useless.  

100. **Hindi prompt:** जिसको भी मेरी बातें पसन्द नहीं है, वो यहाँ से उठ के चले जाए।  
   **Romanized:** Jisko bhee meri baatein pasand nahi hai, vo yahan se uth ke chale jaayen.  
   **English answer:** Whoever does not like my words, get up from here and leave.  

101. **Hindi prompt:** जिसको भी देखो बस आपकी बुराई ही करते रहता है।  
   **Romanized:** Jisko bhee dekho bas aapki hee burai karte rehta hai.  
   **English answer:** Whoever you see, only keeps doing evil to you.  

102. **Hindi prompt:** मैंने जिसको भी देखा, वो यहाँ के खाने की बहुत तारीफ़ करता है।  
   **Romanized:** Maine jisko bhee dekha, vo yahaan ke khaane kee bahut taarif karta hai.  
   **English answer:** Whoever I have seen appreciates the food here.  

103. **Hindi prompt:** मैंने शादी में जिसको भी बुलाया था, वे सब लोग आए थे।  
   **Romanized:** Maine shaadi mein jisko bhee bulaya thaa, ve sub log aaye the.  
   **English answer:** Whoever I had invited to the wedding, they all came.  

104. **Hindi prompt:** तुमने जिसको भी ये बातें बोली हैं, नहीं बोलनी चाहिए थी।  
   **Romanized:** Tumne jisko bhee ye baaten boli hain, nahin bolani chahiye thee.  
   **English answer:** To whomever you have spoken these things, you should not have said it.  

105. **Hindi prompt:** तुमने जिसको भी ये बातें बोली हैं, उन्हें कोई फक नहीं पड़ता।  
   **Romanized:** Tumne jisko bhee ye baaten boli hain, unhe koee fark nahi padta.  
   **English answer:** To whomever you have spoken these things, they do not care.  

106. **Hindi prompt:** आजकल जिसको भी देखो फेसबुक चला रहा है।  
   **Romanized:** Aajkaal jisko bhee dekho facebook chala raha hai.  
   **English answer:** Whoever you see these days is using Facebook.  

107. **Hindi prompt:** आजकल जिसको भी देखो वो फ़ोन में बहुत व्यस्त है।.  
   **Romanized:** Aajkal Jisko bhee dekho vo phone mein bahut vyast hai.  
   **English answer:** Nowadays whoever you see is very busy on the phone.  

108. **Hindi prompt:** तुमने बिना सोचे समझे जिसको भी पीटा वो मेरे गाँव का था।  
   **Romanized:** Tumane bina soche samjhe jisko bhee peeta wo mere gaon ka thaa.  
   **English answer:** Whoever you beat without thinking was from my village.  

109. **Hindi prompt:** मैंने ये बातें जिसको भी बताई वो मेरा मज़ाक बना के चला गया।  
   **Romanized:** Maine ye baaten jisko bhee bataye vo mera mazak bana ke chala gaya.  
   **English answer:** To whomever I told these things, he went away making fun of me.  

110. **Hindi prompt:** जब कभी भी अकेला महसूस करो तो मुझे फ़ोन कर दिया करो।  
   **Romanized:** Jab kabhi bhee akela mehsoos karo to mujhe phone kar diya karo.  
   **English answer:** Whenever you feel lonely, give me a call.  

111. **Hindi prompt:** तुम्हें जब कभी भी मदद की ज़रूरत हो मुझे बोल दिया करो।  
   **Romanized:** Tumhe jab kabhi bhee madad kee zaroorat ho mujhe bol diya karo.  
   **English answer:** Tell me whenever you need help.  

112. **Hindi prompt:** जब कभी भी मैं मम्मी की तस्वीर देखता हूँ, तो मुझे मम्मी की बहुत याद आती है।  
   **Romanized:** Jab kabhi bhee mai mummy ki tasveer dekhta hoon, to mujhe mummy kee bahut yaad aati hai.  
   **English answer:** Whenever I see a picture of Mummy, I miss Mummy a lot.  

113. **Hindi prompt:** जब कभी भी मैं उदास होता हूँ, घर से दूर घूमने निकल जाता हूँ।  
   **Romanized:** Jab kabhi bhee mein udaas hota hoon, ghar se door ghumne nikal jata hoon.  
   **English answer:** Whenever I am sad, I go for a walk away from home.  

114. **Hindi prompt:** तुम अपनी बातें मुझे जब कभी भी बताओगे नहीं तो मुझे पता कैसे चलेगा।  
   **Romanized:** Tum apni baatein mujhe jab kabhi bhee bataoge nahi to mujhe pata kaise chalega.  
   **English answer:** How will I know whenever you don't tell me your things.  

115. **Hindi prompt:** अब जब कभी भी तुम मुझे मिलोगी, मेरे पैसे लेकर आना।  
   **Romanized:** Ab jab kabhi bhee tum mujhe milogi mere paise lekar aana.  
   **English answer:** Now whenever you will meet me, bring my money.  

116. **Hindi prompt:** जब कभी भी तुम मुझसे मिलोगी तो मेरी कार में घूमने चलेंगे।  
   **Romanized:** Jab kabhi bhee tum mujhse milogi to meri car mein ghumne chalenge.  
   **English answer:** Whenever you meet me, you will go for a walk in my car.  

117. **Hindi prompt:** मैं जब कभी भी तुमको देखता हूँ आपका चेहरा मुरझाया ही रहता है।  
   **Romanized:** Main jab kabhi bhee tumko dekhta hoon, apka chehra murjhaya hee rehta hai.  
   **English answer:** Your face always fades whenever I see you.  

118. **Hindi prompt:** जब कभी भी ट्रेन में सफर करो तो अपना टिकट अपने साथ रखो।  
   **Romanized:** Jab kabhi bhee train mein safar karo to apna ticket apne sath rakho.  
   **English answer:** Whenever you travel in a train, keep your ticket with you.  

119. **Hindi prompt:** जब कभी भी घर से बाहर जाते समय मास्क लगाना नहीं भूले।  
   **Romanized:** Jab kabhi bhee ghar se bahar jaate samay mask lagana nahi bhoole.  
   **English answer:** Whenever you go out of the house, do not forget to wear a mask.  

120. **Hindi prompt:** जिस किसी को भी प्यार करो वो सर पर चढ़ जाता है।  
   **Romanized:** Jis kisi ko bhee pyaar karo vo sir par chad jaata hai.  
   **English answer:** Whoever you love goes to the head.  

121. **Hindi prompt:** जिस किसी को भी दिल्ली जाना है वो इस बस में बैठे।  
   **Romanized:** Jis kisi ko bhee Delhi jaana hai vo ess bus main baithe.  
   **English answer:** Whoever wants to go to Delhi should sit in this bus.  

122. **Hindi prompt:** जिस किसी को भी पानी पीने जाना है वो लाइन लगाए।  
   **Romanized:** Jis kisi ko bhee paani peene jaana hai wo line lagaaye.  
   **English answer:** Whoever who wants to go to drink water should put a line.  

123. **Hindi prompt:** जिस किसी को भी मैं पसन्द नहीं वो कृपया यहाँ से चले जाये।  
   **Romanized:** Jis kisi ko bhee main pasand nahi vo kripya yahan se chale jaaye.  
   **English answer:** Whoever doesn't like me, please leave here.  

124. **Hindi prompt:** जिस किसी को भी देखो वो आजकल ऑनलाइन पैसे कमा रहा है।  
   **Romanized:** Jis kisi ko bhee dekho vo aaj kal online paise kama raha hai.  
   **English answer:** Whoever you see is earning money online nowadays.  

125. **Hindi prompt:** जिस किसी को भी मैंने अपना समझा उसने ही मुझे धोखा दिया है।  
   **Romanized:** Jis kisi ko bhee maine apna samjha usne hee dhokha diya hai.  
   **English answer:** Whoever I consider to be my own has deceived me.  

126. **Hindi prompt:** जिस किसी को भी मेरे पीछे आना है, वो आ सकता है।  
   **Romanized:** Jis kisi ko bhee mere piche aana hai vo aa sakta hai.  
   **English answer:** Whoever who wants to follow me can come.  

127. **Hindi prompt:** जिस किसी को भी देखो वो अक्षय कुमार का दीवाना है।  
   **Romanized:** Jis kisi ko bhee dekho wo Akshay Kumar ka deewana hai.  
   **English answer:** Whoever you see is crazy about Akshay Kumar.  

128. **Hindi prompt:** जिस किसी को भी इंग्लिश नहीं आती है वो मुझसे ट्यूशन ले सकता है।  
   **Romanized:** Jis kisi ko bhee English nahi aati hai vo mujhse tuition le sakta hai.  
   **English answer:** Whoever does not know English can take tuition from me.  

129. **Hindi prompt:** जिस किसी को भी तुम जानते हो उसको नमस्ते ज़रूर बोला करो।  
   **Romanized:** Jis kisi ko bhee tum jaanate ho usko Namaste zaroor bola karo.  
   **English answer:** Say hello to whoever you know.  

130. **Hindi prompt:** जो कुछ भी तुम्हें मालूम है मुझे चुपचाप बता दीजिये।  
   **Romanized:** Jo kuch bhee tumhe maloom hai chupchap bata dijiye.  
   **English answer:** Whatever you know, tell me quietly.  

131. **Hindi prompt:** मैं आज जो कुछ भी हूँ अपनी टीचर की बदौलत हूँ।  
   **Romanized:** Main aaj jo kuch bhee hoon, apne teacher ki badolat hoon.  
   **English answer:** Whatever I am today is because of my teacher.  

132. **Hindi prompt:** मैंने जो कुछ भी कमाया था, तुम्हें दे दिया था।  
   **Romanized:** Mene jo kuch bhee kamaya tha, tumhe de diya tha.  
   **English answer:** Whatever I earned, I gave to you.  

133. **Hindi prompt:** जो कुछ भी आपने मुझे बताया, क्या वो सच है?  
   **Romanized:** Jo kuch bhee aapne mujhe bataya, kya woh sach hai?  
   **English answer:** Whatever you told me, is it true?  

134. **Hindi prompt:** जो कुछ भी कोर्ट में आपने गवाही दी मैं उस गवाही से खुश नहीं हूँ।  
   **Romanized:** Jo kuch bhee apne court mein gawahi di, main us gawahi se khush nahi hoon.  
   **English answer:** Whatever you testified in the court, I am not happy with that testimony.  

135. **Hindi prompt:** जो कुछ भी मुझे सही लगेगा, मैं वही करूँगा।  
   **Romanized:** Jo kuch bhee mujhe sahi lagega, main wahi karunga.  
   **English answer:** Whatever feels right to me, I will do.  

136. **Hindi prompt:** जो कुछ भी तुम पाना चाहते हो उसके लिये आपको बहुत मेहनत करनी होगी।  
   **Romanized:** Jo kuch bhee tum pana chahte ho uske liye aapko bahut mehnat karni hogi.  
   **English answer:** Whatever you want to achieve, you have to work very hard.  

137. **Hindi prompt:** मैंने आपको पहले ही कहा था, कि जो कुछ भी तुम रात को डिनर में खाना चाहते हो अभी बता दो।  
   **Romanized:** Maine aapko pehle hi kaha thaa, ki jo kuch bhee tum raat ko dinner mein khaana chaahte ho abhi bataa do.  
   **English answer:** I already told you, whatever you want to eat for dinner at night, tell me now.  

138. **Hindi prompt:** जो कुछ भी तुम ये बड़े-बड़े सपने देखते हो, इनको सच करने की हिम्मत है आपके अंदर।  
   **Romanized:** Jo kuch bhee tum ye bade-bade sapne dekhte ho, inko sach karne ki himmat hai aapke ander.  
   **English answer:** Whatever these big dreams you see, you’ve the courage to make them come true.  

139. **Hindi prompt:** वादा करो, जो कुछ भी आपने देखा किसी को बताओगे नहीं।  
   **Romanized:** Waada karo, jo kuch bhee aapne dekha kisi ko bataoge nahin.  
   **English answer:** Promise, whatever you saw, you will not tell anyone.  

140. **Hindi prompt:** तुम जो कोई भी हो, मुझे कोई बात नहीं करनी है।  
   **Romanized:** Tum jo koi bhee ho, mujhe koi baat nahin karni hai.  
   **English answer:** Whoever you are, I don't want to talk.  

141. **Hindi prompt:** तुम जो कोई भी काम करो हमेशा पूरी लगन के साथ करो।  
   **Romanized:** Tum jo koi bhee kaam karo hamesha poori lagan ke sath karo.  
   **English answer:** Whatever work you do, always do it with full dedication.  

142. **Hindi prompt:** मैंने पहले ही कहा था, कि जो कोई भी टीम जीतेगी वही पहले बल्लेबाजी करेगी।  
   **Romanized:** Maine pahle hi kaha tha, ki jo koi bhee team jeetegi vahi pahle ballebaji karegi.  
   **English answer:** I already said that whichever team wins, will bat first.  

143. **Hindi prompt:** तुम जो कोई भी काम करते हो, हमेशा उल्टा करते हो।  
   **Romanized:** Tum jo koi bhee kaam karte ho, hamesha ulta karte ho.  
   **English answer:** Whatever work you do, always do the opposite.  

144. **Hindi prompt:** तुम में से जो कोई भी नकल करते पकड़ा गया वो कल क्लास में नहीं बैठेगा।  
   **Romanized:** Tum mein se jo koi bhee nakal karte pakda gayaa vo kal se class mein nahin baithega.  
   **English answer:** Whoever among you is caught copying will not sit in the class from tomorrow.  

145. **Hindi prompt:** क्लास में जो कोई भी फर्स्ट आएगा, उसको एक प्राइज़ मिलेगा।  
   **Romanized:** Class mein jo koi bhee first aayega, usko ek prize milega.  
   **English answer:** Whoever comes first in the class will get a prize.  

146. **Hindi prompt:** यहाँ जो कोई भी चोर होगा पुलिस उसको ज़रूर पकड़ लेगी।  
   **Romanized:** Yahaan jo koi bhee chor hoga police usko zaroor pakad legi.  
   **English answer:** Whoever is a thief here, the police will definitely catch him.  

147. **Hindi prompt:** जो कोई भी मुझसे मिलता है, आपकी बहुत तरीफ करता है।  
   **Romanized:** Jo koi bhee mujhse miltaa hai, aapki bahut tarif karta hai.  
   **English answer:** Whoever meets me appreciates you very much.  

148. **Hindi prompt:** मुझे गाँव में जो कोई भी जानता है मेरे पापा के नाम से जानता है।  
   **Romanized:** Mujhe gaon mein jo koi bhee jaanta hai mere papa ke naam se jaanta hai.  
   **English answer:** Whoever knows me in the village knows me by the name of my father.  

149. **Hindi prompt:** तुम जो कोई भी हो मेरे पीछे- पीछे मत आओ।  
   **Romanized:** Tum jo koi bhee ho mere piche-piche mat aao.  
   **English answer:** Whoever you are - don't follow me.  

## Source-text and verification notes

- All 149 Hindi prompts and printed Romanized lines were OCRed from row crops and visually verified against the page scans. All 149 English answers were visually checked against the answer-key scans and paired by printed item number. Prompt and answer sequences are continuous, unique, and complete.
- Lesson 28 spans PDF pages 365–379 (printed pages 364–378). It contains 149 Hindi/Romanized prompts on PDF pages 365–375 and a same-number English answer key on PDF pages 375–379. PDF page 375 contains prompts 140–149 followed by the Answers heading and answers 1–9.
- All 149 Hindi prompts and printed Romanized lines were OCRed from row crops and visually verified against the page scans. All 149 English answers were visually checked against the answer-key scans and paired by the printed item number. Prompt and answer sequences are continuous, unique, and complete; no unreadable sections.
- Punctuation, spelling, capitalization, and abbreviations in printed Romanized text are preserved unless a page-scan comparison showed an OCR insertion or omission. Examples of printed forms retained include `skte`, `fenka huwa`, `khoz`, `Joi`, `dificult`, `roaden`, `vikash`, `selfi`, `ess bus`, and the differing printed hyphen spacing at items 72 and 76. At items 79 and 83, OCR-inserted spaces around a hyphen were removed to match the scan; item 135's printed comma was restored.
- Printed source inconsistencies are preserved rather than silently normalized: item 131 has Hindi `अपनी टीचर` but Romanized `apne teacher`; item 134 has Hindi `आपने` but Romanized `apne`; item 144's Hindi says `कल क्लास` while its Romanized text says `kal se class`; item 147 prints `तरीफ`/`tarif`; and item 149 prints the Hindi spacing `पीछे- पीछे` while the Romanized text is `piche-piche`.
- Other unusual grammar or wording in the English answers and source examples is transcribed as printed, including all alternatives, punctuation, and capitalization. Footer page numbers in the scans are one lower than the PDF page numbers.

**Unreadable text:** none identified.

