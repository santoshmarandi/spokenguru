# Lesson 3 — WH Family Words in English

**PDF pages:** 21–32 (printed pages 20–31)

> Translate the following sentences into English:

### 1
**Hindi:** आपके पापा का क्या नाम है?
**Romanized:** Aapke papa ka kya naam hai?
**Answer:** What is your father’s name?

### 2
**Hindi:** क्या टाइम हुआ है?
**Romanized:** Kya time hua hai?
**Answer:** What time is it?

### 3
**Hindi:** क्या हुआ?
**Romanized:** Kya hua?
**Answer:** What happened?

### 4
**Hindi:** वहाँ क्या क्या हुआ?
**Romanized:** Wahan kya kya hua?
**Answer:** What all happened there?

### 5
**Hindi:** उसके साथ क्या क्‍या हुआ?
**Romanized:** Uske sath kya kya hua?
**Answer:** What all happened with him?

### 6
**Hindi:** उसके पास क्या है?
**Romanized:** Uske paas kya hai?
**Answer:** What does he have?

### 7
**Hindi:** उसके पास क्या क्या है?
**Romanized:** Uske paas kya kya hai?
**Answer:** What all does he have?

### 8
**Hindi:** आपके पास क्या है?
**Romanized:** Aapke paas kya hai?
**Answer:** What do you have?

### 9
**Hindi:** आपके पास क्या नहीं है?
**Romanized:** Aapke paas kya nahi hai?
**Answer:** What do you not have?

### 10
**Hindi:** आपने क्या ख़रीदा?
**Romanized:** Aapne kya kharida?
**Answer:** What did you buy?

### 11
**Hindi:** क्या चल रहा है?
**Romanized:** Kya chal raha hai?
**Answer:** What is going on? / What’s going on?

### 12
**Hindi:** मुझे नहीं पता क्या है ये।
**Romanized:** Mujhe nahi pata kya hai ye.
**Answer:** I don’t know what it is.

### 13
**Hindi:** आप क्या करने की कोशिश कर रहे हो?
**Romanized:** Aap kya karne ki koshish kar rahe ho?
**Answer:** What are you trying to do?

### 14
**Hindi:** आखिरी रविवार को क्‍या किया आपने?
**Romanized:** Akhiri ravivar ko kya kiya aapne?
**Answer:** What did you do last Sunday?

### 15
**Hindi:** आखिरी रविवार को क्या क्या किया आपने?
**Romanized:** Akhiri ravivar ko kya kya kiya apne?
**Answer:** What all did you do last Sunday?

### 16
**Hindi:** आपका मतलब क्या है?
**Romanized:** Aapka matlab kya hai?
**Answer:** What do you mean?

### 17
**Hindi:** उस लड़के में तुम्हें क्या पसंद है?
**Romanized:** Us ladke me tumhe kya pasand hai?
**Answer:** What do you like in that boy?

### 18
**Hindi:** मुझमें तुम्हें क्या पसंद है?
**Romanized:** Mujhme tumhe kya pasand hai?
**Answer:** What do you like in me?

### 19
**Hindi:** क्या इंसान हैं आप!
**Romanized:** Kya insaan hain aap!
**Answer:** What a person you are!

### 20
**Hindi:** क्या लड़की है वो!
**Romanized:** Kya ladki hai vo!
**Answer:** What a girl she is!

### 21
**Hindi:** आप क्या करते हो?
**Romanized:** Aap kya karte ho?
**Answer:** What do you do?

### 22
**Hindi:** अगला टॉपिक क्या था?
**Romanized:** Agla topic kya tha?
**Answer:** What was the next topic?

### 23
**Hindi:** वो आज क्या परफॉर्म कर रहे हैं?
**Romanized:** Wo aaj kya perform kar rahe hain?
**Answer:** What are they performing today?

### 24
**Hindi:** आपका पसंदीदा खेल क्या है?
**Romanized:** Apka pasandida khel kya hai?
**Answer:** What is your favorite sport?

### 25
**Hindi:** आपकी विशेषता क्या है?
**Romanized:** Apki visheshta kya hai?
**Answer:** What's your quality?

### 26
**Hindi:** मुझे दे दो जो कुछ भी तुम्हारे पास है।
**Romanized:** Mujhe de do jo kuchh bhi tumhare paas hai.
**Answer:** Give me whatever you have.

### 27
**Hindi:** जो कुछ मैंने चाहा, मुझे वो मिला।
**Romanized:** Jo kuch maine chaha, mujhe vo mila.
**Answer:** Whatever I wanted, I got that.

### 28
**Hindi:** जो कुछ भी तुमने कहा, गलत है।
**Romanized:** Jo kuch bhi tumne kaha, galat hai.
**Answer:** Whatever you said, is wrong.

### 29
**Hindi:** जो कुछ भी आप चूज़ करते हो, मेरा है।
**Romanized:** Jo kuch bhi aap choose karte ho, mera hai.
**Answer:** Whatever you choose, is mine.

### 30
**Hindi:** आप कहाँ हो?
**Romanized:** Aap kahaan ho?
**Answer:** Where are you?

### 31
**Hindi:** आपकी कैप कहाँ है?
**Romanized:** Apki cap kahaan hai?
**Answer:** Where is your cap?

### 32
**Hindi:** आप कहाँ से हैं?
**Romanized:** Aap kahaan se hai?
**Answer:** Where are you from?

### 33
**Hindi:** हमें कहाँ जाना चाहिये?
**Romanized:** Hume kahaan jaana chahiye?
**Answer:** Where should/shall we go?

### 34
**Hindi:** हमें कहाँ कहाँ जाना चाहिये?
**Romanized:** Hume kahaan kahaan jana chaiye?
**Answer:** Where all should/shall we go?

### 35
**Hindi:** स्टेशन कहाँ है?
**Romanized:** Station kahaan hai?
**Answer:** Where is the station?

### 36
**Hindi:** वो कहाँ गया?
**Romanized:** Wo kahaan gaya?
**Answer:** Where did he go?

### 37
**Hindi:** क्या आपको पता है, वो कहाँ गया?
**Romanized:** Kya apko pata hai wo kahaan gaya?
**Answer:** Do you know, where he went?

### 38
**Hindi:** हम कहाँ मिलेंगे?
**Romanized:** Hum kahaan milenge?
**Answer:** Where will we meet?

### 39
**Hindi:** क्या आपको पता है, हम कहाँ मिलेंगे?
**Romanized:** Kya aapko pata hai, hum kahaan milenge?
**Answer:** Do you know, where we will meet?

### 40
**Hindi:** क्या आपको पता है मेरा मोबाइल फ़ोन कहाँ है?
**Romanized:** Kya aapko pata hai mera mobile phone kahaan hai?
**Answer:** Do you know, where my mobile phone is?

### 41
**Hindi:** आप कहाँ जा रहे थे?
**Romanized:** Aap kahaan ja rahe the?
**Answer:** Where were you going?

### 42
**Hindi:** मैं कहाँ से मूवी टिकट खरीद सकता हूँ?
**Romanized:** Mein kaha se movie ticket kharid sakta hu?
**Answer:** From where can I buy a movie ticket?

### 43
**Hindi:** पुलिस स्टेशन कहाँ है?
**Romanized:** Police station kahaan hai?
**Answer:** Where is the police station?

### 44
**Hindi:** पुलिस स्टेशन कहाँ कहाँ हैं?
**Romanized:** Police station kahaan kahaan hain?
**Answer:** Where all are the police stations?

### 45
**Hindi:** तुम्हें ये पर्स कहाँ मिला?
**Romanized:** Tumhe ye purse kahaan mila?
**Answer:** Where did you find this wallet?

### 46
**Hindi:** सबसे पास बस स्टॉप कहाँ है?
**Romanized:** Sabse paas bus stop kahaan hai?
**Answer:** Where is the nearest bus stop?

### 47
**Hindi:** उसने मुझे सलाह दी कि कहाँ रहना है।
**Romanized:** Usne mujhe salah di,kahaan rehna hai.
**Answer:** She advised me where to stay.

### 48
**Hindi:** आज का अख़बार कहाँ है?
**Romanized:** Aaj ka akhbar kahaan hai?
**Answer:** Where is today's newspaper?

### 49
**Hindi:** राहुल पार्टी कहाँ दे रहा है?
**Romanized:** Rahul party kahaan de raha hai?
**Answer:** Where is Rahul giving party?

### 50
**Hindi:** वो कहाँ कहाँ जाता है?
**Romanized:** Vo kahaan kahaan jata hai?
**Answer:** Where all does he go?

### 51
**Hindi:** वो कहाँ कहाँ जाता है और कब?
**Romanized:** Vo kahaan kahaan jata hai or kab?
**Answer:** Where all does he go and when?

### 52
**Hindi:** आपने कहाँ कहाँ काम किया है?
**Romanized:** Aapne kahaan kahaan kaam kiya hai?
**Answer:** Where all have you worked?

### 53
**Hindi:** आपने कहाँ काम किया है और किस के साथ ?
**Romanized:** Apne kaha kaam kiya h or kis ke sath?
**Answer:** Where all have you worked and with whom?

### 54
**Hindi:** जहाँ कही भी मैं देखता हूँ, तुम्हीं दिखती हो।
**Romanized:** Jaha kahin bhi main dekhta hu, tumhi dikhti ho.
**Answer:** Wherever I see, it’s you.

### 55
**Hindi:** कौन सा आइस-क्रीम फ्लेवर तुमको पसंद है?
**Romanized:** Kaunsa ice-cream flavour tumko pasand hai?
**Answer:** Which ice-cream flavour do you like?

### 56
**Hindi:** कौन सा आइस-क्रीम फ्लेवर तुमको सबसे ज़्यादा पसंद है?
**Romanized:** Kaunsa ice-cream flavour tumko sabse zyada pasand hai?
**Answer:** Which ice-cream flavour do you like the most?

### 57
**Hindi:** कौन कौन से आइस-क्रीम फ्लेवर तुमको पसंद है?
**Romanized:** Kaun kaunse ice-cream flavours tumko pasand hai?
**Answer:** Which all ice-cream flavours do you like?

### 58
**Hindi:** कौन सी मूवी तुम देखना चाहते हो?
**Romanized:** Kaunsi movie tum dekhna chahte ho?
**Answer:** Which movie do you want to watch?

### 59
**Hindi:** कौन कौन सी मूवीज़ तुम देखना चाहते हो?
**Romanized:** Kaun kaun si movies tum dekhna chahte ho?
**Answer:** Which all movies do you want to watch?

### 60
**Hindi:** मैं शिव टेम्पल के पास हूँ, जो कि दिल्ली में बहुत फेमस है।
**Romanized:** Main Shiv temple ke paas hu, jo ki Delhi mein bahut famous hai.
**Answer:** I am near the Shiv temple, which is very famous in Delhi.

### 61
**Hindi:** मैं अयांश के साथ हूँ, जो कि मेरा बेटा है।
**Romanized:** Mein Ayansh ke sath hu, jo ki mera beta hai.
**Answer:** I am with Ayansh, who is my son.

### 62
**Hindi:** आपको कौन सी बुक चाहिए?
**Romanized:** Apko kaunsi book chaiye?
**Answer:** Which book do you want?

### 63
**Hindi:** कौन सी जगहें आपको सबसे ज़्यादा पसंद हैं?
**Romanized:** Kaunsi jagahein apko sabse zyada pasand hain?
**Answer:** Which places do you like the most?

### 64
**Hindi:** तुम्हें दवाई चाहिये, पर कौन सी?
**Romanized:** Tumhe dawai chahiye, par kaunsi?
**Answer:** You need a medicine, but which one?

### 65
**Hindi:** मैं एक किताब ढूँढ रहा हूँ, जो कि लाल कलर की है।
**Romanized:** Main ek kitab dhoond raha hu, jo ki laal colour ki hai.
**Answer:** I am looking for a book, which is red in colour.

### 66
**Hindi:** एंड्रॉइड और विंडोज फोन्स में तुम्हें ज़्यादा पसंद कौन सा है?
**Romanized:** Android or windows phones me tumhe zyada pasand kaunsa hai?
**Answer:** Which one do you prefer, android phones or windows phones?

### 67
**Hindi:** शादी के लिए आप कौन सा चूज़ करोगी?
**Romanized:** Shaadi ke liye aap kaunsa choose karogi?
**Answer:** Which one would you choose for wedding?

### 68
**Hindi:** किस कॉलेज से हो आप?
**Romanized:** Kis college se ho aap?
**Answer:** Which college are you from?

### 69
**Hindi:** ये डिब्बा खाली है, जिसमें बहुत सारे फूल थे।
**Romanized:** Ye dibba khaali hai, jisme bahut saare phool the.
**Answer:** This box is empty, which had many flowers.

### 70
**Hindi:** आप/तुम कौन हो?
**Romanized:** Aap/tum kaun ho?
**Answer:** Who are you?

### 71
**Hindi:** कौन जानता है?
**Romanized:** Kaun jaanta hai?
**Answer:** Who knows?

### 72
**Hindi:** कौन कौन जानते हैं?
**Romanized:** Kaun kaun jaante hai?
**Answer:** Who all know?

### 73
**Hindi:** किसने कहा?
**Romanized:** Kisne kahaan?
**Answer:** Who said?

### 74
**Hindi:** इस तस्वीर को किसने पेंट किया?
**Romanized:** Is tasveer ko kisne paint kiya?
**Answer:** Who painted this picture?

### 75
**Hindi:** वो लड़की कौन है?
**Romanized:** Wo ladki kaun hai?
**Answer:** Who is that girl?

### 76
**Hindi:** वो लड़का कौन है?
**Romanized:** Wo ladka kaun hai?
**Answer:** Who is that boy?

### 77
**Hindi:** इस सेल्फी में ये कौन है?
**Romanized:** Is selfie me ye kaun hai?
**Answer:** Who is this in this selfie?

### 78
**Hindi:** गिटार कौन बजा रहा है?
**Romanized:** Guitar kaun baja raha hai?
**Answer:** Who is playing the guitar?

### 79
**Hindi:** आपका पसंदीदा हीरो कौन है?
**Romanized:** Apka favourite hero kaun hai?
**Answer:** Who is your favourite actor?

### 80
**Hindi:** आपके पसंदीदा एक्टर्स कौन कौन हैं ?
**Romanized:** Apke favourite actors kaun kaun hai?
**Answer:** Who all are your favourite actors?

### 81
**Hindi:** मुझे नहीं पता, केक किसने बनाया?
**Romanized:** Mujhe nahi pata, cake kisne banaya?
**Answer:** I don't know who made the cake.

### 82
**Hindi:** सवाल ये है, कौन इस प्रोजेक्ट को करेगा?
**Romanized:** Sawaal ye hai, kaun is project ko karega?
**Answer:** The question is who will do this project?

### 83
**Hindi:** आज रात कौन गाने वाला है?
**Romanized:** Aaj raat kaun gaane waala hai?
**Answer:** Who is going to sing tonight?

### 84
**Hindi:** इंडिया का पहला प्रधानमंत्री कौन था?
**Romanized:** India ka pahla pradhanmantri kaun tha?
**Answer:** Who was the first prime minister of India?

### 85
**Hindi:** इस तस्वीर को कौन बना सकता है?
**Romanized:** Is tasveer ko kaun bana sakta hai?
**Answer:** Who can make this picture?

### 86
**Hindi:** आपकी राय क्या है, कौन मैच जीतेगा?
**Romanized:** Apki rai kya hai, kaun match jitega?
**Answer:** What is your opinion, who will win the match?

### 87
**Hindi:** आईटी डिपार्टमेंट में राहुल कौन है?
**Romanized:** IT department mein Rahul kaun hai?
**Answer:** Who is Rahul in IT department?

### 88
**Hindi:** अगला सुपर स्टार कौन होगा?
**Romanized:** Agla superstar kaun hoga?
**Answer:** Who will be the next superstar?

### 89
**Hindi:** किसको आइस क्रीम चाहिये?
**Romanized:** Kisko ice-cream chahiye?
**Answer:** Who wants ice-cream?

### 90
**Hindi:** कौन खाना पकायेगा?
**Romanized:** Kaun khana pakayega?
**Answer:** Who will cook the food?

### 91
**Hindi:** ये राम है, जो मेरे साथ था।
**Romanized:** Ye Ram hai, jo mere sath tha.
**Answer:** This is Ram, who was there with me.

### 92
**Hindi:** वो मेरा दोस्त है जिसने तुम्हें कॉल किया था।
**Romanized:** Vo mera dost hai, jisne tumhe call kiya tha.
**Answer:** That is my friend, who had called you.

### 93
**Hindi:** जो कोई भी मुझे जानता है मुझसे प्यार करता है |
**Romanized:** Jo koi bhi mujhe jaanta hai, mujhse pyar karta hai.
**Answer:** Whoever knows me, loves me.

### 94
**Hindi:** जो कोई भी यहाँ है, राहुल उसके साथ बात करना चाहता है।
**Romanized:** Jo koi bhi yaha hai, Rahul uske sath baat karna chahta hai.
**Answer:** Rahul wants to speak with whoever is here.

### 95
**Hindi:** तुमने क्यों पूछा?
**Romanized:** Tumne Kyo pucha?
**Answer:** Why did you ask?

### 96
**Hindi:** तुम क्यों रो रहे हो?
**Romanized:** Tum kyo ro rahe ho?
**Answer:** Why are you crying?

### 97
**Hindi:** तुम अंदर क्यों नहीं आते?
**Romanized:** Tum ander kyo nahi aate?
**Answer:** Why don't you come in?

### 98
**Hindi:** उसने जॉब क्यों छोड़ी?
**Romanized:** Usne job kyo chodi?
**Answer:** Why did he quit the job?

### 99
**Hindi:** तुमने ये टेनिस टेबल क्‍यों खरीदी?
**Romanized:** Tumne ye tennis table kyo kharidi?
**Answer:** Why did you buy this tennis table?

### 100
**Hindi:** तुमने बॉक्स ओपन क्यों किया?
**Romanized:** Tumne box open kyo kiya?
**Answer:** Why did you open the box?

### 101
**Hindi:** हम पिज़्ज़ा आर्डर क्यों न करें?
**Romanized:** Hum pizza order kyo na kare?
**Answer:** Why shall we not order pizza?

### 102
**Hindi:** तुम गुस्सा क्यों हो?
**Romanized:** Tum gussa kyo ho?
**Answer:** Why are you angry?

### 103
**Hindi:** आज तुम इतने थके हुए क्यों हो?
**Romanized:** Aaj tum itne thake hue kyo ho?
**Answer:** Why are you so tired today?

### 104
**Hindi:** तुम एक्टर क्यों बनना चाहते हो?
**Romanized:** Tum actor kyo banna chahte ho?
**Answer:** Why do you want to become an actor?

### 105
**Hindi:** आज सुबह तुम लेट क्यों थे?
**Romanized:** Aaj subah tum late kyo the?
**Answer:** Why were you late this morning?

### 106
**Hindi:** क्या मैं पूछ सकती हूँ क्यों?
**Romanized:** Kya main poonch sakti hu Kyo?
**Answer:** May I ask you why?

### 107
**Hindi:** तुम वहाँ से क्यों भागे?
**Romanized:** Tum wahan se kyo bhaage?
**Answer:** Why did you run from there?

### 108
**Hindi:** तुम निराश क्‍यों हो?
**Romanized:** Tum niraash kyo ho?
**Answer:** Why are you disappointed?

### 109
**Hindi:** उसने इसके बारे में उसे क्यों नहीं कहा?
**Romanized:** Usne iske bare me use kyon nahi kaha?
**Answer:** Why didn't she tell him about it?

### 110
**Hindi:** वे उस बिल्डिंग के आस पास क्‍यों घूम रहे है?
**Romanized:** Ve us building ke aas paas kyo ghoom rahe hai?
**Answer:** Why are they walking around that building?

### 111
**Hindi:** वो सब अच्छे से जानते हैं, रिया क्‍यों दुखी है।
**Romanized:** Wo sab achchhe se jaante hain, Riya kyo dukhi hai.
**Answer:** They all know very well why Riya is upset.

### 112
**Hindi:** आज तुम इतने लेट क्‍यों हो?
**Romanized:** Aaj tum itne late kyo ho?
**Answer:** Why are you so late today?

### 113
**Hindi:** यह पंखा काम क्‍यों नहीं कर रहा?
**Romanized:** Ye pankha kaam kyo nahi kar raha?
**Answer:** Why is this fan not working?

### 114
**Hindi:** तुम कब पढ़ाई करते हो?
**Romanized:** Tum kab padhai karte ho?
**Answer:** When do you study?

### 115
**Hindi:** यह कब शुरू होता है?
**Romanized:** Yeh kab shuru hota hai?
**Answer:** When does it start?

### 116
**Hindi:** तुमने ये साड़ी कब खरीदी?
**Romanized:** Tumne ye saari kab kharidi?
**Answer:** When did you buy this saree?

### 117
**Hindi:** तुम्हारा बर्थ डे कब है?
**Romanized:** Tumhara birthday kab hai?
**Answer:** When is your birthday?

### 118
**Hindi:** तुम वापस कब आ रहे हो?
**Romanized:** Tum wapas kab aa rahe ho?
**Answer:** When are you coming back?

### 119
**Hindi:** रवि बाहर था, जब मैंने कॉल किया।
**Romanized:** Ravi baahar tha, jab mene call kiya.
**Answer:** Ravi was out when I called him.

### 120
**Hindi:** तुम्हारी परीक्षा कब से है?
**Romanized:** Tumari pariksha kabse hai?
**Answer:** When is your exam? / When will your exam start?

### 121
**Hindi:** हम कब पहुँचेंगे?
**Romanized:** Hum kab pahuchenge?
**Answer:** When will we arrive?

### 122
**Hindi:** तुमने फ़ोन कब चेंज किया?
**Romanized:** Tumne phone kab change kiya?
**Answer:** When did you change your phone?

### 123
**Hindi:** जब कभी तुम्हारे पास समय हो मुझे मैसेज करना.
**Romanized:** Jab tumhare paas samay ho, mujhe message karna.
**Answer:** Whenever you have time, message me.

### 124
**Hindi:** जब मैं जवान था, तो अच्छे से तैर सकता था।
**Romanized:** Jab me jawan tha, to acche se tair skta tha.
**Answer:** When I was a young, I could swim well.

### 125
**Hindi:** जब मैं घर आया शिखा रो रही थी.
**Romanized:** Jab mein ghar aaya Shikha ro rahi thi.
**Answer:** When I came home, Shikha was crying.

### 126
**Hindi:** जब वो 20 साल की थी, उसकी शादी हो गयी।
**Romanized:** Jab wo 20 saal ki thi, uski shaadi ho gayi.
**Answer:** When she was 20, She got married.

### 127
**Hindi:** मैं तुम्हें कॉल करूँगा, जब हम जायेंगे।
**Romanized:** Me tumhe call karunga, jab hum jaayenge.
**Answer:** I'll call you when we go.

### 128
**Hindi:** काजल उससे कब मिलेगी?
**Romanized:** Kajal usse kab milegi?
**Answer:** When will Kajal meet him?

### 129
**Hindi:** तुम कब सोये?
**Romanized:** Tum kab soye?
**Answer:** When did you sleep?

### 130
**Hindi:** पायल कहाँ थी, जब उसके पेरेंट्स आये?
**Romanized:** Payal kahaan thi, jab uske parents aaye?
**Answer:** Where was Payal, when her parents turned up?

### 131
**Hindi:** सुमित के अंकल घर कब आयेंगे?
**Romanized:** Sumit ke uncle ghar kab aayege?
**Answer:** When will Sumit’s uncle come home?

### 132
**Hindi:** जब कभी मैं आऊँगा, हम मूवी देखने चलेंगे।
**Romanized:** Jab kabhi main aaunga, hum movie dekhne chalenge.
**Answer:** Whenever I come, we will go for a movie.

### 133
**Hindi:** मैंने अपने दिल की बात उससे कही, जब कभी मुझे मौका मिला।
**Romanized:** Maine apne dil ki baat usse kahi, jab kabhi mujhe mauka mila.
**Answer:** I spoke my heart to her, whenever I got a chance.

### 134
**Hindi:** आप कैसे हो?
**Romanized:** Aap kaise ho?
**Answer:** How are you?

### 135
**Hindi:** तुम्हारा भाई कैसा है |
**Romanized:** Tumhara bhai kaisa hai.
**Answer:** How is your brother?

### 136
**Hindi:** तुम्हारी छुटियाँ कैसी रही?
**Romanized:** Tumhari chutiyaan kaise rahi?
**Answer:** How were your holidays?

### 137
**Hindi:** आज का शो कैसा था?
**Romanized:** Aaj ka show kaisa tha?
**Answer:** How was today's show?

### 138
**Hindi:** तुम्हारे पापा कितने साल के है?
**Romanized:** Tumhare papa kitne saal ke hai?
**Answer:** How old is your father?

### 139
**Hindi:** तुम्हारी कार कितनी लम्बी है?
**Romanized:** Tumhari car kitni lambi hai?
**Answer:** How long is your car?

### 140
**Hindi:** वो कैसे जाता है?
**Romanized:** Wo kaise jata hai?
**Answer:** How does he go?

### 141
**Hindi:** मुझे नहीं पता वेज बिरयानी कैसे बनानी है।
**Romanized:** Mujhe nahi pata veg biryani kaise banani hai.
**Answer:** I don't know how to cook veg biryani.

### 142
**Hindi:** तुमने इस मूवी को कितना एन्जॉय किया?
**Romanized:** Tumne is movie ko kitna enjoy kiya?
**Answer:** How much did you enjoy this movie?

### 143
**Hindi:** आपके कितने बच्चे हैं?
**Romanized:** Apke kitne bachche hai?
**Answer:** How many children do you have?

### 144
**Hindi:** उसके कितने बच्चे हैं?
**Romanized:** Uske kitne bachche hai?
**Answer:** How many children does he have?

### 145
**Hindi:** आपके कितने बच्चे थे?
**Romanized:** Apke kitne bachche the?
**Answer:** How many children did you have?

### 146
**Hindi:** मेरे बेटे को कॉम्पिटेटिव एग्ज़ैम्स के लिए कितना पढ़ना चाहिये?
**Romanized:** Mere bete ko competitive exams ke liye kitna padhna chaiye?
**Answer:** How much should my son study for competitive exams?

### 147
**Hindi:** मोबाइल पर तुम कितना टाइम बिताते हो?
**Romanized:** Mobile per tum kitna time bitate ho?
**Answer:** How much time do you spend on mobile?

### 148
**Hindi:** तुमने तबला बजाना कैसे सीखा?
**Romanized:** Tumne tabla bajana kaise sikha?
**Answer:** How did you learn to play Tabla?

### 149
**Hindi:** इस मशीन को कैसे यूज़ करते हैं?
**Romanized:** Is machine ko kaise use karte hai?
**Answer:** How to use this machine?

### 150
**Hindi:** इस पहेली को कैसे सॉल्व करें?
**Romanized:** Is puzzle ko kaise solve kare?
**Answer:** How to solve this puzzle?

### 151
**Hindi:** एक महीने में तुम कितनी बुक्स पढ़ते हो?
**Romanized:** Ek mahine mein tum kitni books padhte ho?
**Answer:** How many books do you read in a month?

### 152
**Hindi:** तुम डांस कैसे करोगे, जब तुम्हारे पैर काम नहीं कर रहे हैं?
**Romanized:** Tum dance kaise karoge, jab tumare pair kam nahi kar rahe hai?
**Answer:** How will you dance, when your legs not working?

### 153
**Hindi:** देखो, उस त्यौहार को लोग कैसे मना रहे हैं
**Romanized:** Dekho,Us tyohaar ko log kaise mana rahe hai!
**Answer:** See, how the people are celebrating that festival.

### 154
**Hindi:** आप वहाँ अक्सर कब कब जाते हो?
**Romanized:** Aap wahaan aksar kab kab jaate ho?
**Answer:** How often do you go there?

### 155
**Hindi:** आप कब कब उससे मिलते हो?
**Romanized:** Aap kab kab usse milte ho?
**Answer:** How often do you meet him?

### 156
**Hindi:** यहाँ से बस स्टॉप कितना दूर है?
**Romanized:** Yaha se bus stop kitna door hai?
**Answer:** How far is the bus stop from here?

### 157
**Hindi:** आप कितनी दूर जा सकते हो?
**Romanized:** Aap kitni door jaa sakte ho?
**Answer:** How far can you go?

### 158
**Hindi:** तुम किसे आमंत्रित करने वाले हो?
**Romanized:** Tum kise invite karne wale ho?
**Answer:** Whom are you going to invite?

### 159
**Hindi:** उसने इस पोस्ट के लिए किसे चुना?
**Romanized:** Usne is post ke liye kise chuna?
**Answer:** Whom did he hire for this post?

### 160
**Hindi:** तुमने मेरा बैग किसे दिया?
**Romanized:** Tumne mera bag kise diya?
**Answer:** Whom did you give my bag?

### 161
**Hindi:** तुमने किसको देखा?
**Romanized:** Tumne kisko dekha?
**Answer:** Whom did you see?

### 162
**Hindi:** तुमने इस सुझाव के लिए किसे फ़ोन किया था?
**Romanized:** Tumne is sujhav ke liye kise phone kiya tha?
**Answer:** Whom had you called for this suggestion?

### 163
**Hindi:** आप किसे आमंत्रित करना चाहोगे?
**Romanized:** Aap kise invite karna chahoge?
**Answer:** Whom would you like to invite?

### 164
**Hindi:** वो कितनी बार मुझसे मिलेगा?
**Romanized:** Vo kitni baar mujhse milega?
**Answer:** How many times will he meet me?

### 165
**Hindi:** हम कब कब स्कूल जायेंगे?
**Romanized:** Hum kab kab school jayenge?
**Answer:** How often will we go to school?

### 166
**Hindi:** मैं जानता हूँ आप कहाँ रहते हो।
**Romanized:** Main jaanta hu, aap kahaan rahte ho.
**Answer:** I know where you live.

### 167
**Hindi:** वहाँ क्या क्या हुआ था?
**Romanized:** Waha kya kya hua tha?
**Answer:** What all had happened there?

### 168
**Hindi:** राम के पास कितना पैसा है?
**Romanized:** Ram ke paas kitna paisa hai?
**Answer:** How much money does Ram have?

### 169
**Hindi:** मुझसे कौन कौन बात करना चाहेगा?
**Romanized:** Mujhse kaun kaun baat karna chahega?
**Answer:** Who all would like to talk to me?

---
**Verification:** 169 Hindi prompts transcribed from OCR on PDF pages 21–27; Romanized readings preserved from the text layer; 169 answers preserved from the text layer and visually checked against PDF pages 28–32. All 169 numbered prompt–answer pairs are present in order. 0 unreadable sections.

- Source answer-key wording mismatch, item 53: the Hindi/Romanized prompt says “Where have you worked and with whom?”; the printed English answer adds “all.” The printed answer is retained.
- Source answer-key wording mismatch, item 159: the Hindi/Romanized prompt says “whom did he choose for this post”; the printed English answer says “Whom did he hire for this post?” The printed answer is retained.
- Source answer-key wording issue, item 160: the printed answer “Whom did you give my bag?” omits “to”; the printed construction is retained. The obvious spelling “beg” is corrected to “bag” in the Romanized prompt and answer.
- Source Romanized-reading discrepancy, item 73: the printed Romanized prompt says “Kisne kahaan?” while the Hindi and English answer mean “Who said?” Both source readings are retained.
- **OCR verification:** The seven exercise pages were visually reviewed; OCR rows were checked against the page images, including six lines whose parenthesis was missed in the sparse pass.
