# Lesson 16 — All Auxiliary/ Helping/ Modal Verbs

**PDF pages:** 199–223 (printed pages 198–222)

This lesson has one continuous translation exercise (items 1–391). Each Hindi prompt and its printed Romanized line are paired with the English answer carrying the same number in the answer key.

## Translate the following sentences in English

### 1. वह घर पर है।
**Romanized:** (Wah ghar par hai.)
**English answer:** He is at home.

### 2. मैं स्कूल में हूँ।
**Romanized:** (Main school mein hoon.)
**English answer:** I am in school.

### 3. तुम मेरे साथ हो।
**Romanized:** (Tum mere sath ho.)
**English answer:** You are with me.

### 4. वह खेल रही है।
**Romanized:** (Wah Khel rahi hai.)
**English answer:** She is playing.

### 5. आप घर जा रहे हैं।
**Romanized:** (Aap ghar ja rahe hain.)
**English answer:** You are going home.

### 6. उसे भेजा जाता है।
**Romanized:** (Use bheja jata hai.)
**English answer:** He is sent.

### 7. उसे एक किताब दी जाती है।
**Romanized:** (Use ek kitaab di jaati hai.)
**English answer:** She is given a book.

### 8. मुझे बताया जाता है।
**Romanized:** (Mujhe bataya jata hai.)
**English answer:** I am told/informed.

### 9. आपको देखा जाता है।
**Romanized:** (Apko dekha jata hai.)
**English answer:** You are seen.

### 10. हमें प्रताड़ित किया जाता है।
**Romanized:** (Hame prataadit kiya jata hai.)
**English answer:** We are tortured.

### 11. उन्हें दोषी ठहराया जाता है।
**Romanized:** (Unhen doshi thahraya jata hai.)
**English answer:** They are blamed.

### 12. वो घर पर था।
**Romanized:** (Wo ghar par tha.)
**English answer:** He was at home.

### 13. वह स्कूल में थी।
**Romanized:** (Wah School mein thi.)
**English answer:** She was in school.

### 14. उस दिन राहुल मेरे साथ था।
**Romanized:** (Us din Rahul mere sath tha.)
**English answer:** Rahul was with me that day.

### 15. मैं वहाँ था।
**Romanized:** (Main waha tha.)
**English answer:** I was there.

### 16. आप वहाँ नहीं थे।
**Romanized:** (Aap waha nahi the.)
**English answer:** You were not there.

### 17. हम उन दिनों गोवा में थे।
**Romanized:** (Ham un dino Goa mein the.)
**English answer:** We were in Goa those days.

### 18. वह सो रहा था।
**Romanized:** (Wah so raha tha.)
**English answer:** He was sleeping.

### 19. वह रो रही थी।
**Romanized:** (Wah ro rahi thi.)
**English answer:** She was weeping.

### 20. मैं हँस रहा था।
**Romanized:** (Main hans raha tha.)
**English answer:** I was laughing.

### 21. आप घर जा रहे थे।
**Romanized:** (Aap ghar ja rahe the.)
**English answer:** You were going home.

### 22. हम आपके साथ खेल रहे थे।
**Romanized:** (Ham apke sath khel rahe the.)
**English answer:** We were playing with you.

### 23. उसे बताया गया।
**Romanized:** (Use bataya gaya tha.)
**English answer:** He was told.

### 24. उसे एक मोबाइल दिया गया।
**Romanized:** (Use ek mobile diya gaya tha.)
**English answer:** She was given a mobile.

### 25. हमें डांटा गया।
**Romanized:** (Hame danta gaya tha.)
**English answer:** We were scolded.

### 26. हमें हमारे शिक्षकों के द्वारा डांटा गया।
**Romanized:** (Hamen hamare shikshakon ne danta tha.)
**English answer:** We were scolded by our teachers.

### 27. उसके पास एक पैन है।
**Romanized:** (Uske pass ek pen hai.)
**English answer:** He has a pen.

### 28. उसके पास किताबें हैं।
**Romanized:** (Uske pass kitaben hai.)
**English answer:** She has books.

### 29. मेरे पास कुछ है।
**Romanized:** (Mere pass kuch hai.)
**English answer:** I have something.

### 30. आपके पास पैसा है।
**Romanized:** (Apke pass paisa hai.)
**English answer:** You have money.

### 31. हमारे पास बहुत सारी किताबें हैं।
**Romanized:** (Hamare pass bahut sari kitaben hai.)
**English answer:** We have lots of books.

### 32. वह स्कूल गया (जा चुका) है।
**Romanized:** (Wah school gaya hai.)
**English answer:** He has gone to school.

### 33. वह वहाँ रह चुकी है।
**Romanized:** (Wah wahan rah chuki hai.)
**English answer:** She has lived there.

### 34. मैं उस लड़के के साथ खेल चुका हूँ।
**Romanized:** (Mai us ladke ke sath khel chukka hun.)
**English answer:** I have played with that boy.

### 35. तुम मेरी माँ से मिले (मिल चुके) हो।
**Romanized:** (Tum meri maa se mile ho.)
**English answer:** You have met my mom.

### 36. उसके अन्दर कुछ करने की क्षमता है।
**Romanized:** (Uske pass kuch karne ki kshamta hai.)
**English answer:** He has potential to do something.

### 37. मुझमें जोखिम उठाने का साहस है।
**Romanized:** (Mujhme jokhim uthane ka sahas hai.)
**English answer:** I have courage to take risk.

### 38. आपके पास एक बहादुर दिल है।
**Romanized:** (Apke pass ek bahadur dil hai.)
**English answer:** You have a brave heart.

### 39. उसके दो भाई हैं।
**Romanized:** (Uske do bhai hai.)
**English answer:** He has two brothers.

### 40. उसकी तीन बहनें हैं।
**Romanized:** (Uski teen bahne hain.)
**English answer:** She has three sisters.

### 41. मेरे दो चाचा हैं।
**Romanized:** (Mere do chacha hain.)
**English answer:** I have two uncles.

### 42. आपके दो दोस्त हैं।
**Romanized:** (Apke do dost hain.)
**English answer:** You have two friends.

### 43. मेरे पास एक पैन था।
**Romanized:** (Mere pass ek pen tha.)
**English answer:** I had a pen.

### 44. उसके पास किताबें थीं।
**Romanized:** (Uske pass kitaben thi.)
**English answer:** She had books.

### 45. मेरे पास कुछ था।
**Romanized:** (Mere pass kuch tha.)
**English answer:** I had something.

### 46. आपके पास पैसा था।
**Romanized:** (Apke pass paisa tha.)
**English answer:** You had money.

### 47. हमारे पास बहुत सारी किताबें थीं।
**Romanized:** (Hamare pass bahut sari kitaben thi.)
**English answer:** We had lots of books.

### 48. वो खेलने गया (जा चुका) था।
**Romanized:** (Wo khelne gaya (ja chuka) tha.)
**English answer:** He had gone to play.

### 49. वह वहाँ रह चुकी थी।
**Romanized:** (Wah wahan rah chuki hai.)
**English answer:** She had lived there.

### 50. मैं उस लड़के के साथ खेल चुका था।
**Romanized:** (Mai us ladke kai sath khel chukka tha.)
**English answer:** I had played with that boy.

### 51. तुम मेरी माँ से मिले (मिल चुके) थे।
**Romanized:** (Tum meri maa se mil chuke the.)
**English answer:** You had met my mom.

### 52. उनमें जीतने की तीव्र इच्छा थी।
**Romanized:** (Unme Jitene ki tivra ichha thi.)
**English answer:** They had a strong desire to win.

### 53. उसमें कुछ करने की क्षमता थी।
**Romanized:** (Unme kuch karne ki kshamta thi.)
**English answer:** He had potential to do something.

### 54. उसके दो भाई थे।
**Romanized:** (Uske do bhai the.)
**English answer:** He had two brothers.

### 55. हमारी चार बहनें थीं।
**Romanized:** (Ham char bahnen thi.)
**English answer:** We had four sisters.

### 56. वह स्कूल नहीं जाता है।
**Romanized:** (Wah school nahi jata hai.)
**English answer:** He does not go to school.

### 57. वह मेरे साथ नहीं बैठती।
**Romanized:** (Wah mere sath nahi baithti.)
**English answer:** She does not sit with me.

### 58. मैं उसके साथ नहीं खेलता।
**Romanized:** (Main uske sath nahi khelta.)
**English answer:** I do not play with him.

### 59. आप मुझे नहीं जानते हो।
**Romanized:** (Aap mujhe nahi jante.)
**English answer:** You do not know me.

### 60. हम आपसे नहीं मिलते।
**Romanized:** (Ham apse nahi milte.)
**English answer:** We do not meet you.

### 61. वो जाता है।
**Romanized:** (Wo jaata hai.)
**English answer:** He goes. / He does go. (ऽ र दे ते हए - Emphasized)

### 62. मैं जाता हूँ।
**Romanized:** (Main jaata hu.)
**English answer:** I go. / I do go. (ऽ र दे ते हए = Emphasized)

### 63. हम राहुल से रोज़ मिलते हैं।
**Romanized:** (Hum Rahul se roz milte hain.)
**English answer:** We meet Rahul every day. / We do meet Rahul every day. (ऽ र दे ते हए = Emphasized)

### 64. वह मेरे घर नहीं आया।
**Romanized:** (Wah mere ghar nahi aya.)
**English answer:** He did not come to my home.

### 65. वह मेरे साथ नहीं बैठी।
**Romanized:** (Wah mere sath nahi baithi.)
**English answer:** She did not sit with me.

### 66. राहुल आपसे नहीं मिला।
**Romanized:** (Rahul apse nahi mila.)
**English answer:** Rahul did not meet you.

### 67. मैंने आपको फोन नहीं किया।
**Romanized:** (Maine apko phone nahi kiya.)
**English answer:** I did not call you.

### 68. आप वहाँ नहीं गए।
**Romanized:** (Ap waha nahi gaye.)
**English answer:** You did not go there.

### 69. वह वहाँ गया।
**Romanized:** (Wo wahaan gaya.)
**English answer:** He went there. / He did go there. (ज र दे ते हए = Emphasized)

### 70. राहुल रश्मि से मिला।
**Romanized:** (Rahul Rashmi se mila.)
**English answer:** Rahul met Rashmi. / Rahul did meet Rashmi. (ज र दे ते हए = Emphasized)

### 71. वह खेलेगा।
**Romanized:** (Wah khelega.)
**English answer:** He will play.

### 72. मैं जाऊँगा।
**Romanized:** (Main jaunga.)
**English answer:** I will go.

### 73. हम आपसे मिलेंगे।
**Romanized:** (Ham apse milenge.)
**English answer:** We will meet you.

### 74. वे हमारे घर आयेंगे।
**Romanized:** (We mere ghar ayenge.)
**English answer:** They will come to our home.

### 75. क्या मुझे वहाँ जाना चाहिए?
**Romanized:** (Kya mujhe wahaan jana chahiye?)
**English answer:** Shall I go there?

### 76. क्या मुझे खेलना चाहिए?
**Romanized:** (Kya mujhe khelna chahiye?)
**English answer:** Shall I play?

### 77. क्या उसे आपसे मिलना चाहिए?
**Romanized:** (Kya use aapse milna chahiye?)
**English answer:** Shall he meet you?

### 78. क्या हमें आपको बताना चाहिए?
**Romanized:** (Kya hamein aapko batana chahiye?)
**English answer:** Shall we tell you?

### 79. क्या मैं जाऊँ?
**Romanized:** (Kya main jaaun?)
**English answer:** Shall I go? / Do I go?

### 80. क्या मैं आपसे मिलूँ?
**Romanized:** (Kya main jaaun?)
**English answer:** Shall I meet you? / Do I meet you?

### 81. क्या मैं आपके साथ बैदूँ?
**Romanized:** (Kya main aapke sath baithu?)
**English answer:** Shall I sit with you? / Do I sit with you?

### 82. क्या मैं उससे बात करूँ हू?
**Romanized:** (Kya main usse baat karun?)
**English answer:** Shall I talk to him? / Do I talk to him?

### 83. वह घर पर होगा।
**Romanized:** (Wah ghar par hoga.)
**English answer:** He will be at home.

### 84. वह रवीना के साथ होगा।
**Romanized:** (Wah raveena ke sath rahega.)
**English answer:** She will be with Raveena.

### 85. मैं घर पर होऊँगा।
**Romanized:** (Main ghar par hounga.)
**English answer:** I will be at home.

### 86. राहुल और अमन आदित्य के साथ होंगे गे।
**Romanized:** (Rahul aur Aman, Aditya ke sath honge.)
**English answer:** Rahul and Aman will be with Aditya.

### 87. वह शाम को खेल रहा होगा।
**Romanized:** (Wah shaam ko khel raha hoga.)
**English answer:** He will be playing in the evening.

### 88. मैं कल सुबह अमेरिका जा रहा होऊँगा।
**Romanized:** (Main kal subah America jaa raha hounga.)
**English answer:** I will be going to America tomorrow morning.

### 89. मेरे पास अगले साल एक कार होगी।
**Romanized:** (Mere pass agle saal ek car hogi.)
**English answer:** I will have a car next year.

### 90. इस साल दिसम्बर तक आपका अपना घर होगा।
**Romanized:** (Is saal december tak apka apna ghar hoga.)
**English answer:** You will have your own house by December this year.

### 91. उसे अगले साल नौकरी मिल चुकी होगी।
**Romanized:** (Use agle saal naukri mil chuki hogi.)
**English answer:** He will have got a job next year.

### 92. आप 2022 तक भारत के पीएम बन चुके होंगे गे।
**Romanized:** (Ap 2022 tak Bharat ke PM ban chuke honge.)
**English answer:** You will have become the PM of India by 2022.

### 93. उसे जाना चाहिए।
**Romanized:** (Use jana chahiye.)
**English answer:** He should go.

### 94. मुझे खेलना चाहिए।
**Romanized:** (Mujhe khelna chahiye.)
**English answer:** I should play.

### 95. हमें लड़ाई नहीं करनी चाहिए।
**Romanized:** (Hamen ladai nahi karrni chahiye.)
**English answer:** We should not fight.

### 96. उसे अवश्य जाना चाहिए।
**Romanized:** (Use avashya jana chahiye.)
**English answer:** He must go.

### 97. उसे अस्पताल ज़रूर जाना चाहिए।
**Romanized:** (Use aspatal zaroor jana chahiye.)
**English answer:** He must go to hospital.

### 98. हमें अपने राष्ट्र को सशक्त बनाना ही चाहिए।
**Romanized:** (Hamen apne rashtra ko sashakt banana hi chahiye.)
**English answer:** We must empower our nation.

### 99. हमें गरीबों की मदद ज़रूर करनी चाहिए।
**Romanized:** (Hamen garibon ki madad zaroor karni chahiye.)
**English answer:** We must help the poor.

### 100. उन्हें वहाँ ज़रूर जाना चाहिए।
**Romanized:** (Unhe waha zaroor jana chahiye.)
**English answer:** They must go there.

### 101. वह घर पर होना चाहिए।
**Romanized:** (Wah ghar par hona chahiye.)
**English answer:** He should be at home.

### 102. मुझे आपके साथ होना चाहिए।
**Romanized:** (Mujhe aapke sath hona chahiye.)
**English answer:** I should be with you.

### 103. आपको रवि के साथ होना चाहिए।
**Romanized:** (Aapko ravi ke sath hona chahiye.)
**English answer:** You should be with Ravi.

### 104. हमें अगले साल अमेरिका में होना चाहिए।
**Romanized:** (Hamein agle saal America me hona chahiye.)
**English answer:** We should be in America next year.

### 105. राहुल और अमन अभी स्कूल में होने चाहिए।
**Romanized:** (Rahul or Aman abhi school mai hone chahiye.)
**English answer:** Rahul and Aman should be in school right now.

### 106. उसके पास मोबाइल होना चाहिए।
**Romanized:** (Uske paas Mobile hona chahiye.)
**English answer:** He should have a mobile.

### 107. उसके पास किताबें होनी चाहिए।
**Romanized:** (Uske paas Kitabein honi chahiye.)
**English answer:** She should have books.

### 108. राहुल के पास पैसा होना चाहिए।
**Romanized:** (Rahul ke paas paisa hona chahiye.)
**English answer:** Rahul should have money.

### 109. मेरे पास कम से कम कुछ होना चाहिए।
**Romanized:** (Mere paas kam se kam kuch hona chahiye.)
**English answer:** I should have at least something.

### 110. हमारे पास कम से कम 5000 रूपए होने चाहिए।
**Romanized:** (Hamaare paas kam se kam 5000 rupay hone chahiye.)
**English answer:** We should have at least ₹5000.

### 111. मुझे चले जाना चाहिए था।
**Romanized:** (Mujhe chale jana chahiye tha.)
**English answer:** I should have gone.

### 112. उसे आना चाहिए था।
**Romanized:** (Use Aana Chahiye tha.)
**English answer:** He should have come.

### 113. उसे नाचना चाहिए था।
**Romanized:** (Use naachna chahiye tha.)
**English answer:** She should have danced.

### 114. हमें अपने राष्ट्र के लिए लड़ना चाहिए था।
**Romanized:** (Hame apne rashtra ke liye ladna chahiye.)
**English answer:** We should have fought for our nation.

### 115. राहुल और अमन को मेरे घर आना चाहिए था।
**Romanized:** (Rahul or Aman ko mere ghar aana chahiye tha.)
**English answer:** Rahul and Aman should have come my home.

### 116. मुझे स्कूल जाना है।
**Romanized:** (Mujhe school jaana hai.)
**English answer:** I am to go to school. / I have to go to school.

### 117. राहुल को आज मेरे घर आना है।
**Romanized:** (Rahul ko aaj mere ghar aana hai.)
**English answer:** Rahul is to come to my home today.

### 118. हमें आपसे मिलना है।
**Romanized:** (Hamen aapase milana hai.)
**English answer:** We are to meet you.

### 119. मुझे आपसे मिलना है।
**Romanized:** (Mujhe aapase milana hai.)
**English answer:** I am to meet you. / I am supposed to meet you.

### 120. आपको मेरे घर आना है।
**Romanized:** (Aapko mere ghar aana hai.)
**English answer:** You are to come to my home. / You are supposed to come to my home.

### 121. मुझे स्कूल नहीं जाना है।
**Romanized:** (Mujhe school nahi jaana hai.)
**English answer:** I am not to go to School. / I am not supposed to go to School.

### 122. क्या मुझे स्कूल जाना है?
**Romanized:** (Kya Mujhe school jaana hai?)
**English answer:** Am I to go to School? / Am I supposed to go to School?

### 123. मुझे स्कूल जाना है। {ज़रूरी}
**Romanized:** (Mujhe school jaana hai. {zaroor})
**English answer:** I have to go to School.

### 124. मुझे स्कूल जाना पड़ता है।
**Romanized:** (Mujhe school jana padta hai.)
**English answer:** I have to go to School.

### 125. मुझे उसे रोज़ कॉल करना है। {ज़रूरी}
**Romanized:** (Mujhe use roz call karna hai. {zaroor})
**English answer:** He has to call me every day.

### 126. मुझे उसे रोज़ कॉल करना पड़ता है।
**Romanized:** (Mujhe use roz call karna padata hai.)
**English answer:** He has to call me every day.

### 127. मुझे उसे रोज़ बुलाना पड़ता है।
**Romanized:** (Mujhe use roz bulaana padata hai.)
**English answer:** I have to call him every day.

### 128. उसे रोज़ स्कूल जाना पढ़ता है।
**Romanized:** (Use roz school jaana padata hai.)
**English answer:** She has to go to School every day.

### 129. मुझे वहाँ जाना पड़ता है।
**Romanized:** (Mujhe vahaan jaana padata hai.)
**English answer:** I have to go there. / I have got to go there.

### 130. राहुल को बाजार जाना है।
**Romanized:** (Rahul ko baazaar jaana hai.)
**English answer:** Rahul has (has got) to go to market.

### 131. मुझे स्कूल जाना था।
**Romanized:** (Mujhe school jaana tha.)
**English answer:** I was to go to school.

### 132. राहुल को आज मेरे घर आना था।
**Romanized:** (Rahul ko aaj mere ghar aana tha.)
**English answer:** Rahul was to (had to) come to my home today.

### 133. हमें आपसे मिलना था।
**Romanized:** (Hamein aapase milana tha.)
**English answer:** We were to (had to) meet you.

### 134. मुझे आपसे मिलना था।
**Romanized:** (Mujhe aapase milana tha.)
**English answer:** I was to meet you. / I was supposed to meet you. / I had to meet you.

### 135. आपको मेरे घर आना था।
**Romanized:** (Aapko mere ghar aana tha.)
**English answer:** You were to come to my home. / You were supposed to come to my home.

### 136. मुझे फल नहीं खरीदने थे।
**Romanized:** (Mujhe fruits nahi kharidne the.)
**English answer:** I was not to purchase the fruits. / I was not supposed to purchase the fruits.

### 137. क्या मुझे स्कूल जाना था?
**Romanized:** (Kya Mujhe school jaana tha?)
**English answer:** Was I to go to School? / Was I supposed to go to School?

### 138. मुझे स्कूल जाना था। {ज़रूरी}
**Romanized:** (Mujhe school jaana tha. {zaroori})
**English answer:** I had to go to School.

### 139. मुझे स्कूल जाना पड़ता था।
**Romanized:** (Mujhe school jana padta tha.)
**English answer:** I had to go to School.

### 140. मुझे स्कूल जाना पड़ा।
**Romanized:** (Mujhe school jana pada.)
**English answer:** I had to go to School.

### 141. मुझे उसे रोज़ कॉल करना था। {ज़रूरी}
**Romanized:** (Mujhe use roz call karna tha. {zaroori})
**English answer:** I had to call him every day.

### 142. मुझे उसे रोज़ कॉल करना पड़ता था।
**Romanized:** (Mujhe use roz call karna padata tha.)
**English answer:** I had to call him every day.

### 143. उसे रोज़ स्कूल जाना पड़ता था।
**Romanized:** (Use roz school jaana padata tha.)
**English answer:** She had to go to School every day.

### 144. मुझे वहाँ जाना पड़ता था।
**Romanized:** (Mujhe vahaan jaana padata tha.)
**English answer:** I had to go there. / I had got to go there.

### 145. राहुल को बाजार जाना था। {ज़रूरी}
**Romanized:** (Rahul ko baajaar jaana tha. {zaroori})
**English answer:** Rahul had (had got) to go to market.

### 146. अमित को उसके घर जाना पड़ा।
**Romanized:** (Amit ko uske ghar jana pada.)
**English answer:** Amit had (had got) to go to his house.

### 147. मुझे आपसे मिलना होगा/पड़ेगा।
**Romanized:** (Mujhe aapase milana hoga/padega.)
**English answer:** I will have to meet you.

### 148. हमें आपके घर आना होगा/पड़ेगा।
**Romanized:** (humein aapake ghar aana hoga/padega.)
**English answer:** We will have to come to your home.

### 149. उन्हें आपसे बात करनी होगी/पड़ेगी।
**Romanized:** (Unhein aapase baat karanee hogi/padegi.)
**English answer:** They will have to talk to you.

### 150. उसे मेरे साथ बैठना होगा/पड़ेगा।
**Romanized:** (Use mere saath baithana hoga/padega.)
**English answer:** He will have to sit with me.

### 151. उसे वहाँ नहीं जाना होगा/पड़ेगा।
**Romanized:** (Use vahaan nahin jaana hoga/padega.)
**English answer:** He will not have to go there.

### 152. क्या उसे वहाँ जाना होगा/पड़ेगा?
**Romanized:** (Kya use vahaan jaana hoga/padega?)
**English answer:** Will he have to go there?

### 153. मुझे आपसे मिलना होता/पड़ता।
**Romanized:** (Mujhe aapase milana hota/padta.)
**English answer:** I would have to meet you.

### 154. हमें आपके घर आना होता/पड़ता।
**Romanized:** (Humein aapake ghar aana hota/padta.)
**English answer:** We would have to come to your home.

### 155. उन्हें आपसे बात करनी पड़ती।
**Romanized:** (Unhein aap se baat karni padti.)
**English answer:** They would have to talk to you.

### 156. उसे मेरे साथ बैठना होता/पड़ता।
**Romanized:** (Use mere saath baithana hota/padta.)
**English answer:** He would have to sit with me.

### 157. उसे वहाँ नहीं जाना पड़ता।
**Romanized:** (Use vahaan nahin jaana padta.)
**English answer:** He would not have to go there.

### 158. क्या उसे वहाँ नहीं जाना पड़ता?
**Romanized:** (Kya use vahaan nahi jaana padta?)
**English answer:** Would he not have to go there?

### 159. उसे इस वक़्त स्कूल में ज़रूर होना चाहिए।
**Romanized:** (Use is waqt school me zaroor hona chahiye.)
**English answer:** She must be in school right now.

### 160. वो वहाँ ज़रूर होगा।
**Romanized:** (Vo vahaan zaroor hoga.)
**English answer:** He must be there.

### 161. हम उस दिन घर पर ज़रूर होंगे (रहेंगे)।
**Romanized:** (Hum us din ghar par zaroor honge (rahenge).)
**English answer:** We must be at home that day.

### 162. आप आजकल ऑफिस ज़रूर जाते होंगे गे।
**Romanized:** (Aap ajkal office zaroor jate honge.)
**English answer:** You must be going to office these days.

### 163. वो आपको रोज़ कॉल ज़रूर करता होगा।
**Romanized:** (Vo aapko roz call zaroor karta hoga.)
**English answer:** He must be calling you every day.

### 164. उसके पास कुछ न कुछ ज़रूर होना चाहिए।
**Romanized:** (Uske paas kuchh na kuchh zaroor hona chahiye.)
**English answer:** He must have something or the other.

### 165. उसके पास कार ज़रूर होनी चाहिए।
**Romanized:** (Uske paas car zaroor honi chahiye.)
**English answer:** He must have a car.

### 166. राहुल के पास कैलकुलेटर ज़रूर होगा।
**Romanized:** (Rahul ke paas calculator zaroor hoga.)
**English answer:** Rahul must have a calculator.

### 167. उन लड़कियों के पास किताबें ज़रूर होंगी।
**Romanized:** (Un ladkiyon ke paas kitabe zaroor hongi.)
**English answer:** Those girls must have books.

### 168. आपको अपने पापा से ज़रूर मिलना चाहिए था।
**Romanized:** (Aapko apne papa se zaroor milna chahiye tha.)
**English answer:** You must have met your father.

### 169. हमें आपके ऑफिस ज़रूर आना चाहिए था।
**Romanized:** (Humein aapke office zaroor aana chahiye tha.)
**English answer:** We must have come to your office.

### 170. वह पहाड़ पर चढ़ सकता है।
**Romanized:** (Vah pahaad par chadh sakata hai.)
**English answer:** He can climb the mountain.

### 171. आप मैच जीत सकते हैं।
**Romanized:** (Aap match jeet sakate hain.)
**English answer:** You can win the match.

### 172. मैं आसानी से परीक्षा पास कर सकता हूँ।
**Romanized:** (Main aasani se exam paas kar sakta hoon.)
**English answer:** I can pass the exam easily.

### 173. मैं एक घंटे तक लगातार दौड़ सकता हूँ।
**Romanized:** (Main ek ghante tak lagatar daud sakta hu.)
**English answer:** I can run continuously for an hour.

### 174. मैं 5 किलोमीटर तक लगातार दौड़ सकता हूँ।
**Romanized:** (Main 5 km tak lagatar daud sakta hu.)
**English answer:** I can run continuously for 5 kms.

### 175. क्या मैं विभाती से बात कर सकता हूँ?
**Romanized:** (Kya main vibhati se baat kar sakata hoon?)
**English answer:** Can I talk to Vibhati?

### 176. क्या मैं आपसे कल मिल सकता हूँ?
**Romanized:** (Kya main aapase kal mil sakata hoon?)
**English answer:** Can I meet you tomorrow?

### 177. हाँ, आप मिल सकते हैं।
**Romanized:** (Haan aap mil sakate ho.)
**English answer:** Yes, you can.

### 178. नहीं, आप नहीं मिल सकते।
**Romanized:** (Nahin, aap nahin mil sakate.)
**English answer:** No, you can’t.

### 179. यह लक्ष्य हासिल किया जा सकता है।
**Romanized:** (Yah lakshy haasil kiya ja sakata hai.)
**English answer:** This target can be achieved.

### 180. आपको देश के किसी भी शहर में भेजा जा सकता है।
**Romanized:** (Aapako desh ke kisee bhee shahar mein bheja ja sakata hai.)
**English answer:** You can be sent to any city of the country.

### 181. यह किया जा सकता है।
**Romanized:** (Yah kiya ja sakata hai.)
**English answer:** It can be done.

### 182. मेरे पास अगले साल कार हो सकती है।
**Romanized:** (Mere paas agale saal car ho sakatee hai.)
**English answer:** I can have a car next year.

### 183. जल्द ही आपके पास एक अच्छी नौकरी हो सकती है।
**Romanized:** (Jald hee aapake paas ek achchhee naukaree ho sakatee hai.)
**English answer:** You can have a good job soon.

### 184. अगर वह हर दिन जिम जाये तो उसके पास एक अच्छा व्यक्तित्व हो सकता है।
**Romanized:** (Agar vah har din gym jaaye to usake paas ek achchha vyaktitv ho sakata hai.)
**English answer:** He can have a good personality if he goes to gym every day.

### 185. वह पहाड़ पर चढ़ सकता था, क्योंकि उसके पास बहुत अच्छा अनुभव था।
**Romanized:** (Vah pahaad par chadh sakata tha, kyonki usake paas bahut achchha anubhav tha.)
**English answer:** He could climb the mountain, because he had a very good experience.

### 186. आप मैच जीत सकते थे, क्योंकि आपके पास बहुत अच्छे खिलाड़ी थे।
**Romanized:** (Aap match jeet sakate the, kyonki aapake paas bahut achchhe khilaadee the.)
**English answer:** You could win the match, because you had very good players.

### 187. जब मैं युवा था, तो मैं एक घंटे तक लगातार दौड़ सकता था।
**Romanized:** (Jab main yuva tha, to main ek ghante tak lagatar daud sakata tha.)
**English answer:** I could run continuously for an hour when I was young.

### 188. वह गेंद को जोर से मार सकती थी।
**Romanized:** (Vah gend ko jor se maar sakati thi.)
**English answer:** She could hit the ball hard.

### 189. मैं किसी तरह उससे मिल सका/पाया।
**Romanized:** (Main kisee tarah usase mil saka.)
**English answer:** I could somehow meet him.

### 190. मैं जा ना सका/पाया।
**Romanized:** (Main ja na saka.)
**English answer:** I could not go.

### 191. वह मुझे नहीं बुला सका/पाया।
**Romanized:** (Vah mujhe nahin bula saka.)
**English answer:** He could not call me.

### 192. क्या मैं विभाती से बात कर सकता हूँ?
**Romanized:** (Kya main Vibhati se baat kar sakata hoon?)
**English answer:** Could I talk to Vibhati?

### 193. क्या मैं आपसे कल मिल सकता हूँ?
**Romanized:** (Kya main aapase kal mil sakata hoon?)
**English answer:** Could I meet you tomorrow?

### 194. हाँ, आप मिल सकते हैं।
**Romanized:** (Haan aap mil sakate ho.)
**English answer:** Yes, you could.

### 195. नहीं, आप नहीं मिल सकते।
**Romanized:** (Nahin, aap nahin mil sakate.)
**English answer:** No, you couldn’t.

### 196. वह शाम को आपसे मिल सकता है।
**Romanized:** (Vah shaam ko aapase mil sakata hai.)
**English answer:** He could meet you in the evening.

### 197. आपके पिता आपको कभी भी कॉल कर सकते हैं।
**Romanized:** (Aapake pita aapako kabhee bhee call kar sakate hain.)
**English answer:** Your father could call you anytime.

### 198. कल बारिश हो सकती है।
**Romanized:** (kal baarish ho sakatee hai.)
**English answer:** It could rain tomorrow.

### 199. इस मुद्दे को हल किया जा सका।
**Romanized:** (Is mudde ko hal kiya ja saka.)
**English answer:** This issue could be resolved.

### 200. उसे अमेरिका नहीं भेजा जा सका।
**Romanized:** (Use America nahin bheja ja saka.)
**English answer:** He could not be sent to America.

### 201. उन्हें बचाया नहीं जा सका।
**Romanized:** (Unhein bachaaya nahin ja saka.)
**English answer:** They could not be saved.

### 202. इस सवाल को हल किया जा सकता था।
**Romanized:** (Is savaal ko hal kiya ja sakata tha.)
**English answer:** This question could be solved.

### 203. हमें किताबें दी जा सकती थीं।
**Romanized:** (Humein kitaaben dee ja sakatee theen.)
**English answer:** We could be given the books.

### 204. उन्हें पूछा जा सकता था।
**Romanized:** (Unhein poochha ja sakata tha.)
**English answer:** They could be asked for.

### 205. वह कहीं भी हो सकता है/था।
**Romanized:** (Vah kaheen bhee ho sakata hai/tha.)
**English answer:** He could be anywhere at all.

### 206. वो मोबाईल टूटा हुआ हो सकता है/था।
**Romanized:** (Vo mobile toota hua ho sakta tha.)
**English answer:** That mobile could be broken.

### 207. जब मैं जवान था तो मैं एक दिन में 5 किलोमीटर दौड़ सकता था।
**Romanized:** (Jab main jawan tha to main ek din mein 5 kilomeetar daud sakata tha.)
**English answer:** I could run 5 kms a day when I was young. {ABILITY}

### 208. जब मैं जवान था तब मैं जिम ज्वॉइन कर सकता था।
**Romanized:** (Jab main jawan tha, tab main gym join kar sakata tha.)
**English answer:** I could have joined a gym when I was young. {HYPOTHETICAL CASE}

### 209. मैं मौका चूक गया। मैं उस दिन उनके प्रस्ताव को स्वीकार कर सकता था।
**Romanized:** (Main mauka chook gaya. main us din unake prastaav ko sveekaar kar sakata tha.)
**English answer:** I missed a chance. I could have accepted his offer that day. {HYPOTHETICAL CASE}

### 210. रवि एमबीए में शामिल हो सकता था, लेकिन उसने मौका खो दिया।
**Romanized:** (Ravi MBA mein shaamil ho sakata tha, lekin usne mauka kho diya.)
**English answer:** Ravi could have joined MBA, but he just missed this opportunity. {HYPOTHETICAL CASE}

### 211. मैं स्नातक में अंग्रेज़ी ले सकता था।
**Romanized:** (Main snaatak mein angrejee le sakata tha.)
**English answer:** I could have taken English in graduation. {HYPOTHETICAL CASE}

### 212. वह वहाँ जाता था।
**Romanized:** (Vah vahaan jaata tha.)
**English answer:** He would go there.

### 213. वे साथ बैठकर चर्चा करते थे।
**Romanized:** (ve saath baithakar charcha karate the.)
**English answer:** They would sit together and discuss.

### 214. मैं सुबह 6 बजे उठता था। फिर, मैं सुबह की सैर के लिए जाता था। मैं 7 तक वापस आ जाता था।
**Romanized:** (Main subah 6 baje uthata tha. phir, main subah kee sair ke lie jaata tha. main 7 tak vaapas aa jaata tha.)
**English answer:** I would wake up at 6 in the morning. Then, I would go for a morning walk. I would come back by 7.

### 215. अगर मैं घर आता, तो आपको फोन करता।
**Romanized:** (Agar main ghar aata, to aapako phone karata.)
**English answer:** If I came home, I would call you.

### 216. अगर आप मुझे मौका देते तो मैं आपके साथ काम ज़रूर करता।
**Romanized:** (Agar aap mujhe mauka dete to main aapake saath kaam zaroor karta.)
**English answer:** I would definitely work with you if you gave me a chance.

### 217. यदि मैं आप होता तो मैं यह निर्णय नहीं लेता।
**Romanized:** (Yadi main aap hota to main yah nirnay nahin leta.)
**English answer:** If I were you, I wouldn’t take this decision.

### 218. मुझे पता था कि वो नहीं आएगा।
**Romanized:** (Mujhe pata tha ki vo nahin aaega.)
**English answer:** I knew that he would not come.

### 219. उसने मुझे पहले ही सूचित कर दिया था कि वह आज रात पार्टी में शामिल नहीं होगी।
**Romanized:** (Usane mujhe pahale hee soochit kar diya tha ki vah aaj raat party mein shaamil nahin hogee.)
**English answer:** She had informed me beforehand that she would not join the party tonight.

### 220. मैं आज अमेरिका में होता, लेकिन मैंने नौकरी छोड़ दी और अपने देश वापस आ गया।
**Romanized:** (Main aaj America mein hota, lekin mainne naukaree chhod dee aur apane desh vaapas aa gaya.)
**English answer:** I would be in America today, but I left the job and came back to my country.

### 221. आज आप मेरे सबसे अच्छे दोस्त होते, लेकिन आपने मुझे धोखा दिया।
**Romanized:** (Aaj aap mere sabase achchhe dost hote, lekin aapane mujhe dhokha diya.)
**English answer:** You would be my best friend today, but you cheated on me.

### 222. वह आज एक महान राजनीतितज्ञ होती।
**Romanized:** (Vah aaj ek mahaan raajaneetigy hotee.)
**English answer:** She would be a great politician today.

### 223. मैं कंपनी के उत्पादों को बेचने के लिए लोगों को कॉल कर रहा होता।
**Romanized:** (Main company ke utpaadon ko bechane ke lie logo ko call kar raha hota.)
**English answer:** I would be calling people to sell company’s products.

### 224. वह आपको बेवकूफ बना रही होती।
**Romanized:** (Vah aapako bevakooph bana rahee hoteee.)
**English answer:** She would be making you fool.

### 225. हम बिना किसी कारण के अपना समय बर्बाद कर रहे होते।
**Romanized:** (Hum bina kisee kaaran ke apana samay barbaad kar rahe hote.)
**English answer:** We would be just wasting our time for no reason.

### 226. धोनी अगला मैच खेल रहा होगा।
**Romanized:** (Dhoni agala match khel raha hoga.)
**English answer:** Dhoni will be playing the next match. {In future}

### 227. धोनी अभी खेल रहा होगा।
**Romanized:** (Dhoni abhee khel raha hoga.)
**English answer:** Dhoni would be playing right now. {At present}

### 228. वह आपको कल बेवकूफ बना रही होगी।
**Romanized:** (Vah aapako kal bevakooph bana rahee hogee.)
**English answer:** She will be making you fool. {In future}

### 229. वह आपको बेवकूफ बना रही होगी।
**Romanized:** (Vah aapako bevakooph bana rahee hogee.)
**English answer:** She would be making you fool. {At present}

### 230. वह आपको ढूंढ रही होगी।
**Romanized:** (Vah aapako dhoondh rahee hogee.)
**English answer:** She would be looking for you. {At present}

### 231. वे आपसे मिलने की योजना बना रहे होंगे गे।
**Romanized:** (Ve aapase milane kee yojana bana rahe honge.)
**English answer:** They would be planning to meet you. {At present}

### 232. रश्मि अभी सो रही होगी।
**Romanized:** (Rashmi abhee so rahee hogee.)
**English answer:** Rashmi would be sleeping right now. {At present}

### 233. कोहली कल तक खेल चुका होगा।
**Romanized:** (Kohli kal tak khel chuka hoga.)
**English answer:** Kohli will have played by now tomorrow. {In future}

### 234. कोहली अब तक खेल चुका होगा।
**Romanized:** (Kohli ab tak khel chuka hoga.)
**English answer:** Kohli would have played by now. {Action is already PAST}

### 235. ट्रेन अब तक निकल चुकी होगी।
**Romanized:** (Train ab tak nikal chukee hogee.)
**English answer:** The train would have left by now. {Action is already PAST}

### 236. मेरी बहन दिल्ली एयरपोर्ट पहुँच गई होगी।
**Romanized:** (Meree bahan Delhi airport pahunch gaee hogee.)
**English answer:** My sister would have reached Delhi airport. {Action is already PAST}

### 237. आज वर्षा हो सकती है।
**Romanized:** (Aaj varsha ho sakatee hai.)
**English answer:** It may rain today.

### 238. कल बारिश हो सकती थी।
**Romanized:** (Kal baarish ho sakati thee.)
**English answer:** It may rain yesterday.

### 239. कल बारिश हो सकती है।
**Romanized:** (Kal baarish ho sakatee hai.)
**English answer:** It may rain tomorrow.

### 240. वह आज ऑफिस आ सकता है।
**Romanized:** (Vah aaj office aa sakata hai.)
**English answer:** He may come to office today.

### 241. वह कल ऑफिस आ सकता है।
**Romanized:** (Vah kal office aa sakata hai.)
**English answer:** He may come to office yesterday.

### 242. वह शाम को आपसे मिल सकता है।
**Romanized:** (Vah shaam ko aapase mil sakata hai.)
**English answer:** He may meet you in the evening.

### 243. आपके पिता आपको कभी भी कॉल कर सकते हैं।
**Romanized:** (Aapake pita aapako kabhee bhee call kar sakate hain.)
**English answer:** Your father may call you anytime.

### 244. क्या मैं विभाती से बात कर सकता हूँ?
**Romanized:** (Kya main Vibhati se baat kar sakata hoon?)
**English answer:** May I talk to Vibhati?

### 245. क्या मैं आपसे कल मिल सकता हूँ?
**Romanized:** (Kya main aapase kal mil sakata hoon?)
**English answer:** May I meet you tomorrow?

### 246. हाँ, आप मिल सकते हैं।
**Romanized:** (Haan aap mil sakate ho.)
**English answer:** Yes, you may.

### 247. नहीं, आप नहीं मिल सकते।
**Romanized:** (Nahin, aap nahin mil sakate.)
**English answer:** No, you mayn’t.

### 248. भगवान करे आप जीवन में सफल हो जायें!
**Romanized:** (Bhagwan kare, aap jeevan mein saphal ho jaayein!)
**English answer:** May you succeed in life!

### 249. भगवान करे आप परीक्षा में पास हो जायें!
**Romanized:** (Bhagwan kare, aap pareeksha mein pass ho jaayein!)
**English answer:** May you pass the exam!

### 250. भगवान करे कि आप यह मैच जीतें!
**Romanized:** (Bhagwan kare ki aap yah match jeeten!)
**English answer:** May you win this match!

### 251. वह घर पर हो सकता है।
**Romanized:** (Vah ghar par ho sakata hai.)
**English answer:** He may/might be at home.

### 252. वे अभी पार्क में हो सकते हैं।
**Romanized:** (Ve abhee paark mein ho sakate hain.)
**English answer:** They may/might be at the park right now.

### 253. वे आज कक्षा में उपस्थित हो सकते हैं।
**Romanized:** (Ve aaj kaksha mein upasthit ho sakate hain.)
**English answer:** They may/might be present in the class today.

### 254. इसे हल किया जा सकता है।
**Romanized:** (Ise hal kiya ja sakata hai.)
**English answer:** It may/might be resolved.

### 255. हमें ठहरने का आदेश दिया जा सकता है।
**Romanized:** (Humein thaharane ka aadesh diya ja sakata hai.)
**English answer:** We may/might be ordered to stay.

### 256. उसे अमेरिका भेजा जा सकता है।
**Romanized:** (Use America bheja ja sakata hai.)
**English answer:** He may/might be sent to America.

### 257. शायद वह अभी घर जा रहा होगा।
**Romanized:** (Shayad vah abhee ghar ja raha hoga.)
**English answer:** He may/might be going home right now.

### 258. शायद वे उसका समर्थन कर रहे होंगे गे।
**Romanized:** (Shayad ve usaka samarthan kar rahe honge.)
**English answer:** They may/might be supporting him.

### 259. धोनी शायद अभी खेल रहा होगा।
**Romanized:** (Dhoni shayad abhee khel raha hoga.)
**English answer:** Dhoni may/might be playing right now.

### 260. वह शायद आपको बेवकूफ बना रही हो।
**Romanized:** (Vah shayad aapako bevakooph bana rahee ho.)
**English answer:** She may/might be making you fool.

### 261. वह शायद आपको ढूंढ रही होगी।
**Romanized:** (Vah shayad aapako dhoondh rahee hogee.)
**English answer:** She may/might be looking for you.

### 262. शायद वे आपसे मिलने की योजना बना रहे हों।
**Romanized:** (Shayad ve aapase milane kee yojana bana rahe hon.)
**English answer:** They may/might be planning to meet you.

### 263. हो सकता है, रश्मि अभी सो रही हो।
**Romanized:** (Ho sakta hai, Rashmi abhee so rahee h.)
**English answer:** Rashmi may/might be sleeping right now.

### 264. शायद वह ये कर चुका हो/होगा।
**Romanized:** (Shayad vo ye kar chuka ho/hoga.)
**English answer:** He may/might have done it.

### 265. अंजलि ने शायद इस सवाल को हल कर दिया हो/होगा।
**Romanized:** (Anjali ne shaayad is savaal ko hal kar diya ho/hoga.)
**English answer:** Anjali may/might have solved this question.

### 266. कोहली शायद अब तक खेल चुका होगा।
**Romanized:** (Kohli shaayad ab tak khel chuka hoga.)
**English answer:** Kohli may/might have played by now.

### 267. हो सकता है, ट्रेन अब तक निकल चुकी हो।
**Romanized:** (Ho sakta hai, train ab tak nikal chukee ho.)
**English answer:** The train may/might have left by now.

### 268. मेरी बहन शायद दिल्ली एयरपोर्ट पहुँच गई होगी।
**Romanized:** (Meree bahan shaayad Delhi airport pahunch gaee hogee.)
**English answer:** My sister may/might have reached Delhi airport.

### 269. आज मेरे पास अपना छाता होना चाहिए था क्योंकि बारिश तेज़ हो रही है।
**Romanized:** (Aaj mere paas apna chhaata hona chaahie tha kyonki baarish tez ho rahee hai.)
**English answer:** I should have had my umbrella today, as it’s raining heavily.

### 270. आपके पास अपना खुद का कैलकुलेटर होना चाहिए था।
**Romanized:** (Aapake paas apana khud ka calculator hona chaahie tha.)
**English answer:** You should have had your own calculator.

### 271. उसके पास लिखने के लिए पैन होना चाहिए था।
**Romanized:** (Uske pass likhane ke lie pen hona chaahie tha.)
**English answer:** He should have had a pen to write.

### 272. फिल्म के लिए निकलने से पहले उन्हें खाना खा लेना चाहिए था।
**Romanized:** (Film ke lie nikalane se pahale unhen khaana kha lena chaahie tha.)
**English answer:** They should have had the food before they left for the movie.

### 273. मुझे आज सुबह एक कप चाय पीनी चाहिए थी।
**Romanized:** (Mujhe aaj subah ek cup chaay peenee chaahie thee.)
**English answer:** I should have had a cup of tea in the morning today.

### 274. हमें सुबह का नाश्ता करना चाहिए था।
**Romanized:** (Humein subah ka naashta karana chaahie tha.)
**English answer:** We should have had breakfast in the morning.

### 275. इन गरीब बच्चों के पास आज़ादी के 70 साल बाद कम से कम पढ़ने के लिए किताबें तो होनी ही चाहिए थी।
**Romanized:** (In gareeb bachchon ke paas aazaadee ke 70 saal baad kam se kam padhane ke lie kitaaben to honi hi chaahie thi.)
**English answer:** These poor kids must have had at least books to read after 70 years of Independence.

### 276. इस तरह के ट्रिकी प्रश्न को हल करने के लिए आपके पास कोई न कोई ट्रिक तो होनी ही चाहिए।
**Romanized:** (Is tarah ke tricky prashn ko hal karane ke lie aapake paas koee na koee trick to honee hee chaahie thee.)
**English answer:** You must have had some or the trick to solve such a tricky question.

### 277. वीडियो रिकॉर्ड करने के लिए उसके पास कम से कम कैमरा तो होना ही चाहिए था।
**Romanized:** (Video record karane ke lie usake paas kam se kam camera to hona hi chaahie tha.)
**English answer:** He must have had at least a camera to record videos.

### 278. आपको डॉक्टर की सलाह के मुताबिक दवाइयाँ ज़रूर खानी चाहिए थी।
**Romanized:** (Apko doctor kee salaah ke mutaabik davaiyaan jaroor khanee chaahie thee.)
**English answer:** You must have had (taken) the medicines as per the doctor’s prescription.

### 279. आपको कुछ तो खा ही लेना चाहिए था। आपको तीन लैक्चर लगातार देने हैं।
**Romanized:** (Apko kuchh to kha hee lena chaahie tha. aapako teen lecture lagaataar dene hain.)
**English answer:** You must have had (eaten) something. You’ve to deliver three lectures back to back.

### 280. फिल्म के लिए निकलने से पहले उन्हें खाना ज़रूर खा लेना चाहिए था।
**Romanized:** (Film ke lie nikalane se pahale unhen khaana zaroor kha lena chaahie tha.)
**English answer:** They must have had the food before they left for the movie.

### 281. मुझे आज सुबह एक कप चाय ज़रूर पीनी चाहिए थी।
**Romanized:** (Mujhe aaj subah ek cup chaay zaroor peenee chaahie thee.)
**English answer:** I must have had a cup of tea in the morning today.

### 282. हमें सुबह का नाश्ता ज़रूर करना चाहिए था।
**Romanized:** (Humein subah ka naashta zaroor karana chaahie tha.)
**English answer:** We must have had breakfast in the morning.

### 283. उसके पास उनका सपोर्ट भी हो सकता है लेकिन उसने कभी उनके साथ अपने रिश्तों को नहीं बनाये रखा।
**Romanized:** (Uske paas unaka support bhee ho sakata hai lekin usane kabhee unake saath apane rishton ko nahin banaaye rakha.)
**English answer:** He may/might/could have had their support too but he never really maintained relations.

### 284. यदि उसने अपना निर्णय विवेकपूर्ण ढंग से लिया होता; मुझे यकीन है, आज उनके भारी जन समर्थन हो सकता था।
**Romanized:** (Yadi usane apana nirnay vivekapoorn dhang se liya hota; mujhe yakin hai, aaj unke pass bhaari jan samarthan ho sakta tha.)
**English answer:** If he had taken his decision judiciously; I’m sure, he could/may/might have had huge public support today.

### 285. हमारे पास आज हमारी अपनी मर्सिडीज हो सकती थी लेकिन हम में से किसी ने भी कभी कमाने पर ध्यान केंद्रित नहीं किया।
**Romanized:** (Humare paas aaj hamari apni Mercedes ho sakati thi lekin ham me se kisee ne bhi kbhi kamaane pr dhyan kendrit nahi kiya.)
**English answer:** We may/might/could have had our own Mercedes today but none of us really focussed at earning.

### 286. वो पहले खाना खा सकता था।
**Romanized:** (Wo pahle khana kha sakta tha.)
**English answer:** He may/might/could have had the food first.

### 287. आप चाय पी सकते थे।
**Romanized:** (Aap chai pee sakte the.)
**English answer:** You may/might/could have had the tea.

### 288. घर से निकलने से पहले वो एक कप कॉफी पी सकती थी।
**Romanized:** (Ghar se nikalane se pahale vo ek cup coffee pee sakatee thee.)
**English answer:** She could/may/might have had a cup of coffee before leaving home.

### 289. मेरे पास आज बाइक होती।
**Romanized:** (Mmere paas aaj bike hotee.)
**English answer:** I would have had a bike today.

### 290. आज उसके पास बहुत पैसा होता।
**Romanized:** (Aaj usake paas bahut paisa hota.)
**English answer:** She would have had lots of money today.

### 291. यदि आपने अंग्रेज़ी सीखने के लिए खुद को समर्पित किया होता, तो आज आपके पास एक अच्छी नौकरी होती।
**Romanized:** (Yadi aapane English seekhane ke lie khud ko samarpit kiya hota, to aaj aapake paas ek achchhee naukaree hotee.)
**English answer:** If you had devoted yourself to learn English, you would have had a good job today.

### 292. अगर मैंने उनकी सलाह मान ली होती तो मुझे उस पार्टी का समर्थन प्राप्त होता।
**Romanized:** (Aagar mainne unakee salaah maan lee hotee to mujhe us paartee ka samarthan praapt hota.)
**English answer:** I would have had that party’s support if I had followed their advice.

### 293. यदि धोनी ने टीम को प्रेरित नहीं किया होता तो आपके हाथ में यह पुरस्कार नहीं होता।
**Romanized:** (Yadi Dhoni ne teem ko prerit nahin kiya hota to aapke haath mein yah puraskaar nahin hota.)
**English answer:** You wouldn’t have had this award in your hand if Dhoni hadn’t motivated the team.

### 294. वह सुबह से फुटबॉल खेल रहा है।
**Romanized:** (Vah subah se football khel raha hai.)
**English answer:** He has been playing football since morning.

### 295. हम आपको कई दिनों से फोन कर रहे हैं।
**Romanized:** (Hum aapako kaee dinon se phon kar rahe hain.)
**English answer:** We have been calling you for many days.

### 296. मैं 2004 से दिल्ली में हूँ।
**Romanized:** (Main 2004 se Delhi mein hoon.)
**English answer:** I have been in Delhi since 2004.

### 297. वह लंबे समय से घर पर है।
**Romanized:** (Vah lambe samay se ghar par hai.)
**English answer:** He has been at home for a long.

### 298. वह बचपन से मेरा दोस्त है।
**Romanized:** (Vah bachapan se mera dost raha hai.)
**English answer:** He has been my friend since childhood.

### 299. उनसे पूछा जा चुका है।
**Romanized:** (Unse poochha ja chukka gaya hai.)
**English answer:** They have been asked.

### 300. उनसे पुलिस के द्वारा पूछा जा चुका है।
**Romanized:** (Unse police ke dwara poochha ja chukka gaya hai.)
**English answer:** They have been asked by the police.

### 301. हमें किताबें दी गई हैं।
**Romanized:** (Humein kitaaben dee gaee hain.)
**English answer:** We have been given the books.

### 302. हमें राहुल के द्वारा किताबें दी गयी हैं।
**Romanized:** (Humein Rahul ke dwara kitaaben di gayi hain.)
**English answer:** We have been given the books by Rahul.

### 303. यह फिल्म देखी जा चुकी है।
**Romanized:** (Yah film dekhee ja chukee hai.)
**English answer:** This movie has been seen.

### 304. वह सुबह से फुटबॉल खेल रहा था।
**Romanized:** (Vah subah se football khel raha tha.)
**English answer:** He had been playing football since morning.

### 305. हम आपको कई दिनों से फोन कर रहे थे।
**Romanized:** (Hum aapako kaee dinon se phon kar rahe the.)
**English answer:** We had been calling you for many days.

### 306. मैं 2004 से दिल्ली में था।
**Romanized:** (Main 2004 se Delhi mein tha.)
**English answer:** I had been in Delhi since 2004.

### 307. वह लंबे समय से घर पर था।
**Romanized:** (Vah lambe samay se ghar par tha.)
**English answer:** He had been at home for a long.

### 308. वह बचपन से मेरा दोस्त था।
**Romanized:** (Vah bachapan se mera dost tha.)
**English answer:** He had been my friend since childhood.

### 309. उनसे पूछा जा चुका था।
**Romanized:** (Unse poochha ja chukka gaya tha.)
**English answer:** They had been asked.

### 310. उनसे पुलिस के द्वारा पूछा जा चुका था।
**Romanized:** (Unse police ke dwara poochha ja chukka gaya tha.)
**English answer:** They had been asked by the police.

### 311. हमें किताबें दी गई थी।
**Romanized:** (Humein kitaaben dee gaee thi.)
**English answer:** We had been given the books.

### 312. हमें राहुल के द्वारा किताबें दी गयी थी।
**Romanized:** (Humein Rahul ke dwara kitaaben di gayi thi.)
**English answer:** We had been given the books by Rahul.

### 313. यह फिल्म देखी जा चुकी थी।
**Romanized:** (Yah film dekhee ja chukee thi.)
**English answer:** This movie had been seen.

### 314. उसे घर पर होना चाहिए था।
**Romanized:** (Use ghar par hona chaahie tha.)
**English answer:** He should have been at home.

### 315. हमें अभी जिम में होना चाहिए था।
**Romanized:** (Humein abhee gym mein hona chaahie tha.)
**English answer:** We should have been in the gym right now.

### 316. आपको अभी स्कूल में होना चाहिए था।
**Romanized:** (Apko abhee school mein hona chaahie tha.)
**English answer:** You should have been in school right now.

### 317. यह किया जाना चाहिए था।
**Romanized:** (Yah kiya jaana chaahie tha.)
**English answer:** It should have been done.

### 318. इस मोबाइल को रिपेयरिंग के लिए भेज दिया जाना चाहिए था।
**Romanized:** (Is mobile ko repairing ke lie bhej diya jaana chaahie tha.)
**English answer:** This mobile should been sent for repairing.

### 319. हमें घर वापस भेज दिया जाना चाहिए था।
**Romanized:** (Humein ghar vaapas bhej diya jaana chaahie tha.)
**English answer:** We should have been sent back home.

### 320. आपको ऐसे दुखद क्षण में अपने भाई के साथ ज़रूर होना चाहिए था।
**Romanized:** (Apko aise dukhad kshan mein apane bhaee ke saath zaroor hona chahie tha.)
**English answer:** You must have been with your brother in such a tragic moment.

### 321. उसे घर पर ज़रूर होना चाहिए था।
**Romanized:** (Use ghar par zaroor hona chaahie tha.)
**English answer:** He must have been at home.

### 322. हमें अभी जिम में ज़रूर होना चाहिए था।
**Romanized:** (Humein abhee gym mein zaroor hona chaahie tha.)
**English answer:** We must have been in the gym right now.

### 323. आपको इस वक्त स्कूल में ज़रूर होना चाहिए था।
**Romanized:** (Apko is waqt school mein zaroor hona chaahie tha.)
**English answer:** You must have been in school right now.

### 324. यह 1 बजे से पहले ज़रूर कर दिया जाना चाहिए था।
**Romanized:** (Yah 1 baje se pahale jaroor kar diya jaana chaahie tha.)
**English answer:** It must have been done before 1 PM.

### 325. उसके परिवार को पुलिस सुरक्षा ज़रूर दी जानी चाहिए थी।
**Romanized:** (Uske parivaar ko police suraksha zaroor dee jaanee chaahie thee.)
**English answer:** His family must have been given police protection.

### 326. वह आज मेरा एक अच्छा दोस्त हो सकता था लेकिन उसने हमेशा मुझे अपनी खातिर इस्तेमाल किया।
**Romanized:** (Vah aaj mera ek achchha dost ho sakata tha lekin usane hamesha mujhe apanee khaatir istemaal kiya.)
**English answer:** He could/may/might have been a good friend of mine today but he always used me for his sake.

### 327. अगर कोहली ने शतक नहीं लगाया होता तो आप दबाव में हो (आ) सकते थे।
**Romanized:** (Agar Kohli ne shatak nahin lagaaya hota to aap dabaav mein ho(aa) sakate the.)
**English answer:** You could/may/might have been under pressure if Kohli hadn’t hit the century.

### 328. वो आपके घर पर हो सकता था।
**Romanized:** (Wo aapke ghar par ho sakta tha.)
**English answer:** He could/may/might have been at your home.

### 329. उसे बाजार भेजा जा सकता था।
**Romanized:** (Use baajaar bheja ja sakata tha.)
**English answer:** He could/may/might have been sent to market.

### 330. हमसे ये सभी सवाल पूछे जा सकते थे।
**Romanized:** (Humse ye sabhee savaal poochhe ja sakate the.)
**English answer:** We could/may/might have been asked all these questions.

### 331. उन्हें कहीं भी देखा जा सकता था।
**Romanized:** (Unhe kaheen bhee dekha ja sakata tha.)
**English answer:** They could/may/might have been seen anywhere.

### 332. अगर आपने उसे पहले से सूचना दे दी होती, तो वह घर पर होता।
**Romanized:** (Aagar aapane use pahale se soochana de dee hotee, to vah ghar par hota.)
**English answer:** If you had informed him beforehand, he would have been at home.

### 333. अगर आप कल ही मेरे पैसे वापस कर देते तो मैं और अधिक संतुष्ट होता।
**Romanized:** (Aagar aap kal hee mere paise vaapas kar dete to main aur adhik santusht hota.)
**English answer:** I would have been more satisfied if you had returned my money yesterday itself.

### 334. अगर मैंने स्कूल में अच्छी पढ़ाई की होती, तो मैं आज इंजीनियर, शिक्षक या डॉक्टर होता।
**Romanized:** (Agar mainne school mein achchhee padhaee kee hotee, to main aaj engineer, shikshak ya doctor hota.)
**English answer:** If I had studied well in school, I would have been an engineer, a teacher or a doctor today.

### 335. वे अब तक पकड़े जा चुके होते।
**Romanized:** (Ve ab tak pakade ja chuke hote.)
**English answer:** They would have been caught by now.

### 336. दोषियों को अब तक सलाखों के पीछे भेज दिया गया होता।
**Romanized:** (Doshiyon ko ab tak salaakhon ke peechhe bhej diya gaya hota.)
**English answer:** The culprits would have been sent behind the bars by now.

### 337. यदि हमने अनुरोध किया होता, तो हमें सभी महत्वपूर्ण दस्तावेज उपलब्ध कराए जा चुके होते।
**Romanized:** (Yadi hamane anurodh kiya hota, to hamen sabhee mahatvapoorn dastaavej upalabdh karae jaa chuke hote.)
**English answer:** If we had requested, we would have been provided all the important documents.

### 338. आपके पास किताबें होनी चाहिए थी।
**Romanized:** (Apke paas kitaaben honee chaahie thee.)
**English answer:** You should have had books.

### 339. मेरे पास आज बाइक होती।
**Romanized:** (Mere paas aaj bike hotee.)
**English answer:** I would have had a bike today.

### 340. वो लोग अब तक पकड़े जा चुके होते।
**Romanized:** (Vo log ab tak pakade ja chuke hote.)
**English answer:** Those people would have been caught by now.

### 341. उसे घर से 5 किलोमीटर दूर जाना पड़ता था।
**Romanized:** (Use ghar se 5 kilomeetar door jaana padata tha.)
**English answer:** He had to go 5 kilometers away from home.

### 342. हमें शाम को आपसे मिलना पड़ेगा।
**Romanized:** (Humein shaam ko aapase milana padega.)
**English answer:** We will have to see you in the evening.

### 343. शायद रवि अब तक निकल चुका हो/होगा।
**Romanized:** (Shayad Ravi ab tak nikal chuka ho/hoga.)
**English answer:** Ravi may/might have left by now.

### 344. वो आज सुबह आपसे मिलता।
**Romanized:** (Vo aaj subah aapase milata.)
**English answer:** He would meet you this morning.

### 345. अमन मेरे साथ 2007 से है.
**Romanized:** (Aman mere saath 2007 se hai.)
**English answer:** Aman has been with me since 2007.

### 346. उसे घर पर होना चाहिए था।
**Romanized:** (Use ghar par hona chaahie tha.)
**English answer:** He should have been at home.

### 347. हम इस वक्त खेल रहे होते।
**Romanized:** (Hum is vakt khel rahe hote.)
**English answer:** We would be playing right now.

### 348. उसे आज कहीं जाना है।
**Romanized:** (Use aaj kaheen jaana hai.)
**English answer:** He is to go somewhere today. / He has to go somewhere today. (Compulsion)

### 349. आप आजकल ऑफिस ज़रूर जाते होंगे गे?
**Romanized:** (Aap aajakal office zaroor jaate honge?)
**English answer:** You must be going to office nowadays?

### 350. क्या मैं आपके साथ बैठ कर पहढूँ?
**Romanized:** (Kya main aapake saath baith kar padhoon?)
**English answer:** Shall I sit with you and study? / Do I sit with you and study? / Can I sit with you and study?

### 351. वो अक्सर मुझे बताया करता था।
**Romanized:** (Vo aksar mujhe bataaya karata tha.)
**English answer:** He would often tell me. / He used to often tell me.

### 352. वो बच्चा कहीं भी हो सकता है।
**Romanized:** (Vo bachcha kaheen bhee ho sakata hai.)
**English answer:** That child can/could/may/might be anywhere.

### 353. अगले साल उसके पास कार हो सकती है क्योंकि उसकी सैलरी अच्छी है।
**Romanized:** (Agle saal usake paas car ho sakatee hai kyonki uski salary achchhi hai.)
**English answer:** He can have a car next year because his salary is good.

### 354. रश्मि इस वक्त सो रही होगी।
**Romanized:** (Rashmi is vakt so rahee hogee.)
**English answer:** Rashmi would be sleeping at this time.

### 355. उन्हें दोषी ठहराया जाता है।
**Romanized:** (Unhein doshi thahraya jata hai.)
**English answer:** They are blamed.

### 356. हमें किताबें दी गई हैं।
**Romanized:** (Humein kitaaben dee gaee hain.)
**English answer:** We have been given the books.

### 357. हमसे ये सभी सवाल पूछे जा सकते थे।
**Romanized:** (Humse ye sabhee savaal poochhe ja sakate the.)
**English answer:** We could/may/might have been asked all these questions.

### 358. मैं अब तक निकल चुका होता।
**Romanized:** (Main ab tak nikal chuka hota.)
**English answer:** I would have left by now.

### 359. उसे वहाँ होना चाहिए था।
**Romanized:** (Use vahaan hona chaahie tha.)
**English answer:** He should have been there.

### 360. मेरे पास पैन होना चाहिए।
**Romanized:** (Mere paas pen hona chaahie.)
**English answer:** I should have a pen.

### 361. मेरे पास पैन होना चाहिए था।
**Romanized:** (Mere paas pen hona chaahie thaa.)
**English answer:** I should have had a pen.

### 362. मेरे पास पैन होना ही चाहिए।
**Romanized:** (Mere paas pen hona hi chaahie.)
**English answer:** I must have a pen.

### 363. मेरे पास पैन होना ही चाहिए था।
**Romanized:** (Mere paas pen hona hi chaahie thaa.)
**English answer:** I must have had a pen.

### 364. कल सुबह वो स्कूल जा रही होगी।
**Romanized:** (Kal subah Vo school ja rahee hogi.)
**English answer:** She will be going to school tomorrow morning.

### 365. वो स्कूल जा रही होगी।
**Romanized:** (Vo school ja rahee hogi.)
**English answer:** She would be going to school.

### 366. वो पक्का स्कूल जा रही होगी।
**Romanized:** (Vo pakka school ja rahee hogi.)
**English answer:** She must be going to school.

### 367. वो शायद स्कूल जा रही होगी।
**Romanized:** (Vo shayad school ja rahee hogi.)
**English answer:** She may be going to school. / She might be going to school.

### 368. हमें सोचना पड़ता है।
**Romanized:** (Humein sochana padata hai.)
**English answer:** We have to think.

### 369. हमें सोचना पड़ता था।
**Romanized:** (Humein sochana padata tha.)
**English answer:** We had to think.

### 370. हमें सोचना पड़ा।
**Romanized:** (Humein sochana pada.)
**English answer:** We had to think.

### 371. हमें सोचना पड़ेगा।
**Romanized:** (Humein sochana padega.)
**English answer:** We will have to think.

### 372. हमें सोचना पड़ सकता है।
**Romanized:** (Humein sochana pad sakata hai.)
**English answer:** We may have to think.

### 373. आपको घर आना पड़ सकता है।
**Romanized:** (Apko ghar aana pad sakata hai.)
**English answer:** You may have to come home.

### 374. आपको खेलना चाहिए था।
**Romanized:** (Apko khelana chaahie tha.)
**English answer:** You should have played.

### 375. वो घर नहीं आ पायेगा।
**Romanized:** (Vo ghar nahi aa payega.)
**English answer:** He will not be able to come home.

### 376. मैं समझ नहीं पाया।
**Romanized:** (Main samajh nahin paaya.)
**English answer:** I could not understand.

### 377. मैं समझ नहीं पाता हूँ।
**Romanized:** (Main samajh nahin pata hu.)
**English answer:** I am not able to understand.

### 378. मैं समझ नहीं पाता था।
**Romanized:** (Main samajh nahin pata tha.)
**English answer:** I was not able to understand.

### 379. वो कहीं भी हो सकता है।
**Romanized:** (Vo kaheen bhee ho sakata hai.)
**English answer:** He can/could/may/might be anywhere.

### 380. अगर आपने अच्छे से पढ़ाई की होती, तो आज आप एक इंजीनियर होते।
**Romanized:** (Agar aapane achchhe se padhaee kee hotee, to aaj aap ek engineer hote.)
**English answer:** If you had studied diligently, you would have been an engineer today.

### 381. आप आजकल ऑफिस ज़रूर जाते होंगे गे।
**Romanized:** (Aap aajakal office jaroor jaate honge.)
**English answer:** You must be going to office nowadays.

### 382. आपको वहाँ नहीं जाना पड़ता।
**Romanized:** (Aapko vahaan nahin jaana padta.)
**English answer:** You would not have to go there.

### 383. आपके पापा आजकल ऑफिस ज़रूर जाते होंगे गे।
**Romanized:** (Aapke papa aajakal office zaroor jaate honge.)
**English answer:** Your father must be going to office these days.

### 384. मुझे आज ऑफिस जाना पड़ सकता है।
**Romanized:** (Mujhe aaj office jana pad sakta hai.)
**English answer:** I may have to go to office today. / I might have to go to office today. / I could have to go to office today.

### 385. काश मेरा मोबाइल उस वक्त स्विच ऑफ हो जाता।
**Romanized:** (Kaash mera mobile us vakt switch off ho jaata.)
**English answer:** I wish my mobile would have been switched off at that moment. / Would that my mobile would have been switched off at that moment.

### 386. मुझे उसे रोज़ाना कॉल करना पड़ता था।
**Romanized:** (Mujhe use rozana call karna padata tha.)
**English answer:** I had to call him every day.

### 387. क्या मैं इस बारे में उससे बात करूँ?
**Romanized:** (Kya main is baare me usse baat karun?)
**English answer:** Shall/Do I talk to (speak with) him about it?

### 388. आपने मुझे बोलने नहीं दिया।
**Romanized:** (Aapne mujhe bolne nahi diya.)
**English answer:** You didn’t let me speak.

### 389. उसने मुझे वहाँ बिठा दिया।
**Romanized:** (Usne mujhe vahaan bitha diya.)
**English answer:** He made me sit there.

### 390. आज उसके पास बहुत कुछ हो सकता था।
**Romanized:** (Aaj uske paas bahut kuchh ho sakta tha.)
**English answer:** He may have had a lot today. / He might have had a lot today. / He could have had a lot today.

### 391. हमें बस एक मोबाइल दे दिया गया।
**Romanized:** (Hume bas ek mobile de diya gaya.)
**English answer:** We were just given a mobile.

## Source-text notes

- Devanagari OCR was checked against the scanned prompt pages. Internal Hindi alternatives, braces, long wrapped lines, and legible numerals were restored where row OCR had truncated or misread them. No text was identified as unreadable.
- Obvious Romanized typos were corrected at item 10 (“Partadit” → “prataadit”) and item 34 (“kai” → “ke”). The source Romanized line at item 145 had an extra closing parenthesis; the paired line is normalized to one balanced outer pair.
- The source Romanized line adds “tha” at items 23 and 25 although it is absent from the corresponding Hindi prompts; item 26 uses “ne danta tha” where the Hindi says “ke dwara danta gaya”; item 36 says “pass” where the Hindi says “अन्दर”; and items 32 and 35 omit the parenthetical Hindi alternatives in their Romanized lines. These source differences are preserved rather than inferred or rewritten.

**Unreadable text:** none identified.

