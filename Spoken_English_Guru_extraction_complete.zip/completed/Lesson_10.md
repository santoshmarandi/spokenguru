# Lesson 10 — All Tenses in English

**PDF pages:** 87–116 (printed pages 86–115)

**Instruction:** Translate the following sentences into English.

## Bilingual prompts and printed English answers

### 1. मैं नहीं गया।
**Romanized:** (Main nahi gaya.)
**English answer:** I didn’t go.

### 2. तुम कहाँ जाते हो?
**Romanized:** (Tum kaha jaate ho?)
**English answer:** Where do you go?

### 3. हम किस तरह आयेंगे?
**Romanized:** (Hum kis tarah aayenge?)
**English answer:** How will we come?

### 4. मैं कब तक तुम्हारा साथ दूँगा?
**Romanized:** (Main kab tak tumhara saath doonga?)
**English answer:** How long will I support you? / How long will I stand by you?

### 5. रोहित की बहन कहाँ जा रही है?
**Romanized:** (Rohit ki behan kaha ja rahi hai?)
**English answer:** Where is Rohit’s sister going?

### 6. वो किस शहर से आया था?
**Romanized:** (Vo kis shahar se aaya tha?)
**English answer:** From which city had he come?

### 7. राम खेलता है।
**Romanized:** (Ram khelta hai.)
**English answer:** Ram plays.

### 8. वो लड़का ऐसा क्यों सोचता है?
**Romanized:** (Vo ladka aisa kyon sochta hai?)
**English answer:** Why does that boy think so?

### 9. ये बच्चे कहाँ रहते हैं?
**Romanized:** (Ye bache kaha rahte hai?)
**English answer:** Where do these children live?

### 10. लड़कियाँ कल से डांस का अभ्यास कर रही हैं।
**Romanized:** (Ladkiyaan kal se dance ka abhiyas kar rahi hai.)
**English answer:** Girls have been practicing dance since yesterday.

### 11. राकेश नहीं समझता।
**Romanized:** (Rakesh nahi samajhta.)
**English answer:** Rakesh doesn’t understand.

### 12. घाव से खून निकल रहा है।
**Romanized:** (Ghav se khoon nikal raha hai.)
**English answer:** Blood is oozing from the wound.

### 13. मैं पढूँगा।
**Romanized:** (Main padhoonga.)
**English answer:** I will study.

### 14. वो सभी किसके भाई हैं?
**Romanized:** (Vo sabhi kiske bhai hai?)
**English answer:** Whose brothers are they/those all?

### 15. वो खिड़की से झाँक रहा था।
**Romanized:** (Vo khidkee se jhaank raha tha.)
**English answer:** He was peeping through the window.

### 16. बच्चे आ रहे होंगे।
**Romanized:** (Bachche aa rahe honge.)
**English answer:** Children/kids will be coming.

### 17. मैं शिमला अक्सर जाता हूँ।
**Romanized:** (Main Shimla aksar jata hoon.)
**English answer:** I often go to Shimla.

### 18. वो खूब पढ़ता है।
**Romanized:** (Vo khoob padhta hai.)
**English answer:** He studies a lot.

### 19. वो कभी-कभी मेरे घर आता है।
**Romanized:** (Vo kabhi-kabhi mere ghar aata hai.)
**English answer:** He sometimes comes my home.

### 20. बस चली गई होगी।
**Romanized:** (Bus chali gai hogi.)
**English answer:** Bus would have left.

### 21. तुम कब तक यहाँ ठहरोगे?
**Romanized:** (Tum kab tak yaha thahroge?)
**English answer:** For how long will you stay here?

### 22. माँ अपने बच्चे को दूध पिला रही होगी।
**Romanized:** (Ma apne bachche ko doodh pila rahi hogi.)
**English answer:** The mother will be feeding her child.

### 23. हम बहुत देर तक सोते हैं।
**Romanized:** (Hum bahut der tak sote hai.)
**English answer:** We sleep till late.

### 24. वो घर से नहीं आया है।
**Romanized:** (Vo ghar se nahi aaya hai.)
**English answer:** He has not come from home.

### 25. वो अपने सपनों को साकार करेगा।
**Romanized:** (Vo apne sapno ko saakaar karega.)
**English answer:** He will fulfill his dreams. / He will materialize his dreams.

### 26. मैं किसके बारे में सोचता हूँ?
**Romanized:** (Main kiske bare mein sochta hoon?)
**English answer:** Whom do I think about?

### 27. मैं और तुम किसके साथ खेल रहे थे?
**Romanized:** (Main aur tum kiske saath khel rahe the?)
**English answer:** With whom were I & you playing?

### 28. हम वहाँ गये थे।
**Romanized:** (Hum vaha gaye the.)
**English answer:** We had gone there.

### 29. मेरा दोस्त कौन सी कार चला रहा है?
**Romanized:** (Mera dost kaun si car chala raha hai?)
**English answer:** Which car is my friend driving?

### 30. उसने उस आदमी को जान से मार दिया।
**Romanized:** (Usne us admi ko jaan se maar diya.)
**English answer:** He killed that man.

### 31. लड़के के परिवार वालों ने उस पर आरोप लगाया है।
**Romanized:** (ladki ke parivaar valon ne us par aarop lagaya hai.)
**English answer:** The boy’s family has blamed her.

### 32. मेरे साथ कई फिल्म देख रहे थे।
**Romanized:** (Mere saath kai film dekh rahe the.)
**English answer:** There were many, watching movie with me.

### 33. हमने टी.वी. में किसकी लड़ाई देखी?
**Romanized:** (Humne TV mein kiski ladai dekhi?)
**English answer:** Whose fight did we watch on TV?

### 34. हम राम को बिल्कुल नहीं जानते।
**Romanized:** (Hum Ram ko bilkul nahi jante.)
**English answer:** We don’t know Ram at all. / We have no idea who Ram is.

### 35. ये टूटा हुआ दिल कुछ कह रहा है।
**Romanized:** (Ye toota hua dil kuch keh raha hai.)
**English answer:** This broken heart is saying something.

### 36. क्या वो स्कूल से आ गया होगा?
**Romanized:** (Kya vo school se aa gaya hoga?)
**English answer:** Would he have come from school?

### 37. तुम बहुत तेज़ दौड़ रहे थे।
**Romanized:** (Tum bahut tez daud rahe the.)
**English answer:** You were running very fast.

### 38. कौन जायेगा?
**Romanized:** (Kaun jaayega?)
**English answer:** Who will go?

### 39. किस हीरो का दोस्त तुम्हारे पापा के साथ जॉब करता है?
**Romanized:** (Kis hero ka dost tumhare papa ke saath job karta hai?)
**English answer:** Which actor’s friend works with your dad?

### 40. मैं अक्सर उसके घर जाता हूँ।
**Romanized:** (Main aksar uske ghar jata hoon.)
**English answer:** I often go to his home.

### 41. सीमा आये दिन तुम्हें होमवर्क लिखने के लिए बुलाती है।
**Romanized:** (Seema aaye din tumhe homework likhne ke liye bulati hai.)
**English answer:** Seema often calls you to write homework.

### 42. बच्चे सुबह से TV देख रहे हैं।
**Romanized:** (Bachche subah se TV dekh rahe hai.)
**English answer:** Kids have been watching TV since morning.

### 43. उसे किस पार्टी का साथ नहीं मिल रहा है?
**Romanized:** (Use kis party ka saath nahi mil raha hai ?)
**English answer:** Which party’s support is he not getting? / Which party is not supporting him?

### 44. वो मोबाइल से क्या देख रहा है?
**Romanized:** (Vo mobile se kya dekh raha hai?)
**English answer:** What is he watching on Mobile?

### 45. मैं किस लड़की का भाई हूँ?
**Romanized:** (Main kis ladki ka bhai hoon?)
**English answer:** Which girl’s brother am I?

### 46. उसके पापा ने मुझसे बात करना पसंद क्यों नहीं किया?
**Romanized:** (Uske papa ne mujhse baat karna pasand kyon nahi kiya?)
**English answer:** Why did his father not prefer/like to talk to me?

### 47. राम मुश्किल से ही कभी मेरे घर आता है।
**Romanized:** (Ram mushkil se hi kbhi mere ghar aata h.)
**English answer:** Ram hardly comes my home.

### 48. क्या ये बातें याद आयेंगी तुम्हें?
**Romanized:** (Kya ye batein yaad aayengi tumhein?)
**English answer:** Will you remember these words?

### 49. हम सभी लोग उस नेता को पसंद नहीं करते।
**Romanized:** (Hum sabhi log us neta ko pasand ni krte)
**English answer:** We all people don’t like that leader.

### 50. मेरे भाई ने किसी लड़की को परेशान नहीं किया।
**Romanized:** (Mere bhai ne kisi ladki ko pareshan nahi kiya.)
**English answer:** My brother didn’t bother any girl.

### 51. उसने देखने की कोशिश नहीं की।
**Romanized:** (Usne dekhne ki koshish nahi ki.)
**English answer:** He didn’t try to see.

### 52. वो अधिकतर सीता के साथ खेलता है।
**Romanized:** (Vo adhiktar Seeta ke saath khelta hai.)
**English answer:** He mostly plays with Seeta.

### 53. उसने मेरे लिए कभी कुछ किया?
**Romanized:** (Usne mere liye kabhi kuch kiya?)
**English answer:** Did he ever do anything for me?

### 54. उसने कुछ नहीं किया।
**Romanized:** (Usne kuch nahi kiya.)
**English answer:** He did nothing. / He didn’t do anything.

### 55. हम तुम्हारे साथ घूमने जायेंगे।
**Romanized:** (Hum tumhare saath ghoomne jayenge.)
**English answer:** We will go for a walk with you. / We will take a stroll with you.

### 56. राम उसे बहुत प्यार करता है।
**Romanized:** (Ram use bahut pyar karta hai.)
**English answer:** Ram loves him/her a lot.

### 57. तुमने मेरा दिल दुखाया है।
**Romanized:** (Tumne mera dil dukhaya hai.)
**English answer:** You have hurt me. / You have broken my heart.

### 58. आँखें धोखा देती हैं।
**Romanized:** (Aankhen dhokha deti hai.)
**English answer:** Eyes are deceptive.

### 59. क्या तुमने सभी को खाना परोस दिया है?
**Romanized:** (Kya tumne sabhi ko khana paros diya hai?)
**English answer:** Have you served the food to all?

### 60. किसने तुम्हें देखा था?
**Romanized:** (Kisne tumhen dekha tha?)
**English answer:** Who had seen you?

### 61. ये दिल कभी-कभी प्यार के लिए तड़पता है।
**Romanized:** (Ye dil kabhi-2 pyar ke liye tadapta h.)
**English answer:** This heart sometimes craves for love.

### 62. मैंने भगवान से कुछ माँगा है।
**Romanized:** (Maine bhagvaan se kuch manga hai.)
**English answer:** I have begged something from God.

### 63. उसने गलती की है।
**Romanized:** (Usne galti ki hai.)
**English answer:** He has committed / made a mistake.

### 64. हमारी आँखें उसे देख रही थी।
**Romanized:** (Hamari aankhen use dekh rahi thi.)
**English answer:** Our eyes were searching him.

### 65. तुम्हें चोट किसने पहुँचाई?
**Romanized:** (Tumhein chot kisne pahunchai?)
**English answer:** Who hurt you?

### 66. मैंने ऐसा कभी नहीं सोचा।
**Romanized:** (Maine aisa kabhi nahi socha.)
**English answer:** I never thought so.

### 67. राम ने मुझे मेरी जीत पर बधाई दी है।
**Romanized:** (Ram ne mujhe meri jeet par badhai di hai.)
**English answer:** Ram has congratulated me on my victory.

### 68. दुकानदार ने मुझे लूट लिया।
**Romanized:** (Dukandaar ne mujhe loot liya.)
**English answer:** Shopkeeper ripped me off.

### 69. क्या तुम मुझे याद दिलाओगे?
**Romanized:** (Kya tum mujhe yaad dilaoge?)
**English answer:** Will you remind me?

### 70. बुरे दौर में तुम्हारा साथ किसने दिया?
**Romanized:** (Bure daur mein tumhara saath kisne diya?)
**English answer:** Who supported you in bad time? / Who stood by you in bad phase?

### 71. माँ बदले में कुछ नहीं माँगती।
**Romanized:** (Maa badle mein kuch nahi mangatee.)
**English answer:** Mother demands nothing in return.

### 72. हम 2:00 बजे पार्क में घूम रहे थे।
**Romanized:** (Hum 2:00 baje park mein ghoom rahe the.)
**English answer:** We were walking in the park at 2 o’clock.

### 73. वो किसके लिए इतनी दूर गया?
**Romanized:** (Vo kiske liye itni door gaya?)
**English answer:** For whom did he go this far?

### 74. तुम्हारा चेहरा मुझे किसी की याद दिलाता है।
**Romanized:** (Tumhara chehra mujhe kisi ki yad dilata h.)
**English answer:** Your face reminds me of someone.

### 75. ये कौन करता है?
**Romanized:** (Ye kaun karta hai?)
**English answer:** Who does it?

### 76. ये साँप सदियों से अपनी साथी की तलाश कर रहा है।
**Romanized:** (Ye saap sadiyon se apne saathi ki talash kar raha hai.)
**English answer:** This snake has been searching his partner for centuries.

### 77. उसने किताब ले ली थी।
**Romanized:** (Usne kitaab le lee thi.)
**English answer:** He had taken the book.

### 78. मैं पेन से लिखूँगा।
**Romanized:** (Main pen se likhoonga.)
**English answer:** I will write with a pen.

### 79. क्या तुम रोज़ हनुमान जी की पूजा नहीं करती?
**Romanized:** (Kya tum roz Hanuman ji ki pooja ni krti?)
**English answer:** Do you not worship Lord Hanuman daily?

### 80. वो घूमने गया था।
**Romanized:** (Vo ghoomne gaya tha.)
**English answer:** He had gone for a walk.

### 81. ये काम किसने किया?
**Romanized:** (Ye kaam kisne kiya?)
**English answer:** Who did this work?

### 82. ये कहानियाँ मुझे पसंद नहीं।
**Romanized:** (Ye kahaniyan mujhe pasand nahi.)
**English answer:** I don’t like these stories.

### 83. हमने गलती नहीं की।
**Romanized:** (Humne galti nahi ki.)
**English answer:** We didn’t make a mistake.

### 84. राम मेरे बारे में कुछ न कुछ तो बताएगा।
**Romanized:** (Ram mere bare mein kuch na kuch to batayega.)
**English answer:** Ram will tell at least something about me.

### 85. वो दोनों हमें क्या सिखाएंगे?
**Romanized:** (Vo dono hame kya sikhaenge?)
**English answer:** What will they both teach us?

### 86. तुम सभ्य लगते हो।
**Romanized:** (Tum sabhya lagate ho.)
**English answer:** You look civilized.

### 87. वो तुम्हारे घर पहले ही आ चुका है।
**Romanized:** (Vo tumhare ghar pahle hi aa chuka hai.)
**English answer:** He has already come your home.

### 88. मैं तुम्हें रोज़ देखने आया।
**Romanized:** (Main tumhein roz dekhne aaya.)
**English answer:** I came to see you daily.

### 89. तुम अपनी गलती स्वीकार कर चुके हो।
**Romanized:** (Tum apni galti sveekaar kar chuke ho.)
**English answer:** You have accepted your fault.

### 90. मैं तुमसे कभी नहीं मिला।
**Romanized:** (Main tumse kabhi nahi mila.)
**English answer:** I never met you.

### 91. मैं किसी तरह ऑफिस पहुँचा हूँ।
**Romanized:** (Main kisi tarah office pahuncha hoon.)
**English answer:** I have somehow reached office.

### 92. क्या आप हमसे कुछ कह रहे हैं?
**Romanized:** (Kya aap humse kuch kah rahe hai?)
**English answer:** Are you saying something to us?

### 93. वो तुम्हारे घर की तरफ क्यों आता है?
**Romanized:** (Vo tumhare ghar ki taraf kyon aata hai?)
**English answer:** Why does he come towards your home?

### 94. मैं दीवार के पीछे छुप गया।
**Romanized:** (Main deevaar ke peeche chup gaya.)
**English answer:** I hid behind the wall.

### 95. मैं तुमसे मिलने को पागल हो रहा था।
**Romanized:** (Main tumse milne ko pagal ho raha tha.)
**English answer:** I was craving to meet you. / I was being/getting crazy to meet you.

### 96. मैं जल्द ही ऑफिस पहुँच रहा हूँ।
**Romanized:** (Main jald hi office pahunch raha hoon.)
**English answer:** I am reaching office soon.

### 97. सीता ने कम्पनी छोड़ी और चली गयी।
**Romanized:** (Seeta ne company chhodi aur chali gayee.)
**English answer:** Seeta left the company and went.

### 98. तुम अच्छे लग रहे हो।
**Romanized:** (Tum ache lag rahe ho.)
**English answer:** You are looking good.

### 99. तुमने ऐसा क्यों सोचा?
**Romanized:** (Tumne aisa kyon socha?)
**English answer:** Why did you think so?

### 100. उसने गाना कहाँ गाया?
**Romanized:** (Usne gana kaha gaaya?)
**English answer:** Where did he sing the song?

### 101. प्रिया मेरे दिल को समझ रही थी।
**Romanized:** (Priya mere dil ko samajh rahi thi.)
**English answer:** Priya was understanding my feelings.

### 102. मैंने सब कुछ समझ लिया था।
**Romanized:** (Maine sab kuch samjh liya tha.)
**English answer:** I had understood everything.

### 103. लोग मिठाइयाँ खा चुके थे।
**Romanized:** (Log mithaiyaan kha chuke the.)
**English answer:** People had eaten the sweets.

### 104. मुझे उसकी याद आ रही थी।
**Romanized:** (Mujhe uski yaad aa rahi thi.)
**English answer:** I was missing him/her.

### 105. वह दो साल पहले कम्पनी छोड़ चुका है।
**Romanized:** (Vah do saal pahle company chhod chuka h.)
**English answer:** He has left the company 2 years ago.

### 106. वो तुम्हें धमकी क्यों देता है?
**Romanized:** (Vo tumhe dhamkee kyon deta hai?)
**English answer:** Why does he threaten you?

### 107. मैं ऑफिस के बाहर पहले ही अच्छी तरह देख चुका हूँ।
**Romanized:** (Main office ke bahar pahle hi achi tarah dekh chuka hoon.)
**English answer:** I have already seen properly outside the office.

### 108. क्या आप हमसे सहमत हैं?
**Romanized:** (Kya aap humse sahmat hai?)
**English answer:** Do you agree with us?

### 109. राम धोखा दे रहा था।
**Romanized:** (Ram dhokha de raha tha.)
**English answer:** Ram was cheating.

### 110. वो आदमी मुझसे नहीं मिलता है।
**Romanized:** (Vo admi mujhse nahi milta hai.)
**English answer:** That man does not meet me.

### 111. तोता छत पर रो रहा था।
**Romanized:** (Tota chhat par ro raha tha.)
**English answer:** The parrot was crying on the terrace.

### 112. वो तुम्हारा इंतजार 2 बजे से कर रहा था।
**Romanized:** (Vo tumhara intezaar 2 baje se kar raha tha.)
**English answer:** He had been waiting for you since 2'o’clock.

### 113. मैं तुम्हारे बारे में कुछ नहीं सोच रहा हूँ।
**Romanized:** (Main tumhare bare me kuch ni soch raha hu.)
**English answer:** I am not thinking anything about you. / I am thinking nothing about you.

### 114. मैं तुमसे बात करूँगा।
**Romanized:** (Main tumse baat karoonga.)
**English answer:** I will talk to you.

### 115. लोग मुझसे मिलने नहीं आयेंगे।
**Romanized:** (Log mujhse milne nahi aayenge.)
**English answer:** People will not come to meet me.

### 116. राम कम्प्यूटर सीखता है।
**Romanized:** (Ram computer seekhta hai.)
**English answer:** Ram learns computer.

### 117. तुम्हारे बाल झड़ चुके थे।
**Romanized:** (Tumhare baal jhad chuke the.)
**English answer:** You suffered a hair fall.

### 118. मैं अपने माता पिता को विदा कर चुका हूँ।
**Romanized:** (Main apne mata pita ko vida kar chuka hoon.)
**English answer:** I have seen off my parents.

### 119. 2 घंटे हो गये, घाव से खून निकल रहा है।
**Romanized:** (2 ghante ho gaye, ghaav se khoon nikal raha hai.)
**English answer:** Blood has been oozing from the wound for 2 hrs.

### 120. मैं अपने माता-पिता को भेज चुका था।
**Romanized:** (Main apne mata-pita ko bhej chuka tha.)
**English answer:** I had sent my parents.

### 121. क्या आप 3 साल से काम कर रहे हैं?
**Romanized:** (Kya aap 3 saal se kaam kar rahe hai?)
**English answer:** Have you been working for 3 years?

### 122. क्या आप सुबह से घूम रहे हैं?
**Romanized:** (Kya aap subah se ghoom rahe hai?)
**English answer:** Have you been walking since morning?

### 123. नल दिखने में अच्छा लग रहा था।
**Romanized:** (Nal dikhne mein achha lag raha tha.)
**English answer:** The tap was looking good.

### 124. उसने तुम्हें धमकी क्यों दी थी?
**Romanized:** (Usne tumhein dhamkee kyo dee thee?)
**English answer:** Why had he threatened you?

### 125. तुम मुझे सुबह से क्यों ढूंढ रहे हो?
**Romanized:** (Tum mujhe subah se kyon dhoondh rahe ho?)
**English answer:** Why have you been searching me since morning?

### 126. राम ऑफिस कब जाता है?
**Romanized:** (Ram office kab jata hai?)
**English answer:** When does Ram go to office?

### 127. उसने मुझे अकेला छोड़ दिया है।
**Romanized:** (Usne mujhe akela chhod diya hai.)
**English answer:** He has left me alone.

### 128. तुम ऐसा क्यों नहीं सोचते हो?
**Romanized:** (Tum aisa kyon nahi sochte ho?)
**English answer:** Why don’t you think so?

### 129. मैं आपके पास कब आया?
**Romanized:** (Main aapke paas kab aaya?)
**English answer:** When did I come to you?

### 130. मैं तुमसे कभी नहीं मिलूंगा।
**Romanized:** (Main tumse kabhi nahi milunga.)
**English answer:** I will never meet you.

### 131. क्या आपने खाना खाया?
**Romanized:** (kya apne khana khaya?)
**English answer:** Did you eat the food?

### 132. सीता भगवान की पूजा कब से कर रही है?
**Romanized:** (Seeta bhagvaan ki pooja kab se kar rahi hai?)
**English answer:** Since when has Seeta been worshipping God?

### 133. तुमने हाल ही में कौन सी फिल्म देखी है?
**Romanized:** (Tumne haal hee mein kaun si film dekhi h?)
**English answer:** Which movie have you recently seen?

### 134. मैं घूमने गया।
**Romanized:** (Main ghoomne gaya.)
**English answer:** I went for a walk.

### 135. मैं 2 घंटे से ठंड से कांप रहा हूँ।
**Romanized:** (Main 2 ghante se thand se kaanp raha hoon.)
**English answer:** I have been shivering with cold for 2 hours.

### 136. वह दो साल पहले कंपनी छोड़ चुका है।
**Romanized:** (Vah 2 saal pahle company chhod chuka hai.)
**English answer:** He has left the company 2 years ago.

### 137. तुमने मेरा मूड खराब किया।
**Romanized:** (Tumne mera mood kharaab kiya.)
**English answer:** You spoiled my mood.

### 138. मैं 2008 से इस कंपनी में काम कर रहा हूँ।
**Romanized:** (Main 2008 se is company me kaam kar raha hu.)
**English answer:** I have been working with this company since 2008.

### 139. क्या सीता वहाँ बैठी?
**Romanized:** (Kya Seeta vaha baithee?)
**English answer:** Did Seeta sit there?

### 140. वो गाना कहाँ गाता है?
**Romanized:** (Vo gaana kaha gata hai?)
**English answer:** Where does he sing the song?

### 141. वो तुम्हारे घर में खाना खा चुका है?
**Romanized:** (Vo tumhare ghar mein khana kha chuka hai?)
**English answer:** He has eaten/taken/had the food at your home.

### 142. जब मैं आऊँगा, तुम घर जा रहे होंगे।
**Romanized:** (Jab main aaoonga, tum ghar ja rahe honge.)
**English answer:** When I come, you will be going home.

### 143. उसने मुझे माफ किया।
**Romanized:** (Usne mujhe maaf kiya.)
**English answer:** He forgave me.

### 144. मैं ऑफिस परिसर में सिगरेट नहीं पीता।
**Romanized:** (Main office parisar me cigarette nahi peeta.)
**English answer:** I don’t smoke in the office premises.

### 145. मैं अपनी गलती महसूस कर चुका हूँ।
**Romanized:** (Main apni galtee mahasoos kar chuka hoon.)
**English answer:** I have realized my mistake.

### 146. मैंने ये पहेली सुलझा दी।
**Romanized:** (Maine ye paheli suljha di.)
**English answer:** I unravelled this enigma. / I solved this puzzle.

### 147. मैं कभी गाना नहीं गाता।
**Romanized:** (Main kabhi gaana nahi gata.)
**English answer:** I never sing a song.

### 148. मैं आपके पास कब आऊँगा?
**Romanized:** (Main aapke pass kab aaunga?)
**English answer:** When will I come to you?

### 149. दूल्हा अच्छा लगता है।
**Romanized:** (Dulha acha lagta hai.)
**English answer:** The groom looks good.

### 150. यह सुनने में अच्छा लगता है।
**Romanized:** (Yah sunne mein acha lagta hai.)
**English answer:** It sounds good.

### 151. क्या सीता वहाँ बैठेगी?
**Romanized:** (Kya seeta vaha baithegee?)
**English answer:** Will seeta sit there?

### 152. सचिन ने पुराने सभी रिकार्ड्स तोड़े।
**Romanized:** (Sachin ne purane sabhi records tode.)
**English answer:** Sachin broke all the previous records.

### 153. मैं आपका प्रस्ताव स्वीकार करता हूँ।
**Romanized:** (Main apka prastaav sveekaar karta hoon.)
**English answer:** I accept your proposal.

### 154. राम अगले महीने कंप्यूटर सीखेगा।
**Romanized:** (Ram agle mahine computer seekhega.)
**English answer:** Ram will learn computer next month.

### 155. क्या सीता वहाँ बैठती है?
**Romanized:** (Kya Seeta vaha baithatee hai?)
**English answer:** Does Seeta sit there?

### 156. तुम अच्छे लगते हो।
**Romanized:** (Tum ache lagte ho.)
**English answer:** You look good.

### 157. बच्चा छत पर रो रहा होगा।
**Romanized:** (Bachcha chhat par ro raha hoga.)
**English answer:** The kid would be weeping on the terrace.

### 158. मैं तुम्हारे बारे में क्या सोचता हूँ?
**Romanized:** (Main tumhare bare mein kya sochta hoon?)
**English answer:** What do I think about you?

### 159. राम और आदित्य किस ऑफिस से आ रहे हैं?
**Romanized:** (Ram aur Aditya kis office se aa rahe h?)
**English answer:** Which office are Ram & Aditya coming from?

### 160. क्या आप उनसे मिले हो?
**Romanized:** (kya aap unse mile ho?)
**English answer:** Have you met them?

### 161. मैंने तुम्हारे लिए प्रार्थना की थी।
**Romanized:** (Maine tumhare liye prarthana ki thi.)
**English answer:** I had prayed for you.

### 162. राम अच्छी तरह से तैयारी कर चुका है।
**Romanized:** (Ram achchhee tarah se taiyaree kar chuka h.)
**English answer:** Ram has prepared well.

### 163. ये किसने किया?
**Romanized:** (Ye kisne kiya?)
**English answer:** Who did it?

### 164. उसने अनजाने में मुझे दुख पहुँचाया।
**Romanized:** (Usne anjane mein mujhe dukh pahuchaya.)
**English answer:** He unknowingly hurt me.

### 165. मैंने लोगों से पैसे इकट्ठे कर लिए हैं।
**Romanized:** (Maine logo se paise ikatthe kar liye hai.)
**English answer:** I have collected the money from people.

### 166. मैं कसम खाता हूँ कि मैं वहाँ कभी नहीं जाऊँगा।
**Romanized:** (Main kasam khata hoon ki main Vahaan kabhi nahi jaoonga.)
**English answer:** I swear that I will never go there.

### 167. तुम्हारी किताब किसने ली?
**Romanized:** (Tumhari kitaab kisne li?)
**English answer:** Who took your book?

### 168. क्या हुआ?
**Romanized:** (Kya hua?)
**English answer:** What happened?

### 169. तुम्हारे दिमाग को किसने परेशान किया?
**Romanized:** (Tumhare dimaag ko kisne pareshan kiya?)
**English answer:** What disturbed your mind?

### 170. हम बेवजह एक दूसरे के साथ लड़ रहे थे।
**Romanized:** (Hum bevajah ek dusre ke sath lad rahe the.)
**English answer:** We were unnecessarily fighting with each other.

### 171. तुम क्या ढूँढ रहे हो?
**Romanized:** (Tum kya dhoondh rahe ho?)
**English answer:** What are you looking for?

### 172. उन्होंने पूरे कमरे की सजावट बदल दी।
**Romanized:** (Unhone poore kamre ki sajavat badal dee.)
**English answer:** They changed the entire room’s decoration.

### 173. मैंने उसकी आवाज पहचान ली।
**Romanized:** (Maine uski awaaj pehchan li.)
**English answer:** I recognized his voice.

### 174. उसने मुझे पूरी तरह से सहयोग का आश्वासन दिया।
**Romanized:** (Usne mujhe poori tarah se sahayog ka aashvaasan diya.)
**English answer:** He assured me of full cooperation.

### 175. उसने बर्तन धो लिए हैं।
**Romanized:** (Usne bartan dho liye hai.)
**English answer:** He has washed the utensils.

### 176. उसने इतने सारे लोगों को कैसे संभाला?
**Romanized:** (Usne itne sare logo ko kaise sambhala?)
**English answer:** How did he handle these many people?

### 177. जो कोई मेरे पास आया, मैंने मदद की।
**Romanized:** (Jo koi mere pass aaya, maine madad ki.)
**English answer:** Whoever came to me, I helped.

### 178. खेल के दौरान वो खोया खोया सा लगा।
**Romanized:** (Khel ke dauraan vo khoya khoya sa laga.)
**English answer:** During the game, he seemed to be lost.

### 179. तुम कहीं खोये से लगते हो।
**Romanized:** (Tum kaheen khoye se lagte ho.)
**English answer:** You seem to be lost somewhere.

### 180. मैंने उसे उतना पैसा नहीं दिया।
**Romanized:** (Maine use utana paisa nahi diya.)
**English answer:** I didn’t give him that much money.

### 181. हजारों लोग सड़क पर विद्रोह कर रहे हैं।
**Romanized:** (Hajaron log sadak par vidroh kar rahe hai.)
**English answer:** Thousands of people are protesting on roads.

### 182. हस्त रेखा विज्ञान ने उसे पागल कर दिया है।
**Romanized:** (Hast rekha vigyan ne use pagal kr diya h)
**English answer:** Palmistry has made him crazy.

### 183. मेरा भाई किसी तरह घर पहुँचा।
**Romanized:** (Mera bhai kisi tarah ghar pahuncha.)
**English answer:** My brother somehow reached home.

### 184. मैं अपनी सफलता का श्रेय तुम्हें देता हूँ।
**Romanized:** (Main apni safalta ka shrey tumhe deta hun.)
**English answer:** I ascribe my success to you.

### 185. क्या तुममें से कोई पूजा करते हैं?
**Romanized:** (Kya tumme se koi pooja karte hain?)
**English answer:** Do any of you worship?

### 186. तुम इतनी सारी किताबें कैसे लाओगे?
**Romanized:** (Tum itni saree kitabein kaise laoge?)
**English answer:** How will you bring these many books?

### 187. तुममें से कितने ताजमहल गए हो?
**Romanized:** (Tum me se kitne Tajmahal gaye ho?)
**English answer:** How many of you have visited the Tajmahal?

### 188. उसने षड्यंत्र का भांडा फोड़ दिया।
**Romanized:** (Usne shadyantra ka bhanda phod diya.)
**English answer:** He unearthed the conspiracy.

### 189. लोग अक्सर मुझे पूछते हैं।
**Romanized:** (Log aksar mujhe poochhte hai.)
**English answer:** People often ask me.

### 190. आप कब-कब खेलने आते हो?
**Romanized:** (Aap kab-kab khelne aate ho?)
**English answer:** How often do you come to play?

### 191. राहुल कहाँ-कहाँ जाता है?
**Romanized:** (Rahul kaha- kaha jata hai?)
**English answer:** Where all does Rahul go?

### 192. रिया अपना काम खुद करती है।
**Romanized:** (Riya apna kaam khud karti hai.)
**English answer:** Riya does her work herself.

### 193. मैं शायद ही कभी वहाँ जाता हूँ।
**Romanized:** (Mai shayad hi kabhi wahan jata hu.)
**English answer:** I seldom go there. / I rarely go there.

### 194. श्वेता कब तक ऑफिस में रहती है?
**Romanized:** (Shweta kab tak office mein rehti hai?)
**English answer:** Until when does shweta stay in the office?

### 195. मैं घूमने जाता हूँ।
**Romanized:** (Mai ghumne jata hu.)
**English answer:** I go for a walk. / I take a stroll.

### 196. आप क्या करते हो?
**Romanized:** (Aap kya karte ho?)
**English answer:** What do you do?

### 197. आप किस किस के साथ खेलते हो?
**Romanized:** (Aap kis kis ke saath khelte ho?)
**English answer:** Who all do you play with?

### 198. राम फुटबॉल खेलता है।
**Romanized:** (Ram football khelta hai.)
**English answer:** Ram plays football.

### 199. राम फुटबॉल नहीं खेलता है।
**Romanized:** (Ram football nahi khelta hai.)
**English answer:** Ram doesn’t play football.

### 200. क्या राम फुटबॉल खेलता है?
**Romanized:** (Kya Ram football khelta hai?)
**English answer:** Does Ram play football?

### 201. क्या राम फुटबॉल नहीं खेलता है?
**Romanized:** (Kya Ram football nahi khelta hai?)
**English answer:** Does Ram not play football?

### 202. राम क्या खेलता है।
**Romanized:** (Ram kya khelta hai.)
**English answer:** What does Ram play?

### 203. राम क्यों खेलता है?
**Romanized:** (Ram kyo khelta hai?)
**English answer:** Why does Ram play?

### 204. राम कैसे खेलता है?
**Romanized:** (Ram kaise khelta hai?)
**English answer:** How does Ram play?

### 205. राम कहाँ खेलता है?
**Romanized:** (Ram kaha khelta hai?)
**English answer:** Where does Ram play?

### 206. राम किसके साथ खेलता है?
**Romanized:** (Ram kiske saath khelta hai?)
**English answer:** Whom does Ram play with?

### 207. राम कब तक खेलता है?
**Romanized:** (Ram kab tak khelta hai?)
**English answer:** Until when does Ram play?

### 208. राम कितनी बार खेलता है?
**Romanized:** (Ram kitni baar khelta hai?)
**English answer:** How many times does Ram play?

### 209. राम कहाँ-कहाँ खेलता है?
**Romanized:** (Ram kaha-kaha khelta hai?)
**English answer:** Where all does Ram play?

### 210. राम कब-कब खेलता है?
**Romanized:** (Ram kab-kab khelta hai?)
**English answer:** How often does Ram play?

### 211. मैं क्रिकेट खेलता हूँ।
**Romanized:** (Mai cricket khelta hu.)
**English answer:** I play cricket.

### 212. मैं क्रिकेट नहीं खेलता हूँ।
**Romanized:** (Mai cricket nahi khelta hu.)
**English answer:** I don’t play cricket.

### 213. क्या मैं क्रिकेट खेलता हूँ?
**Romanized:** (Kya mai cricket khelta hu?)
**English answer:** Do I play cricket?

### 214. क्या मैं क्रिकेट नहीं खेलता हूँ?
**Romanized:** (Kya mai cricket nahi khelta hu?)
**English answer:** Do I not play cricket?

### 215. राम जाता है।
**Romanized:** (Ram jaata hai.)
**English answer:** Ram goes.

### 216. राम घूमता है।
**Romanized:** (Ram ghoomta hai.)
**English answer:** Ram walks.

### 217. राम घूमने जाता है।
**Romanized:** (Ram ghoomne jata hai.)
**English answer:** Ram goes for a walk.

### 218. वह घूमता है।
**Romanized:** (Vah ghoomta hai.)
**English answer:** He walks.

### 219. वो अक्सर घूमता है।
**Romanized:** (Wo aksar ghoomta hai.)
**English answer:** He often walks. / He walks very often.

### 220. वह कभी कभी घूमता है।
**Romanized:** (Vah kabhi kabhi ghoomta hai.)
**English answer:** He sometimes walks.

### 221. वो शायद ही कभी घूमता है।
**Romanized:** (Wo shayad hi kabhi ghoomta hai.)
**English answer:** He seldom walks.

### 222. वो हमेशा घूमता है।
**Romanized:** (Wo hamesha ghoomta hai.)
**English answer:** He always walks.

### 223. क्या आप खाते हो?
**Romanized:** (Kya aap khate ho?)
**English answer:** Do you eat?

### 224. आप क्या-क्या खाते हो?
**Romanized:** (Aap kya-kya khate ho?)
**English answer:** What all do you eat?

### 225. आप कब-कब खेलने आते हो?
**Romanized:** (Aap kab-kab khelne aate ho?)
**English answer:** How often do you come to play?

### 226. वो किसे प्यार करता है?
**Romanized:** (Wo kise pyar karta hai?)
**English answer:** Whom does he love?

### 227. संजीव कहाँ कहाँ जाता है?
**Romanized:** (Sanjeev kaha kaha jata hai?)
**English answer:** Where all does Sanjeev go?

### 228. मैं उसे घर भेज देता हूँ।
**Romanized:** (Mai use ghar bhej deta hu.)
**English answer:** I send him home.

### 229. वो किसकी कार चलाती है?
**Romanized:** (Wo kiski car chalati hai?)
**English answer:** Whose car does she drive?

### 230. आप किस-किस के साथ बात करते हो?
**Romanized:** (Aap kis-kis ke saath bat karte ho?)
**English answer:** Who all do you speak with?

### 231. कौन जाता है?
**Romanized:** (Kaun jata hai?)
**English answer:** Who goes?

### 232. कौन- कौन जाते हैं?
**Romanized:** (kaun- kaun jate hai?)
**English answer:** Who all go?

### 233. कौन नहीं जाता है?
**Romanized:** (Kaun nahi jata hai?)
**English answer:** Who doesn’t go?

### 234. कौन कौन नहीं जाते हैं?
**Romanized:** (Kaun kaun nahi jate hain?)
**English answer:** Who all don’t go?

### 235. राम कभी नहीं खेलता।
**Romanized:** (Ram kabhi nahi khelta.)
**English answer:** Ram does not ever play. / Ram never plays.

### 236. आप पढ़ना कब से शुरु करते हो?
**Romanized:** (Aap padhna kab se shuru karte ho?)
**English answer:** Since when do you start studying? / Since when do you begin to study?

### 237. किसके भाई के साथ वो खेलना पसंद करता है?
**Romanized:** (Kiske bhai ke sath vo khelna pasand karta h?)
**English answer:** Whose brother does he like to play with?

### 238. मैंने उसकी आवाज पहचान ली है।
**Romanized:** (Mene uski aawaz pahchan li hai.)
**English answer:** I have recognized his voice.

### 239. क्या आप 2011 से एक ही नाई के पास नहीं जा रहे हैं?
**Romanized:** (Kya ap 2011 se ek hi naai ke paas nahi ja rahe hai?)
**English answer:** Have you not been going to the same hair dresser since 2011?

### 240. क्या वह 4 बजे उठता है?
**Romanized:** (Kya vah 4 baje uthta hai?)
**English answer:** Does he wake up at 4 o’clock?

### 241. राम हर दिन एक किलोमीटर दौड़ता है।
**Romanized:** (Ram har din ek kilometer daudta hai.)
**English answer:** Ram runs for a km every day.

### 242. मैं तुमसे तेज़ दौड़ता हूँ।
**Romanized:** (Mai tumse tez daudta hoon.)
**English answer:** I run faster than you.

### 243. वह मुझसे बात करती है।
**Romanized:** (Vah mujhse baat krti hai.)
**English answer:** She talks to me.

### 244. ये लोग हमें खेलने नहीं दे रहे हैं।
**Romanized:** (Ye log hame khelne nahi de rahe hain.)
**English answer:** These people are not letting us play.

### 245. वह सीखना चाहता है।
**Romanized:** (Vah seekhna chahta hai.)
**English answer:** He wants to learn.

### 246. वे कड़ी मेहनत करते हैं।
**Romanized:** (Ve kadi mehnat karte hai.)
**English answer:** They work hard.

### 247. वह टहलने जा रही है।
**Romanized:** (Vah tahalne ja rahi hai.)
**English answer:** She is going for a walk.

### 248. राम नहीं दौड़ता।
**Romanized:** (Ram nahi daudta.)
**English answer:** Ram does not run.

### 249. मैं बास्केटबॉल नहीं खेलता।
**Romanized:** (Mai basketball nahi khelta.)
**English answer:** I do not play basketball.

### 250. वे किताबें नहीं पढ़ते हैं।
**Romanized:** (Ve kitaabe nahi padhte hai.)
**English answer:** They do not read books.

### 251. वह सीखना नहीं चाहता।
**Romanized:** (Vah seekhna nahi chahta.)
**English answer:** He does not want to learn.

### 252. वे मेहनत नहीं करते।
**Romanized:** (Ve mehnat nahi karte.)
**English answer:** They do not work hard.

### 253. क्या वह गाता है?
**Romanized:** (Kya vah gata hai?)
**English answer:** Does he sing?

### 254. तुम वहाँ क्यों जाते हो?
**Romanized:** (Tum waha kyu jaate ho?)
**English answer:** Why do you go there?

### 255. मुझे एक घड़ी मिली है।
**Romanized:** (Mujhe ek ghadi mili hai.)
**English answer:** I have found a watch.

### 256. हम कितने बजे तक खेलते हैं?
**Romanized:** (Hum kitne baje tak khelte hai?)
**English answer:** Until what time do we play?

### 257. मैं वहाँ एक बार गया हूँ।
**Romanized:** (Main wahaan ek baar gaya hu.)
**English answer:** I have gone there once.

### 258. क्या वह स्कूल जाता है?
**Romanized:** (Kya vah school jata hai?)
**English answer:** Does he go to school?

### 259. क्या वह स्कूल नहीं जाता है?
**Romanized:** (Kya vah school nahi jata hai?)
**English answer:** Does he not go to school?

### 260. क्या वह मेहनत से पढ़ाई नहीं करता?
**Romanized:** (Kya vah mehnat se padhai nahi krta?)
**English answer:** Does he not study hard?

### 261. क्या वे एक साथ नहीं खेलते हैं?
**Romanized:** (Kya ve ek sath nahi khelte hai?)
**English answer:** Do they not play together?

### 262. आप उसे क्यों नहीं डाँटते?
**Romanized:** (Aap use kyu nahi daantte?)
**English answer:** Why do you not scold him?

### 263. वह आज सुबह क्रिकेट क्यों नहीं खेल रहा है?
**Romanized:** (Vah aaj subah cricket kyu ni khel rha h?)
**English answer:** Why is he not playing cricket this morning?

### 264. राम स्कूल चला गया है।
**Romanized:** (Ram school chala gaya hai.)
**English answer:** Ram has gone to school.

### 265. क्या मैं सुबह से वही बात नहीं कह रहा हूँ?
**Romanized:** (Kya me subah se wahi baat ni kah rha hu?)
**English answer:** Have I not been saying the same thing since morning?

### 266. वे टहलने के लिए गए थे।
**Romanized:** (Ve tahalne ke liye gaye the.)
**English answer:** They went out for a walk.

### 267. मैं पढ़ रहा हूँ।
**Romanized:** (Main padh raha hoon.)
**English answer:** I am studying.

### 268. मेहमान जा चुके हैं।
**Romanized:** (Mehman ja chuke hai.)
**English answer:** The guests have left.

### 269. वे डिनर कर रहे हैं।
**Romanized:** (Ve dinner kar rahe hai.)
**English answer:** They are having/taking/eating dinner.

### 270. वे पार्टी में जा रहे हैं।
**Romanized:** (Ve ek party me ja rahe hai.)
**English answer:** They are going to a party.

### 271. वो रो रही है।
**Romanized:** (Vo ro rahi hai.)
**English answer:** She is crying.

### 272. वह टहलने नहीं जा रही है।
**Romanized:** (Vah tahalne nahi ja rahi hai.)
**English answer:** She is not going for a walk.

### 273. मैं पढ़ाई नहीं कर रहा हूँ।
**Romanized:** (Mai padhai nahi kar raha hoon.)
**English answer:** I am not studying.

### 274. वे डिनर नहीं कर रहे हैं।
**Romanized:** (Ve dinner nahi kar rahe hai.)
**English answer:** They are not having dinner.

### 275. वे पार्टी में नहीं जा रहे हैं।
**Romanized:** (Ve party me nahi ja rahe hai.)
**English answer:** They are not going to party.

### 276. वह रो नहीं रही है।
**Romanized:** (Vah ro nahi rahi h.)
**English answer:** She is not crying.

### 277. क्या मैं पार्टी में जा रहा हूँ?
**Romanized:** (Kya mai party me ja raha hoon?)
**English answer:** Am I going to the party?

### 278. वह क्यों रो रही है?
**Romanized:** (Vah kyu ro rhi hai?)
**English answer:** Why is she crying?

### 279. वह टहलने क्यों नहीं जा रही है?
**Romanized:** (Vah tahalne kyu nahi ja rahi hai?)
**English answer:** Why is she not going for a walk?

### 280. क्या हम आज स्कूल नहीं जा रहे हैं?
**Romanized:** (Kya hum aj school nahi ja rahe hai?)
**English answer:** Are we not going to school today?

### 281. आज आप अपनी परीक्षा के लिए उपस्थित क्यों नहीं हो रहे हैं?
**Romanized:** (Aaj ap apni pareeksha ke liye upasthit kyu nahi ho rahe hai?)
**English answer:** Why you are not appearing for your examination today?

### 282. आप अपनी परीक्षाओं के लिए पढ़ाई क्यों नहीं कर रहे हैं?
**Romanized:** (Aap apni pareekshao ke liye padhai kyu nahi kar rhe hai?)
**English answer:** Why are you not studying hard for your examinations?

### 283. क्या मैं पत्र लिख रहा हूँ?
**Romanized:** (Kya mai patra likh raha hu?)
**English answer:** Am I writing the letter?

### 284. हमने परिसर को घेर लिया है।
**Romanized:** (Humne parisar ko gher liya hai.)
**English answer:** We have surrounded the premises.

### 285. उसने मेरे मैसेज का जवाब दिया है।
**Romanized:** (Usne mere message ka jawab diya hai.)
**English answer:** She has replied to my message.

### 286. उन्होंने परीक्षा के लिए क्वालीफाई किया।
**Romanized:** (Unhone pareeksha ke liye qualify kiya.)
**English answer:** They qualified for the exam.

### 287. उसने परीक्षाएं पास कर ली हैं।
**Romanized:** (Usne pareekshayein paas kar li hain.)
**English answer:** She has passed the exams.

### 288. राम खेलने के लिए बाहर नहीं गया है।
**Romanized:** (Ram khelne ke liye bahar nahi gaya hai.)
**English answer:** Ram has not gone out to play.

### 289. वे अभी तक नहीं पहुँचे हैं।
**Romanized:** (Ve abhi tak nahi pahunche hai.)
**English answer:** They have not arrived yet.

### 290. उन्होंने हमें वापस नहीं बुलाया है।
**Romanized:** (Unhone hamein wapas nahi bulaya hai.)
**English answer:** They have not called us back.

### 291. क्या आपने आने वाली परीक्षाओं की तैयारी कर ली है?
**Romanized:** (Kya apne aane wali pareekshao ki taiyari kar li hai?)
**English answer:** Have you prepared for the upcoming examinations?

### 292. क्या उसने आपकी किताब पढ़ी है?
**Romanized:** (Kya usne aapki kitab padhi hai?)
**English answer:** Has she read your book?

### 293. क्या उन्होंने हमें वापस बुलाया है?
**Romanized:** (Kya unhone hamein wapas bulaya hai?)
**English answer:** Have they called us back?

### 294. क्या उन्होंने आपके स्कूल की नोटबुक लौटा दी है?
**Romanized:** (Kya unhone aapke school ki notebook lauta di hai?)
**English answer:** Have they returned your school notebook?

### 295. क्या उन्होंने खेल खेलना समाप्त कर दिया है?
**Romanized:** (Kya unhone khel khelna samapt kr diya hai?)
**English answer:** Have they finished playing the game?

### 296. आपने लाइब्रेरी का बकाया भुगतान क्यों नहीं दिया है?
**Romanized:** (Aapne library ka bakaya bhugtaan kyu nahi diya hai?)
**English answer:** Why have you not paid the library dues?

### 297. उसने मैथमेटिक्स ओलंपियाड के लिए आवेदन क्यों नहीं किया है?
**Romanized:** (Usne Mathematics Olympiad ke liye aavedan kyu nahi kiya hai?)
**English answer:** Why has she not applied for the Mathematics Olympiad?

### 298. क्या वह गाना गा रही थी?
**Romanized:** (Kya vah gaana ga rahi thi?)
**English answer:** Was she singing a song?

### 299. उन्होंने खाना क्यों नहीं खाया है?
**Romanized:** (Unhone khana kyu nahi khaya hai?)
**English answer:** Why have they not eaten the food?

### 300. आपने अपना होमवर्क क्यों नहीं किया है?
**Romanized:** (Aapne apna homework kyu nahi kiya hai?)
**English answer:** Why have you not done your homework?

### 301. वह 1947 से यहाँ रह रहा है।
**Romanized:** (Vah 1947 se yaha reh raha hai.)
**English answer:** He has been living here since 1947.

### 302. राम एक घंटे से चल रहा है।
**Romanized:** (Raam ek ghante se chal raha hai.)
**English answer:** Ram has been walking for one hour.

### 303. वह एक हफ्ते से इस किताब को पढ़ रही है।
**Romanized:** (Vah ek hafte se is kitaab ko padh rahi h.)
**English answer:** She has been reading this book for a week.

### 304. वे सात बजे से पढ़ रहे हैं।
**Romanized:** (Ve saat baje se padh rahe hai.)
**English answer:** They have been studying since 7 o’clock.

### 305. वह एक घंटे से मेरा इंतजार कर रहा है।
**Romanized:** (Vah ek ghante se mera intezar kar raha tha.)
**English answer:** He has been waiting for me for an hour.

### 306. वह रविवार से पढ़ाई नहीं कर रही है।
**Romanized:** (Vah ravivaar se padhai nahi kar rahi hai.)
**English answer:** She has not been studying since Sunday.

### 307. वे एक साल से एक-दूसरे से नहीं मिल रहे हैं।
**Romanized:** (Ve ek saal se ek dusre se ni mil rahe h.)
**English answer:** They have not been meeting each other for a year.

### 308. वे सोमवार से एक्सरसाइज नहीं कर रहे हैं।
**Romanized:** (Ve somvaar se exercise nahi kar rahe hai.)
**English answer:** They have not been exercising since Monday.

### 309. वह एक महीने से प्रैक्टिस नहीं कर रहा है।
**Romanized:** (Vah ek mahine se practice ni kar raha hai.)
**English answer:** He has not been practicing for a month.

### 310. आप एक महीने से मेरे कॉल का जवाब नहीं दे रहे हैं।
**Romanized:** (Aap ek mahine se mere call ka jawab nahi de rahe hai.)
**English answer:** You have not been returning my calls for a month.

### 311. वे दो घंटे से क्या बात कर रहे हैं?
**Romanized:** (Ve do ghante se kya baat kar rahe hai?)
**English answer:** What have they been talking about for two hours?

### 312. वे पिछले सप्ताह से क्यों लड़ रहे हैं?
**Romanized:** (Ve pichle saptah se kyu lad rahe hai?)
**English answer:** Why have they been fighting since last week?

### 313. क्या वह पच्चीस साल से पढ़ा रही है?
**Romanized:** (Kya vah pachhees saal se padha rahi hai?)
**English answer:** Has she been teaching for twenty-five years?

### 314. पिछले 1 घंटे से कौन शोर मचा रहा है?
**Romanized:** (Pichle 1 ghante se kaun shor macha raha h?)
**English answer:** Who has been making noise for the last one hour?

### 315. क्या वह पिछले सात दिनों से एक ही किताब पढ़ रहा है?
**Romanized:** (Kya vah pichle saat dino se ek hi kitaab padh raha hai?)
**English answer:** Has he been reading the same book for the past seven days?

### 316. वह कल से अपने कमरे में क्या कर रहा है?
**Romanized:** (Vah kal se apne kamre me kya kr raha h?)
**English answer:** What has he been doing in his room since yesterday?

### 317. क्या वह पिछले दो सप्ताह से एक ही प्रोजेक्ट पर काम नहीं कर रहा है?
**Romanized:** (Kya vah pichle do saptah se ek hi project par kaam nahi kar raha hai?)
**English answer:** Has he not been working on the same project for the last two weeks?

### 318. उसने उसे एक पत्र लिखा।
**Romanized:** (Usne use ek patra likha.)
**English answer:** He wrote a letter to her.

### 319. उन्होंने अपने दोस्तों के साथ खेला।
**Romanized:** (Unhone apne dosto ke sath khela.)
**English answer:** They played with their friends.

### 320. वह अपनी किताबें क्यों नहीं लाई है?
**Romanized:** (Vah apni kitaabe kyu nahi lai hai?)
**English answer:** Why has she not brought her books?

### 321. हमने समय पर अपना होमवर्क जमा कर दिया।
**Romanized:** (Humne samay par apna homework jama kar diya.)
**English answer:** We submitted our homework on time.

### 322. उन्होंने फाइनल के लिए क्वालीफाई नहीं किया।
**Romanized:** (Unhone final ke liye qualify nahi kiya.)
**English answer:** They did not qualify for the finals.

### 323. वे समय पर बस नहीं पकड़ सके।
**Romanized:** (Ve samay par bus nahi pakad sake.)
**English answer:** They could not catch the bus on time.

### 324. उन्हें गिफ्ट पसंद नहीं आया।
**Romanized:** (Unhe gift pasand nahi aaya.)
**English answer:** They did not like the gift.

### 325. मैंने उसका इंतजार नहीं किया।
**Romanized:** (Maine uska intezaar nahi kiya.)
**English answer:** I did not wait for him.

### 326. उसे फिल्म पसंद नहीं आई।
**Romanized:** (Use film pasand nahi aai.)
**English answer:** She did not like the movie.

### 327. क्या आपको किताब पसंद आई?
**Romanized:** (Kya apko kitab pasand aai?)
**English answer:** Did you like the book?

### 328. क्या उसने आखिरी पेज तक किताब पढ़ी?
**Romanized:** (Kya usne aakhiri page tak kitaab padhi?)
**English answer:** Did he read the book till the last page?

### 329. क्या उसने अपनी परीक्षाओं की तैयारी शुरू कर दी?
**Romanized:** (Kya usne apni pareekshao ki taiyaari shuru kar di thi?)
**English answer:** Did he start preparing for his examinations?

### 330. वे अपने घर से क्यों शिफ्ट हुए?
**Romanized:** (Ve apne ghar se kyu shift hue?)
**English answer:** Why did they shift from their home?

### 331. क्या वे असाइनमेंट देना भूल गए?
**Romanized:** (Kya ve assignment dena bhul gaye?)
**English answer:** Did they forget to submit their assignments?

### 332. क्या मैं अपने दस्तावेज़ नहीं लाया?
**Romanized:** (Kya mai apne dastavej nahi laya?)
**English answer:** Did I not bring my documents?

### 333. क्या उसे रात का खाना पसंद नहीं आया?
**Romanized:** (Kya use raat ko khana pasand nahi aaya?)
**English answer:** Did she not like dinner?

### 334. क्या वह परीक्षा के लिए उपस्थित नहीं हुआ?
**Romanized:** (Kya vah pareeksha ke liye upasthit nahi hua tha?)
**English answer:** Did he not appear for the examination?

### 335. क्या उन्हें क्विज के बारे में पता नहीं था?
**Romanized:** (Kya unhe quiz ke bare me pata nahi tha?)
**English answer:** Did they not know about the quiz?

### 336. वह एक आर्टिकल लिख रहा था।
**Romanized:** (Vah ek article likh raha tha.)
**English answer:** He was writing an article.

### 337. वे प्रोजेक्ट पर काम कर रहे थे।
**Romanized:** (Ve project par kaam kar rahe the.)
**English answer:** They were working on the project.

### 338. वह अपना मैथमेटिक्स का होमवर्क पूरा कर रही थी।
**Romanized:** (Vah apna Mathematics ka homework pura kar rahi thi.)
**English answer:** She was completing her Mathematics homework.

### 339. वह अपनी आने वाली परीक्षाओं की तैयारी कर रहा था।
**Romanized:** (Vah apni aane wali pareekshao ki taiyaari kar raha tha.)
**English answer:** He was preparing for his upcoming examinations.

### 340. वह अपनी कार की मरम्मत कर रही थी।
**Romanized:** (Vah apni car ki marammat kar rahi thi.)
**English answer:** She was repairing her car.

### 341. हम अगले साल अमेरिका नहीं जा रहे होंगे।
**Romanized:** (Hum agle saal America nahi ja rahe honge.)
**English answer:** We will not be going to America next year.

### 342. वे बाहर नहीं जा रहे थे।
**Romanized:** (Ve bahar nahi ja rahe the.)
**English answer:** They were not going out.

### 343. वह पिकनिक के लिए तैयार हो रही थी।
**Romanized:** (Vah picnic ke liye taiyaar ho rahi thi.)
**English answer:** She was getting ready for the picnic.

### 344. वे शिक्षक दिवस के लिए कक्षा को सजा रहे थे।
**Romanized:** (Ve shikshak diwas ke liye kaksha ko saja rahe the.)
**English answer:** They were decorating the classroom for Teacher’s Day.

### 345. बच्चे गार्डन में इधर-उधर भाग रहे थे।
**Romanized:** (Bachhe garden me idhar udhar bhag rahe the.)
**English answer:** The children were running around the garden.

### 346. क्या वे कॉलेज जाने के लिए निकल रहे थे?
**Romanized:** (Kya ve college jane ke liye nikal rahe the?)
**English answer:** Were they leaving to go to college?

### 347. क्या वह उनके साथ पार्टी में जा रही थी?
**Romanized:** (Kya vah unke sath party me ja rahi thi?)
**English answer:** Was she accompanying them to the party?

### 348. वे पिकनिक का आयोजन कहाँ कर रहे थे?
**Romanized:** (Ve picnic ka aayojan kaha kar rahe the?)
**English answer:** Where were they organizing the picnic?

### 349. पिछले तीन घंटों से वह क्या कर रही थी?
**Romanized:** (Pichle teen ghanto se vah kya kar rahi thi?)
**English answer:** What was she doing in the last three hours?

### 350. उनकी माँ उन्हें उनकी गलतियों के लिए क्यों नहीं डाँट रही थी?
**Romanized:** (Unki ma unhe unki galtiyon ke liye kyu nahi daant rahi thi?)
**English answer:** Why was their Mother not scolding them for their mistakes?

### 351. तुम मुझे कॉल क्यों नहीं कर रहे थे?
**Romanized:** (Tum mujhe call kyu nahi kar rahe the?)
**English answer:** Why were you not calling out to me?

### 352. क्या वह ऑफिस के समय पर काम नहीं कर रही थी?
**Romanized:** (Kya vah office ke samay par kaam nahi kar rahi thi?)
**English answer:** Was she not working during office hours?

### 353. क्या मैं सवालों के सही जवाब नहीं दे रहा था?
**Romanized:** (Kya mai sawalo ke sahi jawab nahi de raha tha?)
**English answer:** Was I not answering the questions correctly?

### 354. वह घूमने के लिए क्यों नहीं जा रहा था?
**Romanized:** (Vah ghumne ke liye kyu nahi ja raha tha?)
**English answer:** Why was he not going for his walks?

### 355. डॉक्टर के आने से पहले ही मरीज का निधन हो गया था।
**Romanized:** (Doctor ke aane se pehle hi mareez ka nidhan ho gaya tha.)
**English answer:** The patient had passed away before the arrival of the doctor.

### 356. उसने बचपन में कई सर्जरी करवाई थी।
**Romanized:** (Usne Bachpan me kai surgery karvaai thi.)
**English answer:** She had undergone numerous surgeries during her childhood.

### 357. उसने असाइनमेंट पूरा कर लिया था, लेकिन उसे स्कूल ले जाना भूल गई।
**Romanized:** (Usne assignment pura kar liya tha lekin use school le jana bhool gai.)
**English answer:** She had completed the assignments but forgot to take them to school.

### 358. उन्होंने बहुत अधिक जंक फूड खा लिया था।
**Romanized:** (Unhone bahut adhik junk food kha liya tha.)
**English answer:** They had consumed too much junk food.

### 359. मेरे पहुँचने से पहले ही आप निकल चुके थे।
**Romanized:** (Mere pahuchne se pehle hi aap nikal chuke the.)
**English answer:** You had left even before I reached.

### 360. कक्षा की मॉनिटर ने छात्रों को समय सीमा के बारे में सूचित नहीं किया था।
**Romanized:** (Kaksha ki monitor ne chatro ko samay seema ke baare me soochit nahi kiya tha.)
**English answer:** The class monitor had not informed the students about the deadline.

### 361. हमने अपने छात्रावास के कमरे को साफ नहीं किया था।
**Romanized:** (Humne apne chhatravaas ke kamre ko saaf nahi kiya tha.)
**English answer:** We had not cleaned our class room.

### 362. वे स्कूल नहीं गए थे।
**Romanized:** (Ve school nahi gaye the.)
**English answer:** They had not gone to school.

### 363. उसने अपने स्कूल फेयरवैल के लिए अपनी नई ड्रेस पहन रखी थी।
**Romanized:** (Usne apne school farewell ke liye apni nai dress pehan rakhi thi.)
**English answer:** She had worn her new dress for her school farewell.

### 364. क्या आपने अपनी परीक्षा की तैयारी की थी?
**Romanized:** (Kya apne apni pariksha ki taiyaari ki thi?)
**English answer:** Had you prepared for your examination?

### 365. उसने पत्र क्यों लिखा था?
**Romanized:** (Usne patra kyu likha tha?)
**English answer:** Why had she written a letter?

### 366. आपने अपना होमवर्क पूरा नहीं किया है।
**Romanized:** (Aapne apna homework pura nahi kiya hai.)
**English answer:** You have not completed your homework.

### 367. उसने किससे मदद माँगी थी?
**Romanized:** (Usne kisse madad maangi thi?)
**English answer:** Who had he asked for help?

### 368. क्या उसने धूम्रपान छोड़ दिया था?
**Romanized:** (Kya usne dhoomrapaan chhod diya tha?)
**English answer:** Had he quit smoking?

### 369. मेरे पहुँचने से पहले ही वह क्यों चला गया था?
**Romanized:** (Mere pahuchne se pehle hi vah kyu chala gaya tha?)
**English answer:** Why had he left before I reached the place?

### 370. उसने आपको अपनी पार्टी में क्यों नहीं आमंत्रित किया था?
**Romanized:** (Usne apko apni party me kyu nahi amantrit kiya tha?)
**English answer:** Why had she not invited you to her party?

### 371. क्या उन्होंने परीक्षा की तारीख अभी तक नहीं बदली थी?
**Romanized:** (Kya unhone pareeksha ki tareekh abhi tak nahi badli thi?)
**English answer:** Had they not changed the date of the examination yet?

### 372. वह परीक्षा के लिए उपस्थित क्यों नहीं हुआ था?
**Romanized:** (Vah pareeksha ke liye upasthit kyu nahi hua tha?)
**English answer:** Why had he not appeared for the examination?

### 373. आपने निर्धारित समय पर दवा क्यों नहीं ली थी?
**Romanized:** (Apne nirdharit samay par dawa kyu nahi li thi?)
**English answer:** Why had you not taken the medicine at the designated timings?

### 374. क्या वह 2020 तक ग्रेजुएशन कर चुकी होगी?
**Romanized:** (Kya vah 2020 tak graduation kar chuki hogi?)
**English answer:** Will she have graduated by 2020?

### 375. उन्होंने प्रस्ताव को क्यों नहीं स्वीकार किया था?
**Romanized:** (Unone prastaav ko kyu nahi sweekar kiya tha?)
**English answer:** Why had they not accepted the proposal?

### 376. वे दो घंटे से फिल्म देख रहे थे।
**Romanized:** (Ve do ghante se film dekh rahe the.)
**English answer:** They had been watching the movie for two hours.

### 377. वह 8 बजे से पढ़ रही थी।
**Romanized:** (Vah 8 baje se padh rahi thi.)
**English answer:** She had been studying since 8 o’clock.

### 378. वह छह महीने से नौकरी के लिए अप्लाई कर रहा था।
**Romanized:** (Vah 6 mahine se naukri ke liye apply kar raha tha.)
**English answer:** He had been applying for jobs for six months.

### 379. वे 15 वर्षों से अपना बिज़नेस चला रहे थे।
**Romanized:** (Ve 15 varsho se apna business chala rahe the.)
**English answer:** They had been running their business for over fifteen years.

### 380. मैं पिछले हफ़्ते से तुम्हारा इंतज़ार कर रहा था।
**Romanized:** (Mai pichle hafte se tumhara intezaar kar raha tha.)
**English answer:** I had been waiting for you since last week.

### 381. वे दो घंटे से फिल्म नहीं देख रहे थे।
**Romanized:** (Ve do ghante se film nahi dekh rahe the.)
**English answer:** They had not been watching the movie for two hours.

### 382. वह 8 बजे से नहीं पढ़ रही थी।
**Romanized:** (Vah 8 baje se nahi padh rahi thi.)
**English answer:** She had not been studying since 8 o’clock.

### 383. वह छह महीने से नौकरियों के लिए अप्लाई नहीं कर रहा था।
**Romanized:** (Vah chhe mahine se naukriyo ke liye apply nahi kar rha tha.)
**English answer:** He had not been applying for jobs for six months.

### 384. वे पिछले दो हफ्तों से किताबें नहीं पढ़ रहे थे।
**Romanized:** (Ve pichle do hafto se kitaab nahi padh rhe the.)
**English answer:** They had not been reading books for the last two weeks.

### 385. बच्चे 5 बजे से नहीं खेल रहे थे।
**Romanized:** (Bacche 5 baje se nahi khel rahe the.)
**English answer:** The kids had not been playing since 5 o’ clock.

### 386. वो कब से खेल रहा है?
**Romanized:** (Vo kab se khel raha hai?)
**English answer:** Since when has he been playing?

### 387. क्या वे 2017 से प्रोजेक्ट पर काम कर रहे थे?
**Romanized:** (Kya ve 2017 se project par kaam kar rahe hai?)
**English answer:** Had they been working on the project since 2017?

### 388. वे 2015 से एक ही कैमरे का उपयोग क्यों कर रहे थे?
**Romanized:** (Ve 2015 se ek hi camera ka upyog kyu kar rahe the?)
**English answer:** Why had they been using the same camera since 2015?

### 389. वह दो दिनों से अपनी दवा क्यों नहीं ले रही थी?
**Romanized:** (Vah do dino se apni dawa kyu nahi le rahi thi?)
**English answer:** Why had she not been taking her medicine for two days?

### 390. वे तीन सप्ताह से अपने कमरे की सफाई क्यों नहीं कर रहे थे?
**Romanized:** (Ve teen saptah se apne kamre ki safai kyu nahi kar rahe the?)
**English answer:** Why had they not been cleaning their room for three weeks?

### 391. वह सोमवार से परीक्षा के लिए प्रैक्टिस क्यों नहीं कर रहा था?
**Romanized:** (Vah somvaar se pareeksha ke liye practice kyu nahi kar raha tha?)
**English answer:** Why had he not been practicing for the examination since Monday?

### 392. क्या वह तब से पढ़ाई नहीं कर रहा था जब उसके पिता काम के लिए चले गए थे?
**Romanized:** (Kya veh tab se padhai nahi kar raha tha jab uske pita kaam ke liye chale gaye the?)
**English answer:** Had he not been studying since his father left for work?

### 393. वह कल पहुँचेगा।
**Romanized:** (Vah kal pahunchega.)
**English answer:** He will arrive tomorrow.

### 394. वह इसे कल खरीदेगी।
**Romanized:** (Vah ise kal khareedegi.)
**English answer:** She will buy it tomorrow.

### 395. वे उसे एक उपहार भेजेंगे।
**Romanized:** (Ve use ek uphar bhejenge.)
**English answer:** They will send a gift to him.

### 396. वह कॉलेज के लिए निकलेगी।
**Romanized:** (Vah college ke liye niklegi.)
**English answer:** She will leave for college.

### 397. वह उससे शादी करेगा।
**Romanized:** (Vah usse shadi karega.)
**English answer:** He will marry her.

### 398. वह आपकी मदद नहीं करेगा।
**Romanized:** (Vah apki madad nahi karega.)
**English answer:** He will not help you.

### 399. वे आपसे नहीं मिलेंगे।
**Romanized:** (Ve apse nahi milenge.)
**English answer:** They will not meet you.

### 400. वह कॉलेज नहीं जाएगी।
**Romanized:** (Vah college nahi jayegi.)
**English answer:** She will not go to college.

### 401. वह उससे शादी नहीं करेगा।
**Romanized:** (Vah usse shadi nahi karega.)
**English answer:** He will not marry her.

### 402. वह छात्र इस वर्ष परीक्षा नहीं देगा।
**Romanized:** (Vah student is varsha exam nahi dega.)
**English answer:** That student will not appear for the exam this year.

### 403. आप अपने पंखे की मरम्मत कब करेंगे?
**Romanized:** (Aap apne pankhe ki marammat kab karenge?)
**English answer:** When will you repair your fan?

### 404. शिक्षक परीक्षा कब आयोजित करेंगे?
**Romanized:** (Shikshak pareeksha kab aayojit karenge?)
**English answer:** When will the teacher conduct the test?

### 405. आप टेस्ट के लिए प्रैक्टिस कब शुरू करेंगे?
**Romanized:** (Aap test ke liye practice kab shuru karenge?)
**English answer:** When will you start practicing for the test?

### 406. क्या वह 2025 तक बहुत पैसा कमा चुका होगा?
**Romanized:** (Kya vah 2025 tak bahut paisa kama chukka hoga?)
**English answer:** Will he have earned a lot of money by 2025?

### 407. आप आज रात को क्या खाओगे?
**Romanized:** (Aap aj raat ko kya khaoge?)
**English answer:** What will you eat tonight?

### 408. वह गलत काम क्यों करेगा?
**Romanized:** (Vah galt kaam kyu karega?)
**English answer:** Why will he do the wrong thing?

### 409. वह उसे निमंत्रण क्यों नहीं भेजेगा?
**Romanized:** (Vah use nimantran kyu nahi bhejega?)
**English answer:** Why will he not send an invitation to him?

### 410. वह परीक्षा के लिए उपस्थित क्यों नहीं होगा?
**Romanized:** (Vo pariksha ke liye present kyu ni hoga?)
**English answer:** Why will he not appear for the examination?

### 411. वह यहाँ क्यों नहीं आएगी?
**Romanized:** (Vah yaha kyu nahi aayegi?)
**English answer:** Why will she not come here?

### 412. वह काम क्यों नहीं करेगा?
**Romanized:** (Vah kaam kyu nahi karega?)
**English answer:** Why will he not work?

### 413. वह कल अपनी प्रतियोगिता की तैयारी कर रहा होगा।
**Romanized:** (Vah kal apni pratiyogita ki taiyaari kar raha hoga.)
**English answer:** He will be preparing for his competition tomorrow.

### 414. आप कल शाम को अगले चरण के लिए योजना बना रहे होंगे।
**Romanized:** (Aap kal sham ko agle charan ke liye yojna bana rhe honge.)
**English answer:** You will be planning for the next step tomorrow evening.

### 415. कल बारिश हो रही होगी।
**Romanized:** (Kal baarish ho rahi hogi.)
**English answer:** It will be raining tomorrow.

### 416. आप 2 दिन बाद कंपनी के विज्ञापन विभाग का कार्यभार संभाल रहे होंगे।
**Romanized:** (Aap 2 din baad company ke vigyapan vibhaag ka karyabhar sambhal rahe honge.)
**English answer:** You’ll be taking over the Advertisement dept. of the company after 2 days.

### 417. हम अगले साल अमेरिका जा रहे होंगे।
**Romanized:** (Hum agle saal America ja rahe honge.)
**English answer:** We will be going to America next year.

### 418. वह कल स्कूल नहीं जा रही होगी।
**Romanized:** (Vah kal school nahi ja rahi hogi.)
**English answer:** She will not be going to school tomorrow.

### 419. कल बारिश नहीं हो रही होगी।
**Romanized:** (Kal baarish nahi ho rahi hogi.)
**English answer:** It will not be raining tomorrow.

### 420. वह कल स्कूल कितने बजे जा रही होगी?
**Romanized:** (Vah kal school kitne baje ja rahi hogi?)
**English answer:** At what time will she be going to school tomorrow?

### 421. हम अगले साल अमेरिका क्यों जा रहे होंगे?
**Romanized:** (Hum agle saal America kyo ja rahe honge?)
**English answer:** Why will we be going to America next year?

### 422. क्या कल बारिश हो रही होगी?
**Romanized:** (Kya kal baarish ho rahi hogi?)
**English answer:** Will it be raining tomorrow?

### 423. क्या वह आज शाम को इवेंट में गाने गा रही होगी?
**Romanized:** (Kya vah aaj shaam ko event me gaane ga rahi hogi?)
**English answer:** Will she be singing songs at the event in the evening today?

### 424. वह कल स्कूल क्यों नहीं जा रही होगी?
**Romanized:** (Vah kal school kyon nahi ja rahi hogi?)
**English answer:** Why will she not be going to school tomorrow?

### 425. क्या कल बारिश नहीं हो रही होगी?
**Romanized:** (Kya kal baarish nahi ho rahi hogi?)
**English answer:** Will it not be raining tomorrow?

### 426. वह 2025 तक बहुत पैसा कमा चुका होगा।
**Romanized:** (Vah 2025 tak bahut paisa kama chukka hoga.)
**English answer:** He will have earned a lot of money by 2025.

### 427. वह 2020 तक ग्रेजुएशन कर चुकी होगी।
**Romanized:** (Vah 2020 tak graduation kar chuki hogi.)
**English answer:** She will have graduated by 2020.

### 428. वह 2025 तक बहुत पैसा नहीं कमा चुका होगा।
**Romanized:** (Vah 2025 tak bahut paisa nahi kama chukka hoga.)
**English answer:** He will not have earned a lot of money by 2025.

### 429. वह 2020 तक ग्रेजुएशन नहीं कर चुकी होगी।
**Romanized:** (Vah 2020 tak graduation nahi kar chuki hogi.)
**English answer:** She will not have graduated by 2020.

### 430. क्या वह 2025 तक बहुत पैसा नहीं कमा चुका होगा?
**Romanized:** (Kya vah 2025 tak bahut paisa nahi kama chukka hoga?)
**English answer:** Will he have earned a lot of money by 2025?

### 431. कौन-2 घर नहीं आया?
**Romanized:** (Kaun-2 ghar nahi aaya?)
**English answer:** Who all did not come home?

### 432. मैं वहाँ कम से कम एक बार जाऊँगा।
**Romanized:** (Main vahaan kam se kam ek baar jaunga.)
**English answer:** I will go there at least once.

### 433. क्या वो खेल रहा है?
**Romanized:** (Kya vo khel raha hai?)
**English answer:** Is he playing?

### 434. वो क्या खेल रहा है?
**Romanized:** (Vo kya khel raha hai?)
**English answer:** What is he playing?

### 435. हम 4 बजे तक ऑफिस पहुँच चुके होंगे।
**Romanized:** (Hum 4 baje tak office pahunch chuke honge.)
**English answer:** We will have reached the office by 4 o’clock.

### 436. आप उसका दिल दुखाते हो।
**Romanized:** (Aap uska dil dukhate ho.)
**English answer:** You hurt him.

### 437. वह दो महीने से शाकाहारी भोजन क्यों खा रहा था?
**Romanized:** (Vah do mahine se shakahari bhojan kyu kha raha tha?)
**English answer:** Why had he been eating vegetarian food for two months?

### 438. आपने उसका दिल दुखाया।
**Romanized:** (Aapne uska dil dukhaya.)
**English answer:** You hurt him.

### 439. उसके माता पिता उस पर भरोसा नहीं करते।
**Romanized:** (Uske mata pita us par bharosa nahi karte.)
**English answer:** His parents do not trust him.

### 440. मैंने किताब नहीं खरीदी।
**Romanized:** (Maine kitaab nahi kharidi.)
**English answer:** I did not buy the book.

### 441. वो लोग मेरे साथ नहीं रहते हैं।
**Romanized:** (Vo log mere sath nahi rahte hain.)
**English answer:** Those people do not live with me.

### 442. उसने गलती क्यों की?
**Romanized:** (Usne Galati kyon kee.)
**English answer:** Why did he make a mistake?

## Source-text notes

- **Item 31:** The printed Hindi says लड़के (ladke, boys), while the printed Romanized line says ladki (girl); both source readings are retained separately.
- **Item 139:** The printed Romanized line ends after the question mark without a closing parenthesis; the transcript groups that unchanged line in parentheses for consistent formatting.
- **Item 305:** The printed Hindi says कर रहा है (kar raha hai), while the Romanized line says kar raha tha; both are preserved as printed.
- **Item 342:** The printed Romanized line reads ja he, an obvious omission in the word corresponding to Hindi जा रहे; it is normalized to ja rahe without changing meaning.
- **Item 353:** The source has no parentheses around the Romanized line; it is grouped in parentheses in the transcript for consistent formatting.
- **Item 384:** The printed Hindi says किताबें (books), while the printed Romanized line has singular kitaab; both are preserved as printed.

**Editorial corrections:** Obvious OCR or spelling errors in Hindi were corrected against the page images for items 10, 42, 57, 78, 114, 165, 188, 202, 239, 270, 286, 301, 314, 379, 387, 388, 395, 405 and 406. Item 342 has an obvious missing-letter error in the printed Romanized line, normalized using its Hindi counterpart. Other wording and source discrepancies are preserved and noted above.

**Unreadable text:** none identified.

