# Lesson 39 — 1500+ MCQs
Source: PDF pages 478–686 (printed pages 477–685).

**Choose the correct alternative.**

## Quiz 1

```text
Choose the correct alternative:
Q 1: You have to wait……….. I am back.
a) till
b) until
c) unless
d) while
Q 2: …………. Dogs seldom bite.
a) Bark
b) Barking
c) To Bark
d) To Barking
Q 3: Change the following sentence into Interrogative:
     ‚He bought a pen.‛
a) Does he buy a pen?
b) Did he bought a pen?
c) Did he buy a pen?
d) Does he bought a pen?
Q 4: Change into Passive Voice:
      ‚He sent me there.‛
a) I am sent there by him.
b) I was sent there by him.
c) I had been sent there by him.
d) I have been sent there by him.
Q 5: Change into Active Voice:
     ‚They should have been given money by you.‛
a) You should give them money.
b) You should have given them money.
c) You should be given the money
d) You should have give them money.

Q 6: Choose the correct spelling?
a) Heinous
b) Hienous
c) Hinious
d) Hinous
Q 7: Synonym of the word ‚Astonish‛ is:
a) Alumni
b) Enjoy
c) Astound
d) Asterisk
Q 8: Antonym of the word ‚Apparent‛ is:
a) Abundant
b) Hidden
c) Obvious
d) Awkward
Q 9: Translate the following sentence into English:
      वो मुझे जाने नह ीं दे रहा। (Vo mujhe jaane nahi de raha.)
a) He is not let me go.
b) He is not letting me go.
c) He is not being let me go.
d) He is not let me going.
Q 10: He ………….. a book since morning.
a) is reading.
b) was reading.
c) has been reading.
d) have been reading
Q 11: He wants to become a doctor, ………….
a) So did I.
b) So do I.
c) So I did.
d) So I do.
Q 12: He doesn’t like me, ………………….
a) Nor does she.
b) Nor do she.
c) Nor she does.
d) Nor she do.

Q 13: If I had visited Agra, I …………… the Taj.
a) saw.
b) would see.
c) had seen.
d) would have seen.
Q 14: Rahul found the flat…………….
a) locked.
b) locking.
c) has been locked.
d) had been locked.
Q 15: Add question tag: ‚He knows me,…………‛
a) doesn’t he?
b) don’t I?
c) isn’t it?
d) All of the above.
Q 16: This is ……. university.
a) a
b) an
Q 17: In a sentence ‚Raveena is a very clever lady‛, what is ‘very' here?
a) An adjective
b) An adverb
c) A determiner
d) A conjunction
Q 18: In a sentence ‘Love is life’, what is ‘Love'?
a) A verb
b) A noun
c) A Gerund
d) An infinitive
Q 19: Which of the following is an ‚Adverb of Location‛?
a) Fast
b) Daily
c) Late
d) Far
Q 20: Choose the correct spelling?
a) Pronunciation
b) Pronounciation

Q 21: Which part of the following sentence is erroneous?
Generally (A) / Daughter-in-laws (B)/ don’t like (C)/ their mothers-in-law. (D)
a) A
b) B
c) C
d) D
Q 22: Which part of the following sentence is erroneous?
I recall you scolding (A) / him when he shouted (B) / at the poor (C) / No error (D)
a) A
b) B
c) C
d) D
Q 23: Which part of the following sentence is erroneous?
Each one of my friends (A) / are (B) / a smart worker. (C) / No error (D)
a) A
b) B
c) C
d) D
Q 24: Translate the following sentence into English:
       वो राकेश से काम करवाता है । (Vo Rakesh se kaam karvata hai.)
a) He makes Rakesh work.
b) He got Rakesh work.
c) He made Rakesh work.
d) He let Rakesh work.
Q 25: Translate the following sentence into English:
         मैंने उसे जाने हदया। (Maine use jaane diya.)
a) I letted him go.
b) I let him go.
c) I let him went.
d) I did let him went.
Q 26: This is a saying: ‚ All that glitters ……… not gold ‚
a) is
b) are
Q 27: I have a chair,…………. are broken.
a) whose legs
b) the legs of whose
c) which legs

d) the legs of which
Q 28: I have a friend, …………….. are broken.
a) whose legs
b) the legs of whose
c) which legs
d) the legs of which
Q 29: Which word is similar to treacherous?
a) Traitorous
b) Ludicrous
Q 30: Which word is similar to lurch?
a) Unbelievable
b) Stagger
Q 31: In this phrase/idiom i.e. ‚To err is human‛, what is ‘To err'?
a) Infinitive form
b) Bare infinitive form
c) Gerund form
d) Participle form
Q 32: Change into Indirect Speech:
       Rahul said to me, "I will meet people following me on FB.‛
a) Rahul told me that he will meet people following him on FB.
b) Rahul told me that I will meet people following me on FB.
c) Rahul told me that he would meet people following me on FB.
d) Rahul told me that he would meet people following him on FB.
Q 33: Change into Indirect Speech:
       Arohi said to Ayansh, ‚Let her complete the homework first.‛
a) Arohi suggested to Ayansh that she should complete the homework first.
b) Arohi asked Ayansh that she should let her complete the homework first.
c) Arohi suggested to Ayansh that she should let complete the homework first.
d) Arohi ordered Ayansh that she should let complete homework first.
Q 34: Change into Indirect Speech:
       Arnavi said," why am I here?"
A) Arnavi asked why was I there.
B) Arnavi asked why I was there.
C) Arnavi asked why was she there.
D) Arnavi asked why she was there.

Q 35: Which of the following sentences is incorrect?
a) He is a learned person.
b) There are peoples from India, Australia, and England.
c) I have a few money in my pocket.
d) To eat burger is his habit.
Q 36: Which of the following words is incorrect?
a) Burdensome
b) Troublesome
c) Bothersome
d) Problemsome
Q 37: The sentence ‚This is a girls’ hostel.‛ is:
a) Correct
b) Incorrect
Q 38: The sentence ‚This is his.‛ is:
a) Correct
b) Incorrect
Q 39: What does the word ‘SHIRK’ mean?
a) To avoid
b) To destroy
c) To co-operate
d) To elongate
Q 40: Which of the following is a correct statement?
a) ‘Shop’ is an abstract noun.
b) ‘Boy’ is a proper noun.
c) ‘Crowd’ is a collective noun.
d) ‘India’ is a common noun.
Q 41: Which of the following is an incorrect statement?
a) ‘Gold’ is a material noun.
b) ‘Her’ is a possessive pronoun.
c) ‘Myself’ is an intensive pronoun.
d) ‘Him’ is a subjective pronoun.
Q 42: What does the word ‚Deja vu" mean?
a) Already seen
b) Never seen
c) Repeatedly seen
d) Continuously seen

Q 43: Choose the correct spelling:
a) Tomorrow
b) Tommorrow
Q 44: Choose the correct spelling:
a) Weird
b) Wierd
Q45: This building is said to …………. constructed 3 years ago.
a) be
b) have been
c) having been
d) have
Q46: I was sitting ………. many.
a) between
b) among
c) amongst
d) None of the above
Q47: This mobile is made …….. plastic.
a) of
b) by
c) up of
d) up with
Q48: Mr. John Smith in an ……….. India.
a) emigrant in
b) emigrant from
c) immigrant in
d) immigrant from
Q49: The executioner ………… the criminal.
a) hanged
b) hung
c) hang
d) hanging
Q50: In the sentence ‚I have nothing to eat.‛, what is ‚to eat‛ here?
a) Noun Infinitive
b) Adjectival Infinitive
c) Adverbial Infinitive
d) Bare Infinitive

Answers
1b, 2b, 3c, 4b, 5b, 6a, 7c, 8b, 9b, 10c, 11b, 12a, 13d, 14a, 15a, 16a, 17b, 18b, 19d,
20a, 21b, 22a, 23b, 24a, 25b, 26a, 27d, 28a, 29a, 30b, 31a, 32d, 33a, 34d, 35c, 36d,
37a, 38a, 39a, 40c, 41d, 42a, 43a, 44a, 45b, 46c, 47a, 48a, 49a, 50b
```

## Quiz 2

```text
Choose the correct alternative:
Q 1: Repair the ………. window just now.
a) broken
b) break
c) breaking
Q 2: My younger brother used to ………..tennis in his childhood.
a) play
b) playing
c) played
Q 3: I could not go to school yesterday…………I was not well.
a) because
b) until
c) unless
d) since
Q 4: Rama wanted to know……….she …… doing.
a) Where, is
b) what, is
c) while, was
d) what, was
Q 5: Her father is ………… M. L. A.
a) a
b) an
Q 6: Distribute these sweets ……..the children.
a) Between
b) among
c) amongst

Q 7: He has invited………to his birthday party.
a) them
b) their
c) they
d) to them
Q 8: The student has been suffering ……. fever……. 3 days.
a) from, for
b) from, since
c) with, for
d) with, since
Q 9: We ……… go to school tomorrow.
a) can
b) must
c) may
d) All of the above
Q10: My brother is………. S. D. O.
a) a
b) an
Q 11: Mohan invites……. in his birthday party.
a) they
b) those
c) them
Q 12: Ravi didn’t ……….. a football.
a) have
b) has
c) had
Q 13: I met a man having lots of money.
a) having
b) to having
c) to have
d) have
Q 14: My father is a …….. teacher.
a) retire
b) retiring
c) retired

Q 15: .………..the snake, he was afraid.
a) See
b) Seeing
c) Saw
d) Having seeing
Q 16: He jumped…….the horse.
a) on
b) onto
c) upon
d) Any of the above
Q 17: He is not suitable………..this post.
a) to
b) at
c) for
Q 18: Mr. Das is a rich person……….not happy.
a) if
b) but
c) and.
d) yet
Q 19.: Mohan was very tired, so he …….. to bed early.
a) go
b) went
c) gone
d) going
Q 20: The sun rises …….. the east.
a) in
b) from
c) by
d) beyond
Q 21: It was dark, so l…………….a torch with me.
a) take
b) took
c) taken
d) taking

Q 22: Boys were seated on…………..chair.
 a) every
 b) each
 c) all
Q 23: I don’t like………….of them.
a) either
b) neither
Q 24: Abhishek hates………….rich.
a) a
b) an
c) the
Q 25: …………. room of this hotel has a cooler.
 a) Each
 b) Every
 c) Many
 d) All
Q 26: …………care would save you from many accidents.
a) A few
b) The few
c) A little
                                         Answers
1a, 2a, 3a, 4b, 5b, 6b, 7a, 8a, 9d, 10b, 11c, 12a, 13a, 14c, 15b, 16d, 17c, 18b, 19b,
20a, 21b, 22a, 23a, 24c, 25b, 26c.
```

## Quiz 3

```text
Choose the correct alternative:
Q 1: He is in ………..class.
a) Twelth
b) Twelfth
c) Twelve
Q 2: ‚Do you get it‛ means
a) Do you understand?
b) Do you feel comfortable?
c) Do you keep quiet?
d) Do you feel bad?

Q 3: Change the following sentence into Interrogative:
     ‚He needs me.‛
a) Does he need me?
b) Did he need me?
c) Need he me?
d) Do he need me?
Q 4: Change into Passive Voice:
     ‚I can reveal the truth.‛
a) The truth can revealed by me.
b) The truth can be reveal by me.
c) The truth can be revealed by me.
d) The truth can reveal by me.
Q 5: Change into Active Voice:
     ‚They should have been interrogated by police.‛
a) Police should have interrogate them.
b) Police should have interrogated them.
c) Police should interrogate them.
d) Police should interrogated them.
Q 6: I’ll give you money………..you help me.
a) provided
b) provide to
c) so as to
d) as far as
Q 7: ‚Asterisk‛ is:
A) A star symbol
b) An ampersand symbol
c) A hyphen symbol
d) An underscore symbol
Q 8: Antonym of the word ‚Awesome‛ is:
a) Awful
b) Aweful
c) Awe
d) Awkward

Q 9: Translate the following sentence into English:
      वो मुझे खेलने नह ीं दे ता. (Vo mujhe khelne nahi deta.)
a) He does not let me played.
b) He does not let me play.
c) He is not let me played.
d) He is not let me play.
Q 10: Do you know……………….
a) who I am?
b) who am I?
c) who I am.
d) who am I.
Q 11: He generally avoids the work. He is a…………..
a) shirker
b) merger
c) coward
d) healer
Q 12: He is angry with me ……… I’ve done something wrong.
a) even if
b) as if
c) pretended
d) even though
Q 13: If I had called you, you ……………. happier.
a) would
b) would be
c) would have
d) would have been
Q 14: In a sentence ‚I’d to go home yesterday.‛, I’d = ?
a) I had.
b) I would.
Q 15: A cricket team is ……….. 11 players.
a) made of
b) made by
c) made up of
d) made up by

Q 16: This is ……. union’s decision.
a) a
b) an
Q 17: In a sentence ‚He has a smiling face.‛, what is ‘smiling’ here?
a) An adjective
b) An adverb
c) A determiner
d) A conjunction
Q 18: In a sentence ‘Honesty is the best policy’, what is ‘Honesty'?
a) A verb
b) A noun
c) A gerund
d) An infinitive
Q 19: A phrasal verb ‚Get at‛ means
a) to depress
b) to proceed
c) to try to express
d) to recover
Q 20: Which letter is silent in the word ‚ADJACENT‛?
a) D
b) J
c) T
d) J & T
Q 21: Which part of the following sentence has an error?
Each of you has (A) / some or the other (B)/ assign work (C)/ No error. (D)
a) A
b) B
c) C
d) D
Q 22: Which part of the following sentence has an error?
He and me (A) / are in the same team (B) / but we differ (C) / in opinion. (D)
a) A
b) B
c) C
d) D

Q 23: Which part of the following sentence has an error?
My elderly uncle (A) / asked me that (B) / what I was doing. (C) / No error (D)
a) A
b) B
c) C
d) D
Q 24: Translate the following sentence into English:
        वो लापरवाह है । (Vo laaparvaah hai.)
a) He is a shirker.
b) He is an author.
c) He is negligent.
d) He is cautious.
Q 25: Translate the following sentence into English:
         मैंने उसे खेलने नह ीं हदया। (Maine use khelne nahi diya.)
a) I let him not play.
b) I did let him not play.
c) I letted him not play.
d) I let him not played.
                                          Answers
1b, 2a, 3a, 4c, 5b, 6a, 7a, 8a, 9b, 10a, 11a, 12 b, 13d, 14a, 15c, 16a, 17a, 18b, 19c,
20a, 21c, 22a, 23b, 24c, 25a.
```

## Quiz 4

```text
Choose the correct alternative:
Q 1: This is an idiom: ‚All’s well ……… ‛
a) that ends good.
b) that ends well.
c) that finishes good.
d) that finishes well.
Q 2: It’s Ram,…………. I had taken for a day.
a) whose mobile
b) the mobile of whose
c) which mobile
d) the mobile of which

Q 3: Boys were ……….. on ………. chair.
a) seated, each
b) seated, every
c) sitted, each
d) sitted, all
Q 4: Which word is similar to Gigantic?
a) Enormous
b) Exclusive
c) Endeavor
Q 5: Which word is similar to Pang?
a) Cramp
b) Emotion
c) Suppress
Q 6: In a sentence, ‚Working lady can also be a good house maker‛, what is
‘Working'?
a) Infinitive form
b) Bare infinitive form
c) Gerund form
d) Participle form
Q 7: Change into Indirect Speech:
       He said, "I must work now.‛
a) He said that he must to work then.
b) He said that he had to work then.
c) He told that he must to work now.
d) He told that he must have to work then.
Q 8: Change into Indirect Speech:
       He said to her, ‚Are you going?‛
a) He asked her if you were going.
b) He asked her if she was going.
c) He asked her that was she going.
d) He asked her that she was going.
Q 9: Change into Indirect Speech:
       He asked," who called me?"
A) He asked that who called him.
B) He asked that who had called him.
C) He asked who called him.
D) He asked who had called him.

Q 10: Which of the following sentences is incorrect?
a) I don’t like either of you.
b) I don’t like neither of you.
c) I don’t like any of you.
d) I don’t like going with you.
Q 11: I don’t have …………. water.
a) any
b) many
c) few
d) a few
Q 12: Always help ………….
a) the poors
b) the poor
Q 13: The sentence ‚This mobile is hers.‛ is:
a) Correct
b) Incorrect
Q14: What does the word ‘sadden’ mean?
a) To act immediately
b) To make sad
c) To shock
d) To surprise
Q 15: Which of the following is an incorrect statement?
a) ‘Pang’ may be used as a verb as well as a noun.
b) ‘Address’ may be used as a verb as well as a noun.
c) ‘Love’ may be used as a verb as well as a noun.
d) ‘Will’ may be used as a verb as well as a noun.
Q 16: Which of the following is an incorrect statement?
a) ‘Silver’ is a material noun.
b) ‘Hers’ is a possessive pronoun.
c) ‘Myself’ is an objective pronoun.
d) ‘Yourself’ is a reflexive pronoun.
Q 17: What does the word ‚Anguish" mean?
a) Alimony
b) Agony
c) Bliss
d) Broom

Q 18: I want to ………. weight.
a) lose
b) loss
c) loose
Q 19: There is a saying, ‚……..knowledge is a dangerous thing.‛
a) Little
b) A little
c) The little
d) Less
Q 20: He is ……………playing footwall right now.
a) suppose to
b) supposed to
c) suppose to be
d) supposed to be
Q 21: Rearrange it:
     {you/have/how much/experience/got/?}
a) How much have you got experience?
b) How much you have got experience?
c) How much experience have you got?
d) How much experience you have got?
Q 22: Rearrange it:
     {in/that/book/are /there/pages/how/many/?}
a) How many are there pages in that book?
b) How many pages are there in that book?
c) How many are pages there in that book?
d) How many pages there are in that book?
Q 23: I have no idea……………..
a) who are you?
b) who are you.
c) who you are?
d) who you are.
Q 24: I have ………… the shirt behind the door.
a) hanged
b) hung
c) hang
d) hanging

Q 25: I………….to go there now.
a) am
b) will
c) should
d) would
                                         Answers
1b, 2a, 3b, 4a, 5a, 6d, 7b, 8b, 9d, 10b, 11a, 12 b, 13a, 14b, 15a, 16c, 17b, 18a, 19b,
20d, 21c, 22b, 23d, 24b, 25a.
```

## Quiz 5

```text
Choose the correct alternative:
Q 1: The ………. investigation of CBI will unearth the identity of the actual
culprit.
a) exhaustive
b) through
c) detail
d) allies
Q 2: In a sentence, ‚I love driving.‛, what is ‚driving‛?
a) Gerund
b) Present Participle as a verb
c) Present Participle as an adjective
d) Perfect Participle
Q 3: The sentence ‚His daughter is as beautiful as a rose.‛ is an example of
which figure of speech?
a) Personification
b) Metaphor
c) Simile
d) Hyperbole
Q 4: Which word is similar to ‚Defame‛?
a) Calumniate
b) Cultivate
c) Columnist
d) Pathetic

Q 5: Which word is opposite to ‚Immense‛?
a) Huge
b) Tiny
c) Astonish
d) Crumple
Q 6: In a sentence, ‚Her gaze shifted from me to you.‛, what is the word ‘Gaze’
here?
a) A verb
b) A noun
c) An adjective
d) A bare infinitive
Q 7: Change into Indirect Speech:
       He said, "Shall we start?‛
a) He asked if they shall start.
b) He asked that we should start.
c) He asked that they should start.
d) He asked if they should start.
Q 8: A sentence ‚He saw a man who was blind.‛ is a:
a) A simple sentence
b) A complex sentence
c) A compound sentence
Q 9: ‚Either…or‛ is:
A) A cumulative conjunction
B) An adversative conjunction
C) An alternative conjunction
D) An Illative conjunction
Q 10: He is blind …… one eye.
a) of
b) with
c) in
d) by
Q 11: I don’t have …………. petrol in my car.
a) any
b) little
c) few
d) a few

Q 12: In a sentence, ‚Tell that girl there.‛, ‚There‛ is used as:
a) an adverb
b) an adjective
c) an interjection
d) a pronoun
Q 13: The sentence ‚He was in your position 3 years ago.‛ is an example of:
a) The Indicative mood
b) The Imperative mood
c) The Interrogative mood
d) The Subjunctive mood
Q14: The one who lives with the trend is known as:
a) Contemporary
b) Fastidious
c) Omnivorous
d) Philanthropist
Q 15: Practice of having more than one wife at a time is known as:
a) Polyandry
b) Polygamy
Q 16: We must win the final war ………………how many battles we’ve lost
before.
a) except of
b) irrespective of
c) apart from
d) besides of
Q 17: What does the word ‚Bliss" mean?
a) Great joy
b) Great agony
c) Great surprise
d) Great shock
Q 18: The contraction of ‚shall not‛ is
a) Shalln’t
b) Shan’t
c) Shaln’t
d) Shaln’t

Q 19: What does ‚o’clock‛ stands for?
a) On the clock
b) Over the clock
c) Of the clock
d) Onto the clock
Q 20: He ..…………… finished the homework by now.
a) is supposed to be
b) is supposed to have
c) has supposed to be
d) has supposed to have
Q 21: Rearrange it:
     {do/have/how many/pens/you/often/in your bag?}
a) How many pens you do have often in your bag?
b) How many do you have pens often in your bag?
c) How many pens do you have often in your bag?
d) How many pens do you often have in your bag?
Q 22: Translation of the sentence ‚Rahul mujhse chhota hai.‛ is:
       Rahul is …………..
a) younger than I.
b) younger than me.
c) younger to I.
d) younger to me.
Q 23: Translation of the sentence ‚Rahul mujhse badaa hai.‛ is:
       Rahul is …………..
a) elder than I.
b) elder than me.
c) elder to I.
d) elder to me.
Q 24: I have three important …………….. for you.
a) information
b) informations
c) piece of informations
d) pieces of information

Q 25: Translation of the sentence ‚Rahul ke paas pen hona chahiye tha.‛ is:
       Rahul ………….. a pen.
a) should has had
b) should have
c) should have had
d) should has
                                          Answers
1a, 2a, 3c, 4a, 5b, 6b, 7d, 8b, 9c, 10a, 11a, 12 b, 13d, 14a, 15b, 16b, 17a, 18b, 19c,
20b, 21d, 22d, 23a, 24d, 25c.
```

## Quiz 6

```text
Choose the correct alternative:
Q1: What is PANGRAM in a language?
 a) A sentence containing all the letters of the Alphabet.
 b) A sentence containing all the vowels of the Alphabet.
 c) A sentence containing all the consonants of the Alphabet.
 d) sentence containing no consonants of the Alphabet.
Q2. He had ..........supporters.
 a) few
 b) a few
 c) the few
 d) none of the above
Q3. He will get a driving licence as soon as he…….. drive well.
 a) will
 b) shall
 c) may
 d) can
Q4: If I………..your friend, I would help you.
 a) were
 b) was
 c) am
 d) have

Q5: It has been many days having……….you.
 a) meet
 b) met
 c) meeting
 d) been
Q6: This building is said to …………. constructed 3 years ago.
 a) be
 b) have been
 c) having been
 d) have
Q7: I pretended ……..I was not well.
 a) as if
 b) as though
 c) so as to
 d) a & b
Q8: I will come…….Holi.
 a) on
 b) in
 c) at
 d) upon
Q9: If I ……… there, I ………. met him.
 a) had been, would have
 b) had been, would
 c) was, would
Q10: There is a river……….this mountain.
a) beyond
b) across
c) cross
d) away
Q11: …………… an apple is the part of my daily routine.
 a) Eating
 b) To eat

c) Eat
 d) Either (1) or (2)
Q12: I’d is the contraction of
 a) I would
 b) I could
 c) I should
 d) Either (1) or (3)
Q13: He ………. here for a long.
 a) is
 b) was
 c) has been
 d) have been
Q14: In the sentence ‚He is being very selfish.‛, what is ‚very‛ here?
 a) Adjective
 b) Adverb
 c) Preposition
 d) Conjunction
Q15: ‚Mujhe ghar jaana pad raha hai.‛ How to translate it into English:
 a) I am to go home.
 b) I have to go home.
 c) I am having to go home.
 d) I have to be going home.
Q16: .‚Ye kitab uski hai.‛ How to translate it into English:
 a) This book is hers.
 b) This book is her.
 c) Either (1) or (2)
 d) Neither (1) nor (2)
Q17: By the time he reached home, I ………….. the food.
 a) have had
 b) had had
 c) would have had
 d) will have had

Q18: In the sentence ‚Honesty is the best policy.‛, what is ‚Honesty‛ here?
 a) Proper Noun
 b) Common Noun
 c) Collective Noun
 d) Abstract Noun
Q19: In the sentence ‚There is no shortage of water in my village.‛, what is
‚water‛ here?
 a) Common Noun
 b) Abstract Noun
 c) Collective Noun
 d) Material Noun
Q20: How to translate ‚Vo achchha insan hone ka dikhawa karta hai‛?
 a) He pretends to be a good person.
 b) He pretends being a good person.
 c) Either (1) or (2)
 d) Neither (1) nor (2)
Q21: What is the 3rd form (Past participle form) of the verb ‚SHOW‛?
 a) Showed
 b) Shown
 c) Both of the above
 d) None of the above
Q22: {Kaash usne mujhe dekha hota.} How to translate it:
 a) I wish he had seen me.
 b) I wish he would see me.
 c) I wish I saw me.
 d) All of the above
Q23: What is the 3rd form (Past participle form) of the verb ‚GET‛?
 a) Gotten
 b) Got
 c) Both of the above
 d) None of the above
Q24: This is a ……….. hostel.
 a) girl
 b) girls
 c) girl’s
 d) girls’

Q25: In the sentence ‚I have nothing to eat.‛, what is ‚to eat‛ here?
 a) Noun Infinitive
 b) Adjectival Infinitive
 c) Adverbial Infinitive
 d) Bare Infinitive
                                          Answers
1a, 2b, 3d, 4a, 5b, 6b, 7d, 8c, 9a, 10a, 11d, 12 a, 13c, 14b, 15c, 16a, 17b, 18d, 19d,
20a, 21c, 22a, 23c, 24d, 25b.
```

## Quiz 7

```text
Choose the correct alternative:
Q1: Are you going to ………………… with your brothers while you are in
Dehradun?
a) getting in touch
b) get in touch
c) having in touch
d) have in touch
Q2: Her face turned ……………… with anger.
a) red
b) blue
c) green
d) violet
Q3: She ………………….. an engineer from Manipur.
a) married
b) married with
c) married to
Q4: She is …………………. than I thought.
a) more fool
b) more of a fool
c) more like a fool
d) more as a fool
Q5: You can keep my mobile if you like. I ..... it any more.
a) don`t use

b) doesn`t use
c) didn`t use
d) am not using
Q6: What time ............
a) the train leaves?
b) leaves the train?
c) is the train leaving?
d) does the train leave?
Q7: Your phone ...... Can you answer it, please?
a) rings
b) ring
c) rang
d) is ringing
Q8: I've just finished reading a story called Great Ambition. It's about a boy
who ..... his friend because he doesn't want him to achieve more than him.
a) kills
b) killed
c) kill
d) is killing
Q9: I ………….. football every Sunday morning.
a) playing
b) play
c) am playing
d) am play
Q10: Sorry, she can't pick up the phone. She ..... a bath!
a) is having
b) having
c) have
d) has
Q11: Babies ..... when they want someone’s attention.
a) cry
b) cries
c) cried
d) are crying

Q12: Ruby ......... her blue jeans yesterday.
a) was suppose to
b) was supposed to
c) had suppose to
d) had supposed to
Q13: .……………….. is used to indicate possession.
a) A quotation
b) An apostrophe
c) A hyphen
d) An ampersand
Q14: When a comma is used …….., the meaning is ……..
a) inappropriately, maintained
b) illegibly, changed
c) inappropriately, changed
d) illegibly, maintained
Q15: The symbol ‚&‛ is known as
a) A quotation
b) An apostrophe
c) A hyphen
d) An ampersand
Q16: Is this your …………?
a) liking
b) like
c) likes
Q17: In recent years, He has been regaining ……….
a) popularly
b) population
c) popularity
d) popular
Q18: As ___, he forgot to bring his wallet.
a) usual
b) usually

Q19: Does he ___ his brother?
a) resembles to
b) resemble
c) resemble to
d) resembles
Q20: I'm sure there's nothing between…………….
a) you and he.
b) you and him.
                                          Answers
1b, 2a, 3a, 4b, 5a, 6d, 7d, 8a, 9b, 10a, 11a, 12 b, 13b, 14c, 15d, 16a, 17c, 18a, 19b,
20b.
```

## Quiz 8

```text
Choose the correct alternative:
Q1: Change the following sentence into Interrogative:
     ‚They dare shout at him.‛
a) Dare they shout at him?
b) Are they dare shout at him?
c) Do they dare shout at him?
d) Does they dare shout at him?
Q2: Change into Passive Voice:
     ‚I let him go.‛
a) He is let go by me.
b) He let go by me.
c) He has let go by me.
d) He is letted go by me.
Q3: Change into Active Voice:
     ‚He should have been interrogated by the police.‛
a) The police should interrogate him.
b) The police should have interrogate him.
c) The police should have interrogated him.
d) The police should have been interrogated by him.
Q4: Choose the correct spelling?
a) Astarisk
b) Asterisk
c) Astirisk
d) Aastirisk

Q5: Synonym of the word ‚Astound‛ is:
A) Incredible
b) Enjoy
c) Astonish
d) Alter
Q6: Antonym of the word ‚Poverty‛ is:
a) Poor
b) Wealth
c) Liberty
d) Awkward
Q7: Translate the following sentence into English:
       मुझे घर जाना पड़ता। (Mujhe ghar jaana padta.)
a) I will have to go home.
b) I would have to go home.
Q8: He ………….. English for 2 years.
a) is learning.
b) was learning.
c) has been learning.
d) have been learning
Q9: He wants to gain good knowledge, ………….
a) So did I.
b) So do I.
c) So I did.
d) So I do.
Q10: You don’t love me, ………………….
a) Nor does she.
b) Nor do she.
c) Nor she does.
d) Nor she do.
Q11: If I had given you the books, you……… the exam.
a) passed
b) would pass
c) had passed
d) would have passed

Q12: He …………..me there.
a) founded
b) found
c) finded
d) find
Q13: Add question tag: ‚You like me,…………‛
a) doesn’t you?
b) don’t you?
c) isn’t you?
d) aren’t you?
Q14: He is ……. MLA.
a) a
b) an
Q15: In a sentence ‚I am gonna see you today.‛, what is ‘gonna' here?
a) A slang word
b) A unique word
c) A stylish word
d) A new word
Q16: Which part of the following sentence is erroneous?
Generally (A) / an unique person (B)/ makes (C)/ good impression on others. (D)
a) A
b) B
c) C
d) D
Q17: Which part of the following sentence is erroneous?
I recall you (A) / beating me when (B) / I was a kid (C) / No error (D)
a) A
b) B
c) C
d) D
Q18: Translate the following sentence into English:
      हमें सोचना होगा। (Hame sochna hoga.)
a) We will have to think.
b) We would have to think.

Q19: Translate the following sentence into English:
        काश मैं तुमसे हमल पाता। (Kaash main tumse mil paata.)
a) I wish I would meet you.
b) I wish I could meet you.
c) I wish I had met you.
d) I wish I would have met you.
Q20: He has been looking for a job……….yesterday morning.
a) since
b) from
c) for
d) by
                                          Answers
1a, 2a, 3c, 4b, 5c, 6b, 7b, 8c, 9b, 10a, 11d, 12b, 13b, 14b, 15a, 16b, 17a, 18a, 19b,
20a.
```

## Quiz 9

```text
Choose the correct alternative:
Q1: Translate the following sentence into English:
       मुझे ज़ाऩा है । (Mujhe jaana hai.)
a) I have to go.
b) I got to go.
c) I have got to go.
d) All of the above
Q2: Which part of the following sentence is erroneous?
Each of you (A) / have (B)/ a unique idea (C)/ to grow business. (D)
a) A
b) B
c) C
d) D
Q3: Which part of the following sentence is erroneous?
I (A) / don’t have (B) / any water (C) / No error (D)
a) A
b) B
c) C
d) D

Q4: Translate the following sentence into English:
      हमें सोचना होता। (Hame sochna hota.)
a) We will have to think.
b) We would have to think.
Q5: Translate the following sentence into English:
        काश वो मेरा बेटा होता। (Kaash vo mera beta hota.)
a) I wish he was my son.
b) I wish he were my son.
Q6: Nothing worries ………….me.
a) to
b) of
c) for
d) No preposition
Q7: Translate the following sentence into English:
       मैं घर आत़ा और आपसे दमलत़ा। (Main ghar aata aura aapse milta.)
a) I would come home and meet you.
b) I would have come home and meet you.
c) I came home and meet you.
Q8: Translate the following sentence into English:
       मैं 5 स़ाल ददल्ली रह चु क़ा हँ । (Main 5 saal Delhi rah chuka hun.)
a) I have been in Delhi for 5 years.
b) I have been to Delhi for 5 years.
Q9: Translate the following sentence into English:
       मैं एक ब़ार ददल्ली ज़ा चु क़ा हँ । (Main ek baar Delhi jaa chuka hun.)
a) I have been in Delhi once.
b) I have been to Delhi once.
Q10: One, who just believes in luck is known as
a) Invincible
b) Fatalist
c) Bigot
d) Orthodox
Q11: Introductory preface of a drama is called
a) Ideology
b) Calligraphy
c) Prologue
d) Antidote

Q12: Government by people, of people, for people is known as
a) Autocracy
b) Bureaucracy
c) Democracy
d) Monarchy
Q13: Add question tag: This book’s seen everywhere, …………
a) hasn’t it?
b) isn’t it?
Q14: I am looking forward to……………..your brother.
a) call
b) calling
Q15: Change the following sentence into negative:
     ‘He would have been working with me.’
a) He would have not been working with me.
b) He would not have been working with me.
c) He would have been not working with me.
d) He would have been working not with me.
Q16: Change into Passive Voice:
     ‘I make you do it.’
a) You are made do it by me.
b) You are made done it by me.
Q17: Change into Active Voice:
     ‘I can’t be made happy by anyone.’
a) Anyone can’t make me happy.
b) Anyone can’t make me be happy.
c) No one can make me happy.
d) No one can make me be happy.
Q18: Choose the correct spelling?
a) Misspell
b) Mispell
Q19: Synonym of the word ‘Amalgamate’ is:
A) Separate
b) Consolidate

Q20: Antonym of the word ‘Anxiety’ is:
a) Serenity
b) Apprehension
                                         Answers
1d, 2b, 3d, 4b, 5b, 6d, 7a, 8a, 9b, 10b, 11c, 12c, 13b, 14b, 15b, 16a, 17c, 18a, 19b,
20a.
```

## Quiz 10

```text
Choose the correct alternative:
Q1: Translate the following sentence into English:
      तुम पर मेरे Rs.500 उध़ार हैं । (Tum par mere Rs. 500 udhaar hain.)
a) You owe me Rs. 500.
b) I owe you Rs. 500.
Q2: Translate the following sentence into English:
    वो सोच रहा होगा हक मैं पागल हाँ । (Wo soch raha hoga ki main paagal hu.)
a) He will be thinking that I am mad.
b) He would be thinking that I am mad.
c) He will be thinking that I will be mad.
d) He would be thinking that I would be mad.
Q 3: Translate the following sentence into English:
        काश वो मेरा सगा होता। (Kaash vo mera sagaa hota.)
a) I wish he was my real one.
b) I wish he were my real one.
Q4: What are you…..me?
a) to
b) of
c) with
d) No preposition
Q5: Translate the following sentence into English:
     क्य़ा मुझे कही ं ज़ाऩा है ? (Kya mujhe kahin jaana hai?)
a) Have I to go somewhere?
b) Have I to go anywhere?
c) Have I to go elsewhere?
d) All of the above

Q6: How to write 12th:
a) Twelth
b) Twelfth
c) Twelvth
d) Twelveth
Q7: How to write 9th:
a) Ninth
b) Nineth
c) Nienth
Q8: One, who doesn’t believe in God, is known as
a) Venial
b) Fatalist
c) Atheist
d) Theist
Q9: A medicine that counteracts poison is
a) Anecdote
b) Antidote
c) Antedote
d) Anechdote
Q10: Government by a monarch is known as
a) Autocracy
b) Bureaucracy
c) Democracy
d) Monarchy
Q11: Add question tag: He’s a house to live in, …………
a) hasn’t he?
b) isn’t he?
c) doesn’t he?
Q12: Don’t ever look down…….the poor.
a) up to
b) to
c) on
d) at

Q13: Change the following sentence into negative:
     ‘He would have played yet.’
a) He would have not played yet.
b) He would not have played yet.
Q 14: Change into Passive Voice:
     ‘I make you smile.’
a) You are made smile by me.
b) You are made to smile by me.
c) You are made smiled by me.
Q15: Change into Passive Voice:
     ‘Let him eat the fish.’
a) Let the fish be eaten by him.
b) The fish let be eaten by him.
c) The fish let eaten by him.
d) Let the fish eaten by him.
Q16: Choose the correct spelling?
a) Commemorate
b) Comemmorate
c) Commemmorate
c) Comemorate
Q17: Choose the correct sentence:
a) I will live upto your expectations.
b) I will live up to your expectations.
Q18: Which one among the following is incorrect statement?
a) ADVICE is a noun & ADVISE is a verb.
b) ADDRESS is a noun as well as a verb.
c) PRACTICE is a noun & PRACTISE is a verb.
d) LOVE is only a verb, not a noun.
Q19: Which of the following is an incorrect sentence?
a) Each of Ram and Shyam is my friend.
b) Either of Ram and shyam is my friend.
c) Any of Ram and Shyam is my friend.

Q20: Translate the following sentence into English:
       मैं वहााँ जाता तक नह ।ीं (Main wahaan jaata tak nahi.)
a) I don’t even go there.
b) Even, I don’t go there.
                                          Answers
1a, 2b, 3b, 4a, 5a, 6b, 7a, 8c, 9b, 10d, 11a, 12c, 13b, 14a, 15a, 16a, 17b, 18d, 19c,
20a.
```

## Quiz 11

```text
Choose the correct alternative:
Q 1: Which part of the following sentence is erroneous?
None of you (A) / has (B)/ pens (C)/ to write. (D)
a) A
b) B
c) C
d) D
Q2: Which part of the following sentence is erroneous?
He (A) / does have (B) / no money (C) / No error (D)
a) A
b) B
c) C
d) D
Q3: How to tell the time 2:15?
a) Quarter past 2
b) Quarter to 2
c) 2 past quarter
d) 2 to quarter
Q4: AM stands for:
a) Ante meridiem
b) Ante meridian
c) Anti meridiem
d) Anti meridian

Q5: Expression of feelings is depicted in a sentence by the use of
a) Exclamation mark
b) Question mark
c) Full stop
d) Quotation mark
Q6: The person or people being spoken about is/are:
a) First person
b) Second person
c) Third person
d) None of these
Q7: ’’Whosever‛ means:
a) Jiska bhi
b) Jisko bhi
c) Jo koi bhi
d) Kaun sa
Q8: In a sentence, ‚I have three pens.‛, what is THREE here:
a) a conjunction
b) An adverb
c) a preposition
d) A determiner
Q9: Silver is………..
a) a proper noun
b) a common noun
c) an abstract noun
d) a material noun
Q10: Which of the following words is not a neuter gender:
a) Dog
b) Chair
c) Water
d) Light

Q11: The word ‚All‛ in a sentence ‚All is well‛ is:
a) an Intensive pronoun
b) a Possessive pronoun
c) an Indefinite pronoun
d) a Reflexive pronoun
Q12: Which of the following is incorrect pair of Adjective Degrees?
a) Bad – Worse – Worst
b) Cheerful – More cheerful – Most cheerful
c) Black – Blacker – Blackest
d) Well – More well – Most well
Q13: Third form of the verb ‚Show‛ is
a) Showed
b) Shown
c) Both of the above
d) None of the above
Q14: This is a three ………building.
a) story
b) storey
Q15: Aman and Ashish are brothers. …………..one is a guitarist.
a) Latter
b) Later
c) Letter
Q16: Study of the nature of beauty is called
a) Phonology
b) Physiology
c) Athletics
d) Aesthetics
Q17: What does the prepositional phrase ‚In lieu of‛ mean?
a) Instead of
b) Besides
c) Inspite of
d) Irrespective of

Q18: What does the phrasal verb ‚Break into‛ mean?
a) To end a relationship
b) To enter with the aim of theft
c) To escape from some prison
d) To quarrel
Q19: Translate into English: ‚Ram vahi ladka hai, jo vahaan mere sath tha.‛:
a) Ram is the very boy, who was there with me.
b) Ram is the only boy, who was there with me.
c) Ram is that boy, who was there with me.
d) All of the above
Q20: Change into Active voice: ‚I am not let eat it by dad.‛
a) Dad not let me eat it.
b) Dad doesn’t let me eat it.
c) Dad does let me not eat it.
d) Dad not lets me eat it
                                          Answers
1b, 2d, 3a, 4a, 5a, 6c, 7a, 8d, 9d, 10a, 11c, 12d, 13c, 14b, 15a, 16d, 17a, 18b, 19a,
20b.
```

## Quiz 12

```text
Choose the correct alternative:
Q1: Translate into English:
उसे घर ज़ाऩा पड़ा होग़ा। (Use ghar jaana pada hoga.)
a) He will have to go home.
b) He would have to go home.
c) He would have had gone home
d) He would have had to go home.
Q2: Which part of the following sentence is erroneous?
Either of us (A) / has (B) / to listen him (C) / attentively. (D)
a) A
b) B
c) C
d) D

Q3: Apostrophe is used to express:
a) Possession
b) Aggression
c) Full stop (.)
d) All of the above
Q4: The sentences, which state a fact, opinion or an idea are called:
a) Interrogative sentences
b) Imperative sentences
c) Exclamatory sentences
d) Assertive sentences
Q5: ‚To be‛ verbs are:
a) Is/Am/Are/Was/Were
b) Has/Have/Had
c) Do/Does/Did
d) None of the above
Q6: How to say in English?
     ि सब बच्े (vah sab bachche)
a) Those all children
b) These all children
c) This all children
d) That all children
Q7: ‚Whatsoever‛ means:
a) Jo koi bhi
b) Jis kisi ko bhi
c) Kya kabhi
d) Kya kabhi kabhi
Q8: In a sentence, ‚I have a pen.‛, what is ‚a‛ here:
a) a conjunction
b) An adverb
c) a preposition
d) A determiner
Q9: Earth is………..
a) a proper noun
b) a common noun
c) an abstract noun
d) a material noun

Q10: ……………… how far you go, you will remain in heart forever.
a) Irrespective of
b) Regardless of
c) Despite of
d) All of the above
Q11: I will come home…….Christmas.
a) on
b) at
c) in
d) Any of the above
Q12: Which of the following is incorrect pair of Adjective Degrees?
a) Good – Better - Best
b) Well – Better - Best
c) Far – Farther - Farthest
d) Bad – More bad – Most bad
Q13: Third form of the verb ‚Weave‛ is
a) Weaved
b) Woven
c) Both of the above
d) None of the above
Q14: Few, Less & Some are
a) Articles
b) Demonstratives
c) Possessives
d) Quantifiers
Q15: In a sentence, ‚Hi there!‛, what is THERE?
a) an adjective
b) an adverb
c) a pronoun
d) an interjection
Q16: Translate into English:
 क्य़ा आपको बुऱा लगे ग़ा अगर वो घर ज़ाये?
Kya aapko bura lagega agar wo ghar jaaye?
a) Would you mind if he go home?
b) Would you mind if he goes home?
c) Would you mind if he went home?
d) Would you mind if he has gone home?

Q17: She is the main ……………of this film.
a) Heroin
b) Heroine
Ans.- b) Heroine
Q18: Translate into English:
मेरे प़ास पै न होऩा च़ादहए थ़ा।
Mere paas pen hona chahiye tha.
a) I should a pen.
b) I should have a pen.
c) I should had a pen.
d) I should have had a pen.
Q19: A sentence i.e. He told me to have helped my brother, is an example of
a) Perfect Infinitive
b) Perfect Participle
c) Both of the above
d) None of the above
Q20: A sentence, ‚Having been seen, I felt very embarrassing‛ is an example of
a) Perfect Infinitive
b) Perfect Participle
c) Both of the above
d) None of the above
                                          Answers
1d, 2c, 3a, 4d, 5a, 6a, 7a, 8d, 9d, 10d, 11b, 12d, 13c, 14d, 15d, 16b, 17b, 18d, 19a,
20b.
```

## Quiz 13

```text
Choose the correct alternative:
Q 1: Translate into English:
हमने मीदटं ग मंडे तक के दलए पोस्पोन कर दी है ?
(Humne meeting Monday tak ke liye postpone kar di hai.)
a) We have put across the meeting until Monday.
b) We have put forward the meeting until Monday.
c) We have put off the meeting until Monday.
d) We have put forth the meeting until Monday.

Q 2: Which part of the following sentence is erroneous?
Either of you (A) / have (B) / to go (C) / to Canada. (D)
a) A
b) B
c) C
d) D
Q3: Exclamation Mark is used to express:
a) Expression of Surprise
b) Expression of Happiness
c) Expression of Grief
d) All of the above
Q4: The sentences, used to command or request are called:
a) Interrogative sentences
b) Imperative sentences
c) Exclamatory sentences
d) Assertive sentences
Q5: The verb ‚Has‛ is used with
a) Singular Subjects
b) Plural Subjects
c) 3rd Person Singular Subjects
d) 3rd Person Plural Subjects
Q6: The verb ‚did‛ is used with
a) Singular Subjects
b) Plural Subjects
c) Both of the above
d) None of the above
Q7:‚Howsoever‛ means:
a) Jo koi bhi
b) Jis kisi ko bhi
c) Jaise bhi
d) Jab kabhi kabhi
Q8: He is…………D.S.P.
a) a
b) an

Q9: Translate into English:
 वो मेऱा दू र क़ा ररश्तेद़ार है ?
Wo mera door ka rishtedaar hai?
a) He is my distant relative.
b) He is my distance relative.
c) He is my far relative.
d) He is my afar relative.
Q10: I know he is right; but my ego hinders me …… him.
a) to appreciate
b) appreciating
Q11: Who is he………you?
a) of
b) to
c) with
d) All of the above
Q 12: Change into Passive Voice:
     ‚I can go to market.‛
a) Market can be gone by me.
b) Market can gone by me.
c) Both of the above
d) None of the above
Q13: Past Participle form of the verb ‚Seek‛ is
a) Seeked
b) Sought
c) Both of the above
d) None of the above
Q14: The sentence ‚Book is kept on the table‛ is an example of:
a) A Simple Sentence with no action being performed by the subject
b) A passive voice sentence
c) Either of the above
d) Neither of the above
Q15: In a sentence, ‚Look at the man there‛, what is THERE?
a) an adjective
b) an adverb
c) a pronoun
d) an interjection

Q16: Change into Indirect Speech:
He said to me yesterday, ‚I must work there‛.
a) He told me yesterday that he must work there.
b) He told me yesterday that he has to work there.
c) He told me yesterday that he had to work there.
d) He told me yesterday that he would have to work there.
Q17: Find the incorrect sentence among the following:
a) There are 5 stars in the sky.
b) There are 2 hairs on the floor.
c) I have had it 3 hours ago.
d) He has been here since 3 hours.
Q18: Translate into English:
उसके प़ास मोब़ाईल होऩा ही च़ादहए थ़ा।
Mere paas mobile hona hi chahiye tha.
a) He must have a mobile.
b) I must have had a mobile.
c) I must possess a mobile.
d) I must have possess a mobile.
Q19: Translate into English:
मैं खुश हँ दक मुझे ये अवॉडम दमल़ा है ।
Main khush hun ki mujhe ye award mila hai.
a) I am happy to receive this award.
b) I am happy to have received this award.
Q20: How to say in English:
‚चुटकी भर नमक {Chutki bhar namak}‛
a) a pinch of salt
b) a minch of salt
c) a bite of salt
d) a rinch of salt
                                          Answers
1c, 2b, 3d, 4b, 5c, 6c, 7c, 8a, 9a, 10b, 11b, 12d, 13b, 14c, 15a, 16c, 17d, 18b, 19b,
20a.
```

## Quiz 14

```text
Choose the correct alternative:
Q 1: Either he or I……….to blame.
a) am
b) is
c) are
d) will have
Q 2: It’s Rashmi,…………. I had taken that day.
a) whose pen
b) the pen of whose
c) which pen
d) of which pen
Q 3: It’s really tasty. Can I have…………..one?
a) other
b) another
c) more
d) All of the above
Q 4: Synonym of ‚Truthfulness‛:
a) Veracity
b) Voracity
Q 5: Change into Indirect Speech:
      He asked," Who gave me this pen?"
A) He asked that who had given him that pen.
B) He asked that who gave him that pen.
C) He asked who had given him that pen.
D) He asked who gave him that pen.
Q 6: Which of the following sentences is correct?
a) I as well as Shahnaz are playing chess.
b) I as well as Shahnaz am playing chess.
c) I as well as Shahnaz is playing chess.
Q7: What is the meaning of ‘Perseverance’?
a) Steadfastness
b) Vulnerable
c) Anguish
d) Agility

Q 8: Translate the following sentence into English:
      तुमने मुझे इस काप्रबल समझा। (Tumne mujhe is kaabil samjha.)
a) You deemed me worthy to it.
b) You judged me worthy to it.
c) You considered me worthy to it.
d) All of the above
Q 9: Which of the following is an incorrect statement?
a) ‘Few’ is an indefinite pronoun.
b) ‘A’ is an indefinite article.
c) ‘A lot of’ is not a quantifier.
d) ‘Oneself’ is a reflexive pronoun.
Q 10: I am pursuing B.A. from one of the ……………….in Bihar.
a) university
b) universities
Q 11: I met him…………….
a) before 2 days.
b) 2 days ago.
c) 2 days before.
d) All of the above
Q 12: I met him……………I met you.
a) before 2 days
b) 2 days ago
c) 2 days before
d) All of the above
Q 13: I have ………… the scenery on the wall.
a) hanged
b) hung
c) hang
d) hunged
Q 14: A person fond of enjoyment is known as
a) Epicure
b) Ascetic
c) Connoisseur
d) Fastidious

Q 15: Change into Active Voice:
     ‚He had been tortured by her.‛
a) She had been tortured him.
b) She had tortured him.
Q 16: Past Participle (3rd form) of the verb ‚Wake‛ is:
a) Waken
b) Woken
c) Woke
Q 17: Translate the following sentence into English:
      मुझे जाने नह ीं प्रदया जा रहा था। (Mujhe jaane nahi diya ja raha tha.)
a) I was not letting go.
b) I was not being let go.
c) I was not being letting go.
d) I was not having been let go.
Q 18: Translate the following sentence into English:
       मुझे स्कूल जाना है । (Mujhe school jaana hai.)
a) I have to go to school.
b) I have got to go to school.
c) I got to go to school.
d) All of the above
Q 19: Translate the following sentence into English:
       मैं नहीों चाहता प्रक ि जाये । (Main nahi chahta ki vo jaaye.)
a) I don’t want to go him.
b) I don’t want him to go.
c) I don’t want to him go.
d) I don’t to want him go.
Q 20: Choose the correct spelling?
a) Decieve
b) Deceive
                                          Answers
1a, 2a, 3b, 4a, 5d, 6b, 7a, 8d, 9c, 10b, 11b, 12c, 13b, 14a, 15b, 16b, 17b, 18d, 19b,
20b.
```

## Quiz 15

```text
Choose the correct alternative:
Q 1: Translate the following sentence into English:
 ज़्यादातर ल ग जा चुके हैं पर कई ल ग अभी भी िहाूँ हैं । (Zyadatar log jaa chuke hain par
kayi log abhi bhi vahaan hain.)
a) Many people have left but several are still there.
b) Several people have left but many are still there.
c) Many people have left but many are still there.
d) Several people have left but several are still there.
Q 2: Which of the following is an incorrect sentence?
a) Either is my friend.
b) Either of you is my friend.
c) Either he or you is my friend.
d) You are not my friend either.
Q 3: ………..you I, would you have reacted like this?
a) were
b) was
c) would
d) If
Q 4: Which part of the following sentence is erroneous?
Every one (A) / of these pens (B) / is Rahul’s (C) / No error. (D)
a) A
b) B
c) C
d) D
Q 5: Which part of the following sentence is erroneous?
I’m sure (A) / he’ll (B) / make (C) / a strong come back. (D)
a) A
b) B
c) C
d) D
Q 6: Change into Indirect Speech:
       He asked Priya,"Who are you?‛
A) He asked Priya that who you are.
B) He asked Priya that who she was.
C) He asked Priya who you are.
D) He asked Priya who she was.

Q 7: Which of the following sentences is incorrect?
a) If I were the PM, I would take immediate decision on this issue.
b) Were I the PM, I would take immediate decision on this issue.
c) If I was the PM, I would take immediate decision on this issue.
Q 8: All of this mobile……….of no use.
a) is
b) are
Q 9: All these pencils……….of no use.
a) is
b) are
Q10: What is the meaning of ‘Condemn’?
a) To criticize
b) To appreciate
c) To penalize
d) To reward
Q 11: Many a pen………….blue.
a) is
b) are
Q 12: Time and tide ………….for none.
a) wait
b) waits
Q 13: Horse and carriage…………….rarely seen these days.
a) is
b) are
c) has
d) All of the above
Q 14: A person who has never been beaten or defeated, is known as
a) Incredible
b) Invincible
c) Inevitable
d) Cannibal
Q 15: Change into Active Voice:
     ‚I have been seen by her.‛
a) She has seen me.

b) She has been seen me.
c) She has seen by me.
d) She have been seen me.
Q 16: Synonym of the word ‘nevertheless’ is:
a) Whoever
b) Whosever
c) However
d) Whomever
Q 17: Antonym of the word ‘deteriorate’ is:
a) Decline
b) Worsen
c) Improve
d) Decay
Q 18: Translate the following sentence into English:
      मुझे खे लने नह ीं प्रदया जा रहा। (Mujhe khelne nahi diya ja raha.)
a) I am not letting play.
b) I am not being let play.
c) I am not being letting play.
d) I am not having been let play.
Q 19: Choose the correct spelling?
a) Embarrassing
b) Embarassing
c) Embarrasing
d) Embarasing
Q 20: Riya and Priya are intelligent. Former is my sister and …………..is my
friend.
a) Later
b) Latter
c) Letter
d) All of the above
                                          Answers
1a, 2c, 3a, 4d, 5d, 6d, 7c, 8a, 9b, 10a, 11a, 12a, 13a, 14b, 15a, 16c, 17c, 18b, 19a,
20b.
```

## Quiz 16

```text
Choose the correct alternative:
Q 1: Translate the following sentence into English:
     जब भी ि आता है , मैं घर पर ह ता हूँ । (Jab bhi wo aata h, main ghar par hota hu.)
a) Whenever he comes, I am at home.
b) Whenever he comes, I be at home.
c) Both of the above
Q 2: Which of the following is an incorrect sentence?
a) Even, I’m your friend.
b) I’m not even your friend.
c) Many a pen are blue.
d) Many pens are blue.
Q 3: The poet and singer……………..no more.
a) is
b) are
Q 4: The poet and the singer……………..no more.
a) is
b) are
Q 5: Poet and singer……………..no more.
a) is
b) are
Q 6: I came here 5 minutes………..
a) before
b) ago
c) Both of the above
Q 7: Which part of the following sentence is erroneous?
One of these pens (A) / is hers, (B) / not my. (C) / No error. (D)
a) A
b) B
c) C
d) D
Q 8: Which part of the following sentence is erroneous?
I will (A) / start working (B) / since tomorrow. (C) / No error (D)
a) A
b) B

c) C
d) D
Q 9: ‚None‛ is………………
a) A third person singular subject
b) A third person plural subject
c) Both of the above
d) None of the above
Q 10: ‚No one‛ is………………
a) A third person singular subject
b) A third person plural subject
c) Both of the above
d) None of the above
Q11: Which of the following is not the Synonym of the word ‚BRINK‛?
a) Edge
b) Verge
c) Threshold
d) Gloomy
Q12: Which of the following is not the Synonym of the word ‚ALLEGE‛?
a) To claim
b) To proclaim
c) To protect
d) To accuse
Q13: He says that he had sent me a letter yesterday. = ?
a) He is said to have sent me a letter yesterday.
b) He was said to have sent me a letter yesterday.
c) He has said to have sent me a letter yesterday.
d) He has said to have sent me a letter yesterday.
Q 14: 1 Billion = ?
a) 1000000000
b) 100000000
c) 10000000
d) 1000000
Q 15: 1 Million = ?
a) 1000000000
b) 100000000
c) 10000000

d) 1000000
Q 16: How to write 400th?
a) Four hundredth
b) Fourth hundredth
c) Fourth hundred
d) All of the above
Q 17: Translate into English: ‚उसने ज़ाने ददय़ा‛
a) He let go.
b) He did go let.
c) He go let.
d) All of the above
Q 18: ‚Let nature take its course.‛ means?
a) Jo ho raha hai hone do
b) Jab hoga tab dekhenge
c) Jo hua achchha nahi hua
Q 19: A man jumped…………….the Elephant from his car.
a) onto
b) upon
Q 20: A man jumped…………….the Elephant from his terrace.
a) onto
b) upon
Q 21: Choose the correct spelling?
a)Tomorrow
b)Tommorrow
c) Tomorow
d) Tommorow
Q 22: He couldn’t reach………….than 5 kms from here.
a) Further
b) Farther
                                          Answers
1c, 2c, 3a, 4b, 5b, 6b, 7c, 8c, 9c, 10a, 11d, 12c, 13a, 14a, 15d, 16a, 17a, 18a, 19b,
20a, 21a, 22b.
```

## Quiz 17

```text
Choose the correct alternative:
Q 1: Which of the following is an incorrect sentence?
a) Neither of you are my friend.
b) Either of you is my friend.
c) Many a man is sitting in the auditorium.
d) Some of the pens are blue in color.
Q 2: She is……………..FBI agent.
a) a
b) an
Q 3: Mr. Goyal is…………….CBI agent.
a) a
b) an
Q 4: This bouquet of flowers………….gifted to me by my friend.
a) has been
b) have been
Q 5: I ……………..driving cars with automatic gears.
a) am used to
b) used to
c) Both of the above
Q 6: Which part of the following sentence is erroneous?
One of the university (A) / has invited me (B) / for admission. (C) / No error. (D)
a) A
b) B
c) C
d) D
Q 7: Which part of the following sentence is erroneous?
I will (A) / take care myself (B) / and you enjoy yourselves. (C) / No error (D)
a) A
b) B
c) C
d) D
Q 8: ‚YOU‛ is………………
A) A second person singular subject
B) A second person plural subject

C) Both of the above
D) None of the above
Q 9: The glass is…………….upside down on the floor.
A) lie
B) lay
C) lying
D) laid
Q10: Which of the following is not the Synonym of the word ‚ASCEND‛?
a) Rise
b) Arise
c) Conquer
d) Deteriorate
Q11: ‚You owe me Rs.500‛ means?
a) You have to give me Rs. 500.
b) You have to take Rs. 500 from me.
Q12: He will say that he had already come from gym. = ?
a) He will say to have already come from gym.
b) He will say to have already came from gym.
c) He will have said to have already come from gym.
d) He will have said to have already came from gym.
Q 13: …………….does he begin to work in office?
a) Since when
b) From when
c) Both of the above
d) None of the above
Q 14: Choose the correct spelling:
a) color
b) colour
c) Both of the above
d) None of the above
Q 15: Choose the correct spelling:
a) Traveled
b) Travelled
c) Both of the above
d) None of the above

Q 16: Choose the correct spelling:
a) Apologize
b) Apologise
c) Both of the above
d) None of the above
Q 17: Did you...................my voice? I was your classmate in 10 th standard.
a) identify
b) recognize
c) Both of the above
d) None of the above
Q 18: .....................has he been working?
a) Since when
b) From when
c) Both of the above
d) None of the above
Q 19: .....................will he start working?
a) Since when
b) From when
c) Both of the above
d) None of the above
Q 20: One is not satisfied with………..money one………
a) however, has
b) however, have
c) whichever, has
d) whichever, have
                                          Answers
1a, 2b, 3a, 4a, 5a, 6a, 7b, 8c, 9c, 10d, 11a, 12a, 13c, 14c, 15c, 16c, 17b, 18a, 19b,
20a.
```

## Quiz 18

```text
Choose the correct alternative:
Q1: I was taking a bath .................. someone rang the bell.
(a) as
(b) while
(c) when
(d) as soon as
Q 2: She is more intelligent ................. her sister.
(a) to
(b) than
Q 3: He failed the test; ..................., he didn't lose heart.
(a) moreover
(b) then
(c) while
(d) nevertheless
Q 4: He has been changed a lot ..............I saw him last.
(a) since
(b) before
(c) while
(d) when
Q 5: He will fail the exam.............. he does not work hard.
(a) because
(b) if
(c) until
(d) though
(e) unless
Q 6: He will fail the exam.............. he works hard.
(a) because
(b) if
(c) until
(d) though
(e) unless
Q 7: .............. you have any doubt, please don’t hesitate to ask me.
(a) In case
(b) because
(c) unless

(d) until
(e) though
Q 8: He got late ................ it was raining in the morning.
(a) because
(b) after
(c) so
(d) when
Q 9: He could not get the prize, .................. she tried hard for it.
(a) yet
(b) though
(c) but
(d) when
Q 10: We must leave .................... it is getting dark now.
(a) as long as
(b) as soon as
(c) when
(d) as
Q 11: He tried his best; ................... , he couldn't get success.
(a) besides
(b) in case
(c) however
(d) as long as
Q 12: We had lost the key. We had,................... to break the lock open.
(a) therefore
(b) that’s the reason
(c) so
Q 13: The reason of his leave is .................... he is unwell.
(a) that
(b) because
(c) therefore
Q 14: His dad was transferred to Delhi ....................... he was only three years
old.
(a) when
(b) since
(c) while

Q 15: I have been to this place many a ................
(a) time
(b) times
                                          Answers
1c, 2b, 3d, 4a, 5b, 6e, 7a, 8a, 9b, 10d, 11c, 12a, 13a, 14a, 15a.
```

## Quiz 19

```text
Choose the correct alternative:
Q 1: 5 Kilometers………… good enough to run every day, I guess.
a) is
b) are
c) Any of the above
d) None of the above
Q 2: A bunch of grapes ………… brought by my uncle.
a) is
b) are
c) Any of the above
d) None of the above
Q 3: I………here since morning.
a) am
b) have been
c) Any of the above
d) None of the above
Q 4: Negative of ‚I have some water.‛?
a) I don’t have some water.
b) I don’t have any water.
c) I don’t have no water.
d) All of the above
Q 5: One should take care of …………belongings.
a) his
b) her
c) one’s
d) their

Q 6: Choose the correct spelling:
a) Adamant
b) Adament
Q 7: Third form of the verb ‚Come‛ is
a) come
b) came
Q 8: Which part of the following sentence is erroneous?
Any one of these (A) / chairs are (B)/ supposed to (C)/ be sold. (D)
a) A
b) B
c) C
d) D
Q 9: In a sentence, ‚I have something to eat.‛, what is ‚HAVE‛ here:
a) Helping verb
b) Action verb
c) Main verb
d) All of the above
Q 10: Change into Indirect Speech:
       Rashmi said to shweta, ‚Are you leaving for office?‛
a) Rashmi asked Shweta if you were leaving for office.
b) Rashmi asked Shweta if you are leaving for office.
c) Rashmi asked Shweta if she was leaving for office.
d) Rashmi asked Shweta if she is leaving for office.
Q 11: Change into Indirect Speech:
       Rashmi said to shweta, ‚What are you thinking?‛
a) Rashmi asked Shweta if what was she thinking.
b) Rashmi asked Shweta if what she was thinking.
c) Rashmi asked Shweta what she was thinking.
d) Rashmi asked Shweta what was she thinking.
Q 12: Don’t just respect …………., do respect everyone in fact.
a) the rich
b) the riches
c) the richs

Q 13: Life might not give us……………chance. Let’s make every moment count.
a) other
b) another
Q 14: A man from the 2nd floor of the building jumped………..my car.
a) over
b) on
c) onto
d) upon
Q 15: Translate into English: ‚Wo mobile kiske paas hai?‛
a) Who has that mobile?
b) Who does that mobile have?
c) Whose has that mobile?
d) Whose does that mobile have?
Q 16: Translate into English: ‚Tum yahaan kab tak ho?‛
a) Until when are you here?
b) Since when are you here?
c) When until are you here?
d) For how long are you here?
Q 17: Which of the following is an incorrect statement?
a) ‘None’ is an indefinite pronoun.
b) ‘An’ is an indefinite article.
c) ‘lots of’ is a quantifier.
d) ‘Mine’ is a reflexive pronoun.
Q 18: Antonym of the word ‘Interested’ is:
a) Disinterested
b) Uninterested
Q 19: I have 3 ………… experience working in that company.
a) years
b) year
c) year’s
d) years’
Q 20: Optative Sentences are now classified under the category of:
a) Declarative sentences
b) Exclamatory sentences
c) Imperative sentences
d) Interrogative sentences

Answers
1a, 2a, 3b, 4b, 5c, 6a, 7a, 8b, 9c, 10c, 11c, 12a, 13b, 14c, 15a, 16a, 17d, 18b, 19d,
20b.
```

## Quiz 20

```text
Choose the correct alternative:
Q 1: Which part of the following sentence is erroneous?
Does he (A) / have (B) / any of (C) / your pens? (D) / No error. (E)
a) A
b) B
c) C
d) D
e) E
Q 2: He always scolds me ………….. he is my boss.
a) Even if
b) However
c) As though
d) Lest
Q 3: I.........have nothing to eat.
a) Till now
b) Yet
c) though
d) still
e) None of these
Q 4: ‚Albeit‛ means:
a) Even though
b) Although
c) Even if
d) All of the above
e) None of the above
Q 5: Do focus on your studies lest you…….fail the exam.
a) will
b) should
c) may
d) might
e) All of the above

Q 6: He was one of the greatest .............. of Mughal empire.
a) rulers
b) rurals
Q 7: Though I love you a lot, ……… it doesn’t mean you make me fool.
a) but
b) yet
c) however
d) All of the above
Q 8: It was a brilliant ...................., albeit a little late.
a) manoeuvre
b) stear
c) movement
d) Any of the above
Q 9: No one can say ……..he will ever plan to visit this city or not.
a) If
b) That
c) Whether
d) as
Q 10: …….he studies well, he will fail.
a) Until
b) Unless
c) Till
d) All of the above
Q 11: I reach home by 6 or 6.30; depends on ........... I’ve to purchase something
from market.
a) if or not
b) that or not
c) whether or not
Q 12: How to pronounce the word ‚Albeit‛?
a) al-bee-at
b) al-bite
c) ail-bee-at
d) ail-bite

Q 13: How to pronounce the word ‚Colonel‛?
a)Kar-nal
b)Kolo-nal
c) Kolo-nil
Q 14: Which part of the following sentence is erroneous?
The more he (A) / hates me, (B) / more (C) / I love him. (D)
a) A
b) B
c) C
d) D
Q 15: The Acronym ‚P.P.‛ used in formal letter writing stands for:
a) Per Procurationem
b) Per Parity
c) Per Procurational
Q 16: While writing a letter, if you don’t know the name of the person being
addressed in the letter; you must use:
a) Yours faithfully
b) Yours sincerely
Q 17: How to pronounce the word ‚Niche‛?
a)Nee-sh
b)Nee-ch
c) Nee-che
d) Nee-shai
Q 18: How to pronounce the word ‚Genre‛?
a)John-ruh
b)John-ar
c) Gen-ar
d) Gen-rai
Q 19: How to pronounce the word ‚Enterpreneur‛?
a)En-ter-pra-nor
b)On-ter-pra-nor
c) On-ter-pra-nyor
d) En-ter-pra-nyor
Q 20: She is the main .........................of the film.
a) heroin
b) heroine

Answers
1e, 2c, 3d, 4d, 5b, 6a, 7d, 8a, 9c, 10b, 11c, 12a, 13a, 14c, 15a, 16a, 17a, 18a, 19c,
20b.
```

## Quiz 21

```text
Choose the correct alternative:
Q 1: Which of the following sentences is/are correct?
a) I belong to Kota, Rajasthan.
b) I am belong to Kota, Rajasthan.
c) I belong from Kota, Rajasthan
d) Both of the above
e) None of the above
Q 2: Which of the following sentences is/are correct?
a) I am in 6th class.
b) I am in 6 class.
c) I am in 6th standard.
d) All of the above
e) None of the above
Q 3: Choose the incorrect sentence among the following?
a) I am pursuing Graduation.
b) I am in class 11.
c) I have done 6 month’s basic computer course.
d) I have 3 years’ experience in Graphic Designing.
e) All of the above
Q 4. I have rich experience working..............MNCs.
a) with
b) in
c) sometimes ‚with‛ and sometimes ‚in‛
c) Any of the above
d) None of the above
Q 5: Choose the incorrect sentence among the following?
a) I love reading magazines.
b) My hobby is listening music.
c) My hobbies are playing football and cooking.
d) I am from Patna, Bihar.
e) I am PHD in Mathematics.

Q 6: What is the proper sequence of writing a formal letter?
a) Sender’s address – Date – Receiver’s address – Salutation - Subject
b) Receiver’s address – Date – Sender’s address – Salutation – Subject
c) Sender’s address – Date – Receiver’s address – Subject - Salutation
d) Receiver’s address – Date – Sender’s address – Subject – Salutation
Q 7: In letter writing, what does P.P. stand for?
 i) Per procurationam
ii) Per percurationem
iii) Per percurationam
iv) Per procurationem
Q 8: What does P.P. mean?
i) Apart from
ii) On behalf of
iii) Including someone
iv) Per person
Q 9: In formal letter writing, one must address the receiver by the
salutation................
i) Dear sir
ii) Respected sir
iii) Honoured sir
iv) All of the above
Q 10: When you don’t know the name of the person being addressed in a
formal letter, you must end it with ...........................
a) Your’s faithfully
b) Your’s sincerely
c) Yours faithfully
d) Yours sincerely
Q 11: Which of the following acronyms is not used in formal letter writing?
a) C.C.
b) P.P.
c) Enc.
d) T.T.
Q 12: Which is the incorrect way of Salutation in letters?
a) Dear Mrs. Neha
b) Dear Neha
c) Dear Ms. Neha
d) Dear ma’am Neha

Q 13: Choose the incorrect ‚Sentence type – Verb‛ pair?
a)Simple Sentences Past 1st Category – Was/Were
b) Simple Sentences Past 2nd Category – Had
c) Simple Sentences Future 1st Category – Will
d) Simple Sentences Future 2nd Category – Will have
Q 14: Translate the following sentence into English: ‚Kiske paas kya hai?‛
a) Which has what?
b) Who has what?
c) Which do have what?
d) Which does have what?
d) Who do have what?
Q 15: Translate the following sentence into English: ‚Kaun Kaun kahaan kahaan
honge?‛
a) Who all will be where all?
b) Whom all will be where all?
c) Who all will have where all?
d) Who all will have where all?
Q 16: Translate the following sentence into English: ‚Uske paas kya hai?‛
a) What do he has?
b) What does he has?
c) What do he have?
d) What does he have?
Q 17: Which of the following sentences is incorrect?
a) Money is a countable noun.
b) Star is a countable noun.
c) Hair is a countable noun.
d) Rupee is a countable noun.
Q 18: Translate the following sentence into English: ‚Uske kitne bhai honge?‛
a) How many brothers will he have?
b) How many brothers will he has?
c) How many will he have brothers?
d) How many will he has brothers?
Q 19: Translate the following sentence into English: ‚Kya uske paas paise the?‛
a) Did he have money?
b) Did he has money?
c) What did he have money?

d) What did he has money?
Q 20: If you can answer a question in YES or NO, you must ......................
a) always use WH question words
b) never use WH question words
c) sometimes use WH question words
d) Only use WH question words i.e. What and Who
                                          Answers
1a, 2c, 3c, 4c, 5b, 6a, 7d, 8b, 9a, 10c, 11d, 12d, 13c, 14b, 15a, 16d, 17a, 18a, 19a,
20b.
```

## Quiz 22

```text
Choose the correct alternative:
Q 1: Translate into English: ‚Mujhe jaana hai.‛
a) I have to go.
b) I am to go.
c) I’ve got to go.
d) I got to go
e) All of the above
Q 2: I can …………………….. a key player of the company.
a) turn up to be
b) turn out to be
c) turn on to be
d) All of the above
Q 3: They enjoyed………..
a) them
b) themself
c) themselves
d) their
Q 4: He is older………………
a) than I.
b) than me.
c) to I.
d) to me.

Q 5: He is younger………………
a) than I.
b) than me.
c) to I.
d) to me.
Q 6: He had reached before…………………..
a) you reached.
b) you had reached.
c) you have reached.
d) you having reached.
Q 7: …………………, he calls her.
a) Sometime
b) Sometimes
c) Some times
d) Some time
Q 8: He loved me, ……………difficult phase he was going through though.
a) whoever
b) whichever
c) however
d) whosoever
Q 9: The subject of a sentence may be
a) a noun or a pronoun
b) a noun or a gerund
c) a gerund or an infinitive
d) a noun, pronoun, gerund or an infinitive
Q 10: Translate into English: ‚Uske sath kaun gaya?‛
a) Who go with him?
b) Who did go with him?
c) Who went with him?
d) Who had gone with him?
Q 11: Choose the correct spelling:
a) Decieve
b) Deceive
Q 12. What does ‚Naive‛ mean?
a) Selfish
b) Clever

c) Innocent
d) Adamant
Q 13: What does ‚Archaic‛ mean?
a) Old fashioned
b) New fashion
c) Simple and sober
d) Contemporary
Q 14. I could distribute pens to only 15 of them; ……………..were given the
pencils.
a) pending
b) rest
c) other
d) another
Q 15: Translate into Hindi: ‚I was made go.‛
a) Mujhe bheja gaya.
b) Mujhe bhijvaya gaya.
Q 16: Translate into Hindi: ‚I was sent.‛
a) Mujhe bheja gaya.
b) Mujhe bhijvaya gaya.
Q 17: Translate into English: ‚Maine usse help maangi.‛
a. I told him to help me.
b. I said him to help me.
c. I asked him to help me.
d. I begged him to help me.
Q 18: Which helping verbs are used in Passive sentences of Present Indefinite
Tense?
a. Do & Does
b. Is, Am & Are
Q 19: Which helping verb(s) are used in Passive sentences of Past Indefinite
Tense Affirmative sentences?
a) Did
b) Was
c) Was and Were
d) No helping verb

Q 20: What does ‚off hand‛ means?
a) Without money
b) Without preparation
c) Without luck
d) Without love
                                          Answers
1e, 2b, 3c, 4a, 5d, 6a, 7b, 8c, 9d, 10c, 11b, 12c, 13a, 14b, 15b, 16a, 17c, 18b, 19c,
20b.
```

## Quiz 23

```text
Choose the correct alternative:
Q 1: Which of the following is a regular verb?
a) Freeze
b) Read
c) Decide
d) Find
Q 2: Which of the following is an irregular verb?
a) Play
b) Enter
c) Seek
d) Enjoy
Q 3: Which of the following has regular as well as irregular verb forms?
a) Hear
b) Swim
c) Sleep
d) Weave
Q 4: Which of the following is a regular verb?
a) Run
b) Scold
c) Beat
d) Think
Q 5: Which of the following is an irregular verb?
a) Spend
b) Accept
c) Advise
d) Compare

Q 6: Which of the following has regular as well as irregular verb forms?
a) Love
b) Shine
c) Like
d) Want
Q 7: Which of the following verbs has its three forms exactly the same?
a) Quit
b) Sit
c) Hide
d) Come
Q 8: Which of the following is a regular verb?
a) Sing
b) Sink
c) Attend
d) Sell
Q 9: Which of the following is an irregular verb?
a) Start
b) Spread
c) Smile
d) Laugh
Q 10: Which of the following has regular as well as irregular verb forms?
a) Tie
b) Show
c) Put
d) Cut
Q 11: Which of the following verbs has its three forms exactly the same?
a) Dream
b) Spread
c) Rise
d) Hold
Q 12: Which of the following is a regular verb?
a) Grow
b) Blow
c) Avoid
d) Write

Q 13: Which of the following is an irregular verb?
a) Swear
b) Behave
c) Boil
d) Jump
Q 14: Which of the following has regular as well as irregular verb forms?
a) Freeze
b) Need
c) Hang
d) Open
Q 15: Which of the following has regular as well as irregular verb forms?
a) Buy
b) Lie
c) Lay
d) Tell
                                          Answers
1c, 2c, 3d, 4b, 5a, 6b, 7a, 8c, 9b, 10b, 11b, 12c, 13a, 14c, 15b.
```

## Quiz 24

```text
Choose the correct alternative:
Q 1: Translate into English:
वो और तुम मुझसे क्य़ा च़ाहते हो? (Wo or tum mujhse kya chahte ho?)
a) What do he and you want from me?
b) What he and you want from me?
c) What he and you wants from me?
d) What does he and you want from me?
Q 2: Translate into Hindi: Rahul is sitting in the car.
a) Rahul car me baitha hua hai. (Simple Sentence)
b) Rahul car me baith raha hai. (Present Continuous Tense)
c) Both of the above
d) None of the above
Q 3: Translate into Hindi: I was asked to tell him about it.
a) Mujhe poocha gaya ki kya use is baare me bataya jaaye.
b) Mujhe kaha gaya ki main use is baare me batau.
c) Mujhse is baare me poocha gaya ki maine use kya bataya.

Q 4: Translate into English:
वो सोय़ा हुआ थ़ा। (Wo soya hua tha.)
a) He was sleeping.
b) He was asleep.
c) Both of the above
d) None of the above
Q 5: Translate into English:
वो सो रह़ा थ़ा। (Wo so raha tha.)
a) He was sleeping.
b) He was asleep.
c) Both of the above
d) None of the above
Q 6: Translate into English:
वो मेऱा क्य़ा है ? (Wo mera kya hai?)
a) What is he to me?
b) What is he to mine?
c) What is he of me?
d) What is he of mine?
Answer - a) What is he to me?
Q 7: Translate into English:
वो कब कब आत़ा है ? (Wo kab kab aata hai?)
a) When when does he come?
b) When all does he come?
c) How often does he come?
d) How long does he come?
Q 8: Translate into English:
मैं 4 बजे घर पर होत़ा हँ । (Main 4 baje ghar par hota hu.)
a) I am at home at 4 o’clock.
b) I be at home at 4 o’clock.
c) I am home at 4 o’clock.
d) All of the above
Q9: Translate into English:
 वो मेऱा दू र क़ा दोस्त है ।(Wo mera door ka dost hai.)
a) He is my distant friend.
b) He is my distance friend.
c) He is my far friend.
d) He is my afar friend.

Q10: Translate into English:
 बन्दर पे ड पर बैठ़ा है ।(Monkey tree par baitha hai.)
a) The monkey is sitting on the tree.
b) The monkey is sitting in the tree.
c) The monkey is sitting at the tree.
d) All of the above
Q11: Translate into English:
 क्य़ा रद्धि ज़ा प़ायेगी?(Kya Rashmi jaa payegi?)
a) Will Rashmi able to go?
b) Will Rashmi be able to go?
c) Could Rashmi be able to go?
d) Could Rashmi able to go?
Q 12: Translate into Hindi: I had to go.
a) Mujhe jaana tha.
b) Mujhe jaana pada.
c) Mujhe jaana padta tha.
d) All of the above
Q 13: Translate into Hindi: It comes to Rs. 100.
a) Total Rs. 100 ho gaya.
b) Rs.100 ki baat hai.
c) Ye Rs. 100 me aata hai.
d) Ye Rs.100 lene ko aata hai.
Q14: Translate into Hindi: His shirt was torn.
a) Uski shirt fati hui thi. (A simple sentence with no action by subject)
b) Uski shirt faadi gayi. (Passive Voice – Past Indefinite)
c) Both of the above
d) None of the above
Q15: Translate into English:
 उसे दबठ़ाय़ा गय़ा। (Use bithaya gaya.)
a) He was sitting.
b) He was to make sit.
c) He was made sit.
d) He was made to sit.
Q16: Translate into Hindi: I let him go.
a) Main use jaane deta hu. (Present Indefinite Tense)
b) Maine use jaane diya. (Past Indefinite Tense)

c) Both of the above
d) None of the above
Q17: Translate into English:
 उसे ज़ाने ददय़ा ज़ात़ा है । (Use jaane diya jaata hai.)
a) He is let go.
b) He is made go.
c) He let goes.
d) He is let to go.
Q18: Translate into English:
उसके प़ास दकत़ाब होनी ही च़ादहए थी। (Uske paas book honi hi chahiye thi.)
a) He must have a book.
b) He must have had a book.
c) He had to have a book.
d) He had to had a book.
Q19: Translate into English:
मैं आज श़ाम आपसे दमलूँग़ा। (Main aaj shaam aapse milunga.)
a) I’ll meet you in the evening today.
b) I’m gonna meet you in the evening today.
c) Both of the above
d) None of the above
Q20: Translate into English:
चुटकी भर दसं दूर क़ाफी है । (Chutki bhar sindoor kaafi hai)
a) A pinch of sindoor is enough.
b) A minch of sindoor is enough.
c) A belittle of sindoor is enough.
d) All of the above
                                          Answers
1a, 2c, 3b, 4b, 5a, 6a, 7c, 8d, 9a, 10a, 11b, 12d, 13a, 14c, 15c, 16c, 17a, 18b, 19c,
20a.
```

## Quiz 25

```text
Choose the correct alternative:
Q 1: I am going to a ……………… shop.
a) stationary
b) stationery
Q 2: He booked a ………… in a 5 star hotel.
a) suite
b) suit
c) sweet
d) sweat
Q 3: After this incident, I really felt ………………… working with him.
a) embarrasing
b) embarrassing
c) embarasing
d) embarassing
Q 4: Uske paas kya hai? = What does he………….?
a) has
b) have
Q 5: Translate into English: KISKE PAAS KYA HAI?
a) Who does have what?
b) Who has what?
c) Who does what have?
Q 6: Which part of the following sentence is erroneous?
One of my friend (A) / has invited me (B) / at his house. (C) / No error. (D)
a) A
b) B
c) C
d) D
Q 7: Homophones are the words………………………………..
a) same in pronunciation but different in spelling and meaning.
b) same in spelling but different in pronunciation and meaning.
c) same in spelling and pronunciation but different in meaning.

Q 8: Homographs are the words………………………………..
a) same in pronunciation but different in spelling and meaning.
b) same in spelling but different in pronunciation and meaning.
c) same in spelling and pronunciation but different in meaning.
Q 9: I will ………… for you.
A) pray
B) prey
Q10: He ……………. asleep for a long.
a) is
b) has been
Q11: Choose the correct spelling:
a) Tomorrow
b) Tommorow
c) Tomorow
d) Tommorrow
Q12: Beauty is in the eye of the …………..
a) beholder
b) viewer
Q 13: I don’t know……………..
a) who is he?
b) who he is.
c) who he is?
d) who is he.
Q 14: I can’t say……………..
a) what is it.
b) what is it?
c) what it is.
d) what it is?
Q 15: This is a …………….. hostel.
a) girl’s
b) girls’
Q 16: This game is all ……………. first choice.
a) student’s
b) students’

Q 17: This is ….. university.
a) a
b) an
Q 18: He is ………MBA.
a) a
b) an
Q 19: Translate the following sentence into English:
       मैं 10 स़ाल ददल्ली रह चु क़ा हँ. (Main 10 saal Delhi rah chuka hun.)
a) I have been in Delhi for 10 years.
b) I have been to Delhi for 10 years.
Q 20: Translate the following sentence into English:
मैं एक ब़ार ददल्ली ज़ा चु क़ा हँ . (Main ek baar Delhi jaa chuka hun.)
a) I have been in Delhi once.
b) I have been to Delhi once.
                                          Answers
1b, 2a, 3b, 4b, 5b, 6a, 7a, 8b, 9a, 10b, 11a, 12a, 13b, 14c, 15b, 16b, 17a, 18b, 19a,
20b.
```

## Quiz 26

```text
Choose the correct alternative:
Q 1: He travelled seven kilometres......two hours.
a) in
b) for
c) since
d) from
Q 2: Thanks for you help. It really means a lot ..........
a) for me
b) to me
c) on me
d) at me
Q 3: LEMME..................................
a) is the contraction of LET ME.
b) doesn’t exist in the dictionary.
c) is the antonym of the GIMME.
d) All of the above

Q 4: I have only ............. in my attaché.
a) two jeans
b) two pair of jeans
c) two pair of jeanses
d) two pairs of jeans
Q 5: I told him, I ............. not go.
a) will
b) would
c) Any of the above
Q 6: He was one of the humblest .............. of Delhi sultanate.
a) rulers
b) ruler
c) rurals
d) rural
Q 7: He has been working .............. he met me.
 a) ever since
b) ever from
c) ever when
d) All of the above
Q 8: Which of the following verb forms is incorrect?
a) Debitting
b) Getting
c) Putting
d) Knitting
Q 9: I love both of my sisters. ........... of them ......... in Dehradun.
a) Neither, live
b) Neither, lives
c) None, live
d) None, lives
Q 10: …….you attend the party, I’ll not attend ........
a) Until, too
b) Unless, either
c) Until, either
d) Unless, too

Q 11: He ........ at my eyes to discover any fear I might have had; but I wasn’t
vulnerable to get scared of him.
a) saw
b) watched
c) looked
d) Any of the above
Q 12: How to pronounce the word ‚Albeit‛?
a) al-bee-at
b) al-bite
c) ail-bee-at
d) ail-bite
Q 13. How to pronounce the word ‚Colonel‛?
a)Kar-nal
b)Kolo-nal
c) Kolo-nil
Q 14: Change into Passive voice: THEY LET ME GO.
a) I was let go by them.
b) I am let go by them.
c) Both of the above
d) None of the above
Q 15: The Acronym LOL stands for.......................
a) Laugh Out Loud
b) Laughing Out Loud
c) Laugh Onto Loud
d) Laughing Onto Loud
Q 16: The moment clock .............. midnight, fireworks begin.
a) strike
b) struck
c) strikes
d) sticks
Q 17. We must make a new year ................... to devote more time to learn
English.
a)Resolution
b) Revolution

Q 18: May the new year bring...............in your life!
a) prosperity
b) prosperous
c) happy
d) adversity
Q 19: How to pronounce the word ‚Strategic‛?
a)Strait- jic
b)Stra - teejic
Q 20: It........a great day so far.
a) is
b) has been
c) have been
                                          Answers
1a, 2b, 3a, 4d, 5b, 6a, 7a, 8a, 9b, 10b, 11c, 12a, 13a, 14c, 15b, 16c, 17a, 18a, 19b,
20b.
```

## Quiz 27

```text
Choose the correct alternative:
Q 1: Choose the correct sentence:
a) He is older than I.
b) He is older than I am.
c) He is older than me.
d) All of the above
Q 2: Choose the correct sentence:
a) His pen is better than me.
b) His pen is better than my.
c) His pen is better than mine.
d) All of the above
Q 3: Choose the correct sentence:
a) His hair is black.
b) I found 5 strands of hair in the vegetable.
c) I found 5 hairs in the vegetable.
d) All of the above

Q 4: Choose the incorrect sentence:
a) Honesty is the best policy.
b) He is honest.
c) He is an honest.
d) He is an honest person.
Q 5: Choose the incorrect word:
a) Driven
b) Droven
c) Woven
d) Sought
Q 6: Choose the incorrect word:
a) Storey
b) Rite
c) Both of the above
d) None of the above
Q 7: Choose the correct sentence:
a) He had showed me three cars.
b) He had shown me three cars.
c) Both of the above
d) None of the above
Q 8: Choose the correct sentence:
a) No one is my friend.
b) Neither is my friend.
c) Both of the above
d) None of the above
Q 9: Choose the correct sentence:
a) Behave well lest you shall be punished.
b) Behave well lest you should be punished.
c) Behave well lest you will be punished.
d) Behave well lest you would be punished.
Q10: Choose the incorrect sentence:
a) I’ll not call you until you message me.
b) I’ll not come until 10 PM.
c) Until and unless you call me, I’ll not get ready for the party.
d) All of the above
e) None of the above

Q 11: Choose the incorrect sentence:
a) I love talking to you.
b) I love speaking with you.
c) I love telling the lie.
d) I love telling the truth.
Q 12: Choose the incorrect sentence:
a) I have 3 sister-in-laws.
b) I have 5 brothers-in-law.
c) I am to go home.
d) I have to go home.
Q 13: Choose the correct sentence:
a) My house is being painted.
b) My house is being paint.
c) My house is getting paint.
d) All of the above
 e) None of the above
Q 14: Choose the correct sentence:
a) He waits for none.
b) He waits for no one.
c) Both of the above
d) None of the above
Q 15: Choose the correct sentence:
a) Meeting you at least once is my lifelong desire.
b) To meet you at least once is my lifelong desire.
c) Both of the above
d) None of the above
Q 16: Choose the correct sentence:
a) He is here to meet you at least once.
b) He is here meeting you at least once.
c) Both of the above
d) None of the above
Q 17: Choose the incorrect sentence:
a) He got me some water.
b) He made me write a letter.
c) He got to write a letter.
d) All of the above
e) None of the above

Q 18: Choose the incorrect sentence:
a) I ain’t doing anything.
b) He’d’ve left in another minute.
c) You shan’t breach the rule.
d) All of the above
e) None of the above
Q 19: Choose the incorrect sentence:
a) I have come home.
b) I have came home.
c) I rode someone else’s bike.
d) He rode someone else’s bike.
Q 20: Choose the incorrect sentence:
a) It’s been a great day so far.
b) It’s my pleasure.
c) It’s 2nd day of the weak.
d) All of the above
e) None of the above
                                          Answers
1b, 2c, 3d, 4c, 5b, 6d, 7c, 8c, 9b, 10e, 11c, 12a, 13a, 14c, 15c, 16a, 17e, 18e, 19b,
20c.
```

## Quiz 28

```text
Choose the correct alternative:
Q 1: All of it………….made in India.
a) is
b) are
c) has
d) have
Q 2: All of these………….made in India.
a) is
b) are
c) has
d) have

Q 3: Neither of them……..my friend.
a) is
b) are
c) has
d) have
Q 4: A bouquet of roses……….gifted to me by my roommate.
a) has
b) have
c) was
d) were
Q 5: I, Aditya Rana,…….. a banker and a youtuber.
a) is
b) am
c) are
Q 6: India………..11 players on the field and 6 sitting outside.
a) is
b) are
c) has
d) have
Q 7: As a country, India………... a rich cuture.
a) is
b) are
c) has
d) have
Q 8: Bread and butter in the morning ……..my favorite breakfast.
a) is
b) are
c) has
d) have
Q 9: One Bread and 500 gms butter …….. to be purchased from the shop.
a) is
b) are
c) has
d) have
Q 10: The producer and director of this film………….supposed to visit Delhi
today.
a) is

b) are
c) has
d) have
Q 11: The producer and the director of this film………….supposed to visit Delhi
today.
a) is
b) are
c) has
d) have
Q 12: Producer and director of this film………….supposed to visit Delhi today.
a) is
b) are
c) has
d) have
Q 13: If I……..a doctor, I…………love to treat the poor for free.
a) was, would
b) was, would have
c) were, would
d) were, would have
Q 14: He, as well as You…………not taking it seriously.
a) is
b) am
c) are
Q 15. He, along with You…………not taking it seriously.
a) is
b) am
c) are
Q 16: He, not You…………not taking it seriously.
a) is
b) am
c) are
Q 17: Either of you guys……..to come on stage and perform with me.
a) need
b) needs
Q 18: Here ………….the teacher.
a) comes

b) come
c) is come
d) has come
Q 19: There…….no one at the door.
a) is
b) are
c) has
d) have
Q 20: All that glitters………..not gold.
a) is
b) are
Q 21: Some of the laptops………….been malfunctioning.
a) is
b) are
c) has
d) have
                                          Answers
1a, 2b, 3a, 4c, 5b, 6d, 7c, 8a, 9b, 10a, 11b, 12b, 13c, 14a, 15a, 16a, 17b, 18a, 19a,
20a,21d.
```

## Quiz 29

```text
Choose the correct alternative:
Q 1. What is the star .......... of this movie?
a) cast
b) caste
Q 2. He is ............. by nature.
a) tasty
b) testy
Q 3. I’ve booked a luxurious........... in a 5 star hotel.
a) suite
b) suit
c) sweet
d) sweat

Q 4. One of your bicycle’s .......... needs to be repaired.
a) breaks
b) brakes
c) break
d) brake
Q 5. I know what............ looking for.
a) their
b) they’re
c) there
d) All of the above
Q 6. I will visit your house .............morning.
a) in
b) in the
c) Both of the above
d) None of the above
Q 7. I don’t like my mobile’s ..........; rather I love listening to your...........
a) voice, sound
b) sound, voice
c) voice, voice
d) sound, sound
Q 8. Choose the correct spelling:
a) Colour
b) Color
c) Both of the above
d) None of the above
Q 9. Choose the correct spelling:
a) Favorite
b) Favourite
c) Both of the above
d) None of the above
Q 10. Only 10 people were present on his................
a) cremation
b) cramation
c) crametion
d) creamation

Q 11. It’s .............that 10% people have 90% money and vice versa.
a) a paradox
b) an orthodox
Q 12. Tedious means .............
a) lengthy and boring
b) hard worker
c) patience
d) Tax
Q 13. His...........explanation made things easy to understand.
a) lucid
b) rigid
Q 14. Cite means ................
a) to mention something as an example.
b) the place where building is made.
c) To look at someone
Q 15. .............. is the money that is demanded by kidnappers to free someone.
a) Ransom
b) Ranson
c) Ramson
d) Ramsom
Q 16. His.............is doubtful.
a) integrity
b) antegrity
c) intigrity
d) antigrity
Q 17. ..............novels is a good habit.
a) Reading
b) To read
c) Both of the above
d) None of the above
Q 18. I decided............novels.
a) reading
b) To read
c) Both of the above
d) None of the above

Q 19. There are..........boys in the class.
a) some
b) few
c) Both of the above
d) None of the above
Q 20. He has.............money.
a) a lot of
b) lots of
c) Both of the above
d) None of the above
                                          Answers
1a, 2b, 3a, 4b, 5b, 6b, 7b, 8c, 9c, 10a, 11a, 12a, 13a, 14a, 15a, 16a, 17c, 18b, 19c,
20c.
```

## Quiz 30

```text
Choose the correct alternative:
Q 1: Change into Passive Voice:
      ‚He sent me there.‛
a) I am sent there by him.
b) I was sent there by him.
c) I had been sent there by him.
d) I have been sent there by him.
Q2. Mr. Das is a rich person……….not happy.
 a) if
 b) but
 c) and
 d) yet
Q 3: Change the sentence into Interrogative: ‚He needs me.‛
a) Does he need me?
b) Did he need me?
c) Need he me?
d) Do he need me?
Q 4: Antonym of the word ‚Awesome‛ is:
a) Awful
b) Aweful
c) Awe
d) Awkward

Q 5: Which word is similar to Enormous?
a) Gigantic
b) Exclusive
c) Endeavor
Q 6: Change into Indirect Speech:
       He said, "I must work now.‛
a) He said that he must to work then.
b) He said that he had to work then.
c) He told that he must to work now.
d) He told that he must have to work then.
Q 7: Change into Indirect Speech:
       He said to her, ‚Are you going?‛
a) He asked her if you were going.
b) He asked her if she was going.
c) He asked her that was she going.
d) He asked her that she was going.
Q 8: Change into Indirect Speech:
         He asked," who called me?"
a) He asked that who called him.
b) He asked that who had called him.
c) He asked who called him.
d) He asked who had called him.
Q 9: What time ............
 a) the train leaves?
 b) leaves the train?
 c) is the train leaving?
 d) does the train leave?
Q 10. Sorry, he can't pick up the phone. He ..... a bath!
a) is having
b) having
c) have
d) has
Q 11. She ......... her blue jeans yesterday.
a) was suppose to
b) was supposed to
c) had suppose to
d) had supposed to

Q 12: Change into Passive Voice: ‚I let him go.‛
a) He is let go by me.
b) He let go by me.
c) He has let go by me.
d) He is letted go by me.
Q 13: Change into Passive Voice: ‘I make you smile.’
a) You are made smile by me.
b) You are made to smile by me.
c) You are made smiled by me.
Q 14: Change into Passive Voice: ‘Let him eat the fish.’
a) Let the fish be eaten by him.
b) The fish let be eaten by him.
c) The fish let eaten by him.
d) Let the fish eaten by him.
Q 15: Change into Passive Voice: ‚I can go to market.‛
a) Market can be gone by me.
b) Market can gone by me.
c) Both of the above
d) None of the above
Q16. Change into Indirect Speech:
He said to me yesterday, ‚I must work there‛.
a) He told me yesterday that he must work there.
b) He told me yesterday that he has to work there.
c) He told me yesterday that he had to work there.
d) He told me yesterday that he would have to work there.
Q 17: Change into Indirect Speech:
       He asked," Who gave me this pen?"
A) He asked that who had given him that pen.
B) He asked that who gave him that pen.
C) He asked who had given him that pen.
D) He asked who gave him that pen.
Q 18: Which of the following sentences is correct?
a) I as well as Rehman are playing chess.
b) I as well as Rehman am playing chess.
c) I as well as Rehman is playing chess.

Q 19: Change into Active Voice:
     ‚He had been tortured by her.‛
a) She had been tortured him.
b) She had tortured him.
Q 20: Change into Indirect Speech:
       He asked Priya,"Who are you?‛
A) He asked Priya that who you are.
B) He asked Priya that who she was.
C) He asked Priya who you are.
D) He asked Priya who she was.
                                          Answers
1a, 2b, 3a, 4a, 5a, 6b, 7b, 8d, 9d, 10a, 11b, 12a, 13a, 14a, 15d, 16c, 17d, 18b, 19b,
20d.
```

## Quiz 31

```text
Choose the correct alternative:
Q 1: Change into Indirect Speech:
     He said to Ravi, ‚I need to go home with you.‛
a) He told Ravi that he needed to go home with him.
b) He told Ravi that I needed to go home with him.
c) He told Ravi that he need to went home with you.
d) He told Ravi that you need to went home with him.
Q 2: Change into Indirect Speech:
     He said to me, ‚Does he go to school daily?‛
a) He asked me if he did go to school daily.
b) He asked me if he went to school daily.
c) He asked me if did he go to school daily.
d) He asked me if does he go to school daily.
Q 3: Change into Indirect Speech:
     He said to me, ‚I am your best friend.‛
a) He told me that I was your best friend.
b) He told me that I am his best friend.
c) He told me that he is my best friend.
d) He told me that he was my best friend.

Q 4: Change into Indirect Speech:
     He said, ‚Raveena had a car.‛
a) He told that Raveena had a car.
b) He said that Raveena had a car.
c) Both of the above
d) None of the above
Q 5: Change into Indirect Speech:
     He said, ‚Who are you?‛
a) He asked who I was.
b) He asked who was I.
c) Both of the above
d) None of the above
Q 6: Change into Indirect Speech:
     He said to Shweta, ‚Who are you to me?‛
a) He asked Shweta who she was to him.
b) He asked Shweta who was she to him.
c) Both of the above
d) None of the above
Q 7: Change into Indirect Speech:
     My boss said to me, ‚Don’t go there.‛
a) My boss requested me not to go there.
b) My boss ordered me not to go there.
c) My boss requested me that not to go there.
d) My boss ordered me that not to go there.
Q 8: Change into Indirect Speech:
      He said, ‚Would that I were a girl!‛
a) He wished that he was a girl.
b) He wished that he were a girl.
c) He wished that he had been a girl.
d) All of the above
Q 9: Change into Indirect Speech:
     He said, ‚May you succeed in life!‛
a) He wished that you succeeded in life.
b) He prayed that I succeeded in life.
c) He prayed that I might succeed in life.
d) He wished that I might succeed in life.

Q 10: Change into Indirect Speech:
     He said, ‚Oh no! I missed it.‛
a) He exclaimed with joy that he missed it.
b) He exclaimed with joy that he had missed it.
c) He exclaimed with sorrow that he missed it.
d) He exclaimed with sorrow that he had missed it.
Q 11: Change into Indirect Speech:
     She said to Mayank, ‚Whom will you meet today?‛
a) She asked Mayank whom will you meet today.
b) She asked Mayank whom would you meet that day.
c) She asked Mayank whom he would meet today.
d) She asked Mayank whom he would meet that day.
Q 12: Change into Indirect Speech:
     He said, ‚Honesty is the best policy.‛
a) He told that honesty is the best policy.
b) He told that honesty was the best policy.
a) He said that honesty is the best policy.
b) He said that honesty was the best policy.
Q 13: Change into Indirect Speech:
     He said, ‚Ravi met me yesterday.‛
a) He told that Ravi met him yesterday.
b) He said that Ravi had met him yesterday.
c) He said that Ravi met me yesterday.
d) He told that Ravi had met me yesterday.
Q 14: Change into Indirect Speech:
     He said, ‚Am I at home?‛
a) He asked if he was at home.
b) He asked whether he was at home.
c) Both of the above
d) None of the above
Q 15: Change into Indirect Speech:
      She said, ‚Would that she were at home!‛
a) She wished that she was at home.
b) She wished that she were at home.
c) She wished that she had been at home.
d) All of the above

Q 16: Change into Indirect Speech:
     He said to Shabnam, ‚May you live long!‛
a) He wished to Shabnam that she might lived long.
b) He prayed to Shabnam that she might lived long.
c) He prayed that Shabnam might live long.
d) He wished that Shabnam might live long.
Q 17: Change into Indirect Speech:
     He said, ‚How many people are here?‛
a) He asked how many people are there.
b) He asked how many people were there.
c) He asked how many people there are.
d) He asked how many people there were.
Q 18: Change into Indirect Speech:
     He said, ‚You can’t talk about me.‛
a) He said that he couldn’t talk about me.
b) He said that I couldn’t talk about him.
c) He told that he couldn’t talk about me.
d) He told that I couldn’t talk about him.
Q 19: Change into Indirect Speech:
     He said to Meena, ‚I must consult a doctor.‛
a) He told Meena that he has to consult a doctor.
b) He told Meena that he had to consult a doctor.
c) He told Meena that he should consult a doctor.
d) He told Meena that he shall consult a doctor.
Q 20: Change into Indirect Speech:
  He said to me, ‚Please keep the door ajar.‛
a) He requested me to keep the door ajar.
b) He requested me to kept the door ajar.
c) He advised me to kept the door ajar.
d) He ordered me to kept the door ajar.
                                          Answers
1a, 2b, 3d, 4b, 5a, 6a, 7b, 8c, 9c, 10d, 11d, 12c, 13b, 14c, 15c, 16c, 17d, 18b, 19b,
20a.
```

## Quiz 32

```text
Choose the correct alternative:
Q 1: Change into Indirect Speech:
     He said, ‚May you earn lots of money!‛
a) He wished that I might earn lots of money.
b) He prayed that I might earn lots of money.
c) He wished that he might earn lots of money.
d) He prayed that he might earn lots of money.
Q 2: Change into Indirect Speech:
     He said, ‚Ranveer is so handsome!‛
a) He exclaimed with wonder that Ranveer was so handsome.
b) He exclaimed with applause that Ranveer was so handsome.
a) He exclaimed with wonder that Ranveer is so handsome.
b) He exclaimed with applause that Ranveer is so handsome.
Q 3: Change into Indirect Speech:
     He said, ‚Oh! I missed the chance.‛
a) He exclaimed with sorrow that I missed the chance.
b) He exclaimed with sorrow that he missed the chance.
c) He exclaimed with sorrow that he had missed the chance.
d) He exclaimed with sorrow that he has missed the chance.
Q 4: Change into Indirect Speech:
     He said, ‚How tragic the situation is!‛
a) He exclaimed with sorrow how tragic the situation was.
b) He exclaimed with sorrow that the situation was so tragic.
a) He exclaimed with sorrow how tragic the situation is.
b) He exclaimed with sorrow that the situation is so tragic.
Q 5: Change into Indirect Speech:
     He said, ‚Who are we?‛
a) He asked who we are.
b) He asked who are we.
c) He asked who they were.
d) He asked who were they.
Q 6: Change into Indirect Speech:
     He said to Shweta, ‚May you pass the interview today!‛
a) He wished that she might pass the interview that day.
b) He wished that Shweta might pass the interview that day.

c) He prayed that she might pass the interview that day.
d) He prayed that Shweta might pass the interview that day.
Q 7: Change into Indirect Speech:
     My boss said to me, ‚Don’t come inside the room.‛
a) My boss ordered me not to come inside the room.
b) My boss ordered me that not to come inside the room.
c) My boss ordered me to not come inside the room.
d) My boss ordered me that to not come inside the room.
Q 8: Change into Indirect Speech:
     He said, ‚Would that she were a teacher!‛
a) He wished that she were a teacher.
b) He wished that she had been a teacher.
c) He wished that she was a teacher.
d) He wished that she was to be a teacher.
Q 9: Change into Indirect Speech:
     He said, ‚May you score 99 percentile in CAT!‛
a) He wished that you might score 99 percentile in CAT.
b) He prayed that you might score 99 percentile in CAT.
c) He wished that I might score 99 percentile in CAT.
d) He prayed that I might score 99 percentile in CAT.
Q10: Change into Indirect Speech:
     My friend said, ‚What a rapper Emiway is!‛
a) My friend exclaimed with wonder that Emiway is a great rapper.
b) My friend exclaimed with wonder that Emiway was a great rapper.
c) My friend exclaimed with wonder that Emiway has been a great rapper.
d) My friend exclaimed with wonder that Emiway had been a great rapper.
Q 11: Change into Indirect Speech:
     She said to Mayank, ‚Good bye!‛
a) She bade Mayank good bye.
b) She bade good bye to Mayank.
c) Both of the above
d) None of the above
Q 12: Change into Indirect Speech:
     She said to her dad, ‚Good morning, dad!‛
a) She wished her dad good morning.
b) She bade her dad good morning.

c) Both of the above
d) None of the above
Q 13: Change into Indirect Speech:
     Boss said to me, ‚Follow me.‛
a) Boss ordered me to follow him.
b) Boss instructed me to follow him.
c) Both of the above
d) None of the above
Q 14: Change into Indirect Speech:
     He asked, ‚Am I in office?‛
a) He asked if he was in office.
b) He asked whether he was in office.
c) Both of the above
d) None of the above
Q 15: Change into Indirect Speech:
     She said, ‚Would that Raveena were here!‛
a) She wished that Raveena was here.
b) She wished that Raveena had been here.
a) She wished that Raveena was there.
b) She wished that Raveena had been there.
Q 16: Change into Indirect Speech:
     He said to me, ‚May you live long!‛
a) He wished me that I might live long.
b) He prayed me that I might live long.
c) He prayed that I might live long.
d) He wished that I might live long.
Q 17: Change into Indirect Speech:
     Doctor said to the patient, ‚Stop drinking.‛
a) Doctor advised the patient to stop drinking.
b) Doctor advised the patient to stop drink.
c) Doctor advised the patient to stop drunk.
d) Doctor advised the patient to stop to drink.
Q 18: Change into Indirect Speech:
     He said, ‚Sorry for being rude to you!‛
a) He exclaimed with regret that he was rude to you.
b) He exclaimed with regret that he was rude to him.

c) He exclaimed with regret that he was rude to me.
d) He exclaimed with regret that you were rude to me.
Q 19: Change into Indirect Speech:
     He said to Shweta, ‚Please speak the truth.‛
a) He requested Shweta to speak the truth.
b) He requested Shweta to spoke the truth.
c) He requested Shweta to spoken the truth.
d) He requested Shweta to have spoken the truth.
Q 20: Change into Indirect Speech:
     He said to me, ‚Please keep the windows open.‛
a) He requested me to keep the windows open.
b) He requested me to kept the windows open.
c) He advised me to kept the windows opened.
d) He ordered me to keep the windows opened.
                                          Answers
1b, 2a, 3c, 4b, 5c, 6d, 7a, 8b, 9d, 10b, 11c, 12a, 13c, 14c, 15b, 16c, 17a, 18c, 19a,
20a.
```

## Quiz 33

```text
Choose the correct alternative:
Q 1: He decided ......... to Delhi for a consultation with her.
a) to go
b) going
c) go
d) to going
Q 2: I love .............. with you.
a) to dance
b) dancing
c) Any of the above
d) None of the above
Q 3: He continued ................. in office even in such adverse situations.
a) to work
b) working
c) Any of the above
d) None of the above

Q 4: He stopped ............... hello to his friends.
a) to say
b) saying
c) Any of the above
d) None of the above
Q 5: He turned out ................. a great player of the last decade.
a) to be
b) being
c) Any of the above
     d) None of the above
Q 6: Our country resumed ................. against the evil.
a) to fight
b) fighting
c) Any of the above
d) None of the above
Q 7: I felt like .............. him for this misbehaviour.
a) to slap
b) slapping
c) Any of the above
d) None of the above
Q 8: She preferred ............... with me.
a) to work
b) working
c) Any of the above
d) None of the above
Q 9: I enjoyed ................... in my childhood.
a) to swim
b) swimming
c) Any of the above
d) None of the above
Q 10: Why do you hesitate ............... in English?
a) to speak
b) speaking
c) Any of the above
d) None of the above

Q 11. They failed ............... home early morning.
a) to leave
b) leaving
c) Any of the above
d) None of the above
Q 12: You tend .............. more when you fail than when you win.
a) to learn
b) learning
c) Any of the above
d) None of the above
Q 13; He deserves ................. promoted for his great work.
a) to be
b) being
c) Any of the above
d) None of the above
Q 14: They look forward ................. me today.
a) to meet
b) to meeting
c) meeting
d) Any of the above
Q 15: It was worth ............... you.
a) to meet
b) to meeting
c) meeting
d) Any of the above
Q 16: I can’t hold .............. while .............. to his comedy.
a) laughing, listen
b) laugh, listening
c) laughing, listening
d) laugh, listen
Q 17: I beg ............ that I’ve been facing problems with this account.
a) saying
b) to say
c) Any of the above
d) None of the above

Q 18: She pretended not ............ doing anything.
a) being
b) to be
c) Any of the above
d) None of the above
Q 19: She hated ............. permission from such a rude boss.
a) to take
b) taking
c) Any of the above
d) None of the above
Q 20: I remember ............... him.
a) to meet
b) meet
c) Any of the above
d) None of the above
                                          Answers
1a, 2c, 3c, 4c, 5a, 6b, 7b, 8c, 9b, 10a, 11a, 12a, 13a, 14b, 15c, 16c, 17b, 18b, 19c,
20c.
```

## Quiz 34

```text
Choose the correct alternative:
Q1: Rahul, with his parents ,............ every week.
a) visit
b) visits
Q2: Saleem, along with his sisters ............ coming today.
a) is
b) are
Q3: She, as well as I ............ your friend.
a) is
b) are
c) am

Q4: He, not his brothers ............. sitting there..
a) is
b) are
Q5: Here ............he.
a) comes
b) come
Q6: Here ............they.
a) comes
b) come
Q7: Here ........... Sapna and Soni.
a) come
b) comes
Q8: If I (was/were) you, I wouldn’t call him.
a) was
b) were
Q9: All of the books ............ mine.
a) Is
b) are
Q10: All of the book ............ to needed to be learnt.
a) Is
b) are
Q11: Each of the apples ............. ripe.
a) was
b) were
Q12: 5 Kms ............. good enough for morning walk.
a) Is
b) are
Q13: Rs. 1000/- ............ the cost of these books
a) Is
b) are
Q14: Many a soldier ........... killed in the war.
a) was
b) were

Q15:The writer and editor of the film ............ invited.
a) was
b) were
Q16:The writer and the editor of the film ........... invited.
a) was
b) were
Q17: Writer and editor of the film ............ invited.
a) was
b) were
Q18:This almirah of books ............ mine.
a) Is
b) are
Q19: A bouquet of the flowers ............ given to him..
a) Is
b) are
Q20: Bread and Butter ............ her daily breakfast.
a) Is
b) are
                                          Answers
1b, 2a, 3a, 4a, 5a, 6b, 7a, 8b, 9b, 10a, 11a, 12a, 13a, 14a, 15a, 16b, 17b, 18a, 19a,
20a.
```

## Quiz 35

```text
Choose the correct alternative:
Q 1: It was ..........who came running .......... the room.
a) he, into
b) him, into
c) he, in
d) he, into
Q 2: Goa is ............. 250 meters ......... the sea level.
a) situating, above
b) situating, over
c) situated, above
d) situated, over
Q 3: .............. it rains heavily, shall we stay at home?
a) suppose if
b) supposing if
c) if
d) supposed if
Q 4: Either you or she .............
a) are in the wrong.
b) is in the wrong.
c) are at the wrong.
d) is at the wrong.
Q 5: Change into Passive Voice: She lets him meet you.
a) He is let meet you by her.
b) He is let met her by you.
c) You are let meet her by him.
d) You are let met him by her.
Q 6: Change into Passive Voice: It makes me cry.
a) I am made cry by it.
b) I made cry by it.
c) I am made cried by it.
d) I made cried by it.

Q 7: I felt like .............. the whole material that day itself.
a) read
b) reading
c) Any of the above
d) None of the above
Q 8: I, as well as, my brothers, ............... older ............
a) am, than he.
b) am, to him.
c) are, to him.
d) are, than him.
Q 9: Change into Indirect Speech: He told me, ‚Who am I?‛
a) He asked me who I am.
b) He asked me who he is.
c) He asked me who I was.
d) He asked me who he was.
Q 10: ‚I love meeting her there.‛ - What is ‚Meeting‛ here?
a) Gerund Form
b) Present Participle Form
Q 11. ‚I am meeting her today.‛ - What is ‚Meeting‛ here?
a) Gerund Form
b) Present Participle Form
Q 12: Spot the error? - He repeatedly warns (A) / us not to (B) / make noise but
(C) / no one cares. (D) / No error (E)
a) A
b) B
c) C
d) D
e) E
Q 13: Spot the error? – Speaking over there (A) / wouldn’t trouble him (B) / if
there were less people (C) / sitting in the auditorium. (D) / No error (E)
a) A
b) B
c) C
d) D
e) E

Q 14: Spot the error? – The number of internet users (A) / is expected (B) / to
rise in huge numbers this year. (C) / No error (D)
a) A
b) B
c) C
d) D
Q 15: The sentence, ‚He is as handsome as Ranveer.‛, is an example of which
figure of speech?
a) Simile
b) Metaphor
c) Oxymoron
d) Hyperbole
Q 16: Synonym of the word ‚Defame‛ is
a) Calumniate
b) Futile
c) Cubicle
d) Fertile
Q 17: The one who has never been defeated is called
a) Fastidious
b) Philanthropist
c) Invincible
d) Victorious
Q 18: Translate the sentence into English: ‚Uske paas ek mobile hona chahiye
tha.‛
a) He should have a mobile.
b) He should have had a mobile.
c) He should has a mobile.
d) He should has had a mobile.
Q 19: Translate the sentence into English: ‚Usne mujhse apna kaam karvaya.‛
a) He made me do his work.
b) He made me did his work.
c) He made me done his work.
Q 20: Translate the sentence into English: ‚Mere dost ke papa ka dost ek
businessman hai.‛
a) My friend’s father’s friend is a businessman.
b) The friend of my friend’s father is a businessman.
c) Any of the above

d) None of the above
                                          Answers
1a, 2c, 3c, 4b, 5a, 6a, 7b, 8a, 9d, 10a, 11b, 12c, 13c, 14d, 15a, 16a, 17c, 18b, 19a,
20c.
```

## Quiz 36

```text
Choose the correct alternative:
Q 1: Translate the following sentence into English:
      तुम पर मेरे Rs.500 उध़ार हैं । (Tum par mere Rs. 500 udhaar hain.)
a) You owe me Rs. 500.
b) I owe you Rs. 500.
Q 2: Translate the following sentence into English:
       वो सोच रहा होगा हक मैं पागल हाँ . (Wo soch raha hoga ki main paagal hu.)
a) He will be thinking that I am mad.
b) He would be thinking that I am mad.
c) He will be thinking that I will be mad.
d) He would be thinking that I would be mad.
Q 3: Translate the following sentence into English:
        काश वो मेरा सगा होता। (Kaash vo mera sagaa hota.)
a) I wish he was my real one.
b) I wish he were my real one.
Q 4: Translate the following sentence into English:
      क्य़ा मु झे कही ं ज़ाऩा है ? (Kya mujhe kahin jaana hai?)
a) Have I to go somewhere?
b) Have I to go anywhere?
c) Have I to go elsewhere?
d) All of the above
Q 5: Change into Passive Voice:
     ‘I make you smile.’
a) You are made smile by me.
b) You are made to smile by me.
c) You are made smiled by me.

Q 6: Change into Passive Voice:
     ‘Let him eat the fish.’
a) Let the fish be eaten by him.
b) The fish let be eaten by him.
c) The fish let eaten by him.
d) Let the fish eaten by him.
Q 7: Translate the following sentence into English:
       मैं वहााँ जाता तक नह ।ीं (Main wahaan jaata tak nahi.)
a) I don’t even go there.
b) Even, I don’t go there.
Q 8: Which part of the following sentence is erroneous?
He repeatedly warns (A) / us not to (B) / make noise but (C) / no one cares. (D) / No
error (E)
a) A
b) B
c) C
d) D
e) E
Q 9: Which part of the following sentence is erroneous?
Speaking over there (A) / wouldn’t trouble him (B) / if there were less people (C) /
sitting in the auditorium. (D) / No error (E)
a) A
b) B
c) C
d) D
e) E
Q 10: Which part of the following sentence is erroneous?
The number of internet users (A) / is expected (B) / to rise in huge numbers this year.
(C) / No error (D)
a) A
b) B
c) C
d) D
e) E
Q 11: Which part of the following sentence is erroneous?
Any one of these (A) / chairs are (B)/ supposed to (C)/ be sold. (D)
a) A

b) B
c) C
d) D
Q 12: Translate into English: ‚Wo mobile kiske paas hai?‛
a) Who has that mobile?
b) Who does that mobile have?
c) Whose has that mobile?
d) Whose does that mobile have?
Q 13: Translate into English: ‚Tum yahaan kab tak ho?‛
a) Until when are you here?
b) Since when are you here?
c) When until are you here?
d) For how long are you here?
Q 14: Which of the following is an incorrect statement?
a) ‘None’ is an indefinite pronoun.
b) ‘An’ is an indefinite article.
c) ‘lots of’ is a quantifier.
d) ‘Mine’ is a reflexive pronoun.
Q 15: Translate into English:
ि और तु म मुझसे क्या चाहते ह ? (Wo or tum mujhse kya chahte ho?)
a) What do he and you want from me?
b) What he and you want from me?
c) What he and you wants from me?
d) What does he and you want from me?
Q16. Translate into English:
उसे प्रबठाया गया। (Use bithaya gaya.)
a) He was sitting.
b) He was to make sit.
c) He was made sit.
d) He was made to sit.
Q17. Translate into Hindi: ‘I let him go.’
a) Main use jaane deta hu. (Present Indefinite Tense)
b) Maine use jaane diya. (Past Indefinite Tense)
c) Both of the above
d) None of the above

Q18. Translate into English:
उसे जाने प्रदया जाता है । (Use jaane diya jaata hai.)
a) He is let go.
b) He is made go.
c) He let goes.
d) He is let to go.
Q19. Translate into English:
उसके पास प्रकताब ह नी ही चाप्रहए थी। (Uske paas book honi hi chahiye thi.)
a) He must have a book.
b) He must have had a book.
c) He had to have a book.
d) He had to had a book.
Q 20: Change into Indirect Speech:
       He asked," Who gave me this pen?"
A) He asked that who had given him that pen.
B) He asked that who gave him that pen.
C) He asked who had given him that pen.
D) He asked who gave him that pen.
                                          Answers
1a, 2b, 3b, 4a, 5a, 6a, 7a, 8c, 9c, 10b, 11b, 12a, 13a, 14d, 15a, 16c, 17c, 18a, 19b,
20d.
```

## Quiz 37

```text
Choose the correct alternative:
Q 1: Change the following sentence into Interrogative:
     ‚He bought a pen.‛
a) Does he buy a pen?
b) Did he bought a pen?
c) Did he buy a pen?
d) Does he bought a pen?

Q 2: Change into Passive Voice:
      ‚He sent me there.‛
a) I am sent there by him.
b) I was sent there by him.
c) I had been sent there by him.
d) I have been sent there by him.
Q 3: Change into Active Voice:
     ‚They should have been given money by you.‛
a) You should give them money.
b) You should have given them money.
c) You should be given the money
d) You should have give them money.
Q 4: Translate the following sentence into English:
      वो मुझे जाने नह ीं दे रहा. (Vo mujhe jaane nahi de raha.)
a) He is not let me go.
b) He is not letting me go.
c) He is not being let me go.
d) He is not let me going.
Q 5: If I had visited Agra, I …………… the Taj.
a) saw.
b) would see.
c) had seen.
d) would have seen.
6. He has invited………to his birthday party.
a) them
b) their
c) they
d) to them
7. Mohan invites……. in his birthday party.
   a) they
   b) those
   c) them
8. Ravi didn’t ……….. a football.
  a) have
  b) has
  c) had

9. I met a man …………….. lots of money.
    a) having
    b) to having
    c) to have
    d) have
10. …………. room of this hotel has a cooler.
   a) Each
   b) Every
   c) Many
   d) All
11. …………care would save you from many accidents.
    a) A few
    b) The few
    c) A little
Q 12: Change the following sentence into Interrogative:
     ‚He needs me.‛
a) Does he need me?
b) Did he need me?
c) Need he me?
d) Do he need me?
Q 13: Change into Passive Voice: ‚I can reveal the truth.‛
a) The truth can revealed by me.
b) The truth can be reveal by me.
c) The truth can be revealed by me.
d) The truth can reveal by me.
Q 14: Change into Active Voice:
     ‚They should have been interrogated by police.‛
a) Police should have interrogate them.
b) Police should have interrogated them.
c) Police should interrogate them.
d) Police should interrogated them.
Q 15: I’ll give you money………..you help me.
a) provided
b) provide to
c) so as to
d) as far as

Q 16: Translate into English:
उसे घर जाना पाा ह गा। (Use ghar jaana pada hoga.)
a) He will have to go home.
b) He would have to go home.
c) He would have had gone home
d) He would have had to go home.
Q 17: ‚To be‛ verbs are:
a) Is/Am/Are/Was/Were
b) Has/Have/Had
c) Do/Does/Did
d) None of the above
Q.18: In a sentence, ‚I have a pen.‛, what is ‚a‛ here:
a) a conjunction
b) An adverb
c) a preposition
d) A determiner
Q.19: Earth is………..
a) a proper noun
b) a common noun
c) an abstract noun
d) a material noun
Q20: Translate into English:
मेरे प़ास पै न होऩा च़ादहए थ़ा। (Mere paas pen hona chahiye tha.)
a) I should a pen.
b) I should have a pen.
c) I should had a pen.
d) I should have had a pen.
                                          Answers
1c, 2b, 3b, 4b, 5d, 6a, 7c, 8a, 9a, 10b, 11c, 12a, 13c, 14b, 15a, 16d, 17a, 18d, 19d,
20d.
```

## Quiz 38

```text
Choose the correct alternative:
1. Are you going to ………………… with your brothers while you are in
Dehradun?
a) getting in touch
b) get in touch
c) having in touch
d) have in touch
2. Her face turned ……………… with anger.
a) red
b) blue
c) green
d) violet
3. She ………………….. an engineer from Manipur.
a) married
b) married with
c) married to
4. She is …………………. than I thought.
a) more fool
b) more of a fool
c) more like a fool
d) more as a fool
Q 5: Either he or I……….to blame.
a) am
b) is
c) are
d) will have
Answer - a) am
Q 6: It’s Rashmi,…………. I had taken that day.
a) whose pen
b) the pen of whose
c) which pen
d) of which pen
Q 7: It’s really tasty. Can I have…………..one?
a) other
b) another

c) more
d) All of the above
Q 8: Synonym of ‚Truthfulness‛:
a) Veracity
b) Voracity
Q 9: Change into Indirect Speech:
       He asked," Who gave me this pen?"
A) He asked that who had given him that pen.
B) He asked that who gave him that pen.
C) He asked who had given him that pen.
D) He asked who gave him that pen.
Q 10: Which of the following is an incorrect sentence?
a) Neither of you are my friend.
b) Either of you is my friend.
c) Many a man is sitting in the auditorium.
d) Some of the pens are blue in color.
Q 11: Which part of the following sentence is erroneous?
One of the university (A) / has invited me (B) / for admission. (C) / No error. (D)
a) A
b) B
c) C
d) D
Q 12: Which part of the following sentence is erroneous?
I will (A) / take care myself (B) / and you enjoy yourselves. (C) / No error (D)
a) A
b) B
c) C
d) D
Q 13: One is not satisfied with………..money one………
a) however, has
b) however, have
c) whichever, has
d) whichever, have
Q 14: It was a brilliant ...................., albeit a little late.
a) maneuvre
b) stear

c) movement
d) Any of the above
Q 15: No one can say ……..he will ever plan to visit this city or not.
a) If
b) That
c) Whether
d) as
Q 16: …….he studies well, he will fail.
a) Until
b) Unless
c) Till
d) All of the above
Q 17: I can …………………….. a key player of the company.
a) turn up to be
b) turn out to be
c) turn on to be
d) All of the above
Q 18: The subject of a sentence may be
a) a noun or a pronoun
b) a noun or a gerund
c) a gerund or an infinitive
d) a noun, pronoun, gerund or an infinitive
Q 19: Translate into English: ‚Uske sath kaun gaya?‛
a) Who go with him?
b) Who did go with him?
c) Who went with him?
d) Who had gone with him?
Q 20: Translate into English: ‚Maine usse help maangi.‛
a. I told him to help me.
b. I said him to help me.
c. I asked him to help me.
d. I begged him to help me.
                                          Answers
1b, 2a, 3a, 4b, 5a, 6a, 7b, 8a, 9d, 10a, 11a, 12b, 13a, 14a, 15c, 16b, 17b, 18d, 19c,
20c.
```

## Quiz 39

```text
Choose the correct alternative:
Q 1: What is a synonym for "fecund"?
a) Fertile
b) Fetid
c) Fusion
d) Facet
Q 2: What is an antonym for "dismantle"?
a) Remake
b) Assemble
c) Arrange
d) Mantle
Q 3: What is an antonym for "abundant"?
a) Scarce
b) Plentiful
c) Huge
d) Excessive
Q4: What is a synonym for "noticeable"?
a) Conspicuous
b) Extraordinary
c) Entertaining
d) Disgusting
Q5: What is a synonym for "Damp"?
a) Slightly dry
b) Slightly wet
c) Slightly hot
d) Slightly cold
Q6: What is an antonym for "halt"?
a) Begin
b) Stop
c) End
d) Postpone
Q7: Arduous means:
a) Easy

b) Difficult
c) Thin
d) Angry
Q8: Rapture means:
a) Grief
b) Depression
c) Happiness
d) Peace
Q 9: Change into Indirect Speech:
       He said to her, ‚Are you going?‛
a) He asked her if you were going.
b) He asked her if she was going.
c) He asked her that was she going.
d) He asked her that she was going.
Q 10: Change into Indirect Speech:
       He asked," who called me?"
A) He asked that who called him.
B) He asked that who had called him.
C) He asked who called him.
D) He asked who had called him.
Q 11: The Earth is not…………….in its axis.
a) stationary
b) stationery
Q12: Translate the sentence: ‚Kya main ghar jaaun?‛
a) Do I go home?
b) Shall I go home?
c) Should I go home?
d) All of the above
Q 13: Homophones are the words………………………………..
a) same in pronunciation but different in spelling and meaning.
b) same in spelling but different in pronunciation and meaning.
c) same in spelling and pronunciation but different in meaning.
Q 14: Translate the following sentence into English:
       मैं 10 स़ाल दे हऱादू न रह चु क़ा हँ. (Main 10 saal Dehradun rah chuka hun.)
a) I have been in Dehradun for 10 years.
b) I have been to Dehradun for 10 years.

Q 15: Translate the following sentence into English:
       मैं एक ब़ार दे हऱादू न ज़ा चु क़ा हँ . (Main ek baar Dehradun jaa chuka hun.)
a) I have been in Dehradun once.
b) I have been to Dehradun once.
Q16: ‚He owes me Rs.500‛ means?
a) He has to give me Rs. 500.
b) He has to take Rs. 500 from me.
Q 17: Could you...................his voice, even though it was noisy around.
a) identify
b) recognize
c) Both of the above
d) None of the above
Q 18: What is PANGRAM in a language?
a) A sentence containing all the letters of the Alphabet.
b) A sentence containing all the vowels of the Alphabet.
c) A sentence containing all the consonants of the Alphabet.
d) A sentence containing no consonants of the Alphabet.
Q19: There is a river……….this mountain.
a) beyond
b) across
c) cross
d) away
Q20: ‚Mujhe ghar jaana pad raha hai.‛ How to translate it into English?
a) I am to go home.
b) I have to go home.
c) I am having to go home.
d) I have to be going home.
                                          Answers
1a, 2b, 3a, 4a, 5b, 6a, 7b, 8c, 9b, 10d, 11a, 12d, 13a, 14a, 15b, 16a, 17b, 18a, 19a,
20c.
```

## Quiz 40

```text
Choose the correct alternative:
Q 1: Which part of the following sentence is erroneous?
Each of my friends (A) / are (B) / self motivated. (C) / No error (D)
a) A
b) B
c) C
d) D
Q 2: Choose the correct sentence:
a) Meeting you at least once is my lifelong desire.
b) To meet you at least once is my lifelong desire.
c) Both of the above
d) None of the above
Q 3: Choose the correct sentence:
a) He is here to meet you at least once.
b) He is here meeting you at least once.
c) Both of the above
d) None of the above
Q 4: He is blind …… one eye.
a) of
b) with
c) in
d) by
Q 5: Change into Indirect Speech:
       Rahul said to me, "I will meet people following me on FB.‛
a) Rahul told me that he will meet people following him on FB.
b) Rahul told me that I will meet people following me on FB.
c) Rahul told me that he would meet people following me on FB.
d) Rahul told me that he would meet people following him on FB.
Q 6: Change into Indirect Speech:
       Arohi said to Ayansh, ‚Let her complete the homework first.‛
a) Arohi suggested to Ayansh that she should complete the homework first.
b) Arohi asked Ayansh that she should let her complete the homework first.
c) Arohi suggested to Ayansh that she should let complete the homework first.
d) Arohi ordered Ayansh that she should let complete homework first.

Q 7: Change into Indirect Speech:
       Arnavi said," why am I here?"
a) Arnavi asked why was I there.
b) Arnavi asked why I was there.
c) Arnavi asked why was she there.
d) Arnavi asked why she was there.
Q 8: Which of the following sentences is incorrect?
a) He is a learned person.
b) There are peoples from India, Australia, and England.
c) I have a few money in my pocket.
d) To eat burger is his habit.
Q 9: The sentence ‚This is theirs.‛ is:
a) Correct
b) Incorrect
Q 10: Which of the following is a correct statement?
a) ‘Shop’ is an abstract noun.
b) ‘Boy’ is a proper noun.
c) ‘Crowd’ is a collective noun.
d) ‘India’ is a common noun.
Q 11: Which of the following is an incorrect statement?
a) ‘Gold’ is a material noun.
b) ‘Her’ is a possessive pronoun.
c) ‘Myself’ is an intensive pronoun.
d) ‘Him’ is a subjective pronoun.
Q 12: Mr. John Smith in an ……….. India.
a) emigrant in
b) emigrant from
c) immigrant in
d) immigrant from
Q 13: The executioner ………… the criminal.
a) hanged
b) hung
c) hang
d) hanging

Q 14: In the sentence ‚I have nothing to eat.‛, what is ‚to eat‛ here?
a) Noun Infinitive
b) Adjectival Infinitive
c) Adverbial Infinitive
d) Bare Infinitive
Q 15: In a sentence, ‚I love driving.‛, what is ‚driving‛?
a) Gerund
b) Present Participle as a verb
c) Present Participle as an adjective
d) Perfect Participle
Q 16: The sentence ‚His daughter is as beautiful as a rose.‛ is an example of
which figure of speech?
a) Personification
b) Metaphor
c) Simile
d) Hyperbole
Q 17: Which word is similar to ‚Defame‛?
a) Calumniate
b) Cultivate
c) Columnist
d) Pathetic
Q 18: Change into Indirect Speech:
       He said, "Shall we start?‛
a) He asked if they shall start.
b) He asked that we should start.
c) He asked that they should start.
d) He asked if they should start.
Q 19: A sentence ‚He saw a man who was blind.‛ is a:
a) A simple sentence
b) A complex sentence
c) A compound sentence
Q 20: ‚Either…or‛ is:
A) A cumulative conjunction
B) An adversative conjunction
C) An alternative conjunction
D) An Illative conjunction

Answers
1b, 2c, 3a, 4a, 5d, 6a, 7d, 8c, 9a, 10c, 11d, 12a, 13a, 14b, 15a, 16c, 17a, 18d, 19b,
20c.
```

## Quiz 41

```text
Choose the correct alternative:
Q 1: Translate into English:
      हमें भेज़ा गय़ा। (hame bheja gaya)
a) We were sent.
b) We were to go.
c) We were made go.
d) We were let go.
Q 2: Translate into English:
      ऱाम को ड़ांट़ा ज़ा रह़ा थ़ा। (Ram ko daanta jaa raha tha.)
a) Ram was scolding.
b) Ram was being scold.
c) Ram was being scolded.
d) Ram was made scolded.
Q 3: Translate into English:
       उसे मु झसे दमलव़ाय़ा ज़ायेग़ा। (Use mujhse milvaya jayega)
a) He will be made meet me.
b) He will be made to meet me.
c) Either of the above.
d) Neither of the above
Q 4: Translate into English:
      तुम्हें क्य़ा दसख़ाय़ा ज़ात़ा है ? (tumhe kya sikhaya jaata hai.)
a) What are you taught?
b) What are you be taught?
c)What do you be taught?
d) What are you learned?
Q 5: Translate into English:
      मुझे दभजव़ाय़ा गय़ा। (mujhe bhijvaya gaya.)
a) I was sent.
b) I was made sent.
c) I was made go.
d) I made go.

Q 6: Translate into English:
      उन्हें बत़ाय़ा गय़ा थ़ा। (unhe bataya gaya tha.)
a) They were told.
b) They had been told.
c) They were informed.
d) They were been told.
Q 7: Translate into English:
      तुम्हें क्यों नही ं ज़ाने ददय़ा गय़ा? (tumhe kyo nahi jaane diya gaya.)
a) Why did you not go?
b) Why did you not let go?
c) Why were you not let go?
d) Why were you not let gone?
Q 8:Translate into English:
      क्य़ा आज हमें खे लने ददय़ा ज़ायेग़ा? (kya aaj hame khelne diya jayega.)
a) Will we be let play today?
b) Will we be made play today?
c) Will we let play today?
d) Will we get the play today?
Q 9:Translate into English:
      मुझसे क़ाम करव़ाय़ा ज़ा सकत़ा है। (mujhse kaam karvaya jaa sakta hai.)
a) I can get the work done.
b) Work can be done by me.
c) I can made do the work.
d) I can be made to do the work.
Q 10: Translate into English:
       क्य़ा तुम्हें पीट़ा ज़ात़ा थ़ा? (kya tumhe peeta jata tha.)
a) Had you to be beaten?
b) Were you use to beat?
c) Did you use to be beaten?
d) Were you use to be beaten?
e) Had you been to be beaten?
Q 11: Translate into English:
      सीत़ा को हॉद्धस्पटल ले ज़ाय़ा गय़ा थ़ा। (Seeta ko hospital le jaaya gaya tha.)
a)Seeta was brought to hospital.
b) Seeta had been brought to hospital.
c) Seeta was made bring to hospital.
d) Seeta was got brought to hospital.

Q 12:Translate into English:
       सबको ज़ाने ददय़ा ज़ायेग़ा। (sabko jaane diya jayega.)
a) All will let go.
b) All will be gone.
c) All will let be gone.
d) All will be let go.
Q 13:Translate into English:
    हमें ख़ाऩा नही ं ददय़ा ज़ात़ा थ़ा। (hame khana nahi diya jaata tha.)
a) We were not given the food.
b) We didn’t be given the food.
c) We didn’t use to be given the food.
d) We were not to be given the food.
Q 14:Translate into English:
     तुम मु झे पढने क्यों नही ं दे रहे? (tum mujhe padhne kyo nahi de rahe?)
a) Why are you not letting me study?
b) Why do you not let me study?
c) Why are you not let me study?
d) Why are you not let me studying?
Q 15:Translate into English:
      ये क़ाम दकससे करव़ाय़ा गय़ा थ़ा? (ye kaam kisse karvaya gaya tha?)
a) Who was made to do this work?
b) Who was made do this work?
c) Whom was this work get done by?
d)All of the above
Q 16: My father always scolds me ………….. he is Hitler.
a) Even
b) However
c) As though
d) So that
e) None of these
Q 17: I have not met him ……….
a) Till now
b) As Yet
c) So far
d) Still
e) None of these

Q 18: Work hard lest you…….fail.
a) will
b) should
c) can
d) might
e) None of these
Q 19: I can’t say ……..he will come.
a) If
b) That
c) Whether
d) as
e) None of these
Q 20: I can’t say ……..he will come or not.
a) If
b) That
c) Whether
d) as
e) None of these
                                        Answers
1a, 2c, 3c, 4a, 5c, 6b, 7c, 8a, 9d, 10c, 11b, 12d, 13c, 14a, 15d, 16c, 17b, 18b, 19a,
20c.
```

## Quiz 42

```text
Choose the correct alternative:
Q1: I was sitting…………….the shade of a tree.
a) under
b) in
Q2: The kids were …….the Sun all day, that’s why they got sunburned.
a) under
b) in
Q3: He was basking…………..the Sun.
a) under
b) in
Q4: There is nothing ………. the sun
a) under
b) in
Q5: Aman ……………………………my home.
a) sometimes comes
b) sometime comes
c) sometimes come
d) sometime come
Q6: Famous saying: It takes two to …………..
a) tango.
b) bingo
c) ringo
Q7: Famous saying: It takes two to make a ……………….
a) dispute
b) quarrel
c) fight
Q8: Make passive of: He gave Rakesh a pen.
a) Rakesh was given a pen by him.
b) A pen was given to Rakesh by him.
c) Both of the above
d) None of the above

Q9: Superfluous means:
a) Unnecessary
b) Supreme
c) Superhit
d) Needed
Q10: Synonym of ‚Aphorism‛:
a) Saying
b) Proverb
c) Idiom
d) All of the above
Q11: I………………..the food.
a) have had
b) had had
c) Both of the above
d) None of the above
Q12: In a sentence, ‚He is clever.‛, What is CLEVER?
a) Complement
b) Adjective
c) Both of the above
d) None of the above
Q13: Which part of the following sentence is erroneous?
I (A) / don’t have (B) / any money (C) / No error (D)
a) A
b) B
c) C
d) D
Q14: Translate the following sentence into English:
      हमें सोचना होता. (Hame sochna hota.)
a) We will have to think.
b) We would have to think.
Q15: Introductory preface of a drama is called
a) Ideology
b) Calligraphy
c) Prologue
d) Antidote

Q16: Government by people, of people, for people is known as
a) Autocracy
b) Bureaucracy
c) Democracy
d) Monarchy
Q17: Add question tag: I am your friend, …………
a) aren’t I?
b) Ain’t I?
c) Both of the above
Q18: Change the following sentence into negative:
     ‘He would have been working with me.’
a) He would have not been working with me.
b) He would not have been working with me.
c) He would have been not working with me.
d) He would have been working not with me.
Q19: Choose the correct spelling?
a) Pronunciation
b) Pronounciation
Q20: Antonym of the word ‘Amalgamate’ is:
A) Separate
b) Consolidate
                                          Answers
1b, 2b, 3b, 4a, 5a, 6a, 7b, 8c, 9a, 10d, 11c, 12c, 13d, 14b, 15c, 16c, 17c, 18b, 19a,
20a.
```

## Quiz 43

```text
Choose the correct alternative:
Q1: Choose the correct spelling:
 a) Accommodate
 b) Accomodate
 c) Accommodate
Q2: Choose the correct spelling:
 a) Achieve
 b) Achieve
Q3: Choose the correct spelling:
 a) Aggressive
 b) Agressive
 c) Aggressive
Q4: Choose the correct spelling:
 a) Bizzarre
 b) Bizarre
 c) Bizzare
Q5: Choose the correct spelling:
 a) Cemetary
 b) Cemetery
Q6: Choose the correct spelling:
 a) Concious
 b) Conscious
Q7: Choose the correct spelling:
 a) Curiousity
 b) Curiosity
Q8: Choose the correct spelling:
 a) Embarass
 b) Embarrass
Q9: Choose the correct spelling:
 a) Florescent
 b) Flourescent

Q10: Choose the correct spelling:
 a) Fourty
 b) Forty
Q11: Choose the correct spelling:
 a) Nineth
 b) Ninth
Q12: Choose the correct spelling:
 a) Twelveth
 b) Twelvth
 c) Twelfth
 d) Twelvfth
Q13: Choose the correct spelling:
 a) Necessary
 b) Necessary
Q14: Choose the correct spelling:
 a) Propaganda
 b) Propoganda
 c) Propeganda
Q15: Choose the correct spelling:
 a) Tommorrow
 b) Tommorow
 c) Tomorrow
 d) Tomorrow
Q16: Choose the correct spelling:
 a) Truely
 b) Truly
Q17: Choose the correct spelling:
 a) wierd
 b) Weird
Q18: Choose the correct spelling:
 a) Supercede
 b) Supersede

Q19: Choose the correct spelling:
a) Concede
b) Consede
Q20: Choose the correct spelling:
a) Posession
b) Possession
c) Possesion
                                         Answers
1a, 2a, 3a, 4b, 5b, 6b, 7b, 8b, 9b, 10b, 11b, 12c, 13a, 14a, 15c, 16b, 17b, 18b, 19a,
20b.
```

## Quiz 44

```text
Choose the correct alternative:
Q 1: I have three old …………….. to sell this month.
a) furniture
b) furnitures
c) piece of furniture
d) pieces of furniture
Q 2: The sentence ‚He is as hard as a rock.‛ is an example of which figure of
speech?
a) Personification
b) Metaphor
c) Simile
d) Hyperbole
Q 3: In a sentence, ‚I like riding.‛, what is ‚riding‛?
a) Gerund
b) Present Participle as a verb
c) Present Participle as an adjective
d) Perfect Participle
Q 4. Change into Indirect Speech:
     He said, ‚How tragic the situation is!‛
a) He exclaimed with sorrow how tragic the situation was.
b) He exclaimed with sorrow that the situation was so tragic.
a) He exclaimed with sorrow how tragic the situation is.
b) He exclaimed with sorrow that the situation is so tragic.

Q 5: Which word is opposite to ‚Tiny‛?
a) Little
b) Immense
c) Astonish
d) Crumple
Q 6: In a sentence, ‚Her deep thought on this matter was anticipatory for
everyone.‛, what is the word ‘thought’ here?
a) A verb
b) A noun
c) An adjective
d) A bare infinitive
Q 7: Which word is similar to ‚Calumniate‛?
a) Defame
b) Cultivate
c) Columnist
d) Pathetic
Q 8: A sentence ‚He only eats the food, which is cooked at his home.‛ is a:
a) A simple sentence
b) A complex sentence
c) A compound sentence
Q 9: He is blind …… both the eyes.
a) of
b) with
c) in
d) by
Q 10: ‚Neither…nor‛ is:
A) A cumulative conjunction
B) An adversative conjunction
C) An alternative conjunction
D) An Illative conjunction
Q 11: I don’t have …………. water in my glass.
a) any
b) little
c) few
d) a few

Q 12: In a sentence, ‚Tell that boy there.‛, ‚There‛ is used as:
a) an adverb
b) an adjective
c) an interjection
d) a pronoun
Q 13: Change into Indirect Speech:
       He said, "Shall we go?‛
a) He asked if they shall go.
b) He asked that we should go.
c) He asked that they should go.
d) He asked if they should go.
Q 14: What does the word ‚Agony" mean?
a) Great joy
b) Great sorrow
c) Great surprise
d) Great shock
Q 15: The contraction of ‚shall not‛ is
a) Shalln’t
b) Shan’t
c) Shaln’t
d) Shaln’t
Q 16: What does ‚o’clock‛ stands for?
a) On the clock
b) Over the clock
c) Of the clock
d) Onto the clock
Q17: The one who lives with the trend is known as:
a) Contemporary
b) Fastidious
c) Omnivorous
d) Philanthropist
Q 18: ………………how many times we lagged in the rounds, we must finally win
the race.
a) Except of
b) Regardless of
c) Apart from
d) Besides of

Q 19: The ………. investigation will surely reveal the truth in our favor, I bet.
a) exhaustive
b) through
c) detail
d) allies
Q 20. Change into Indirect Speech:
     He said, ‚Would that she were a teacher!‛
a) He wished that she were a teacher.
b) He wished that she had been a teacher.
c) He wished that she was a teacher.
d) He wished that she was to be a teacher.
                                          Answers
1d, 2c, 3a, 4b, 5b, 6b, 7a, 8b, 9a, 10c, 11a, 12b, 13d, 14b, 15b, 16c, 17a, 18b, 19a,
20b.
```

## Quiz 45

```text
Choose the correct alternative:
Q 1: Translate the following sentence into English:
        काश मैं तुमसे हमल पाता. (Kaash main tumse mil paata.)
a) I wish I would meet you.
b) I wish I could meet you.
c) I wish I could have met you.
d) I wish I would have met you.
Q2: Translate the following sentence into English:
       वो मुझे जाने नह ीं दे रहा. (Vo mujhe jaane nahi de raha.)
a) He is not let me go.
b) He is not letting me go.
c) He is not being let me go.
d) He is not let me going.
3. He has invited………to his birthday party.
a) them
b) their
c) they
d) to them

4. The student has been suffering ……. fever……. 3 days.
a) from, for
b) from, since
c) with, for
d) with, since
Q 5: I’ll give you money………..you help me.
a) provided
b) provide to
c) so as to
d) as far as
Q 6: ‚Asterisk‛ is:
A) A star symbol
b) An ampersand symbol
c) A hyphen symbol
d) An underscore symbol
Q 7: Antonym of the word ‚Awesome‛ is:
a) Awful
b) Aweful
Q 8: Change into Indirect Speech:
       He said to her, ‚Are you going?‛
a) He asked her if you were going.
b) He asked her if she was going.
c) He asked her that was she going.
d) He asked her that she was going.
Q 9: Change into Indirect Speech:
       He asked," who called me?"
A) He asked that who called him.
B) He asked that who had called him.
C) He asked who called him.
D) He asked who had called him.
Q 10: The sentence ‚He was in your position 3 years ago.‛ is an example of:
a) The Indicative mood
b) The Imperative mood
c) The Interrogative mood
d) The Subjunctive mood

Q 11: The contraction of ‚shall not‛ is
a) Shalln’t
b) Shan’t
c) Shaln’t
d) Shaln’t
Q 12: He ..…………… finished the homework by now.
a) is supposed to be
b) is supposed to have
c) has supposed to be
d) has supposed to have
Q13: What is PANGRAM in a language?
a) A sentence containing all the letters of the Alphabet.
b) A sentence containing all the vowels of the Alphabet.
c) A sentence containing all the consonants of the Alphabet.
d A sentence containing no consonants of the Alphabet.
Q14: He ………. here for a long.
a) is
b) was
c) has been
d) have been
Q15: ‚Mujhe ghar jaana pad raha hai.‛ How to translate it into English:
a) I am to go home.
b) I have to go home.
c) I am having to go home.
d) I have to be going home.
Q 16: Translate the following sentence into English:
       मुझे घर जाना पड़ता. (Mujhe ghar jaana padta.)
a) I will have to go home.
b) I would have to go home.
Q 17: Which part of the following sentence is erroneous?
Generally (A) / an unique person (B)/ makes (C)/ good impression on others. (D)
a) A
b) B
c) C

d) D
Q 18: He ………….. a book since morning.
a) is reading.
b) was reading.
c) has been reading.
d) have been reading
Q 19: Translate the following sentence into English:
      हमें सोचना होता. (Hame sochna hota.)
a) We will have to think.
b) We would have to think.
Q 20: Translate the following sentence into English:
        काश वो मेरा बेटा होता। (Kaash vo mera beta hota.)
a) I wish he was my son.
b) I wish he were my son.
                                          Answers
1b, 2b, 3a, 4a, 5a, 6a, 7a, 8b, 9d, 10d, 11b, 12b, 13a, 14c, 15c, 16b, 17b, 18c, 19b,
20b.
```

## Quiz 46

```text
Choose the correct alternative:
Q1: He got only ……….. marks.
a) pass
b) passing
c) passed
Q2: Please look into the matter. …………………. faithfully
a) your
b) yours
c) your’s
d) yours’
Q3: I want to buy ten ……..
a) knives
b) knifes
c) knife
d) pair of knife

Q4: I go for a five ………. walk every day.
a) mile
b) miles
Q5: Every person should write …………name neatly.
a) his
b) their
c) every’s
d) one’s
Q6: Spot the error?
     I heard (a) / about (b) / an university (c) / yesterday itself. (d)
a) a
b) b
c) c (A UNIVERSITY)
d) d
Q7: Spot the error?
     Bible (a) / says that (b) / God is (c) / great. (d)
a) a (THE BIBLE)
b) b
c) c
d) d
Q8: He was …….. of the two brothers.
a) older
b) elder
c) the oldest
d the eldest
Q9: He did nothing but ………
a) cry
b) crying
c) cried
d) to cry
Q10: She prefers coffee …………….tea.
a) over
b) to
c) for

Q11: He has to ………………..his expenses due to falling income.
a) cut off
b) cut of
c) cut down
d) cut out
Q12: Tension between them has …………….. to some extent.
a) eased up
b) eased off
c) eased
d) eased over
Q13: This monument is a ………………example of 1902 architecture.
a) prime
b) primary
c) prevalent
d) primitive
Q14: He doesn’t work, …………………..
a) nor does she.
b) nor she does
Q15: Do you know …………………?
a) swimming
b) how to swim
c) how to swimming
Q16: Many a ………………… sitting there.
a) man are
b) men are
c) man is
d) men is
Q17. Choose the correct spelling:
a) Accommodate
b) Accommodate
c) Acommodate
Q18. Choose the correct spelling:
a) Bizzarre
b) Bizarre
c) Bizzare

Q19. Choose the correct spelling:
a) Propaganda
b) Propoganda
c) Propeganda
Q20. Choose the correct spelling:
a) weird
b) Weird
                                          Answers
1a, 2b, 3a, 4a, 5a, 6c, 7a, 8b, 9a, 10b, 11c, 12a, 13a, 14a, 15b, 16c, 17a, 18b, 19a,
20b .
```

## Quiz 47

```text
Choose the correct alternative:
Q1: Spot the error:
Two people, the (A) / cashier and the (B) / officer, helps me (C) / in my bank. (D) / No
error (E)
a) A
b) B
c) C
d) D
e) E
Q 2: Spot the error:
My house (A) / is far better (B) / than John. (C) / No error (D)
a) A
b) B
c) C
d) D
Q 3: Translate the following sentence into English:
      तुम पर मेरे Rs.500 उध़ार हैं । (Tum par mere Rs. 500 udhaar hain.)
a) You owe me Rs. 500.
b) I owe you Rs. 500.
Q 4: Change into Passive Voice:
     ‘Let him eat the fish.’
a) Let the fish be eaten by him.
b) The fish let be eaten by him.

c) The fish let eaten by him.
d) Let the fish eaten by him.
Q 5: ………………did you meet yesterday?
a) who
b) whom
c) either who or whom
Q 6: ……………………. called you that day?
a) who
b) whom
c) either who or whom
Q 7: He gave him some ………………….
a) advice
b) advise
Q 8: Translate into English:
उसे प्रबठाया गया। (Use bithaya gaya.)
a) He was sitting.
b) He was to make sit.
c) He was made sit.
d) He was made to sit.
Q 9: Translate into Hindi: I let him go.
a) Main use jaane deta hu. (Present Indefinite Tense)
b) Maine use jaane diya. (Past Indefinite Tense)
c) Both of the above
d) None of the above
Q 10: Only 10 people were present on his................
a) cremation
b) cramation
c) crametion
d) creamation
Q 11: It’s .............that 10% people have 90% money and vice versa.
a) a paradox
b) an orthodox

Q 12: Which part of the following sentence is erroneous?
One of these cars (A) / is mine, (B) / not her. (C) / No error. (D)
a) A
b) B
c) C
d) D
Q 13: Honesty is………..
a) a proper noun
b) a common noun
c) an abstract noun
d) a material noun
Q 14: Few, Less & Some are
a) Articles
b) Demonstratives
c) Possessives
d) Quantifiers
Q 15: What time ............
a) the bus leaves?
b) leaves the bus?
c) is the bus leaving?
d) does the bus leave?
Q 16: I'm sure there's nothing between…………….
a. you and I.
b. you and me.
Q 17: Change into Indirect Speech:
       He said to her, ‚Are you going?‛
a) He asked her if you were going.
b) He asked her if she was going.
c) He asked her that was she going.
d) He asked her that she was going.
Q 18: Change into Indirect Speech:
       He asked," who called me?"
A) He asked that who called him.
B) He asked that who had called him.
C) He asked who called him.
D) He asked who had called him.

Q 19: He is ……………playing cricket at this moment.
a) suppose to
b) supposed to
c) suppose to be
d) supposed to be
Q 20: I don’t know who ……………..
a) he is.
b) he is?
c) is he.
d) is he?
                                           Answers
1c, 2c, 3a, 4a, 5b, 6a, 7a, 8c, 9c, 10a, 11a, 12c, 13c, 14d, 15d, 16b, 17b, 18d, 19d,
20a.
```

## Quiz 48

```text
Choose the correct alternative:
Q1: I can’t help ……………….. you.
a) call
b) to call
c) calling
Q2: It’s no use……………him.
a) call
b) to call
c) calling
Q3: ……………did he tell about this plan?
a) who
b) whom
c) Both of the above
Q4: ……..does not obey me?
a) who
b) whom
c) Both of the above
Q5: She gave me some ………………
a) advice
b) advise

Q6: It takes time ………….. the dishes.
a) to wash
b) washing
c) wash
Q7: It’s time ……………….goodbye.
a) saying
b) say
c) to say
Q8: I am good ……………. playing football.
a) in
b) at
Q9: It’s ……………….but a pen.
a) none
b) nothing
c) no one
c) One of the above
Q10: Make sure that you …………….. early tomorrow.
a) wake up
b) woke up
c) will wake up
c) would wake up
Q 11: What is a synonym for "fecund"?
a) Fertile
b) Fetid
c) Fusion
d) Facet
Q 12: What is an antonym for "dismantle"?
a) Remake
b) Assemble
c) Arrange
d) Mantle
Q 13: I felt like .............. him for this misbehaviour.
a) to slap
b) slapping
c) Any of the above
d) None of the above

Q 14: She preferred ............... with me.
a) to work
b) working
c) Any of the above
d) None of the above
Q 15: I enjoyed ................... in my childhood.
a) to swim
b) swimming
c) Any of the above
d) None of the above
Q 16: Goa is ............. 250 meters ......... the sea level.
a) situating, above
b) situating, over
c) situated, above
d) situated, over
Q 17: Either you or he .............
a) are in the wrong.
b) is in the wrong.
c) are at the wrong.
d) is at the wrong.
Q 18: Change into Passive Voice: It makes me cry.
a) I am made cry by it.
b) I made cry by it.
c) I am made cried by it.
d) I made cried by it.
Q 19: ‚I love talking to her.‛ - What is ‚talking‛ here?
a) Gerund Form
b) Present Participle Form
Q 20: ‚I am talking to her today.‛ - What is ‚talking‛ here?
a) Gerund Form
b) Present Participle Form
                                          Answers
1c, 2c, 3b, 4a, 5a, 6a, 7c, 8b, 9b, 10a, 11a, 12b, 13b, 14c, 15b, 16c, 17b, 18a, 19a,
20b.
```

## Quiz 49

```text
Choose the correct alternative:
Q 1: My father always scolds me ………….. he is Hitler.
a) Even
b) However
c) As though
d) So that
e) None of these
Q 2: I have not met him ……….
a) Till now
b) As Yet
c) So far
d) Still
e) None of these
Q 3: Work hard lest you…….fail.
i) will
ii) should
iii) can
iv) might
v) None of these
Q 4: I can’t say ……..he will come.
a) If
b) That
c) Whether
d) as
e) None of these
Q 5: Either you or he ……….wrong.
a) Am
b) Are
c) Is
d) Were
e) None of these
Q 6: Did you not go there ……….?
a) also
b) even

c) either
d) too
e) None of these
Q 7: Although I am your friend, ………it doesn’t mean you make me fool.
a) then also
b) yet
c) however
d) still
e) but
Q 8: He can’t…….go there.a)
a) even
b) either
c) yet
d) still
e) also
Q 9: He as well as his friends ……….coming.
a) is
b) are
c) were
d) have been
e) None of these
Q 10: Whether he ……..or not, I must go.
a) comes
b) came
c) come
d) will come
e) None of these
Q 11: I am at ………home.
a) the
b) a
c) an
d) No article
Q 12: She invited me to ……….dinner.
a) the
b) a
c) an
d) No article

Q 13: I was studying in ………..Delhi university.
a) the
b) a
c) an
d) No article
Q 14: I was born in ………….Calcutta.
a) the
b) a
c) an
d) No article
Q 15: He is one of …………..most intelligent students of mine.
a) the
b) a
c) an
d) No article
Q 16: You are……..honest boy.
a) the
b) a
c) an
d) No article
Q 17: You are……..honest.
a) the
b) a
c) an
d) No article
Q 18: I have four and …………half years of experience with international BPOs.
a) the
b) a
c) an
d) No article
Q 19: He is …………..greatest warrior of today.
a) the
b) a
c) an
d) No article

Q 20: He is good at……….mathematics.
a) the
b) a
c) an
d) No article
                                          Answers
1c, 2b, 3b, 4a, 5c, 6c, 7b, 8a, 9a, 10a, 11d, 12d, 13d, 14d, 15a, 16c, 17d, 18b, 19a,
20d.
```

## Quiz 50

```text
Choose the correct alternative:
Q 1: Translate the following sentence into English:
        क्या कभी प्रकसी ने ऐसा स चा ह गा? (Kya kabhi kisi ne aisa socha hoga?)
a) Will one have ever thought so?
b) Would one have ever thought so?
Q 2: Which of the following is an incorrect sentence?
a) Either is my friend.
b) One of them is mine.
c) Either he or you are his friend.
d) This is yours; that is her.
Q 3: ………..he been here, I wouldn’t have worried about you.
a) were
b) had
c) If
Q 4: Which part of the following sentence is erroneous?
Each one (A) / of these toy (B) / is Anjali’s. (C) / No error. (D)
a) A
b) B
c) C
d) D
Q 5: Which part of the following sentence is erroneous?
I’m sure (A) / he’ll (B) / make (C) / a strong come back. (D)
a) A
b) B
c) C
d) D

Q 6: Change into Indirect Speech:
       He asked Aman,"Who are you?‛
A) He asked Aman that who you are.
B) He asked Aman that who he was.
C) He asked Aman who you are.
D) He asked Aman who he was.
Q 7: Which of the following sentences is incorrect?
a) If I were the PM, I would take immediate decision on this issue.
b) Were I the PM, I would take immediate decision on this issue.
c) If I was the PM, I would take immediate decision on this issue.
Q 8: All of this house……….of no use.
a) is
b) are
Q 9: All these cars……….of no use.
a) is
b) are
Q10: What is the meaning of ‘Condemn’?
a) To criticize
b) To appreciate
c) To penalize
d) To reward
Q 11: It was just like a dream, ……….?
a) wasn’t it?
b) isn’t it?
c) Any of the above
Q 12: Choose the correct spelling?
a) Amatuer
b) Amateur
Answer - b) Amateur
Q 13: Horse and carriage…………….rarely seen these days.
a) is
b) are
c) has
d) Aany of the above

Q 14: A person who has never been beaten or defeated, is known as
a) Incredible
b) Invincible
c) Inevitable
d) Cannibal
Q 15: Change into Active Voice:
     ‚I have been seen by him.‛
a) He has seen me.
b) He has been seen me.
c) He has seen by me.
d) He have been seen me.
Q 16: Synonym of the word ‘However’ is:
a) Whoever
b) Whosever
c) Nevertheless
d) Whomever
Q 17: Antonym of the word ‘Incline’ is:
a) Decline
b) Worsen
c) Improve
d) Decay
Q 18: Translate the following sentence into English:
      मुझे खे लने नह ीं प्रदया जा रहा था। (Mujhe khelne nahi diya ja raha tha.)
a) I was not letting play.
b) I was not being let play.
c) I was not being letting play.
d) I was not having been let play.
Q 19: Choose the correct spelling?
a) Embarrassing
b) Embarassing
c) Embarrasing
d) Embarasing
Q 20: Salman and Boby are intelligent. Former is my brother and …………..is my
friend.
a) Later
b) Latter
c) Letter

Answers
1b, 2d, 3b, 4b, 5d, 6d, 7c, 8a, 9b, 10a, 11a, 12b, 13a, 14b, 15a, 16c, 17a, 18b, 19a,
20b.
```

## Quiz 51

```text
Choose the correct alternative:
Q 1: Translate into English:
हमें भेज़ा गय़ा। (hame bheja gaya)
a) We were sent.
b) We were to go.
c) We were made go.
d) We were let go.
Q 2: Translate into English:
ऱाम को ड़ांट़ा ज़ा रह़ा थ़ा। (Ram ko daanta jaa raha tha.)
a) Ram was scolding.
b) Ram was being scold.
c) Ram was being scolded.
d) Ram was made scolded.
Q 3: Translate into English:
तुम्हें क्य़ा दसख़ाय़ा ज़ात़ा है ? (tumhe kya sikhaya jaata hai.)
a) What are you taught?
b) What are you be taught?
c) What do you be taught?
d) What are you learned?
Q 4: Translate into English:
मुझे दभजव़ाय़ा गय़ा। (mujhe bhijvaya gaya.)
a) I was sent.
b) I was made sent.
c) I was made go.
d) I made go.
Q 5: Translate into English:
उन्हें बत़ाय़ा गय़ा थ़ा। (unhe bataya gaya tha.)
a) They were told.
b) They had been told.
c) They were informed.
d) They were been told.

Q 6: Translate into English:
तुम्हें क्यों नही ं ज़ाने ददय़ा गय़ा? (tumhe kyo nahi jaane diya gaya.)
a) Why did you not go?
b) Why did you not let go?
c) Why were you not let go?
d) Why were you not let gone?
Q 7: Translate into English:
क्य़ा आज हमें खे लने ददय़ा ज़ायेग़ा? (kya aaj hame khelne diya jayega.)
a) Will we be let play today?
b) Will we be made play today?
c) Will we let play today?
d) Will we get the play today?
Q 8: Translate into English:
सबको ज़ाने ददय़ा ज़ायेग़ा। (sabko jaane diya jayega.)
a) All will let go.
b) All will be gone.
c) All will let be gone.
d) All will be let go.
Q 9: Translate into English:
तुम मुझे पढने क्यों नही ं दे रहे ? (tum mujhe padhne kyo nahi de rahe?)
a) Why are you not letting me study?
b) Why do you not let me study?
c) Why are you not let me study?
d) Why are you not let me studying?
Q 10: My father always scolds me ………….. he is Hitler.
a) Even
b) However
c) As though
d) So that
e) None of these
Q 11: I have not met him ……….
a) Till now
b) As Yet
c) So far
d) Still
e) None of these

Q 12: Work hard lest you…….fail.
a) will
b) should
c) can
d) might
e) None of these
Q 13: I can’t say ……..he will come.
a) If
b) That
c) Whether
d) as
e) None of these
Q 14: I can’t say ……..he will come or not.
a) If
b) That
c) Whether
d) as
e) None of these
Q 15: Either you or he ……….wrong.
a) Am
b) Are
c) is
d) Were
e) None of these
Q 16: Did you not go there ……….?
a) also
b) even
c) either
d) too
e) None of these
Q 17: Although I am your friend, ………it doesn’t mean you make me fool.
a) then also
b) yet
c) however
d) still
e) but

Q 18: He can’t…….go there.
a) even
b) either
c) yet
d) still
e) also
Q 19: He as well as his friends ……….coming.
a) is
b) are
c) were
d) have been
e) None of these
Q 20: Whether he ……..or not, I must go.
a) comes
b) came
c) come
d) will come
e) None of these
                                          Answers
1a, 2c, 3a, 4c, 5b, 6c, 7a, 8d, 9a, 10c, 11b, 12b, 13a, 14c, 15c, 16c, 17b, 18a, 19a, 20a.
```

## Quiz 52

```text
Choose the correct alternative:
Q1: Did you have any problems........this pen?
a) find
b) finding
c) to find
d) for finding
Q2: Do call me the moment you ………… there.
a) get
b) got
c) have got
d) will get

Q3: He was angry …………….her decision of buying a new laptop.
a) about
b) by
c) against
d) to
Q4): I asked………….I could use this mobile.
a) whether
b) if
c) that
d) All of the above
Q5): It ………………..raining on and off since yesterday.
a) has been
b) is
c) had been
Q6): The bedsheet is ……………… on the bed.
a) lying
b) laid
c) Any of the above
d) None of the above
Q7): She is as ………….as her sister.
a) bad
b) worse
c) worst
d) All of the above
Q8): You are as ………….as her father.
a) tall
b) taller
c) tallest
d) All of the above
Q9): The clothes are …………….in the almirah.
a) hanged
b) hung
Q10: We use a …………….to check the holidays.
a) Calender
b) Calendar

Q11: We will meet you……………….
a) next week
b) next weak
Q12: What do we say to the group of trees?
a) A grove
b) A heap
c) A bundle
d) A herd
Q13: What do we say to the group of stones?
a) A grove
b) A heap
c) A bunch
d) A herd
Q14: What do we say to the group of rubbish?
a) A grove
b) A heap
c) A bundle
d) A herd
Q15: I am tired ……………..this work.
a) of
b) with
c) Any of the above
d) None of the above
Q16: All these pencils……….of no use to me.
a) is
b) are
Q17: All of this mobile……….of no use to me.
a) is
b) are
Q18: Choose the correct spelling:
a) Talkactive
b) Talkative
Q19: Riya and Priya are intelligent. Former is my sister and …………..is my
friend.
a) Later

b) Latter
c) Letter
d) All of the above
Q20: Sorry! She can't come to office,…………...she is unwell.
a) as
b) because
c) for
d) All of the above
                                          Answers
1b, 2a, 3a, 4b, 5a, 6c, 7a, 8a, 9b, 10b, 11a, 12a, 13b, 14b, 15a, 16b, 17a, 18b, 19b,
20d.
```

## Quiz 53

```text
Choose the correct alternative:
Q1: I will……….the train at the next stop.
a) get on
b) get off
c) get off from
d) get on from
Q2: I was driving ______ the road when my bike started making a funny sound.
a) in
b) at
c) down
d) through
Q3: We get good marks ______ we study.
a) but
b) or
c) during
d) because
Q4. Turn left at the next intersection, then go straight for about a kilometer. Go
______ the market, and then turn left.
a) past
b) through
c) at
d) to
e) after

Q5. What are you ……..at the party?
a) Wear
b) Wearing
c) Worn
Q6) I asked………….I can go there or not.
a) whether
b) if
c) that
d) All of the above
Q7. Where……….you put up in Delhi?
a) are
b) do
Q8. What…………….you home yesterday?
a) brought
b) bought
c) sought
d) caught
Q9) The criminal was………..to death.
a) hanged
b) hung
Q10. Which is the correct spelling?
a) Accomodation
b) Accommodation
Q11. Which is the correct spelling?
a) Necessary
b) Neccessary
Q12. Which is the correct spelling?
a) Writing
b) Writing
Q13. Which is the correct spelling?
a) Getting
b) Geting

Q14. Which is the correct spelling?
a) Debitting
b) Debiting
Q15. What do we say to the group of sand?
a) A grove
b) A heap
c) A bundle
d) A herd
Q16. What do we say to the group of cows?
a) A grove
b) A heap
c) A bunch
d) A herd
Q17. Question: What about your turn? Answer: ……………
a) I have done.
b) I am done.
Q18. Question: What about the results? Answer: ……………
a) I have gone.
b) I am gone.
Q19. Which is the correct spelling?
a) Embarrasment
b) Embarrassment
Q20. Which is the correct spelling?
a) Proffessional
b) Professional
                                          Answers
1b, 2c, 3d, 4a, 5b, 6a, 7b, 8a, 9a, 10b, 11a, 12b, 13a, 14b, 15b, 16d, 17b, 18b, 19b,
20b.
```

## Quiz 54

```text
Choose the correct alternative:
Q1. Please………………your shoes before you enter a temple.
a) get off
b) take off
c) put off
d) All of the above
Q2. Which of these is not a word or phrase?
a) Allot
b) Alot
c) A lot
Q3. ……………..are none sitting in the class.
a) There
b) They’re
c) Their
Q4. The weather can …………..the play today.
a) Affect
b) Effect
c) Both of the above
Q5. …………….Monday today.
a) It’s
b) Its
Q6) Your drawing is better ……………………….
a) than me
b) than my
c) than mine
d) than I
Q7. When I reached the bus stand. The bus ……………..left.
a) had been
b) had
Q8. The movie …………….to a happy ending.
a) eluded
b) alluded

Q9) My parents ……………………..from America in 1995.
a) emigrated
b) Immigrated
Q10: Translate the following sentence into English:
   वो सोच रहा होगा हक मैं पागल हाँ . (Wo soch raha hoga ki main paagal hu.)
a) He will be thinking that I am mad.
b) He would be thinking that I am mad.
c) He will be thinking that I will be mad.
d) He would be thinking that I would be mad.
Q11: Translate the following sentence into English:
     काश वो मेरा सगा होता। (Kaash vo mera sagaa hota.)
a) I wish he was my real one.
b) I wish he were my real one.
Q12: Change into Passive Voice: ‘I make you smile.’
a) You are made smile by me.
b) You are made to smile by me.
c) You are made smiled by me.
Q13: Change into Passive Voice: ‘Let him eat the fish.’
a) Let the fish be eaten by him.
b) The fish let be eaten by him.
c) The fish let eaten by him.
d) Let the fish eaten by him.
Q14. His...........explanation made things easy to understand.
a) lucid
b) rigid
Q15: Translate into English: वो कब कब आत़ा है ? (Wo kab kab aata hai?)
a) When when does he come?
b) When all does he come?
c) How often does he come?
d) How long does he come?
Q16: Translate into English:
मैं 4 बजे घर पर होत़ा हँ । (Main 4 baje ghar par hota hu.)
a) I am at home at 4 o’clock.
b) I be at home at 4 o’clock.
c) I am home at 4 o’clock.
d) All of the above

Q17. What does the prepositional phrase ‚In lieu of‛ mean?
a) Instead of
b) Besides
c) Inspite of
d) Irrespective of
Q18. What does the phrasal verb ‚Break into‛ mean?
a) To end a relationship
b) To enter with the aim of theft
c) To escape from some prison
d) To quarrel
Q19: {Kaash usne mujhe dekha hota.} How to translate it:
a) I wish he had seen me.
b) I wish he would see me.
c) I wish I saw me.
d) All of the above
Q20: What is the 3rd form (Past participle form) of the verb ‚GET‛?
a) Gotten
b) Got
c) Both of the above
d) one of the above
                                          Answers
1b, 2b, 3a, 4a, 5a, 6c, 7b, 8b, 9b, 10b, 11b, 12a, 13a, 14a, 15c, 16d, 17a, 18b, 19a,
20c.
```

## Quiz 55

```text
Choose the correct alternative:
Q1: Which of the following sentences is/are correct?
a) The bus left before we reached.
b) The bus had left before we reached.
c) The bus left before we had reached.
d) The bus had left before we had reached.
Q2: Which of the following sentences is/are correct?
a) He is addicted to smoke.
b) He is addicted to smoking.
c) Both of the above
d) None of the above

Q3: Which of the following sentences is/are correct?
a) He never hesitates to sing.
b) He never hesitates in singing.
c) Both of the above
d) None of the above
Q4: Which of the following sentences is/are correct?
a) Mr. Kumar is my English Teacher.
b) Mr. Kumar is my Teacher of English.
c) Both of the above
d) None of the above
Q5: Which of the following sentences is/are correct?
a) His Exam starts on Monday.
b) His Exam starts from Monday.
c) Both of the above
d) None of the above
Q6: Which of the following sentences is/are correct?
a) Its color is black.
b) It’s color is black.
c) Both of the above
d) None of the above
Q7: Which of the following sentences is/are correct?
a) He died of Cancer.
b) He died from Cancer.
c) He died by Cancer.
d) He died with Cancer.
Q8: Which of the following sentences is/are correct?
a) I am going home.
b) I am going to home.
c) Both of the above
d) None of the above
Q9: Which of the following sentences is/are correct?
a) I have lost patience.
b) I have lost my patience.
c) Both of the above
d) None of the above

Q10: Which of the following sentences is/are correct?
a) One day, you will be my age.
b) One day, you will be of my age.
c) Both of the above
d) None of the above
Q11: Which of the following sentences is/are correct?
a) He lives in UK.
b) He lives in the UK.
c) Both of the above
d) None of the above
Q12: Which of the following sentences is/are correct?
a) The thief escaped from the police.
b) The thief escaped off the police.
c) Both of the above
d) None of the above
Q13: Which of the following sentences is/are correct?
a) Open at fifth page.
b) Open fifth page.
c) Both of the above
d) None of the above
Q14: Which of the following sentences is/are correct?
a) He is one of the best friend of mine.
b) He is one of the best friends of mine.
c) Both of the above
d) None of the above
Q15: Which of the following sentences is/are correct?
a) This is a girl hostel.
b) This is a girls hostel.
c) This is a girl’s hostel.
d) This is a girls’ hostel.
Q16: Which of the following sentences is/are correct?
a) My hair is black.
b) My hair are black.
c) Both of the above
d) None of the above

Q17: Which of the following sentences is/are correct?
a) You, who is honest, should not do it.
b) You, who are honest, should not do it.
c) Both of the above
d) None of the above
Q18: Which of the following sentences is/are correct?
a) The director and producer is dead.
b) The director and producer are dead.
c) Both of the above
d) None of the above
Q19: Which of the following sentences is/are correct?
a) The director and producer are dead.
b) Director and producer are dead.
c) Both of the above
d) None of the above
Q20: Which of the following sentences is/are correct?
a) I, as well as, he am to blame.
b) I, as well as, he is to blame.
c) Both of the above
d) None of the above
                                          Answers
1b, 2b, 3b, 4b, 5a, 6a, 7a, 8c, 9a, 10a, 11b, 12a, 13a, 14b, 15d, 16a, 17b, 18a, 19b,
20a.
```

## Quiz 56

```text
Choose the correct alternative:
Q1. Change into Passive Voice: It makes me cry.
a) I am made cry by it.
b) I made cry by it.
c) I am made cried by it.
d) I made cried by it.
Q2. Change into Indirect Speech:
     He said, ‚Who are you?‛
a) He asked who I was.
b) He asked who was I.
c) Both of the above
d) None of the above

Q3. Change into Indirect Speech:
     He said, ‚How tragic the situation is!‛
a) He exclaimed with sorrow how tragic the situation was.
b) He exclaimed with sorrow that the situation was so tragic.
a) He exclaimed with sorrow how tragic the situation is.
b) He exclaimed with sorrow that the situation is so tragic.
Q4. Aman ……………………………my home.
a) sometimes comes
b) sometime comes
c) sometimes come
d) sometime come
Q5: Tension among them …………….. to some extent.
a) has eased up
b) have eased off
c) has eased
d) have eased over
Q6. Choose the incorrect sentence:
a) I love talking to you.
b) I love speaking with you.
c) I love telling the lie.
d) I love telling the truth.
Q7. Choose the incorrect sentence:
a) I ain’t doing anything.
b) He’d’ve left in another minute.
c) You shan’t breach the rule.
d) All of the above
e) None of the above
Q8: Translate into English:
Humne meeting Monday tak ke liye postpone kar di hai.
a) We have put across the meeting until Monday.
b) We have put forward the meeting until Monday.
c) We have put off the meeting until Monday.
d) We have put forth the meeting until Monday.
Q9: Change into Passive Voice:
     ‚I can go to school.‛
a) School can be gone by me.
b) School can gone by me.
c) Both of the above
d) None of the above

Q10. Translate into English:
Main khush hun ki mujhe ye award mila hai.
a) I am happy to receive this award.
b) I am happy to have received this award.
c) I am happy to be received this award.
Q11. In letter writing, what does P.P. stand for?
 i) Per procurationam
ii) Per percurationem
iii) Per percurationam
iv) Per procurationem
Q12: What does P.P. mean?
i) Apart from
ii) On behalf of
iii) Including someone
iv) Per person
Q13: Translate the following sentence into English: ‚Kaun Kaun kahaan kahaan
honge?‛
a) Who all will be where all?
b) Whom all will be where all?
c) Who all will have where all?
d) Who all will have where all?
Q14: In a sentence, ‚I love eating mangoes.‛, what is ‚eating‛?
a) Gerund
b) Present Participle as a verb
c) Present Participle as an adjective
d) Perfect Participle
Q15: The sentence ‚She is as beautiful as a rose.‛ is an example of which figure
of speech?
a) Personification
b) Metaphor
c) Simile
d) Hyperbole
Q16: ‚Either…or‛ is:
a) A cumulative conjunction
b) An adversative conjunction
c) An alternative conjunction
d) An Illative conjunction

Q17: In a sentence, ‚Tell that girl there.‛, ‚There‛ is used as:
a) an adverb
b) an adjective
c) an interjection
d) a pronoun
Q18: Practice of having more than one wife at a time is known as:
a) Polyandry
b) Polygamy
Q19: Change the following sentence into Interrogative:
     ‚They dare shout at him.‛
a) Dare they shout at him?
b) Are they dare shout at him?
c) Do they dare shout at him?
d) Does they dare shout at him?
Q20: He …………..this company in 1998.
a) founded
b) found
c) finded
d) find
                                          Answers
1a, 2a, 3b, 4a, 5a, 6c, 7e, 8c, 9d, 10b, 11d, 12b, 13a, 14a, 15c, 16c, 17a, 18b, 19a,
20a.
```

## Quiz 57

```text
Choose the correct alternative:
Q 1: ‚He calls me every day.‛ is an example of
a) Indicative Mood
b) Interrogative Mood
c) Conditional Mood
d) Imperative Mood
e) Subjunctive Mood
Q 2: ‚If you come today, we will go for shopping.‛ is an example of
a) Indicative Mood
b) Interrogative Mood
c) Conditional Mood
d) Imperative Mood
e) Subjunctive Mood

Q 3: ‚I wish I had a car that day‛ is an example of
a) Indicative Mood
b) Interrogative Mood
c) Conditional Mood
d) Imperative Mood
e) Subjunctive Mood
Q 4: ‚The mobile was malfunctioning.‛ is an example of
a) Indicative Mood
b) Interrogative Mood
c) Conditional Mood
d) Imperative Mood
e) Subjunctive Mood
Q 5: ‚Do you have something to eat?‛ is an example of
a) Indicative Mood
b) Interrogative Mood
c) Conditional Mood
d) Imperative Mood
e) Subjunctive Mood
Q 6: ‚If I were in your position, I wouldn’t quit the job.‛ is an example of
a) Indicative Mood
b) Interrogative Mood
c) Conditional Mood
d) Imperative Mood
e) Subjunctive Mood
Q 7: ‚Let me find out the solution of this problem.‛ is an example of
a) Indicative Mood
b) Interrogative Mood
c) Conditional Mood
d) Imperative Mood
e) Subjunctive Mood
Q 8: ‚Please don’t go there.‛ is an example of
a) Indicative Mood
b) Interrogative Mood
c) Conditional Mood
d) Imperative Mood
e) Subjunctive Mood

Q 9: ‚She orders me, as if she is my mom.‛ is an example of
a) Indicative Mood
b) Interrogative Mood
c) Conditional Mood
d) Imperative Mood
e) Subjunctive Mood
Q 10: ‚I would have rather taken the bus that day.‛ is an example of
a) Indicative Mood
b) Interrogative Mood
c) Conditional Mood
d) Imperative Mood
e) Subjunctive Mood
Q 11: ‚He didn’t let them go out.‛ is an example of
a) Indicative Mood
b) Interrogative Mood
c) Conditional Mood
d) Imperative Mood
e) Subjunctive Mood
Q 12: ‚He seems to be a nice person.‛ is an example of
a) Indicative Mood
b) Interrogative Mood
c) Conditional Mood
d) Imperative Mood
e) Subjunctive Mood
Q 13: ‚If it rains today. I’ll not go to office.‛ is an example of
a) Indicative Mood
b) Interrogative Mood
c) Conditional Mood
d) Imperative Mood
e) Subjunctive Mood
Q 14: ‚I would like to take tea right now.‛ is an example of
a) Indicative Mood
b) Interrogative Mood
c) Conditional Mood
d) Imperative Mood
e) Subjunctive Mood

Q 15: ‚I wish, he grows in his life.‛ is an example of
a) Indicative Mood
b) Interrogative Mood
c) Conditional Mood
d) Imperative Mood
e) Subjunctive Mood
Q 16: ‚Let it be.‛ is an example of
a) Indicative Mood
b) Interrogative Mood
c) Conditional Mood
d) Imperative Mood
e) Subjunctive Mood
Q 17: ‚She doesn’t write legibly.‛ is an example of
a) Indicative Mood
b) Interrogative Mood
c) Conditional Mood
d) Imperative Mood
e) Subjunctive Mood
Q 18: ‚Are you at home right now?‛ is an example of
a) Indicative Mood
b) Interrogative Mood
c) Conditional Mood
d) Imperative Mood
e) Subjunctive Mood
Q 19: ‚If you become the captain, take me in your team.‛ is an example of
a) Indicative Mood
b) Interrogative Mood
c) Conditional Mood
d) Imperative Mood
e) Subjunctive Mood
Q 20: ‚Ask me.‛ is an example of
a) Indicative Mood
b) Interrogative Mood
c) Conditional Mood
d) Imperative Mood
e) Subjunctive Mood

Answers
1a, 2c, 3e, 4a, 5b, 6e, 7d, 8d, 9e, 10e, 11a, 12a, 13c, 14c, 15c, 16d, 17a, 18b, 19c,
20d.
```

## Quiz 58

```text
Choose the correct alternative:
Q 1. Which of the following is a false statement?
a) Full stop is also known as Period.
b) Exclamation mark is also known as Exclamation point.
c) Parenthesis is also known Square Bracket.
d) A quotation mark is also known as a Speech mark.
Q2: Declarative sentences end with a …………..
a) Full stop
b) Exclamation mark
c) Question mark
Q3: Optative sentences end with a ……………..
a) Full stop
b) Exclamation mark
c) Question mark
Q4: An abbreviation i.e. stands for:
a) Id est
b) In est
c) Id ert
d) In ert
Q5: An abbreviation e.g. stands for:
a) Example gratia
b) Exampli gratia
c) For exampli
d) For example gratia
Q6: An abbreviation etc. stands for:
a) Etcetera
b) Etcetra
c) Etcectra
d) Etcectera

Q 7. Which of the following sentence violates the punctuation rules?
a) Anjana said, ‚It’s my choice.‛
b) Anjana said: ‚It’s my choice.‛
c) Both of the above
d) None of the above
Q 8. Which of the following sentence violates the punctuation rules?
a) Anjana said, ‚My favourite letter is ‚I‛.‛
b) Anjana said, ‚My favourite letter is ‘I’.‛
c) Anjana said: ‚My favourite letter is ‘I’.‛
Q9: Colon(:) is used to:
a) Enumerate a list
b) Separate a list
c) Both of the above
d) None of the above
Q10: Which of the following is true?
a) Hyphen and dash are same length.
b) Hyphen is longer than Dash.
c) Dash is longer than Hyphen.
Q11: Which punctuation mark is used to introduce a quotation?
a) Comma
b) Colon
c) Both of the above
d) None of the above
Q12: Which punctuation mark is compulsorily to be used after an introductory
adverb in a sentence?
a) Colon
b) Semicolon
c) Comma
Q13: Which punctuation mark is used to express possession?
a) Apostrophe
b) Ellipsis
c) Inverted commas
Q14: Which of the following is(are) correct sentence(s)?
a) There are two 1s in ‚115262‛.
b) There are two 1’s in ‚115262‛.

c) Both of the above
d) None of the above
Q15: Which of the following is (are) correct sentence(s)?
a) There are two rs in ‚tomorrow‛.
b) There are two r’s in ‚tomorrow‛.
c) Both of the above
d) None of the above
Q16: Which of the following is (are) correct sentence(s)?
a) This is Vikas’s pen.
b) This is Vikas’ pen.
c) Both of the above
d) None of the above
Q17: Choose the correct phrase:
a) Boys’ hostel
b) Boy’s hostel
Q18: Choose the correct phrase:
a) Ladies’s compartment
b) Ladies’ compartment
Q19: How many dots are there in Ellipsis?
a) 3
b) 4
c) Either 3 or 4
d) Neither 3 nor 4
Q20: Braces are also known as:
a) Small brackets
b) Curly brackets
c) Square brackets
d) Parendthesis
                                          Answers
1c, 2a, 3b, 4a, 5b, 6a, 7d, 8a, 9a, 10c, 11c, 12c, 13a, 14b, 15b, 16c, 17a, 18b, 19c,
20b.
```

## Quiz 59

```text
Choose the correct alternative:
Q 1: Translate the following sentence into English:
      वो मुझे जाने नह ीं दे रहा. (Vo mujhe jaane nahi de raha.)
a) He is not let me go.
b) He is not letting me go.
c) He is not being let me go.
d) He is not let me going.
Q 2: Translate the following sentence into English:
       वो राकेश से काम करवाता है . (Vo Rakesh se kaam karvata hai.)
a) He makes Rakesh work.
b) He got Rakesh work.
c) He made Rakesh work.
d) He let Rakesh work.
Q 3: Translate the following sentence into English:
         मैंने उसे जाने हदया. (Maine use jaane diya.)
a) I letted him go.
b) I let him go.
c) I let him went.
d) I did let him went.
Q4: I was sitting ………. many.
a) between
b) among
c) amongst
d) None of the above
Q5: This mobile is made …….. plastic.
a) of
b) by
c) up of
d) up with
Q6: Mr. John Smith in an ……….. India.
a) emigrant in
b) emigrant from
c) immigrant in
d) immigrant from

Q7: My brother is………. S. D. O.
 a) a
 b) an
Q8: .………..the snake, he was terrified.
 a) See
 b) Seeing
 c) Saw
 d) Having seeing
Q 9: Antonym of the word ‚Awesome‛ is:
a) Awful
b) Aweful
Q 10: Translate the following sentence into English:
      वो मुझे खेलने नह ीं दे ता. (Vo mujhe khelne nahi deta.)
a) He does not let me played.
b) He does not let me play.
c) He is not let me played.
d) He is not let me play.
Q 11: Translate the following sentence into English:
        वो लापरवाह है . (Vo laaparvaah hai.)
a) He is a shirker.
b) He is an author.
c) He is negligent.
d) He is cautious.
Q 12: Change into Indirect Speech:
       He said to her, ‚Are you going?‛
a) He asked her if you were going.
b) He asked her if she was going.
c) He asked her that was she going.
d) He asked her that she was going.
Q 13: Change into Indirect Speech: He asked," who called me?"
A) He asked that who called him.
B) He asked that who had called him.
C) He asked who called him.
D) He asked who had called him.

Q 14: Which of the following sentences is incorrect?
a) I don’t like either of you.
b) I don’t like neither of you.
c) I don’t like any of you.
d) I don’t like going with you.
Q 15: Translate into English:
उसे घर जाना पाा ह गा। (Use ghar jaana pada hoga.)
a) He will have to go home.
b) He would have to go home.
c) He would have had gone home
d) He would have had to go home.
Q.16: In a sentence, ‚I have a pen.‛, what is ‚a‛ here:
a) a conjunction
b) An adverb
c) a preposition
d) A determiner
Q.17: Earth is………..
a) a proper noun
b) a common noun
c) an abstract noun
d) a material noun
Q18: Translate into English:
क्या आपक बुरा लगेगा अगर ि घर जाये ? (Kya aapko bura lagega agar wo ghar jaaye?)
a) Would you mind if he go home?
b) Would you mind if he goes home?
c) Would you mind if he went home?
d) Would you mind if he has gone home?
Q 19: Which of the following is an incorrect sentence?
a) Even, I’m your friend.
b) I’m not even your friend.
c) Many a pen are blue.
d) Many pens are blue.
Q 20: Which part of the following sentence is erroneous?
One of these pens (A) / is hers, (B) / not my. (C) / No error. (D)
a) A
b) B

c) C
d) D
                                         Answers
1b, 2a, 3b, 4c, 5a, 6a, 7b, 8b, 9a, 10b, 11c, 12b, 13d, 14b, 15d, 16d, 17d, 18b, 19c,
20c.
```

## Quiz 60

```text
Choose the correct alternative:
Q1: Choose the correct spelling:
a) Putting
b) Puting
Q2: Choose the correct spelling:
a) Debitting
b) Debiting
Q3: Choose the correct spelling:
a) Desparate
b) Desperate
c) Desperete
Q4: Choose the correct spelling:
a) Anxiety
b) Anxeity
Q5: Choose the correct spelling:
a) Fulfill
b) Fulfil
Q6: Choose the correct spelling:
a) Handfull
b) Handful
Q7; Choose the correct spelling:
a) Necessary
b) Neccesary
Q8: Choose the correct spelling:
a) Believe
b) Beleive

Q9: Choose the correct spelling:
a) Tomorrow
b) Tommorow
Q10: Choose the correct spelling:
a) Nevertheless
b) Neverthless
Q11: Choose the correct spelling:
a) Truely
b) Truly
Q12: Choose the incorrect spelling:
a) Message
b) Messege
c) Massage
Q13: Choose the correct spelling:
a) Village
b) Villege
Q14: Choose the correct spelling:
a) Percieve
b) Perceive
Q15: Choose the correct spelling:
a) Guidance
b) Guidence
Q16: Choose the correct spelling:
a) Imaginery
b) Imaginary
Q17: Choose the correct spelling:
a) Begining
b) Beginning
Q18: Choose the correct spelling:
a) Independent
b) Independant

Q19: Choose the correct spelling:
a) Defination
b) Definition
Q20: Choose the correct spelling:
a) Mischievous
b) Mischeivous
                                         Answers
1a, 2b, 3b, 4a, 5a, 6b, 7a, 8a, 9a, 10a, 11b, 12b, 13a, 14b, 15a, 16b, 17b, 18a, 19b,
20a.
```

## Quiz 61

```text
Choose the correct alternative:
Q1: Translate into English:
तुम मुझे पढने क्य ों नहीों दे रहे थे? (tum mujhe padhne kyo nahi de rahe the?)
a) Why were you not letting me study?
b) Why did you not let me studying?
c) Why did you not letting me study?
d) Why were you not let me studying?
Q2: Translate into English:
सबक जाने प्रदया गया। (sabko jaane diya gaya.)
a) All were let go.
b) All had be gone.
c) All were let be gone.
Q3: Translate into English:
तुम्हें क्या प्रसखाया जाता है ? (tumhe kya sikhaya jaata hai.)
a) What are you taught?
b) What are you be taught?
c) What do you be taught?
d) What are you learned?
Q4: Translate the following sentence into English:
         काश मैं तुमसे हमल पाता. (Kaash main tumse mil paata.)
a) I wish I would meet you.
b) I wish I could meet you.
c) I wish I could have met you.
d) I wish I would have met you.

Q5: Translate the following sentence into English:
         काश मैं तुमसे हमलता. (Kaash main tumse milta.)
a) I wish I would meet you.
b) I wish I could meet you.
c) I wish I could have met you.
d) I wish I would have met you.
Q6: Translate the following sentence into English:
       मुझे घर जाना पड़ता. (Mujhe ghar jaana padta.)
a) I will have to go home.
b) I would have to go home.
c) I had to go home.
Q7: Translate the following sentence into English:
       वो सोच रहा होगा हक मैं पागल हाँ . (Wo soch raha hoga ki main paagal hu.)
a) He will be thinking that I am mad.
b) He would be thinking that I am mad.
c) He will be thinking that I will be mad.
d) He would be thinking that I would be mad.
Q8: Translate into English:
ि कब कब आता है ? (Wo kab kab aata hai?)
a) When when does he come?
b) When all does he come?
c) How often does he come?
d) How long does he come?
Q9: Translate into English: ‚Uske sath kaun gaya?‛
a) Who go with him?
b) Who did go with him?
c) Who went with him?
d) Who had gone with him?
Q10: Translate into Hindi: ‚I was made go.‛
a) Mujhe bheja gaya.
b) Mujhe bhijvaya gaya.
Q11: Translate into Hindi: ‚I was sent.‛
a) Mujhe bheja gaya.
b) Mujhe bhijvaya gaya.

Q12: Translate into English: ‚Maine usse help maangi.‛
a. I told him to help me.
b. I said him to help me.
c. I asked him to help me.
d. I begged him to help me.
Q13: Translate into English: ‚Tum yahaan kab tak ho?‛
a) Until when are you here?
b) Since when are you here?
c) When until are you here?
d) For how long are you here?
Q14: Which word is similar to Gigantic?
a) Enormous
b) Exclusive
c) Endeavor
Q15: Which word is similar to Pang?
a) Cramp
b) Emotion
c) Suppress
Q16: How to Pronounce ‚Gigantic‛?
a) Gai-gan-tuhk
b) Jai-gan-tuhk
Q17: Rearrange it:
     {you/have/how much/experience/got/?}
a) How much have you got experience?
b) How much you have got experience?
c) How much experience have you got?
d) How much experience you have got?
Q18: Rearrange it:
     {in/that/book/are /there/pages/how/many/?}
a) How many are there pages in that book?
b) How many pages are there in that book?
c) How many are pages there in that book?
d) How many pages there are in that book?
Q19: Do you know……………….
a) who I am?
b) who am I?

c) who I am.
d) who am I.
Q20: He will come in ……. year.
a) a
b) an
                                          Answers
1a, 2a, 3a, 4b, 5a, 6b, 7b, 8c, 9c, 10b, 11a, 12c, 13a, 14a, 15a, 16b, 17c, 18b, 19a,
20a.
```

## Quiz 62

```text
Choose the correct alternative:
Q 1: I appreciate ………….. in touch with me.
a) you get
b) your get
c) you getting
d) your getting
Q 2: Add question tag: ‚They play with me,…………‛
a) doesn’t they?
b) don’t they?
c) isn’t they?
d) aren’t they?
Q 3: Add question tag: ‚I ain’t your friend,…………‛
a) Am I?
b) Am I not?
c) Ain’t I?
d) Any of the above
Q 4: He ………….. English for 2 years.
a) is learning.
b) was learning.
c) has been learning.
d) have been learning
Q 5: I met him…………… than I met you.
a) 2 days ago
b) 2 days back

c) 2 days earlier
d) Any of the above
Q 6: A person fond of enjoyment is known as
a) Epicure
b) Ascetic
c) Connoisseur
d) Fastidious
Q 7: Past Participle (3rd form) of the verb ‚Wake‛ is:
a) Waken
b) Woken
c) Woke
Q 8. ‚Albeit‛ means:
a) Even though
b) Although
c) Both of the above
Q 9: …….he studies well, he will fail.
a) Until
b) Unless
c) Till
d) Any of the above
Q 10: I loved the …………….. of this film.
a) heroin
b) heroine
Q 11: Which part of the following sentence is erroneous?
Either of you (A) / have (B) / got a car, (C) / I suspect. (D)
a) A
b) B
c) C
d) D
Q12: Past Participle form of the verb ‚Seek‛ is
a) Seeked
b) Sought
c) Seeken
d) Soughten

Q13: Find the incorrect sentence among the following:
a) There are 5 stars in the sky.
b) There are 20 hair strands on the floor.
c) I have already had the food.
d) He has been here since 3 hours.
Q 14: In letter writing, what does P.P. stand for?
 a) Per procurationam
b) Per percurationem
c) Per percurationam
d) Per procurationem
Q 15: What does P.P. mean?
a) Apart from
b) On behalf of
c) Including someone
d) Per person
Q 16: Which is the incorrect way of Salutation in letters?
a) Dear Mrs. Neha
b) Dear Neha
c) Dear Ms. Neha
d) Dear ma’am Neha
Q 17: He is younger………………
a) than I.
b) than me.
c) to I.
d) to me.
Q18:What does ‚Naive‛ mean?
a) Selfish
b) Clever
c) Innocent
d) Adamant
Q 19: What does ‚Archaic‛ mean?
a) Old fashioned
b) New fashion
c) Simple and sober
d) Contemporary

Q20: What does ‚off hand‛ means?
a) Without money
b) Without preparation
c) Without luck
d) Without love
                                         Answers
1d, 2b, 3a, 4c, 5c, 6a, 7b, 8c, 9b, 10b, 11b, 12b, 13d, 14d, 15b, 16d, 17d, 18c, 19a,
20b.
```

## Quiz 63

```text
Choose the correct alternative:
Q1: Synonym of the word ‚PROPEL‛ is:
a) Drive
b) Repel
c) Burst
d) Modification
Q2: Synonym of the word ‚LAMENT‛ is:
a) Complain
b) Comment
c) Condone
d) Console
Q3: Synonym of the word ‚FOSTERING‛ is:
a) Safeguarding
b) Neglecting
c) Ignoring
d) Nurturing
Q4: Synonym of the word ‚MASSIVE‛ is:
a) Strong
b) Little
c) Gaping
d) Huge
Q5: Synonym of the word ‚DILIGENT‛ is:
a) Progressive
b) Brilliant
c) Inventive
d) Hard-working

Q6: Synonym of the word ‚CANDID‛ is:
a) Apparent
b) Explicit
c) Frank
d) Bright
Q7: Synonym of the word ‚LYNCH‛ is:
a) Hang
b) Madden
c) Kill
d) Shoot
Q8: Synonym of the word ‚INTIMIDATE‛ is:
a) Hint
b) Frighten
c) Bluff
d) Harass
Q9: Synonym of the word ‚MASSACRE‛ is:
a) Murder
b) Stab
c) Assassinate
d) Slaughter
Q10: Synonym of the word ‚SHIVER‛ is:
a) Feel
b) Rock
c) Tremble
d) Move
Q11: Synonym of the word ‚STRINGENT‛ is:
a) Tense
b) Stringly
c) Strict
d) Shrink
Q12: Synonym of the word ‚LAUD‛ is:
a) Lord
b) Eulogy
c) Praise
d) Extolled

Q13: Synonym of the word ‚CORRESPONDENCE‛ is:
a) Agreements
b) Contracts
c) Documents
d) Letters
Q14: Synonym of the word ‚VIGOUR‛ is:
a) Strength
b) Boldness
c) Warmth
d) Enthusiasm
Q15: Synonym of the word ‚INDICT‛:
a) Condemn
b) Reprimand
c) Accuse
d) Allege
Q16: Synonym of the word ‚RESCUE‛ is:
a) Save
b) Command
c) Help
d) Defence
Q17: Synonym of the word ‚CONSEQUENCES‛ is:
a) Results
b) Conclusions
c) Difficulties
d) Applications
Q18: Synonym of the word ‚IRONIC‛ is:
a) Inflexible
b) Bitter
c) Good-natured
d) Sarcastic
Q19: Synonym of the word ‚NEUTRAL‛ is:
a) Unbiased
b) Non-aligned
c) Undecided
d) Indifferent

Q20: Synonym of the word ‚INSOLVENT‛ is:
a) Poor
b) Bankrupt
c) Penniless
d) Broke
                                        Answers
1a, 2a, 3d, 4e, 5d, 6c, 7c, 8b, 9d, 10c, 11c, 12c, 13d, 14a, 15c, 16a, 17a, 18d, 19a,
20b.
```

## Quiz 64

```text
Choose the correct alternative:
Q1: I want to buy ten ……..
a) knives
b) knifes
c) knife
d) pair of knife
Q2: I go for a five ………. walk every day.
a) mile
b) miles
Q3: Every person should write …………name neatly.
a) his
b) their
c) every’s
d) one’s
Q4: This monument is a ………………example of 1902 architecture.
a) prime
b) primary
c) prevalent
d) primitive
Q5: He doesn’t work, …………………..
a) nor does she.
b) nor she does

Q6: Do you know …………………?
a) swimming
b) how to swim
c) how to swimming
Q7: Please………………your shoes before you enter a temple.
a) get off
b) take off
c) put off
d) All of the above
Q8: Which of these is not a word or phrase?
a) Allot
b) Alot
c) A lot
Q9: ……………..are none sitting in the class.
A: There
C: They’re
D: Their
Q10: Change into Passive Voice:
     ‘I make you smile.’
a) You are made smile by me.
b) You are made to smile by me.
c) You are made smiled by me.
Q 11: He …………..me there.
a) founded
b) found
c) finded
d) find
Q12: Change into Passive Voice:
     ‘Let him eat the fish.’
a) Let the fish be eaten by him.
b) The fish let be eaten by him.
c) The fish let eaten by him.
d) Let the fish eaten by him.
Q13: His...........explanation made things easy to understand.
a) lucid
b) rigid

14: Aman ……………………………my home.
a) sometimes comes
b) sometime comes
c) sometimes come
d) sometime come
Q15: Tension among them …………….. to some extent.
a) has eased up
b) have eased off
c) has eased
d) have eased over
Q16: Synonym of the word ‚Astound‛ is:
A) Incredible
b) Enjoy
c) Astonish
d) Alter
Q17: Antonym of the word ‚Poverty‛ is:
a) Poor
b) Wealth
c) Liberty
d) Awkward
Q18: Tension between them has …………….. to some extent.
a) eased up
b) eased off
c) eased
d) eased over
Q19: I know he is right; but my ego hinders me …… him.
a) to appreciate
b) appreciating
Q20: Who is he………you?
a) of
b)to
c) with
d) All of the above
                                          Answers
1a, 2a, 3a, 4a, 5a, 6b, 7b, 8b, 9a, 10a, 11b, 12a, 13a, 14a, 15a, 16c, 17b, 18a, 19b,
20b.
```

## Quiz 65

```text
Choose the correct alternative:
Q1: Did you have any problems........this pen?
a) find
b) finding
c) to find
d) for finding
Q2: Do call me the moment you ………… there.
a) get
b) got
c) have got
d) will get
Q3: We use a …………….to check the holidays.
a) Calender
b) Calendar
Q4: We will meet you……………….
a) next week
b) next weak
Q5: What do we say to the group of trees?
a) A grove
b) A heap
c) A bundle
d) A herd
Q6: What do we say to the group of stones?
a) A grove
b) A heap
c) A bunch
d) A herd
Q7: What do we say to the group of rubbish?
a) A grove
b) A heap
c) A bundle
d) A herd

Q8: Change into Indirect Speech:
     She said to Mayank, ‚Good bye!‛
a) She bade Mayank good bye.
b) She bade good bye to Mayank.
c) Both of the above
d) None of the above
Q9: Change into Indirect Speech:
     He said to me, ‚Please keep the windows open.‛
a) He requested me to keep the windows open.
b) He requested me to kept the windows open.
c) He advised me to kept the windows opened.
d) He ordered me to keep the windows opened.
Q10: Our country resumed ................. against the evil.
a) to fight
b) fighting
c) Any of the above
d) None of the above
Q11: I felt like .............. him for this misbehaviour.
a) to slap
b) slapping
c) Any of the above
d) None of the above
Q12: I enjoyed ................... in my childhood.
a) to swim
b) swimming
c) Any of the above
d) None of the above
Q13: Why do you hesitate ............... in English?
a) to speak
b) speaking
c) Any of the above
d) None of the above
Q14: I, as well as, my brothers, ............... older ............
a) am, than he.
b) am, to him.
c) are, to him.
d) are, than him.

Q15: Change into Indirect Speech: He told me, ‚Who am I?‛
a) He asked me who I am.
b) He asked me who he is.
c) He asked me who I was.
d) He asked me who he was.
Q16: ‚I love meeting her there.‛ - What is ‚Meeting‛ here?
a) Gerund Form
b) Present Participle Form
Q17: ‚I will be meeting her today.‛ - What is ‚Meeting‛ here?
a) Gerund Form
b) Present Participle Form
Q18: Translate into English: ‚Uske paas mobile hona chahiye tha.‛
a) He should have a mobile.
b) He should have had a mobile.
c) He should has a mobile.
d) He should has had a mobile.
Q19: Translate into English: ‚Usne mujhse apna kaam karvaya.‛
a) He made me do his work.
b) He made me did his work.
c) He made me done his work.
Q20: Translate into English:
Mere paas mobile zaroor hona chahiye tha.
a) He must have a mobile.
b) I must have had a mobile.
c) I must possess a mobile.
d) I must have possess a mobile.
                                       Answers
1b, 2a, 3b, 4a, 5a, 6b, 7b, 8c, 9a, 10b, 11b, 12b, 13a, 14a, 15d, 16a, 17b, 18b, 19a,
20b.
```

## Quiz 66

```text
Choose the correct alternative:
Q1: If I .......... you, I wouldn’t go.
e) Was
f) were
Q2: I wish I .......... a girl.
a) was
b) were
Q3: Many a soldier ............ killed in the war.
a) was
b)were
Q4: Many a ............. distributed so far.
a) gift has been
b) gifts have been
Q5: Rs. 10000 .......... is good enough for me.
a) Is
b) are
Q6: kms ............. a long distance to cover by bicycle.
a) Is
b) Are
Q7: More .......... going to attend the party today.
a) Is
b) are
Q8: More ............ needed to filled this glass.
a) Is
b) are
Q9: They are the ............... I was talking about.
a) One
b) ones

Q10: Every time I go on break, someone else ............ my seat.
a) Take
b) takes
Q11: Why ............ someone let us know about it?
a) don’t
b) doesn’t
Q12: A sports club of many fascinating games ............ there in that city.
a) Is
b) are
Q13: There ........... they.
a) Meet
b) meets
Q14: Rajma and Rice ............. my favorite dish.
a) Is
b) are
Q15: My bag and baggage .......... been thrown out of the hotel room.
a) Has
b) have
Q16: An engineer, together with few electricians, .......... on duty.
a) Was
b) were
Q17: Every player here ........... good sportsmanship.
a) Show
b) shows
Q18: Someone .......... to finish the work.
a) Has
b) have
Q19: Everyone who disagreed with these people .......... in trouble now.
a) Is
b) are
Q20: Anjum, along with her brother, ............. attending the meeting today.
a) Is
b) are

Q21: Either way ............ correct.
a) Is
b) are
Q22: Each boy and girl ............ scared of it.
a) is
b) are
Q23: Ravi, not Aman and Rakesh, ............. to school.
a) Go
b) goes
Q24: I, with he, ............. coming.
a) Is
b) Am
c) are
Q25: A pen, in addition to three pencils, ............... to be given for free.
a) is
b) are
                                         Answers
1b, 2b, 3a, 4a, 5a, 6a, 7b, 8a, 9b, 10b, 11b, 12a, 13a, 14a, 15a, 16a, 17b, 18a, 19a,
20a, 21a, 22a, 23b, 24b, 25a.
```

## Quiz 67

```text
Choose the correct alternative:
Q1: Priya, along with Rekha and Deepika, ............. there.
a)     Was
b)     were
Q2: Each of the members ............ contributed.
a) has
b) have
Q3: Neither the students nor the teacher .............. interested.
a) was
b)were

Q4: The better of the two mobiles ........... been sold.
a) has
b) have
Q5: Here ............ the teacher to meet students.
a) come
b) comes
Q6: Neither of my friends .............. present in the class.
a) Is
b) Are
Q7: He, as well as I, .............. going to market.
a) is
b) am
c) are
Q8: Where ............ my mobile and laptop?
a) Is
b) are
Q9: There ........... opportunities for all of us.
a) Is
b) are
Q10: ............ anybody want a burger?
a) Do
b) Does
Q11: The set of rules ........... the game.
a) control
b) controls
Q12: One of the boys .......... late for the exam.
a) was
b) were
Q13: Each of the apples ......... ripe.
a) was
b) were

Q14:You shouldn’t hurt .......... emotions.
a) one’s
b) ones
c) ones’e
Q15: All that glitters ........... not gold.
a) Is
b) Are
Q16: All the toys .......... expensive.
a) was
b) were
Q17: All of this book .......... written by me.
a) Is
b) are
Q18: Everyone .............. when his wish gets fulfilled.
a) cheer
b) cheers
Q19:One of my favorite dishes .............. Rajma Rice.
a) Is
b) are
Q20: No one except Ranjan and Ravi ........... excited.
a) was
b) were
Q21: Neither you nor he .............. the game correctly.
a) play
b) plays
Q22: Each and every player ............. to win the game.
a) try
b) tries
Q23: Neither he nor she ............... to school.
a) Go
b) goes

Q24: Learning English is easy if one .............
a) concentrate
b) concentrates
Q25: I want ............ to market today..
a) to go
b) going
                                         Answers
1a, 2a, 3a, 4a, 5b, 6a, 7a, 8b, 9b, 10b, 11b, 12a, 13a, 14a, 15a, 16b, 17a, 18b, 19a,
20a, 21b, 22b, 23b, 24b, 25a.
```

## Source notes

Source notes
The PDF text layer was extracted page-by-page with pdftotext -layout; running headers, footers, standalone page numbers, and blank layout lines were removed only. All question stems, choices, bilingual text, inline printed “Answer - …” lines, and printed answer keys are retained in quiz order. Printed source irregularities (including numbering styles, duplicate choices, grammar/spelling anomalies, and key/stem disagreements) are preserved rather than silently corrected. No answer was inferred where the source did not print one.

Coverage: PDF pages 478–686 inclusive (209 pages), Quiz 1–67, 1399 keyed items. Lesson 40 starts on PDF page 687.
