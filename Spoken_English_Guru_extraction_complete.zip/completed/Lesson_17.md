# Lesson 17 — Use of IT

**PDF pages:** 224–229 (printed pages 223–228)

This lesson has one translation exercise (items 1–100). Each Hindi prompt and its printed Romanized line is paired with the English answer carrying the same number in the answer key.

## Translate the following sentences in English

### 1. आज तुम्हारा दिन है, कल मेरा होगा।
**Romanized:** (Aaj Tumhara din hai, kal mera hoga.)
**English answer:** It is your day today, it will be mine tomorrow.

### 2. तुम्हें देखे हुए मुझे दस दिन हो गये हैं।
**Romanized:** (Tumhe dekhe hue mujhe das din ho gaye hai.)
**English answer:** It has been 10 days to me having seen you.

### 3. राम से मिले हुए सात साल हो गये हैं।
**Romanized:** (Ram se mile hue saat saal ho gaye hai.)
**English answer:** It has been 7 years having met Ram.

### 4. क्या कल छुट्टी थी?
**Romanized:** (Kya kal chhuttee thee?)
**English answer:** Was it a holiday yesterday? Was it off yesterday?

### 5. 5 दिन लगेंगे।
**Romanized:** (5 Din lagenge.)
**English answer:** It will take 5 days.

### 6. 6 साल लगे।
**Romanized:** (6 saal lage.)
**English answer:** It took 6 years.

### 7. मुझे घर पहुँचने में 5 घंटे लगते हैं।
**Romanized:** (Mujhe ghar pahuchne mein 5 ghante lagte hai.)
**English answer:** It takes me 5 hours to reach home.

### 8. मुझे स्कूल पहुँचने में 30 मिनट लगते हैं।
**Romanized:** (Mujhe school pahuchne me 30 mins lagte hain.)
**English answer:** It takes me half an hour to reach school.

### 9. राम को खाना बनाने में काफी समय लगता है।
**Romanized:** (Ram ko khana banane mein kaphee samay lagta hai.)
**English answer:** Ram takes lots of time to prepare the food.

### 10. हमें कम्प्यूटर सीखने में 3 महीने लगे।
**Romanized:** (Hame computer seekhne mein 3 mahine lage.)
**English answer:** We took 3 months to learn computer.

### 11. तुम्हें ढूंढने में मुझे केवल 5 मिनट लगे।
**Romanized:** (Tumhe dhoodne me mujhe keval 5 minute lage.)
**English answer:** I took me only 5 minutes to find/search you.

### 12. ये काम करने में काफी समय लगेगा।
**Romanized:** (Ye kaam karne mein kaphee samay lagega.)
**English answer:** It will take plenty of time to do this work.

### 13. आज सोमवार नहीं है।
**Romanized:** (Aaj somvaar nahi hai.)
**English answer:** It is not Monday today.

### 14. कल छुट्टी थी।
**Romanized:** (Kal chhuttee thee.)
**English answer:** It was a holiday yesterday. / It was off yesterday.

### 15. आज बारिश होगी।
**Romanized:** (Aaj barish hogee.)
**English answer:** It will rain today.

### 16. कल बारिश हुई थी।
**Romanized:** (Kal barish hui thee.)
**English answer:** It had rained yesterday.

### 17. परसों छुट्टी थी।
**Romanized:** (Parson chhuttee thee.)
**English answer:** It was holiday the day before yesterday.

### 18. परसों छुट्टी होगी।
**Romanized:** (Parson chhuttee hogee.)
**English answer:** It will be holiday the day after tomorrow.

### 19. 2 मिनट लगते हैं।
**Romanized:** (2 minute lagte hai.)
**English answer:** It takes 2 minutes.

### 20. 2 मिनट लग रहे हैं।
**Romanized:** (2 Minute lag rahe hai.)
**English answer:** It is taking 2 minutes.

### 21. 2 मिनट लगे हैं।
**Romanized:** (2 Minute lage hai.)
**English answer:** It has taken 2 minutes.

### 22. 2 मिनट लगे।
**Romanized:** (2 Minute lage.)
**English answer:** It took 2 minutes.

### 23. 2 मिनट लग रहे थे।
**Romanized:** (2 Minute lag rahe the.)
**English answer:** It was taking 2 minutes.

### 24. 2 मिनट लगे थे।
**Romanized:** (2 Minute lage the.)
**English answer:** It had taken 2 minutes.

### 25. 2 मिनट लगेंगे।
**Romanized:** (2 Minute lagenge.)
**English answer:** It will take 2 minutes.

### 26. मुझे 2 मिनट लगेंगे।
**Romanized:** (Mujhe 2 Minute lagenge.)
**English answer:** I will take 2 minutes. / It will take me 2 minutes.

### 27. अब तुम्हारी बारी है।
**Romanized:** (Ab Tumharee baree hai.)
**English answer:** It is your turn now.

### 28. यह तुम्हारा प्यार है।
**Romanized:** (Yah tumhara pyar hai.)
**English answer:** This is your love.

### 29. यह क्या है?
**Romanized:** (Yah kya hai?)
**English answer:** What is it/this?

### 30. 2 दिन हो गये हैं।
**Romanized:** (2 din ho gaye hai.)
**English answer:** It has been 2 days.

### 31. 2 दिन हो गये थे।
**Romanized:** (2 Din ho gaye the.)
**English answer:** It had been 2 days.

### 32. मुझे 2 दिन हो गये थे।
**Romanized:** (Mujhe 2 din ho gaye the.)
**English answer:** It had been 2 days to me.

### 33. तुमसे मिले हुए मुझे 2 दिन हो गए थे।
**Romanized:** (Tumse mile hue mujhe 2 din ho gae the.)
**English answer:** It had been 2 days to me having met you.

### 34. उसे कितना समय लगेगा?
**Romanized:** (Use kitna samay lagega?)
**English answer:** How much time will he take?

### 35. तुम्हें कितना समय लगता है?
**Romanized:** (Tumhen kitna samay lagta hai?)
**English answer:** How much time do you take?

### 36. तुम्हें इतना समय क्यों लग रहा है?
**Romanized:** (Tumhen itna samay kyon lag raha hai?)
**English answer:** Why are you taking this much time?

### 37. ऑफिस पहुँचने में कितना समय लगा? ,
**Romanized:** (Office pahunchne mein kitna samay laga?)
**English answer:** How much time did it take to reach office?

### 38. ऑफिस पहुँचने में तुम्हें कितना समय लगा?।
**Romanized:** (Office pahunchne mein tumhen kitna samay laga?)
**English answer:** How much time did you take to reach office?

### 39. राम को बहुत समय लगा।
**Romanized:** (Ram ko bahut samay laga.)
**English answer:** Ram took lots of time.

### 40. कल ओले पड़े थे।
**Romanized:** (Kal ole pade the.)
**English answer:** It had hailed yesterday.

### 41. आज ओले पड़ेंगे।
**Romanized:** (Aaj ole padenge.)
**English answer:** It will hail today.

### 42. परसों ओले पड़ेंगे।
**Romanized:** (Parson ole padenge.)
**English answer:** It will hail the day after tomorrow.

### 43. परसों ओले पड़े थे।
**Romanized:** (Parson ole pade the.)
**English answer:** It had hailed the day before yesterday.

### 44. बारिश कब होगी?
**Romanized:** (Barish kab hogee?)
**English answer:** When will it rain?

### 45. क्या बारिश होगी?
**Romanized:** (Kya barish hogee?)
**English answer:** Will it rain?

### 46. क्या बारिश हो रही होगी?
**Romanized:** (Kya barish ho rahee hogee?)
**English answer:** Will it be raining?

### 47. किताब खत्म करने में मुझे 2 महीने लगे।
**Romanized:** (Kitaab khatm karne me mujhe 2 mahine lage.)
**English answer:** It took me 2 months to finish the book.

### 48. सीता को काफी साल लगे।
**Romanized:** (Seeta ko kaaphee saal lage.)
**English answer:** Seeta took lots of time.

### 49. आई ए एस अधिकारी बनने में 3 साल लगे।
**Romanized:** (IAS adhikaree banne mein 3 saal lage.)
**English answer:** I took 3 years to become an IAS officer.

### 50. ये कपड़ा सिलने में करीब 20 दिन लगेंगे।
**Romanized:** (Ye kapda silne mein kareeb 20 din lagenge.)
**English answer:** It will take about 20 days to stitch this cloth.

### 51. अगर तुम पेंसिल से लिखो, तो काफी समय लगेगा।
**Romanized:** (Agar tum pencil se likho, to kafi samay lagega.)
**English answer:** If you write with a pencil, it will take too long.

### 52. तुम कितना समय लोगे?
**Romanized:** (Tum kitna samay loge?)
**English answer:** How much time will you take?

### 53. ये खत्म करने में तुम कितना समय लोगे?
**Romanized:** (Ye khatm karne mein tum kitna samay loge?)
**English answer:** How much time will you take to finish this?

### 54. मैं दस मिनट लूंगा।
**Romanized:** (Main das minute loonga.)
**English answer:** I will take 10 minutes.

### 55. वो दिन एक स्पेशल दिन था।
**Romanized:** (Vo din ek special din tha.)
**English answer:** It was a special day that day.

### 56. उस दिन क्या था?
**Romanized:** (Us din kya tha?)
**English answer:** What was it on that day?

### 57. अंधेरा हो रहा है।
**Romanized:** (Andhera ho raha hai.)
**English answer:** It is getting dark.

### 58. उमस हो रही है।
**Romanized:** (Umas ho rahee hai.)
**English answer:** It is getting humid.

### 59. यह मेरी ख्वाहिश है।
**Romanized:** (Yah meree khvahish hai.)
**English answer:** It / This is my wish/desire.

### 60. हमारी शादी की सालगिरह है आज।
**Romanized:** (Hamari shadi ki salgirah hai aaj.)
**English answer:** It is our marriage anniversary today.

### 61. तुम्हें देखे हुए मुझे करीब 2 साल हो गये हैं।
**Romanized:** (Tumhe dekhe hue mujhe kareeb 2 saal ho gaye hai.)
**English answer:** It has been about 2 years to me having seen you.

### 62. जब मैं वहाँ पहुँचा, बारिश हो रही थी।
**Romanized:** (Jab main vaha pahuncha, barish ho rahi thee.)
**English answer:** When I reached there, it was raining.

### 63. वहाँ बहुत बारिश होती है।
**Romanized:** (Vaha bahut barish hoti hai.)
**English answer:** It rains a lot there.

### 64. आज बारिश हो सकती है।
**Romanized:** (Aaj barish ho saktee hai.)
**English answer:** It can rain today.

### 65. आज बारिश होनी है।
**Romanized:** (Aaj barish honi hai.)
**English answer:** It has to rain today.

### 66. आज बारिश होनी थी।
**Romanized:** (Aaj barish honee thee.)
**English answer:** It had to rain today.

### 67. ये तुम्हारी सोच है।
**Romanized:** (Ye tumhari soch hai.)
**English answer:** It/This is your thinking.

### 68. ये किसका पैन है?
**Romanized:** (Ye kiska pen hai?)
**English answer:** Whose pen is this/it?

### 69. खाना खाये हुए मुझे कई दिन हो गये हैं।
**Romanized:** (Khana khaye hue mujhe kai din ho gaye hai.)
**English answer:** It has been many days to me having had the food.

### 70. अच्छे कपड़े पहने हुए कई दिन हो गये हैं।
**Romanized:** (Achhe kapde pahne hue kai din ho gaye h.)
**English answer:** It’s been many days having worn good clothes.

### 71. वहाँ गए हुए मुझे कई दिन हो गये हैं।
**Romanized:** (Vaha gae hue mujhe kai din ho gaye hai.)
**English answer:** It has been many days to me having gone there.

### 72. खाना खाये हुए मुझे कई दिन हो गये हैं।
**Romanized:** (Khana khaye hue mujhe kai din ho gaye hai.)
**English answer:** It has been many days to me having had the food.

### 73. आज ओले पड़ने थे।
**Romanized:** (Aaj ole padane the.)
**English answer:** It had to hail today.

### 74. आज ओले पड़ सकते हैं।
**Romanized:** (Aaj ole pad sakate hai.)
**English answer:** It may hail today.

### 75. आज ओले पड़ सकते थे पर नहीं पड़े।
**Romanized:** (Aaj ole pad sakte the par nahi pade.)
**English answer:** It may have hailed today but didn’t.

### 76. वो मेरी जिंदगी का बहुत अहम दिन था।
**Romanized:** (Vo meree jindgee ka bahut aham din tha.)
**English answer:** It was a very important day of my life.

### 77. राम को लिखने में ज़्यादा समय नहीं लगा।
**Romanized:** (Ram ko likhne mein zyada samay nahi laga.)
**English answer:** Ram didn’t take much time to write.

### 78. राम को लिखने में थोड़ा सा ही समय लगा।
**Romanized:** (Ram ko likhane me thoda sa hi samay laga.)
**English answer:** Ram took a little time to write.

### 79. इसकी कीमत 5 रुपया है।
**Romanized:** (Iskee keemat 5 Rupya hai.)
**English answer:** It’s for Rs 5. / It costs Rs 5.

### 80. इसकी कीमत 5 रुपया होगी।
**Romanized:** (Iskee keemat 5 Rupya hogee.)
**English answer:** It will be for Rs 5. / It will cost Rs 5.

### 81. उस दिन पूरे देश में छुट्टी थी।
**Romanized:** (Us din poore desh mein chhuttee thee.)
**English answer:** It was a holiday that day in the whole country.

### 82. सुबह से बारिश हो रही थी।
**Romanized:** (Subah se barish ho rahee thee.)
**English answer:** It had been raining since morning.

### 83. क्या आज सोमवार है?
**Romanized:** (Kya aaj somvaar hai?)
**English answer:** Is it Monday today?

### 84. यहाँ बारिश हो रही है।
**Romanized:** (Yaha barish ho rahee hai.)
**English answer:** It is raining here.

### 85. वहाँ ओले पड़ रहे थे।
**Romanized:** (Vaha ole pad rahe the.)
**English answer:** It was hailing there.

### 86. क्या काफी समय हो गया है?
**Romanized:** (Kya kaphee samay ho gaya hai?)
**English answer:** Has it been enough time?

### 87. कितना समय हो गया है?
**Romanized:** (kitna samay ho gaya hai?)
**English answer:** How long has it been?

### 88. क्या कल बारिश होगी?
**Romanized:** (Kya kal barish hogee?)
**English answer:** Will it rain tomorrow?

### 89. मुझे दो घंटे लगे।
**Romanized:** (Mujhe do ghante lage.)
**English answer:** It took me 2 hrs. / I took 2 hrs.

### 90. चेरापूंजी में सबसे अधिक बारिश क्यों होती है?
**Romanized:** (Cherapunji me sabse adhik barish kyo hoti h?)
**English answer:** Why does it rain the most in Cherapunji?

### 91. बर्गर खाये हुए मुझे 4 महीने हो गये हैं।
**Romanized:** (Burger khaye hue mujhe 4 mahine ho gaye hai.)
**English answer:** It has been 4 months to me having eaten/had Burger.

### 92. तुम्हें देखे हुए मुझे 3 दिन हो गये हैं।
**Romanized:** (Tumhen dekhe hue mujhe 3 din ho gaye hai.)
**English answer:** It has been 3 days to me having seen you.

### 93. क्या देहरादून में बारिश हुई?
**Romanized:** (Kya Dehradun me barish hui?)
**English answer:** Did it rain in Dehradun?

### 94. बारिश क्यों होती है?
**Romanized:** (Barish kyo hotee hai?)
**English answer:** Why does it rain?

### 95. उन्हें घर पहुँचने में कितना समय लगा?
**Romanized:** (Unhe ghar pahunchane me kitna samay laga?)
**English answer:** How much time did they take to reach home?

### 96. मैच का आनंद लेते हुए 2 घंटे हो गए हैं।
**Romanized:** (Match ka anand lete hue 2 ghante ho gae h.)
**English answer:** It has been 2 hrs, enjoying the match.

### 97. मूवी देखते हुए मुझे 15 मिनट हो गए हैं।
**Romanized:** (Movie dekhate hue mujhe 15 min ho gae h.)
**English answer:** It has been 15 minutes to me, watching movie.

### 98. यह प्यार है।
**Romanized:** (Yah pyar hai.)
**English answer:** It is love. / This is love.

### 99. यह एक कुर्सी है।
**Romanized:** (Yah ek kursee hai.)
**English answer:** It is a chair. / This is a chair.

### 100. उस शहर में बारिश हो रही होगी।
**Romanized:** (Us shahar mein barish ho rahee hogee.)
**English answer:** It will be raining in that city.

## Source-text notes

- The Hindi prompts were OCRed from the scanned pages and checked against PDF pages 224–227. Obvious scan/OCR slips in items 41, 73–75, and 97 were corrected against the page images; stray OCR punctuation was removed. No text was unreadable.
- All 100 printed English answers on PDF pages 227–229 were checked in order and paired to the matching numbered prompt. The source answer wording, including the unusual “I took me” at item 11, is retained rather than rewritten.
- The Hindi prompt at item 72 duplicates item 69 in the source; both occurrences are retained.

**Unreadable text:** none identified.

