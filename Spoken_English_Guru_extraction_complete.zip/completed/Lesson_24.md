# Lesson 24 — Active to Passive Voice

**PDF pages:** 336–346 (printed pages 335–345)

## Please change the following ACTIVE VOICE sentences into PASSIVE VOICE:

1. **Active sentence:** He plays football.  
   **Passive voice answer:** Football is played by him.  

2. **Active sentence:** She doesn't play cricket.  
   **Passive voice answer:** Cricket is not played by her.  

3. **Active sentence:** I play my guitar every day.  
   **Passive voice answer:** My guitar is played by me every day.  

4. **Active sentence:** Do I call you?  
   **Passive voice answer:** Are you called by me?  

5. **Active sentence:** Do I know you?  
   **Passive voice answer:** Are you known by me?  

6. **Active sentence:** Why do you eat pizza?  
   **Passive voice answer:** Why is the pizza eaten by you?  

7. **Active sentence:** Rekha was singing a song.  
   **Passive voice answer:** A song was being sung by Rekha.  

8. **Active sentence:** Is Raju purchasing mobile right now?  
   **Passive voice answer:** Is the mobile being purchased by Raju right now?  

9. **Active sentence:** They will inform you about it.  
   **Passive voice answer:** You will be informed about it by them.  

10. **Active sentence:** I have watched this movie.  
   **Passive voice answer:** This movie has been watched by me.  

11. **Active sentence:** Have you met him?  
   **Passive voice answer:** Has he been met by you?  

12. **Active sentence:** Why did he call you?  
   **Passive voice answer:** Why were you called by him?  

13. **Active sentence:** He hit the ball hard.  
   **Passive voice answer:** The ball was hit hard by him.  

14. **Active sentence:** Did he tell you something.  
   **Passive voice answer:** Were you told something by him?  

15. **Active sentence:** What did he eat today?  
   **Passive voice answer:** What was eaten today by him?  

16. **Active sentence:** How much does he love his brother?  
   **Passive voice answer:** How much is his brother loved by him?  

17. **Active sentence:** How much do you love your brother?  
   **Passive voice answer:** How much is your brother loved by you?  

18. **Active sentence:** Does anyone meet you at your home?  
   **Passive voice answer:** Are you met by anyone at your home?  

19. **Active sentence:** Rajni will have met Rashmi by the evening.  
   **Passive voice answer:** Rashmi will have been met by Rajni by the evening.  

20. **Active sentence:** He will have called you tomorrow.  
   **Passive voice answer:** You will have been called by him tomorrow.  

21. **Active sentence:** I didn't do it, trust me!  
   **Passive voice answer:** It was not done by me, trust me!  

22. **Active sentence:** Is she attending the class today?  
   **Passive voice answer:** Is the class being attended by her today?  

23. **Active sentence:** They will consult the doctor.  
   **Passive voice answer:** The doctor will be consulted by them.  

24. **Active sentence:** Why have you read this book?  
   **Passive voice answer:** Why has this book been read by you?  

25. **Active sentence:** I have been asking you since morning.  
   **Passive voice answer:** You have been being asked by me since morning.  

26. **Active sentence:** She had been reading that novel for months.  
   **Passive voice answer:** That novel had been being read by her for months.  

27. **Active sentence:** He will be opening the door at that moment.  
   **Passive voice answer:** The door will be being opened by him at that moment.  

28. **Active sentence:** Can you do it?  
   **Passive voice answer:** Can it be done by you?.  

29. **Active sentence:** We couldn't ask him.  
   **Passive voice answer:** He couldn’t be asked by us.  

30. **Active sentence:** They should never blame you for this mistake.  
   **Passive voice answer:** You should never be blamed by them for this mistake.  

31. **Active sentence:** He may have to read this book.  
   **Passive voice answer:** This book may have to be read by him.  

32. **Active sentence:** You must attend the class.  
   **Passive voice answer:** The class must be attended by you.  

33. **Active sentence:** He can drive this car.  
   **Passive voice answer:** This car can be driven by him.  

34. **Active sentence:** He cannot drive this car.  
   **Passive voice answer:** This car cannot be driven by him.  

35. **Active sentence:** Can he drive this car?  
   **Passive voice answer:** Can this car be driven by him?  

36. **Active sentence:** We shouldn’t kill the animals.  
   **Passive voice answer:** The animals shouldn’t be killed by us.  

37. **Active sentence:** He ought to help the poor.  
   **Passive voice answer:** The poor ought to be helped by him.  

38. **Active sentence:** He must have passed the exam.  
   **Passive voice answer:** The exam must have been passed by him.  

39. **Active sentence:** He might call you next week.  
   **Passive voice answer:** You might be called by him next week.  

40. **Active sentence:** Should I start a job?  
   **Passive voice answer:** Should a job be started by me?  

41. **Active sentence:** Should I have started a job?  
   **Passive voice answer:** Should a job have been started by me?  

42. **Active sentence:** Did you let him enter the house?  
   **Passive voice answer:** Was he let enter the house by you?  

43. **Active sentence:** He must let him go to market.  
   **Passive voice answer:** He must be let go to market by him.  

44. **Active sentence:** She lets me go wherever I want to.  
   **Passive voice answer:** I am let go by her wherever I want to.  

45. **Active sentence:** I will not let my brother know about it.  
   **Passive voice answer:** My brother will not be let know about it by me.  

46. **Active sentence:** He lets me go.  
   **Passive voice answer:** I am let go by him.  

47. **Active sentence:** She doesn't let me read the book.  
   **Passive voice answer:** I am not let read the book by her.  

48. **Active sentence:** I won't let you do it.  
   **Passive voice answer:** You won't be let do it by me.  

49. **Active sentence:** You should let him go.  
   **Passive voice answer:** He should be let go by you.  

50. **Active sentence:** I can let you play.  
   **Passive voice answer:** You can be let play by me.  

51. **Active sentence:** He should have let you do what you wanted to.  
   **Passive voice answer:** You should have been let do by him what you wanted to.  

52. **Active sentence:** He lets me go home.  
   **Passive voice answer:** I am let go home by him.  

53. **Active sentence:** She is not letting me study.  
   **Passive voice answer:** I am not being let study by her.  

54. **Active sentence:** They are letting Rahul work with Ram.  
   **Passive voice answer:** Rahul is being let work with Ram by them.  

55. **Active sentence:** He shouldn't have let you play all the time.  
   **Passive voice answer:** You shouldn't have been let play all the time by him.  

56. **Active sentence:** How often do you let him go to the park?  
   **Passive voice answer:** How often is he let go to the park by you?  

57. **Active sentence:** My brother never let me visit the Taj.  
   **Passive voice answer:** I am never let visit the Taj by my brother.  

58. **Active sentence:** Why do you not let him come home?  
   **Passive voice answer:** Why is he not let come home by you?  

59. **Active sentence:** There are two bananas to eat.  
   **Passive voice answer:** There are two bananas to be eaten.  

60. **Active sentence:** I have a bill to pay.  
   **Passive voice answer:** I have a bill to be paid.  

61. **Active sentence:** He has to meet me tomorrow.  
   **Passive voice answer:** I have to be met by him tomorrow.  

62. **Active sentence:** They seem to ask you this question.  
   **Passive voice answer:** You seem to be asked this question by them.  

63. **Active sentence:** She needs to finish the task today itself.  
   **Passive voice answer:** The task needs to be finished by her today itself.  

64. **Active sentence:** Hurry up, please.  
   **Passive voice answer:** You are requested to hurry up.  

65. **Active sentence:** Did you grow vegetables?  
   **Passive voice answer:** Were vegetables grown by you?  

66. **Active sentence:** It is time to take a cup of coffee.  
   **Passive voice answer:** It is time for a cup of coffee to be taken.  

67. **Active sentence:** Did he win the match?  
   **Passive voice answer:** Was the match won by him?  

68. **Active sentence:** My progress satisfied my parents.  
   **Passive voice answer:** My parents were satisfied with my progress.  

69. **Active sentence:** Were they singing songs?  
   **Passive voice answer:** Were songs being sung by them?  

70. **Active sentence:** They know my father.  
   **Passive voice answer:** My father is known to them.  

71. **Active sentence:** Ravi married Asha.  
   **Passive voice answer:** Asha was married to Ravi.  

72. **Active sentence:** Sugar tastes sweet.  
   **Passive voice answer:** Sugar is sweet when tasted.  

73. **Active sentence:** It is now time to close the doors.  
   **Passive voice answer:** It is now time for the doors to be closed.  

74. **Active sentence:** He hopes to win a medal.  
   **Passive voice answer:** It is hoped that he will win a medal.  

75. **Active sentence:** Her failure shocked us.  
   **Passive voice answer:** We were shocked at her failure.  

76. **Active sentence:** The rose smells great.  
   **Passive voice answer:** The rose is great when smelt.  

77. **Active sentence:** I want to buy a pen.  
   **Passive voice answer:** I want a pen to be bought.  

78. **Active sentence:** People take this meal all over the world.  
   **Passive voice answer:** This meal is taken by people all over the world.  

79. **Active sentence:** You cannot please him.  
   **Passive voice answer:** He cannot be pleased with you.  

80. **Active sentence:** The flowers are being watered by the gardener.  
   **Passive voice answer:** The gardener is watering the flowers.  

81. **Active sentence:** He has invited me.  
   **Passive voice answer:** I have been invited by him.  

82. **Active sentence:** The news of his departure shocked us.  
   **Passive voice answer:** We were shocked at the news of his departure.  

83. **Active sentence:** They have insulted us.  
   **Passive voice answer:** We have been insulted by them.  

84. **Active sentence:** I had never seen such a lovely girl before.  
   **Passive voice answer:** Such a lovely girl had never been seen by me before.  

85. **Active sentence:** I do not love him.  
   **Passive voice answer:** He is not loved by me.  

86. **Active sentence:** I had sold the old books.  
   **Passive voice answer:** The old books had been sold by me.  

87. **Active sentence:** They had prepared many things.  
   **Passive voice answer:** Many things had been prepared by them.  

88. **Active sentence:** Did he consult you?  
   **Passive voice answer:** Were you consulted by him?  

89. **Active sentence:** Have they finished their assignments?  
   **Passive voice answer:** Have their assignments been finished by them?  

90. **Active sentence:** What have you made?  
   **Passive voice answer:** What has been made by you?  

91. **Active sentence:** They have built this robot themselves.  
   **Passive voice answer:** This robot has been built by them themselves.  

92. **Active sentence:** The judge advised them to settle the matter.  
   **Passive voice answer:** They were advised by the judge to settle the matter.  

93. **Active sentence:** You are spending too much time on this matter.  
   **Passive voice answer:** Too much time is being spent by you on this matter.  

94. **Active sentence:** He will have advised her.  
   **Passive voice answer:** She will have been advised by him.  

95. **Active sentence:** That scientist discovered a new pill to stimulate the appetite.  
   **Passive voice answer:** A new pill was discovered by that scientist to stimulate the appetite.  

96. **Active sentence:** He is running a hospital these days.  
   **Passive voice answer:** A hospital is being run by him these days.  

97. **Active sentence:** You must do your duty.  
   **Passive voice answer:** Your duty must be done by you.  

98. **Active sentence:** No one ever taught me how to play the guitar.  
   **Passive voice answer:** I was never taught by anyone how to play the guitar.  

99. **Active sentence:** One must do one's duty.  
   **Passive voice answer:** Duty must be done (by all).  

100. **Active sentence:** The man could not climb the tree.  
   **Passive voice answer:** The tree could not be climbed by the man.  

101. **Active sentence:** I have proved all his calculations wrong.  
   **Passive voice answer:** All his calculations have been proven wrong by me.  

102. **Active sentence:** Who is disturbing you?  
   **Passive voice answer:** By whom are you being disturbed?  

103. **Active sentence:** I would have attended the meeting if it were possible.  
   **Passive voice answer:** The meeting would have been attended by me if it were possible.  

104. **Active sentence:** We have to do it very early in the morning.  
   **Passive voice answer:** It has to be done by us very early in the morning.  

105. **Active sentence:** She will have finished the paper by 1 o'clock.  
   **Passive voice answer:** The paper will have been finished by her by 1 o'clock.  

106. **Active sentence:** Has he made all the necessary arrangements?  
   **Passive voice answer:** Have all the necessary arrangements been made by him?  

107. **Active sentence:** You should switch off the inverter when changing a fuse.  
   **Passive voice answer:** The inverter should be switched off while changing a fuse.  

108. **Active sentence:** He asked me to wait there.  
   **Passive voice answer:** I was asked by him to wait there.  

109. **Active sentence:** She should have helped her friends.  
   **Passive voice answer:** Her friends should have been helped by her.  

110. **Active sentence:** You cannot expect him to understand these problems.  
   **Passive voice answer:** He can't be expected to understand these problems.  

111. **Active sentence:** He will have closed his shop by now.  
   **Passive voice answer:** His shop will have been closed by him by now.  

112. **Active sentence:** You could have solved this question.  
   **Passive voice answer:** This question could have been solved by you.  

113. **Active sentence:** You should return the book next week.  
   **Passive voice answer:** The book should be returned by you next week.  

114. **Active sentence:** They can't put you in prison.  
   **Passive voice answer:** You can't be put in prison by them.  

115. **Active sentence:** The owner himself showed her the house.  
   **Passive voice answer:** She was shown the house by the owner himself.  

116. **Active sentence:** We ought to respect our elders.  
   **Passive voice answer:** Our elders ought to be respected by us.  

117. **Active sentence:** She always gives me gifts at new year.  
   **Passive voice answer:** I am always given gifts by her at new year.  

118. **Active sentence:** Did you paint these pictures in your house?  
   **Passive voice answer:** Were these pictures painted in your house?  

119. **Active sentence:** We should obey our teachers.  
   **Passive voice answer:** Our teachers should be obeyed by us.  

120. **Active sentence:** They rejected his proposal.  
   **Passive voice answer:** His proposal was rejected by them.  

121. **Active sentence:** Let them do it now.  
   **Passive voice answer:** Let it be done by them now.  

122. **Active sentence:** He can help you.  
   **Passive voice answer:** You can be helped by him.  

123. **Active sentence:** He will rob them if they are not cautious.  
   **Passive voice answer:** They will be robbed by him if they are not cautious.  

124. **Active sentence:** They did not tell me anything about the situation.  
   **Passive voice answer:** I was not told anything about the situation.  

125. **Active sentence:** They might win the match.  
   **Passive voice answer:** The match might be won by them.  

126. **Active sentence:** Post this letter.  
   **Passive voice answer:** Let this letter be posted.  

127. **Active sentence:** Cut your shirt according to your requirement.  
   **Passive voice answer:** Let your shirt be cut according to your requirement.  

128. **Active sentence:** They have decided to increase the level.  
   **Passive voice answer:** It has been decided to increase level.  

129. **Active sentence:** Never tell a lie.  
   **Passive voice answer:** Let a lie never be told.  

130. **Active sentence:** He performed a dance for the first time last week.  
   **Passive voice answer:** His dance was performed for the first time last week.  

131. **Active sentence:** Do not pluck flowers.  
   **Passive voice answer:** Let flowers not be plucked.  

132. **Active sentence:** They will look after you.  
   **Passive voice answer:** You will be looked after by them.  

133. **Active sentence:** Tell him to go.  
   **Passive voice answer:** Let him be told to go.  

134. **Active sentence:** They promised Rahul a new phone on his birthday.  
   **Passive voice answer:** Rahul was promised a new phone on his birthday.  

135. **Active sentence:** Did they not tell you to be here by 8 o'clock?  
   **Passive voice answer:** Were you not told to be here by 8 o'clock?  

136. **Active sentence:** Have they carried out his orders?  
   **Passive voice answer:** Have his orders been carried out by them?  

137. **Active sentence:** Mom will have to amuse him with riddles.  
   **Passive voice answer:** He will have to be amused by mom with riddles.  

138. **Active sentence:** Please sit here and wait till I come back.  
   **Passive voice answer:** You are requested to wait here till I come back.  

139. **Active sentence:** Ravi chose his words with care.  
   **Passive voice answer:** Words were chosen with care by Ravi.  

140. **Active sentence:** Is he running a race?  
   **Passive voice answer:** Is a race being run by him?  

141. **Active sentence:** Has someone told her about her result?  
   **Passive voice answer:** Has she been told about her result?  

142. **Active sentence:** It shocked me to hear that someone had bothered you.  
   **Passive voice answer:** I was shocked to hear that you had been bothered by someone.  

143. **Active sentence:** Everyone knows that he is a footballer.  
   **Passive voice answer:** He is known to be a footballer.  

144. **Active sentence:** Do they like my teachers?  
   **Passive voice answer:** Are my teachers liked by them?  

145. **Active sentence:** Work hard.  
   **Passive voice answer:** You are advised to work hard.  

146. **Active sentence:** Can you solve this question?  
   **Passive voice answer:** Can this question be solved by you?  

147. **Active sentence:** Let him sing a song  
   **Passive voice answer:** Let a song be sung by him.  

148. **Active sentence:** Please shut the door.  
   **Passive voice answer:** You are requested to shut the door.  

149. **Active sentence:** Who teaches you Maths?  
   **Passive voice answer:** By whom are you taught Maths?  

150. **Active sentence:** She ran fast to win the race.  
   **Passive voice answer:** She ran fast for the race to be won.  

151. **Active sentence:** This bottle contains water  
   **Passive voice answer:** Water is contained in this bottle.  

152. **Active sentence:** Why do you blame me?  
   **Passive voice answer:** Why am I blamed by you?  

153. **Active sentence:** Does this guy sell grocery?  
   **Passive voice answer:** Is grocery sold by this guy?  

154. **Active sentence:** He had not seen this place before.  
   **Passive voice answer:** This place had not been seen by him before.  

155. **Active sentence:** I will never forget your behavior.  
   **Passive voice answer:** Your behavior will never be forgotten by me.  

156. **Active sentence:** The lady had already cooked food.  
   **Passive voice answer:** Food had already been cooked by the lady.  

157. **Active sentence:** We were expecting her.  
   **Passive voice answer:** She was being expected by us.  

158. **Active sentence:** The peon has done it.  
   **Passive voice answer:** It has been done by the peon.  

159. **Active sentence:** The issue is being looked into by the judge.  
   **Passive voice answer:** The judge is looking into the issue.  

160. **Active sentence:** We have painted the windows.  
   **Passive voice answer:** The windows have been painted by us.  

161. **Active sentence:** They have won the match.  
   **Passive voice answer:** The match has been won by them.  

162. **Active sentence:** We should keep this in the cupboard.  
   **Passive voice answer:** This should be kept in the cupboard (by us).  

163. **Active sentence:** The rich must help the poor.  
   **Passive voice answer:** The poor must be helped by the rich.  

164. **Active sentence:** My uncle helped me.  
   **Passive voice answer:** I was helped by my uncle.  

165. **Active sentence:** They will help me.  
   **Passive voice answer:** I will be helped by them.  

166. **Active sentence:** They wrote several letters.  
   **Passive voice answer:** Several letters were written by them.  

167. **Active sentence:** The doctor treats these patients well.  
   **Passive voice answer:** These patients are treated well by the doctor.  

168. **Active sentence:** I do not understand this problem.  
   **Passive voice answer:** This problem is not understood by me.  

169. **Active sentence:** He writes stories.  
   **Passive voice answer:** Stories are written by him.  

170. **Active sentence:** He sang a song.  
   **Passive voice answer:** A song was sung by him.  

171. **Active sentence:** They will not disobey you.  
   **Passive voice answer:** You will not be disobeyed by them.  

172. **Active sentence:** The laborers will repair the road.  
   **Passive voice answer:** The road will be repaired by the laborers.  

173. **Active sentence:** The teacher corrected my homework.  
   **Passive voice answer:** My homework was corrected by the teacher.  

174. **Active sentence:** It is time to say prayers.  
   **Passive voice answer:** It is time for prayers to be said.  

175. **Active sentence:** We must follow the rules.  
   **Passive voice answer:** The rules must be followed.  

176. **Active sentence:** Somebody gave her something on her birthday.  
   **Passive voice answer:** Something was given to her on her birthday. / She was given something on her birthday.  

177. **Active sentence:** Did you say something?  
   **Passive voice answer:** Was something said by you?  

178. **Active sentence:** He does not obey his teachers.  
   **Passive voice answer:** His teachers are not obeyed by him.  

179. **Active sentence:** It is necessary to write this poem.  
   **Passive voice answer:** It is necessary for this poem to be written.  

180. **Active sentence:** They are watching cricket.  
   **Passive voice answer:** Cricket is being watched by them.  

181. **Active sentence:** We should serve our country.  
   **Passive voice answer:** Our country should be served by us.  

182. **Active sentence:** Children like chocolates.  
   **Passive voice answer:** Chocolates are liked by children.  

183. **Active sentence:** The girl is flying a kite.  
   **Passive voice answer:** A kite is being flown by the girl.  

184. **Active sentence:** The students were solving the problems.  
   **Passive voice answer:** The problems were being solved by the students.  

185. **Active sentence:** He is betraying me.  
   **Passive voice answer:** I am being betrayed by him.  

186. **Active sentence:** You are going through this lesson.  
   **Passive voice answer:** This lesson is being gone through by you.  

187. **Active sentence:** Many worship the rising sun.  
   **Passive voice answer:** The rising sun is worshipped by many.  

188. **Active sentence:** He will teach a new lesson today.  
   **Passive voice answer:** A new lesson will be taught by him today.  

189. **Active sentence:** My mother was telling a story.  
   **Passive voice answer:** A story was being told by my mother.  

190. **Active sentence:** We can buy this but not that one.  
   **Passive voice answer:** This can be bought by us but not that one.  

191. **Active sentence:** People will remember him.  
   **Passive voice answer:** He will be remembered by people.  

192. **Active sentence:** We are not wasting time here.  
   **Passive voice answer:** Time is not being wasted by us here.  

193. **Active sentence:** The boys are drawing the pictures.  
   **Passive voice answer:** The pictures are being drawn by the boys.  

194. **Active sentence:** Get out of my house.  
   **Passive voice answer:** You are ordered to get out of my house.  

195. **Active sentence:** There is no money to waste.  
   **Passive voice answer:** There is no money to be wasted.  

196. **Active sentence:** A child cannot throw it.  
   **Passive voice answer:** It cannot be thrown by a child.  

197. **Active sentence:** They laughed at me.  
   **Passive voice answer:** I was laughed at by them.  

198. **Active sentence:** You might have heard his name.  
   **Passive voice answer:** His name might have been heard by you.  

199. **Active sentence:** He might do it.  
   **Passive voice answer:** It might be done by him.  

200. **Active sentence:** Who has broken the cup?  
   **Passive voice answer:** By whom has the cup been broken?  

201. **Active sentence:** Has he returned the pens?  
   **Passive voice answer:** Have the pens been returned by him?  

202. **Active sentence:** Will you have read the magazine by tomorrow?  
   **Passive voice answer:** Will the magazine have been read by you by tomorrow?  

203. **Active sentence:** Has anyone seen Rajesh this evening?  
   **Passive voice answer:** Has Rajesh been seen (by anyone) this evening?  

204. **Active sentence:** We are blaming global warming for this.  
   **Passive voice answer:** Global warming is being blamed for this.  

205. **Active sentence:** Someone sent application forms to me.  
   **Passive voice answer:** I was sent application forms (by someone). / Application forms were sent to me (by someone).  

206. **Active sentence:** Someone handed me a bag.  
   **Passive voice answer:** I was handed a bag (by someone). / A bag was handed to me (by someone).  

207. **Active sentence:** Someone is sending me threatening messages.  
   **Passive voice answer:** Threatening messages are being sent to him (by someone). / I am being sent threatening messages (by someone).  

208. **Active sentence:** Everyone believed that it would not help.  
   **Passive voice answer:** It was believed (by everyone) that it would not help.  

209. **Active sentence:** Everyone said that there was no one in the room.  
   **Passive voice answer:** It was said (by everyone) that there was no one in the room.  

210. **Active sentence:** This decision has deprived many people of the education.  
   **Passive voice answer:** Many people have been deprived of the education by this decision.  

211. **Active sentence:** The police has questioned the witnesses for a long time.  
   **Passive voice answer:** The witnesses have been questioned for a long time by the police.  

212. **Active sentence:** Her silly questions began to irritate me.  
   **Passive voice answer:** I began to be irritated by her silly questions.  

213. **Active sentence:** Tarun has interviewed the new candidate.  
   **Passive voice answer:** The new candidate has been interviewed by Tarun.  

214. **Active sentence:** Someone had stolen the watch from the showroom.  
   **Passive voice answer:** The watch had been stolen from the showroom.  

215. **Active sentence:** It is reported that this decision has worsened his condition.  
   **Passive voice answer:** His condition is reported to have been worsened by this decision.  

216. **Active sentence:** I look after my parents.  
   **Passive voice answer:** My parents are looked after by me.  

## Source and verification notes

- All 216 numbered active-voice prompts and all 216 printed passive-voice answers were visually checked against PDF pages 336–346 and paired by the same number. The prompt and answer sequences are complete and unique.
- This lesson is printed in English only; no Hindi or Romanized text appears on PDF pages 336-346.
- The printed page footer numbers are one less than the PDF page numbers.
- The source answer at item 28 includes the printed punctuation “Can it be done by you?.”; preserve it as printed rather than silently rewriting the source.

**Hindi/Romanized text:** none printed in this lesson.
**Unreadable text:** none identified.

