# Lesson 31 — Homonyms

**PDF pages:** 415–416 (printed pages 414–415)

## Fill in the blanks with the appropriate word given in brackets below.

1. The minority community shouldn’t be ……. (prosecuted, persecuted) by the majority.  
   **Answer:** persecuted  

2. The kings of the Maurya empire are listed here in a ……… (historical, historic) manner.  
   **Answer:** historical  

3. The Prime Minister delivered a ……….. (historical, historic) speech today.  
   **Answer:** historic  

4. I was ……….. (born, borne) in Dehradun.  
   **Answer:** born  

5. All the expenses are to be ……….. (born, borne) by the company.  
   **Answer:** borne  

6. He has always been a very ……… (amiable, amenable) child.  
   **Answer:** amenable  

7. She is certainly an ……… (amiable, amenable) boss to work with.  
   **Answer:** amiable  

8. Do you have any ………. (alternative, alternate) arrangement?  
   **Answer:** alternative  

9. He visits my house on ………. (alternative, alternate) days.  
   **Answer:** alternate  

10. Working twelve hours a day is no doubt …… (exhaustive, exhausting).  
   **Answer:** exhaustive  

11. A meeting of the ………. (council, cabinet) of ministers is to be held in this hall today.  
   **Answer:** council  

12. You are not ………. (illegible/ eligible) for this post because you are not graduate.  
   **Answer:** eligible  

13. His handwriting is so ………. (illegible/ eligible) that nobody can read it.  
   **Answer:** illegible  

14. Haridwar comes on the train ……….. (route, rout) to Dehradun.  
   **Answer:** route  

15. His brother is a very …………… (sensible, sensitive) person.  
   **Answer:** sensible  

16. He is very ……… (sensible, sensitive) to people’s reactions on his actions.  
   **Answer:** sensitive  

17. All the pleasures and the problems are just … (momentary, momentous); don’t worry.  
   **Answer:** momentary  

18. His personality all around the world is ………. . (momentary, momentous)  
   **Answer:** momentous  

19. I’m sure, he has done some ………. (tempering, tampering) with the secret documents.  
   **Answer:** tampering  

20. That model had a ……… (gracious, graceful) appearance in the show.  
   **Answer:** graceful  

21. He is a ……… (gracious, graceful) person by nature, as he does lots of social work.  
   **Answer:** gracious  

22. He is not a permanent employee, but a ………. (temporal, temporary)  
   **Answer:** temporary  

23. The big businessmen stay at the luxurious ……… (mansions/ mentions) only.  
   **Answer:** mansions  

24. The house got demolished due to heavy ………… (lightning/ lightening) last night.  
   **Answer:** lightning  

25. I will …………. (practice, practise) speaking a lot to become a fluent speaker.  
   **Answer:** practise  

26. They have done so much ………….. (practice, practise) in order to win the game.  
   **Answer:** practice  

27. Why are you ………. (jealous/ zealous) of his success?  
   **Answer:** jealous  

28. My wife is a ………. (jealous/ zealous) supporter of Indian cricket team?  
   **Answer:** zealous  

29. One must take ……. (judicious, judicial) decisions in business.  
   **Answer:** judicious  

30. He is in …………. (judicious, judicial) custody right now.  
   **Answer:** judicial  

## Source-text and verification notes

- The source lesson is English-only; no Hindi text appears on these pages.
- All 30 choices and blanks on PDF page 415 were checked against the scan. The answer key on page 416 contains all 30 entries and each is paired to the same-number prompt.
- Printed wording, punctuation, and source irregularities are retained, including the extra punctuation in item 18 and the question mark at the end of item 28.

**Unreadable text:** none identified.

