# Lesson 27 — Use of “Be, Being & Been”

**PDF pages:** 360–364 (printed pages 359–363)

## Please translate the following sentences into English:

1. **Hindi prompt:** बिल्डिंग बनाई जा चुकी है।  
   **Romanized:** Building Banai ja chuki hai.  
   **English answer:** The building has been constructed.  

2. **Hindi prompt:** बिल्डिंग बनाई जानी है।  
   **Romanized:** Building Banai Jaani hai.  
   **English answer:** The building has to be constructed. / The building is to be constructed.  

3. **Hindi prompt:** कमरों को साफ किया जाना है।  
   **Romanized:** Kamron ko saaf kiya jana hai.  
   **English answer:** The rooms have to be cleaned. / The rooms are to be cleaned.  

4. **Hindi prompt:** कमरों को साफ किया जाना था।  
   **Romanized:** Kamron ko saaf kiya jana tha.  
   **English answer:** The rooms had to be cleaned. / The rooms were to be cleaned.  

5. **Hindi prompt:** हमें खुश किया जा रहा है।  
   **Romanized:** Hame Khush Kiya ja raha hai.  
   **English answer:** We are being made happy.  

6. **Hindi prompt:** हमें समझाया जा रहा है।  
   **Romanized:** Hame samjhaya ja raha hai.  
   **English answer:** We are being made understand.  

7. **Hindi prompt:** उसे रूलाया जा रहा है।  
   **Romanized:** Use rulaya ja raha hai.  
   **English answer:** He is being made cry.  

8. **Hindi prompt:** तुम्हें हँसाया जा रहा है।  
   **Romanized:** Tumhe hansaya ja raha hai.  
   **English answer:** He is being made laugh.  

9. **Hindi prompt:** मुझे बताया गया था।  
   **Romanized:** Mujhe bataya gaya tha.  
   **English answer:** I had been told.  

10. **Hindi prompt:** वो मेरे होने वाले पति हैं।  
   **Romanized:** Wo mere hone wale Pati hai.  
   **English answer:** He is my to-be husband. / He is my husband to-be.  

11. **Hindi prompt:** वो मेरी होने वाली पत्नी है।  
   **Romanized:** Wo meri hone wale Patni hai.  
   **English answer:** She is my to-be wife. / She is my wife to-be.  

12. **Hindi prompt:** राहुल स्वार्थी हो रहा है।  
   **Romanized:** Rahul swarthi ho raha hai.  
   **English answer:** Rahul is being selfish. / Rahul is getting selfish.  

13. **Hindi prompt:** रोहित को पीटा जा रहा था।  
   **Romanized:** Rohit ko pita ja raha tha.  
   **English answer:** Rohit was being beaten. / Rohit was getting beaten.  

14. **Hindi prompt:** हमें भेजा जा रहा है।  
   **Romanized:** Hame bheja Ja Raha hai.  
   **English answer:** We are being sent.  

15. **Hindi prompt:** पैसे के मामले में स्वार्थी बनो।  
   **Romanized:** Paise Ke maamle mein swarthi bano.  
   **English answer:** Be selfish for money matters.  

16. **Hindi prompt:** वो घर पर होना चाहिए।  
   **Romanized:** Wo ghar par hona chahiye  
   **English answer:** He should be at home.  

17. **Hindi prompt:** अयांश इस वक्त स्कूल में नहीं होना चाहिए।  
   **Romanized:** Ayansh is waqt school mein nahi hona chahiye.  
   **English answer:** Ayansh shouldn’t be in school right now.  

18. **Hindi prompt:** हमें पुलिस के द्वारा बहुत बुरी तरह प्रताड़ित किया गया।  
   **Romanized:** Hame police ke dwara bahut Buri Tarah Pratadit kiya Gaya.  
   **English answer:** We were tortured very badly by the police.  

19. **Hindi prompt:** मुझे 6:00 बजे तक ऑफिस में रहना है।  
   **Romanized:** Mujhe 6:00 baje tak office mein rahna Hai.  
   **English answer:** I have to be in office till 6 o'clock. / I am to be in office till 6 o'clock.  

20. **Hindi prompt:** आप थके हुए लग रहे हो।  
   **Romanized:** Aap thake huye lag rahe ho.  
   **English answer:** You are looking tired. / You seem to be tired.  

21. **Hindi prompt:** उसे घर पर रहने को कहा गया है।  
   **Romanized:** Use ghar par rehne ko kaha gaya hai.  
   **English answer:** He has been told to be at home. / He has been told to stay at home. / He has been told to remain at home.  

22. **Hindi prompt:** युद्ध में दुश्मन को मार गिराने की क्या संभावना है?  
   **Romanized:** Yuddh me dushman ko maar girane ki kya sambhavna hai?  
   **English answer:** What is the possibility of killing the enemy in the war?  

23. **Hindi prompt:** युद्ध में मारे जाने की क्या संभावना है?  
   **Romanized:** Yuddh me maare jaane ki kya sambhavna h?  
   **English answer:** What is the possibility of being killed in the war?  

24. **Hindi prompt:** तुम्हारे साथ होना मेरी जिंदगी की सबसे बड़ी उपलब्धि है।  
   **Romanized:** Tumhare sath Hona Meri Zindagi Ki Sabse Badi uplabdhi hai  
   **English answer:** Being with you is the biggest achievement of my life.  

25. **Hindi prompt:** तुम्हारे साथ होना मेरा सौभाग्य है।  
   **Romanized:** Tumhare sath Hona mera saubhagya hai  
   **English answer:** Being with you is my luck.  

26. **Hindi prompt:** हमें कहा गया कि बिल्डिंग बनाई जानी है।  
   **Romanized:** Hame Kaha gaya ki building banai Jaani h.  
   **English answer:** We were told that the building had to be constructed./ The building was said to be constructed.  

27. **Hindi prompt:** हमें कहा गया कि बिल्डिंग बनाई जा चुकी है।  
   **Romanized:** Hume kaha gaya ki building banai ja chuki hai.  
   **English answer:** We were told that the building had to be constructed./ The building was said to have been constructed.  

28. **Hindi prompt:** कमरे को साफ किया जा रहा था।  
   **Romanized:** Kamre ko saaf Kiya ja raha tha.  
   **English answer:** The room was being cleaned.  

29. **Hindi prompt:** आपको झूठ बोला गया था कि आज मेरी शादी है।  
   **Romanized:** Aapko jhoot bola gaya tha ki aaj meri shaadi hai.  
   **English answer:** You had been told a lie that it was my marriage that day.  

30. **Hindi prompt:** स्वार्थी मत बनिए।  
   **Romanized:** Swarthi mat baniye.  
   **English answer:** Don't be selfish.  

31. **Hindi prompt:** ये काम किया जाना है।  
   **Romanized:** Ye Kaam Kiya jana hai  
   **English answer:** This work is to be done.  

32. **Hindi prompt:** आपसे पुलिस के द्वारा पूछताछ की जानी है।  
   **Romanized:** Apse police ke dwara puchtach ki Jani h.  
   **English answer:** You have to be interrogated by the police.  

33. **Hindi prompt:** वो मेरे पिटने के बारे में बात कर रहे थे।  
   **Romanized:** Wo Mere Pitne ke bare me baat kar rahe the  
   **English answer:** They were talking about my being beaten.  

34. **Hindi prompt:** वो मुझे पीटने के बारे में बात कर रहे थे।  
   **Romanized:** Wo Mujhe Peetne k bare me baat kr rhe the  
   **English answer:** They were talking about beating me.  

35. **Hindi prompt:** उसने मुझे तुम्हारे भाई के द्वारा मदद किए जाने के बारे में बताया।  
   **Romanized:** Usne mujhe Tumhare bhai ke dwara madad kiye jane ke bare mein Bataya.  
   **English answer:** He told me about having been helped by your brother.  

36. **Hindi prompt:** वो तुम्हारे पिटने के बारे में बात कर रहे हैं।  
   **Romanized:** Wo Tumhare Pitne ke bare mein baat kar rahe hai.  
   **English answer:** They are talking about your being beaten.  

37. **Hindi prompt:** इस वक्त घर पर होना मेरे लिए ज़रूरी है।  
   **Romanized:** Is wakt ghar par hona mere liye zaruri hai.  
   **English answer:** Being at home is important for me right now.  

38. **Hindi prompt:** कभी-कभी स्वार्थी होना अच्छा होता है।  
   **Romanized:** Kabhi kabhi Swarthi Hona acha Hota Hai.  
   **English answer:** Being selfish at times is fair.  

39. **Hindi prompt:** आपका स्कूल में होना कितना मायने रखता है ?  
   **Romanized:** Aapka school mein Hona Kitna maayne Rakhta hai?  
   **English answer:** How important is it for you being in school?  

40. **Hindi prompt:** वो दिल्ली में कभी नहीं रहा है।  
   **Romanized:** Wo Delhi mein kabhi nahi raha hai.  
   **English answer:** He has never been in Delhi. / He has never lived in Delhi.  

41. **Hindi prompt:** मैं आपसे मिलने को बेताब हो रहा हूँ।  
   **Romanized:** Main apse milne ko Betab ho raha hun.  
   **English answer:** I am being impatient to meet you. / I am craving to meet you.  

42. **Hindi prompt:** आपको पूछा जाना चाहिए था।  
   **Romanized:** Aapko Poocha Jana chahiye tha.  
   **English answer:** You should have been asked.  

43. **Hindi prompt:** उसे मुंबई नहीं भेजा जा सका।  
   **Romanized:** Use Mumbai nahi bheja Ja saka.  
   **English answer:** He could not be sent to Mumbai.  

44. **Hindi prompt:** मुझे टीम में खेलने नहीं दिया जा रहा है।  
   **Romanized:** Mujhe team Me khelne nahi diya ja raha hai.  
   **English answer:** I am not being let play in the team.  

45. **Hindi prompt:** मेरी शादी को 5 साल हो गए हैं।  
   **Romanized:** Meri Shadi ko 5 saal ho gaye hai.  
   **English answer:** It has been 5 year to my marriage. / I have been married for 5 years.  

46. **Hindi prompt:** डांट खाने के बाद वो दुखी हो गया।  
   **Romanized:** Dant khane ke baad wo dukhi ho gya.  
   **English answer:** Having been scolded, he turned/got sad.  

47. **Hindi prompt:** आरोप लगाए जाने के बाद, उसने निर्दोष व्यवहार करना शुरु कर दिया।  
   **Romanized:** Aarop Lagaye jane ke bad usne Nirdosh vyavahar karna Shuru kar diya.  
   **English answer:** Having been accused, he started behaving innocent.  

48. **Hindi prompt:** लगता है वो देहरादून में काफी समय से हैं।  
   **Romanized:** Lagta hai wo Dehradun mein Kafi Samay se hai.  
   **English answer:** He seems to have been in Dehradun for quite a long.  

49. **Hindi prompt:** वो बदल रहा है।  
   **Romanized:** Wo badal raha hai.  
   **English answer:** He is being changed. / He is getting changed.  

50. **Hindi prompt:** मैं थक रहा हूँ।  
   **Romanized:** Mai thak raha hun.  
   **English answer:** I am being tired. / I am getting tired.  

51. **Hindi prompt:** एक अध्यापक होने के नाते, ये मेरा फर्ज हैं।  
   **Romanized:** Ek teacher hone ke naate, ye mera farz h.  
   **English answer:** Being a teacher, it is my duty.  

52. **Hindi prompt:** वो घर पर रहना पसंद करता है।  
   **Romanized:** Wo ghar par rehna pasand karta hai.  
   **English answer:** He loves being at home.  

53. **Hindi prompt:** घर पर होने की वजह से मैं आपसे मिल पाया।  
   **Romanized:** Ghar pr hone ki wajah se main aapse mil paya.  
   **English answer:** I could meet you due to being at home.  

54. **Hindi prompt:** उसे भेजा जा रहा होगा।  
   **Romanized:** Use bheja ja raha Hoga.  
   **English answer:** He will be getting sent.  

55. **Hindi prompt:** पकड़े जाने के डर से वो डरा हुआ था।  
   **Romanized:** Pakde jaane ke dar se wo dara hua tha.  
   **English answer:** He was scared of being caught.  

56. **Hindi prompt:** आपके डांट खाने की क्या संभावना है?  
   **Romanized:** Aapke daant khane ki kya Sambhavna hai?  
   **English answer:** What is the chance of your being scolded?  

57. **Hindi prompt:** मुझे शाम 7:00 बजे तक ऑफिस में रहने का आदेश किया गया था।  
   **Romanized:** Mujhe Shaam 7:00 baje tak office me rehne ka aadesh kiya gaya tha.  
   **English answer:** I had been instructed to stay/be in office till 7 PM.  

## Source-text and verification notes

- All 57 Hindi prompts and their printed Romanized lines were OCRed from row crops and visually checked against the scans; all 57 English answers were visually reviewed and paired by number. The prompt and answer sequences are complete and unique.
- Lesson 27 spans PDF pages 360–364 (printed pages 359–363). Hindi/Romanized prompts 1–21 are on PDF page 360, 22–43 on page 361, and 44–57 on page 362. The English answer key runs 1–32 on page 363 and 33–57 on page 364; all answers were visually reviewed and paired by number.
- All 57 Hindi prompts and their printed Romanized lines were OCRed from row crops and visually checked against the scanned pages; all 57 English answers were visually reviewed. Continuous 1–57 prompt and answer sequences confirmed; no unreadable sections.
- Printed page footer numbers are one lower than PDF page numbers.
- Romanized source spellings, capitalization, abbreviations, and punctuation are retained. Noted source mismatches include Hindi plural `हैं` with Roman singular `hai` at items 10, 45, 48, and 51; item 23’s printed `h`; item 34’s `k`, `kr`, `rhe`; and item 51’s abbreviated `h.`. Item 11 has `होने वाली पत्नी` in Hindi but `hone wale Patni` in the printed Romanized line. Item 16 Romanized line has no terminal period. These are preserved as printed.
- At item 51 the source prints `ये मेरा फर्ज हैं।`; preserve the agreement quirk. Item 57’s printed wording `आदेश किया गया था` is also retained even though unusual. Source capitalization such as `team Me`, `Shadi`, `Aarop Lagaye`, `Nirdosh`, `Shuru`, `Kafi Samay`, `Hoga`, `Sambhavna`, and `Shaam` is retained.
- English answer wording and all printed alternatives are retained as printed.

**Unreadable text:** none identified.

