# Lesson 36 — Mixed Practice Exercise

**PDF pages:** 455–462 (printed pages 454–461)

Please translate the following sentences into English.

## Prompts and answers

1. **उसे घर लाया गया ।**
   Romanized: Use ghar laya gaya.  
   **Answer:** He was brought home.

2. **मुझे 2 मिनट दिये गये थे ।**
   Romanized: Mujhe 2 minute diye gaye the.  
   **Answer:** I had been given 2 minutes.

3. **ये लोग तुमसे कब मिले ?**
   Romanized: Ye log tumse kab mile?  
   **Answer:** When did these people meet you?

4. **ये काम कौन करता है ?**
   Romanized: Ye kaam kon karta hai?  
   **Answer:** Who does this work?

5. **मैं अक्सर तुम्हारे घर आता था ।**
   Romanized: Main aksar tumhare ghar aata tha.  
   **Answer:** I used to often come your home.

6. **तुम लोगों को पैसे नहीं दिये जा सकते ।**
   Romanized: Tum logo ko paise nahin diye ja sakte.  
   **Answer:** You people can’t be given money. / Money can’t be given to you people.

7. **उसने बच्चों को बैठने दिया था।**
   Romanized: Usne bachho ko baithane diya tha.  
   **Answer:** He had let children sit.

8. **मैं बहुत देर से उसे ढूंढ रहा हूँ ।**
   Romanized: Main bahut der se use dhoondh raha hoon.  
   **Answer:** I have been searching him for a long?

9. **बाबर को अकबर से मिलने दिया जायेगा ।**
   Romanized: Babar ko Akbar se milne diya jaayega.  
   **Answer:** Babar will be let meet Akbar.

10. **इस देश में दीपावली कब मनाई जाती है ?**
   Romanized: Is desh mein deepawali kab manai jati hai?  
   **Answer:** When is Diwali celebrated in this country?

11. **तुम्हें किसके घर जाना है ?**
   Romanized: Tumhe kiske ghar jana hai?  
   **Answer:** Whose home have you to go?

12. **क्या तुम्हें ऐसा कहना चाहिए था ?**
   Romanized: Kya tumhe aisa kehna chahiye tha?  
   **Answer:** Should you have said so?

13. **राम के भाई के पास क्या नहीं है ?**
   Romanized: Ram ke bhai ke pass kya nahin hai?  
   **Answer:** What does Ram’s brother not have?

14. **तुमसे मिले हुए कई साल हो गये हैं ।**
   Romanized: Tumse mile hue kai saal ho gaye hain.  
   **Answer:** It has been many years having met you.

15. **शायद वो स्कूल गया होगा ।**
   Romanized: Shayad wo school gaya hoga.  
   **Answer:** He might have gone to school.

16. **लोग ऐसे क्यों होते हैं ?**
   Romanized: Log aise kyon hote hain?  
   **Answer:** Why are people so?

17. **उसने ऐसा कभी नहीं किया।**
   Romanized: Usne aisa kabhi nahi kiya.  
   **Answer:** He never did so.

18. **लोगों को घर जाना पड़ा।**
   Romanized: Logo ko ghar jana pada.  
   **Answer:** People had to go home.

19. **तुमसे कोई शादी नहीं करना चाहेगा ।**
   Romanized: Tumse koi shadi nahi karna chahega.  
   **Answer:** Nobody would like to marry you.

20. **मोबाइल में क्या है ?**
   Romanized: Mobile mein kya hai?  
   **Answer:** What is there in mobile?

21. **वो किसी और के सपनों में खोया हुआ था ।**
   Romanized: Vo kisi or ke sapno mein khoya hua tha.  
   **Answer:** He was lost in someone else’s dreams.

22. **हमें पढ़ने क्‍यों नहीं दिया जा रहा है ?**
   Romanized: Hume padhne kyon nahin diya jaa raha hai?  
   **Answer:** Why are we not letting study?

23. **क्या तुम यहाँ सो पाओगे ?**
   Romanized: Kya Tum yahan so paoge?  
   **Answer:** Will you be able to sleep here?

24. **उसके कितने भाई थे ?**
   Romanized: Uske kitne bhai the?  
   **Answer:** How many brothers did he have?

25. **ज़्यादा टी वी देखना आँखों के लिए ठीक नहीं है।**
   Romanized: Zyada T.V dekhna aankho ke liye thik nahin hai.  
   **Answer:** Watching TV a lot is not good for eyes.

26. **वो शायद मुझे याद कर रहा हो ।**
   Romanized: Vo shaayad mujhe yaad kar raha ho.  
   **Answer:** He might be missing me.

27. **उसने आने दिया ।**
   Romanized: Usne aane diya.  
   **Answer:** He let come.

28. **शायद कल ओले पड़ें ।**
   Romanized: Shaayad kal ole pade.  
   **Answer:** It might hail tomorrow.

29. **वो मुझे अक्सर याद आता था।**
   Romanized: Vo mujhe aksar yaad aata tha.  
   **Answer:** He used to often miss me.

30. **राम ने कहा है ।**
   Romanized: Ram ne kaha hai.  
   **Answer:** Ram has said.

31. **बर्गर खाये हुए तुम्हें कितने दिन हो गये हैं ?**
   Romanized: Burger khaye huye tumhe kitne din ho gaye hain?  
   **Answer:** How many days has it been to you having eaten/taken/had burger?

32. **सभी को कुछ दिया जा रहा था ।**
   Romanized: Sabhi ko kuch diya ja raha tha.  
   **Answer:** All were being given something.

33. **भगवान कृष्ण को मारा नहीं जा सकता।**
   Romanized: Bhagwan Krishna ko mara nahin ja sakta.  
   **Answer:** Lord Krishna can’t be killed.

34. **अगर मैं आता तो तुमसे मिलता ।**
   Romanized: Agar mein aata to tumse milta.  
   **Answer:** If I came, I would meet you.

35. **यहाँ बारिश क्यों नहीं होती ?**
   Romanized: Yahaan barish kyon nahin hoti?  
   **Answer:** Why does it not rain here?

36. **मुझे घुसने नहीं दिया जा रहा था।**
   Romanized: Mujhe ghusne nahi diya ja raha tha.  
   **Answer:** I was not being let enter.

37. **वो मेरे आगे खड़ा था।**
   Romanized: Vo mere aage khada tha.  
   **Answer:** He was standing ahead of me.

38. **परसों छुट्टी थी।**
   Romanized: Parso chutti thi.  
   **Answer:** It was holiday day before yesterday.

39. **किस हीरो का भाई दिल्ली में है ?**
   Romanized: Kis hero ka bhai Delhi mein hai?  
   **Answer:** Which actor’s brother is in Delhi?

40. **उसे रोज़ हॉस्पिटल क्‍यों ले जाया जाता था ?**
   Romanized: Use roz Hospital kyo le jaya jata tha?  
   **Answer:** Why did he use to be taken to hospital every day?

41. **ज़्यादा सोचना बेकार है ।**
   Romanized: Zyada sochna bekar hai.  
   **Answer:** Thinking a lot is a waste.

42. **बच्चों को भेजा जाएगा ।**
   Romanized: Bachho ko bheja jayega.  
   **Answer:** Children will be sent.

43. **उसके चेहरे ने मुझे एक आदमी की याद दिला दी जिसे मैं 1985 में मिला था।**
   Romanized: Uske chehre ne mujhe ek aadmi ki yaad dila di jise main 1985 mein mila tha.  
   **Answer:** His face reminded me of a man whom I had met in 1985.

44. **भाई पक्का स्कूल के लिए निकल गया होगा ।**
   Romanized: Bhai pakka school ke liye nikal gaya hoga.  
   **Answer:** Brother must have left for school.

45. **मैंने कहा था कि मैं जाऊँगा ।**
   Romanized: Maine kaha tha, ki main jaoonga.  
   **Answer:** I had said that I would go.

46. **मैं चारों भाईयों में सबसे बड़ा हूँ ।**
   Romanized: Main charo bhaiyo mein sabse bada hoon.  
   **Answer:** I am the eldest among 4 brothers.

47. **वो कब से खेल रहा है ?**
   Romanized: Vo kab se khel raha hai?  
   **Answer:** Since when has he been playing?

48. **हमने उसे दिखाया था।**
   Romanized: Humne use dikhaya tha.  
   **Answer:** We had shown him.

49. **ये किस पेड़ का आम है ।**
   Romanized: Ye kis ped ka Aam hai.  
   **Answer:** Which tree’s mango is it?

50. **राम उन दिनों हमसे मिलता था ।**
   Romanized: Ram un dino humse milta tha.  
   **Answer:** Ram used to meet us those days.

51. **तुम्हें हॉस्पिटल क्‍यों ले जाया गया ?**
   Romanized: Tumhe hospital kyu le jaya gaya?  
   **Answer:** Why were you brought to hospital?

52. **राम को भेजा जाना चाहिए ।**
   Romanized: Ram ko bheja jaana chahiye.  
   **Answer:** Ram should be sent.

53. **वो मेरा क्या लगता है ?**
   Romanized: Vo mera kya lagta hai?  
   **Answer:** What is he to me?

54. **उसे खाना नहीं दिया जायेगा ।**
   Romanized: Use khana nahi diya jaayega.  
   **Answer:** He will not be given the food.

55. **हमें भेजा जा रहा है ।**
   Romanized: Hume bheja jar aha hai.  
   **Answer:** We are being sent.

56. **मैं तुम्हें जाने नहीं देता ।**
   Romanized: Main tumhe jane nahi deta.  
   **Answer:** I don’t let you go.

57. **जीतना उसकी आदत बन गयी है ।**
   Romanized: Jitna uski aadat ban gayi hai.  
   **Answer:** Winning has become his habit.

58. **उसे किसने नहीं देखा ?**
   Romanized: Use kisne nahin dekha?  
   **Answer:** Who didn’t see him?

59. **वो किसके साथ पढ़ता था ?**
   Romanized: Vo kiske sath padhta tha?  
   **Answer:** With whom did he use to study?

60. **मेरे पास किसी का पैन नहीं है ।**
   Romanized: Mere paas kisi ka pain nahin hai?  
   **Answer:** We don’t have anybody’s pen.

61. **मेरा दिल उससे ज़्यादा मजबूत है ।**
   Romanized: Mera Dil usse zyada majboot hai.  
   **Answer:** My heart is stronger than his.

62. **आज ओले नहीं पड़े ।**
   Romanized: Aaj ole nahin pade.  
   **Answer:** It didn’t hail today.

63. **तुमसे मिले हुए मुझे कई साल हो गये है ।**
   Romanized: Tumse mile hue mujhe kai saal ho gaye hai.  
   **Answer:** It has been many years having met you.

64. **मुझे स्कूल पहुँचने में 10 मिनट लगते हैं।**
   Romanized: Mujhe school pahuchne me 10 mins lgte h.  
   **Answer:** It takes me 10 minutes to reach school.

65. **25 साल लगे।**
   Romanized: 25 saal gaye.  
   **Answer:** It took 25 years.

66. **ये बच्चा किस औरत का है ?**
   Romanized: Ye bacha kis Aurat ka hai?  
   **Answer:** Of which woman is this child?

67. **क्या ये उस लड़की का है ?**
   Romanized: Kya ye us ladki ka hai?  
   **Answer:** Is it of that girl? / Is it that girl’s?

68. **वो मुझे कभी हारने नहीं देगा ।**
   Romanized: Vo mujhe kabhi haarne nahin dega.  
   **Answer:** He will never let me lose.

69. **कितने दिन लगे ?**
   Romanized: Kitne din lage?  
   **Answer:** How many days did it take?

70. **वहाँ कौन छिपा हुआ है ?**
   Romanized: Vahan kon chipa hua hai?  
   **Answer:** Who is hidden there?

71. **किस लड़के की बहन वहाँ खड़ी थी ?**
   Romanized: Kis ladke ki behan wahan khadi thi?  
   **Answer:** Which boy’s sister was standing there?

72. **मैं कब से जगा हुआ हूँ?**
   Romanized: Main kab se jaga hua hoon.  
   **Answer:** Since when/From when am I awake?

73. **शायद उसने देखा होगा ?**
   Romanized: Sayad usne dekha hoga?  
   **Answer:** He might/may have seen.

74. **मुझे कहा गया था कि मुझे अमेरिका भेजा जाएगा ।**
   Romanized: Mujhe kaha gaya tha ki mujhe America bheja jaayega.  
   **Answer:** I was said that I will be sent to America.

75. **ये कब हुआ ?**
   Romanized: Ye kab hua?  
   **Answer:** When did it happen?

76. **तुम मुझसे कम पैसे वाले हो ।**
   Romanized: Tum mujhse kam paise wale ho.  
   **Answer:** You are poorer than I.

77. **हमें सुबह से पढ़ाया जा रहा है ।**
   Romanized: Hume subah se padhaya ja raha hai.  
   **Answer:** We are being taught since morning.

78. **वो काफी देर से सोया हुआ है ।**
   Romanized: Vo kafi der se soya hua hai.  
   **Answer:** He is asleep for a long.

79. **उसे भेजा जाना चाहिए ।**
   Romanized: Use bheja jana chahiye.  
   **Answer:** He should be sent.

80. **मैं कल से यहाँ बैठा हूँ ।**
   Romanized: Main kal se yahan baitha hoon.  
   **Answer:** I have been sitting here since yesterday.

81. **ये मोबाइल तुम्हारे मोबाइल से ज़्यादा पुराना है।**
   Romanized: Ye Mobile tumhare Mobile se zyada purana hai.  
   **Answer:** This mobile is older than your mobile.

82. **उसके पास किसी और का पैन था |**
   Romanized: Uske paas kisi or ka pen tha.  
   **Answer:** He had somebody else’s pen.

83. **क्या मैं उससे ज़्यादा बुरा हूँ ?**
   Romanized: Kya main usse zyada bura hoon.  
   **Answer:** Am I worse than he?

84. **बारिश कितने बजे हुई ?**
   Romanized: Barish kitne baje hui?  
   **Answer:** At what time did it rain?

85. **क्या तुम्हें नहीं जाना ?**
   Romanized: Kya tumhe nahi jaana?  
   **Answer:** Have you not to go?

86. **क्या पता, उसने कहा हो ।**
   Romanized: Kya pata, usne kaha ho?  
   **Answer:** He might/may have said.

87. **सरकार हमें विद्रोह क्‍यों नहीं करने देती ?**
   Romanized: Sarkar hume vidroh kyon nahi karne deti?  
   **Answer:** Why does Government not let us protest?

88. **मुझे चैन से जीने दो ।**
   Romanized: Mujhe chain se jeena do.  
   **Answer:** Let me live peacefully.

89. **उसका कुछ नहीं है, सब मेरा है ।**
   Romanized: Uska kuch nahin hai, sab mera hai.  
   **Answer:** His is nothing, all is mine.

90. **मेरी है ये किताब ?**
   Romanized: Meri hai ye kitab?  
   **Answer:** Mine is this book.

91. **बाहर ओले पड़ रहे हैं।**
   Romanized: Bahar ole pad rahe hai.  
   **Answer:** It’s hailing outside.

92. **ये कुछ और नहीं मेरा प्यार है।**
   Romanized: Ye kuch or nahi mera pyaar hai.  
   **Answer:** It’s nothing but my love.

93. **माँ ने हमें जन्म दिया।**
   Romanized: Maa ne hume janam diya.  
   **Answer:** Mother bred us.

94. **ये रोड कहाँ जाती है?**
   Romanized: Ye road kahan jaati hai?  
   **Answer:** Where does this road lead to?

95. **वो पैसा मेरे किसी काम का नहीं।**
   Romanized: Vo Paisa mere kisi kaam ka nahin.  
   **Answer:** That money is of no use to me.

96. **राम यहीं पर था।**
   Romanized: Ram yahin par tha.  
   **Answer:** Ram was very much here.

97. **आखिरकार शादी के शुभ दिन की घोषणा हो चुकी है।**
   Romanized: Aakhirkar shaadi ke shubh din ki ghoshna ho chuki hai.  
   **Answer:** Finally, auspicious date of marriage is announced.

98. **ध्यान रखना तुम्हें मेरे घर आना है।**
   Romanized: Dhyaan rakhna tumhe mere ghar aana hai.  
   **Answer:** Keep in mind, you have to come to my home

99. **मैं कोई कसर नहीं छोड़ूँगा।**
   Romanized: Main koi kasar nahin chodunga.  
   **Answer:** I’ll not leave any stone unturned.

100. **मुझे कई साल लगे उसे भूलने में।**
   Romanized: Mujhe kai saal lage use bhulane mein.  
   **Answer:** It took me many years to forget her.

101. **चाहे कोई कुछ भी कहे मैं तुम्हारा साथ दूँगा।**
   Romanized: Chahe koi kuch bhi kahe main tumhara sath dunga.  
   **Answer:** Irrespective of what anyone says, I’ll stand by you.

102. **दहेज प्रथा एक अभिशाप है।**
   Romanized: Dahej pratha ek abhishaap hai.  
   **Answer:** Dowry system is a malediction.

103. **महँगाई भ्रष्टाचार को जन्म देती है।**
   Romanized: Mahangai bhrashtachar ko janam deti hai.  
   **Answer:** Inflation breeds corruption.

104. **उसने साफ मना कर दिया।**
   Romanized: Usne saaf mana kar diya.  
   **Answer:** He refused a point blank.

105. **तुम क्या शर्त रखना चाहते हो?**
   Romanized: Tum kya shart rakhna chahte ho?  
   **Answer:** What condition do you want to lie?

106. **हिन्दू मरे हुए को जलाते हैं और मुस्लिम दफनाते।**
   Romanized: Hindu mare hue ko jalate hain aur muslim dafnate.  
   **Answer:** Hindus burn the dead bodies and Muslims bury.

107. **मैं अपनी सफलता का श्रेय तुम्हें देता हूँ।**
   Romanized: Main apni safalta ka shrey tumhe deta hoon.  
   **Answer:** I ascribe my success to you.

108. **आग बुझा दो ऐसा न हो कि फैल जाए।**
   Romanized: Aag bhuja do esa na ho ki fail jaaye.  
   **Answer:** Put out the fire lest it should spread out.

109. **उस षड्यंत्र का पर्दाफाश मैं करूँगा।**
   Romanized: Us sadyantar ka pardafash main krunga.  
   **Answer:** I’ll unearth that conspiracy.

110. **आसपास रहना मैं बस अभी आ रहा हूँ।**
   Romanized: Aas Paas rehna main bus abhi aa raha hu.  
   **Answer:** Stick around, I am just coming.

111. **सचिन का आउट होना एक जबरदस्त झटका है।**
   Romanized: Sachin ka out hona ek Jabardast jhatka hai.  
   **Answer:** Sachin’s departure is big blow.

112. **अच्छा हुआ तुम आ गये, मैं बस अभी निकल गया होता।**
   Romanized: Acha hua tum aa gaye, main bus abhi nikal gaya hota.  
   **Answer:** Thank God you dropped in, I would have just left.

113. **मुझे भोला भाला समझने की गलती मत कर पछताएगा।**
   Romanized: Mujhe bhola bhala samajhne ki galti mat kar pachtayega.  
   **Answer:** Don’t mistake me for a credulous, you would regret.

114. **एक कहावत है, “नफरत पाप से करो पापी से नहीं"।**
   Romanized: Ek kahawat hai. ‘’ Nafrat paap se karo papi se nahi.  
   **Answer:** There is a saying, “Hate sin, not a sinner.”

115. **जिम्मेदारी से भागना लगता है, तुम्हारे खून में है।**
   Romanized: Jimmedari se bhagna lagta hai tumhare khoon mein hai.  
   **Answer:** To shirk responsibility seems to be in your blood.

116. **मानो सदियाँ बीत गई हो, हमें मिले हुए।**
   Romanized: Mano sadiya beet gayi ho, hume mile huye.  
   **Answer:** As if centuries have passed since we met.

117. **जितना मैं सोचूंगा, उतना ही पागल हो जाऊँगा।**
   Romanized: Jitna main sochunga, utna hi pagal ho jaaonga.  
   **Answer:** Deeper I think, more I’ll go mad.

118. **मैंने जानबूझकर कभी तुम्हारा दिल नहीं दुखाया।**
   Romanized: Maine janbujhkar kabhi tumhara dil nahi dukhaya.  
   **Answer:** I never hurt you unknowingly.

## Source notes

All 118 Hindi prompts and same-number English answer-key entries were checked against the scans on PDF pages 455–462. Scan-confirmed OCR errors were corrected in Hindi items 17, 18, 25, 29, 38, 43, 48, 64, 65, 81, 94, and 109; answer 114’s quotation marks were restored to match the scan. The printed English answer-key wording, including awkward source grammar, is otherwise preserved. No unreadable text was found.
