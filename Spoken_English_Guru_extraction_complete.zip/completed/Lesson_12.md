# Lesson 12 — Should + Be, Have & Been

**PDF pages:** 128–138 (printed pages 127–137)

**Instruction:** Translate the following sentences into English.

## Bilingual prompts and printed English answers

### 1. तुम्हें ऐसा नहीं कहना चाहिए।
**Romanized:** (Tumhe aisa nahi kehna chahiye.)
**English answer:** You should not say so.

### 2. लोगों को निकल जाना चाहिए।
**Romanized:** (Logon ko nikal jana chahiye.)
**English answer:** People should leave.

### 3. तुम्हें वहाँ जाना चाहिए था।
**Romanized:** (Tumhe wahan jana chahiye tha.)
**English answer:** You should have gone there.

### 4. तुम्हें मुझे याद दिलाना चाहिए था।
**Romanized:** (Tumhe mujhe yaad dilana chahiye tha.)
**English answer:** You should have reminded me.

### 5. तुम्हें कम से कम शादी में तो जाना चाहिए था।
**Romanized:** (Tumhe kam se kam shaadi mein to jana chahiye tha.)
**English answer:** You should have at least attended the marriage.

### 6. मुझे जाना चाहिए था।
**Romanized:** (Mujhe jana chahiye tha.)
**English answer:** I should have gone.

### 7. राम को उससे कभी नहीं मिलना चाहिए।
**Romanized:** (Ram ko usse kabhi nahi milna chahiye.)
**English answer:** Ram should never meet him.

### 8. तुम्हें कम से कम वहाँ जाना चाहिए था।
**Romanized:** (Tumhe kam se kam wahan jana chahiye tha.)
**English answer:** You should have at least gone there.

### 9. आज मुझे शॉपिंग के लिए जाना चाहिए था।
**Romanized:** (Aaj mujhe shopping ke liye jana chahiye tha.)
**English answer:** I should have gone for shopping today.

### 10. तुम्हें कम से कम आज तो काम करना चाहिए था।
**Romanized:** (Tumhe kam se kam aaj to kam karna chahiye tha.)
**English answer:** You should have worked at least today.

### 11. राकेश को सोचना चाहिए था।
**Romanized:** (Rakesh ko sochna chahiye tha.)
**English answer:** Rakesh should have thought.

### 12. तुम्हारा क्या ख्याल है, मुझे वहाँ जाना चाहिए?
**Romanized:** (Tumhara kya khyal hai, mujhe wahan jana chahiye?)
**English answer:** What do you think, should I go there?

### 13. तुम्हें उसकी हालत के बारे में सोचना चाहिए था।
**Romanized:** (Tumhe uski halat ke bare mein sochna chahiye tha.)
**English answer:** You should have thought about his condition.

### 14. वहाँ अच्छा मौसम होना चाहिए।
**Romanized:** (Wahan accha mausam hona chahiye.)
**English answer:** There should be a good weather.

### 15. वो अब तक निकल गये होंगे।
**Romanized:** (Wo ab tak nikal gaye honge.)
**English answer:** They should have left by now.

### 16. उसे अब जाना चाहिए।
**Romanized:** (Use ab jana chahiye.)
**English answer:** He should leave/go now.

### 17. हमें अपने बड़ों की इज्जत करनी चाहिए।
**Romanized:** (Hame apne bado ki izzat karni chahiye.)
**English answer:** We should respect our elders.

### 18. तुम्हें सुबह टहलने जाना चाहिए।
**Romanized:** (Tumhe subah tahalne jana chahiye.)
**English answer:** You should go for a morning walk.

### 19. तुम्हें गाली नहीं देनी चाहिए।
**Romanized:** (Tumhe gaali nahi deni chahiye.)
**English answer:** You should not abuse.

### 20. मुझे उस लड़की को प्रपोज कर देना चाहिए था।
**Romanized:** (Mujhe us ladki ko propose kar dena chahiye tha.)
**English answer:** I should have proposed that girl.

### 21. हमें झूठ नहीं बोलना चाहिए।
**Romanized:** (Hame jhoot nahi bolna chahiye.)
**English answer:** We should not tell a lie.

### 22. उसे चापलूसी नहीं करनी चाहिए।
**Romanized:** (Use chaplusi nahi karni chahiye.)
**English answer:** He should not flatter.

### 23. हमें दूसरों की निंदा नहीं करनी चाहिए।
**Romanized:** (Hame dusro ki ninda nahi karni chahiye.)
**English answer:** We should not condemn others.

### 24. बच्चों को ज़्यादा मोबाइल का इस्तेमाल नहीं करना चाहिए।
**Romanized:** (Baccho ko zyada mobile ka istemal nahi karna chahiye.)
**English answer:** Kids should not use mobile a lot.

### 25. उसे अपने माता पिता की आज्ञा का पालन करना चाहिए।
**Romanized:** (Use apne mata pita ki aagya ka palan karna chahiye.)
**English answer:** He should obey his parents.

### 26. क्या हमें रात को देर से सोना चाहिए?
**Romanized:** (Kya hame raat ko der se sona chahiye?)
**English answer:** Should we sleep late at night?

### 27. तुम्हें मेरी बात मान लेनी चाहिए थी।
**Romanized:** (Tumhe meri baat man leni chahiye thi.)
**English answer:** You should have listened to me.

### 28. उन्हें कुछ पैसे बचा लेने चाहिए थे।
**Romanized:** (Unhe kuch paise bacha lene chahiye the.)
**English answer:** They should have saved some money.

### 29. क्या उसके भाई को वहाँ जाना चाहिए?
**Romanized:** (Kya uske bhai ko wahan jana chahiye?)
**English answer:** Should his brother go there?

### 30. तुम्हें इतना ज़्यादा नहीं सोचना चाहिए।
**Romanized:** (Tumhe itna zyada nahi sochna chahiye.)
**English answer:** You should not think so much.

### 31. उसे ऐसा नहीं सोचना चाहिए।
**Romanized:** (Use aisa nahi sochna chahiye.)
**English answer:** He should not think so.

### 32. राम को उनकी इज्जत करनी चाहिए।
**Romanized:** (Ram ko unki izzat karni chahiye.)
**English answer:** Ram should respect them.

### 33. मुझे जल्दी उठना चाहिए।
**Romanized:** (Mujhe jaldi uthna chahiye.)
**English answer:** I should wake up early.

### 34. तुम्हें धूम्रपान नहीं करना चाहिए।
**Romanized:** (Tumhe dhumrapan nahi karna chahiye.)
**English answer:** You should not smoke.

### 35. हमें दूसरों का मज़ाक क्यों नहीं उड़ाना चाहिए?
**Romanized:** (Hame dusro ka mazak kyon nahi udana chahiye?)
**English answer:** Why should we not make fun of others?

### 36. आपको अंग्रेज़ी सीखनी चाहिए।
**Romanized:** (Aapko angreji seekhni chahiye.)
**English answer:** You should learn English.

### 37. क्या मुझे उससे पैसे उधार लेने चाहिए?
**Romanized:** (Kya mujhe usse paise udhar lene chahiye?)
**English answer:** Should I borrow money from him?

### 38. हमें ट्रैफिक के नियमों का उल्लंघन नहीं करना चाहिए।
**Romanized:** (Hame traffic ke niyamo ka ullanghan nahi karna chahiye.)
**English answer:** We should not violate the traffic rules.

### 39. तुम्हें समय बरबाद नहीं करना चाहिए।
**Romanized:** (Tumhe samay barbad nahi karna chahiye.)
**English answer:** You should not waste time.

### 40. तुम्हें आराम करना चाहिए।
**Romanized:** (Tumhe aaram karna chahiye.)
**English answer:** You should take rest.

### 41. टीचर को तुम्हें एक मौका देना चाहिए।
**Romanized:** (Teacher ko tumhe ek mauka dena chahiye.)
**English answer:** Teacher should give you a chance.

### 42. बच्चों को फूल नहीं तोड़ना चाहिए।
**Romanized:** (Baccho ko fool nahi todna chahiye.)
**English answer:** Children should not pluck the flowers.

### 43. हर किसी को इस ज़िंदगी की अहमियत समझनी चाहिए।
**Romanized:** (Har kisi ko is zindagi ki ahmiyat samajhni chahiye.)
**English answer:** Everyone should understand the importance of this life.

### 44. तुम्हें उसे ऐसे नहीं घूरना चाहिए।
**Romanized:** (Tumhe use aise nahi ghurna chahiye.)
**English answer:** You should not stare at her like this.

### 45. हमें इस बात को गंभीरता से लेना चाहिए।
**Romanized:** (Hame is baat ko gambheerta se lena chahiye.)
**English answer:** We should take this matter seriously.

### 46. उन लड़कों को उन लड़कियों को नहीं छेड़ना चाहिए।
**Romanized:** (Un ladko ko un ladkiyo ko nahi chedna chahiye.)
**English answer:** Those boys should not tease those girls.

### 47. अभिभावकों को अपने बच्चों के अन्दर जिम्मेदारी की भावना भरने की कोशिश करनी चाहिए।
**Romanized:** (Abhibhavako ko apne baccho ke andar zimmedari ki bhavana bharne ki koshish karni chahiye.)
**English answer:** Parents should try to inculcate a sense of responsibility in their children.

### 48. तुम्हें पहले सोचना चाहिए।
**Romanized:** (Tumhe pahle sochna chahiye.)
**English answer:** You should think first.

### 49. संदीप को जाना चाहिए।
**Romanized:** (Sandeep ko jana chahiye.)
**English answer:** Sandeep should go.

### 50. संदीप को नहीं जाना चाहिए।
**Romanized:** (Sandeep ko nahi jana chahiye.)
**English answer:** Sandeep should not go.

### 51. क्या संदीप को जाना चाहिए?
**Romanized:** (Kya sandeep ko jana chahiye?)
**English answer:** Should Sandeep go?

### 52. मुझे कब जाना चाहिए?
**Romanized:** (Mujhe kab jana chahiye?)
**English answer:** When should I go?

### 53. उसे किसके साथ पढ़ना चाहिए?
**Romanized:** (Use kiske saath padhna chahiye?)
**English answer:** With whom should he study?

### 54. हमें कहाँ नहीं खेलना चाहिए?
**Romanized:** (Hame kahan nahi khelna chahiye?)
**English answer:** Where should we not play?

### 55. उसे पूछना चाहिए था।
**Romanized:** (Use puchna chahiye tha.)
**English answer:** He should have asked.

### 56. उसे पूछना नहीं चाहिए था।
**Romanized:** (Use puchna nahi chahiye tha.)
**English answer:** He should not have asked.

### 57. क्या उसे पूछना चाहिए था?
**Romanized:** (Kya use puchna chahiye tha?)
**English answer:** Should he have asked?

### 58. उसे क्या पूछना चाहिए था?
**Romanized:** (Use kya puchna chahiye tha?)
**English answer:** What should he have asked?

### 59. उसे क्यों नहीं पढ़ना चाहिए था?
**Romanized:** (Use kyo nahi padhna chahiye tha?)
**English answer:** Why should he not have studied?

### 60. राम को कहाँ नहीं खेलना चाहिए था?
**Romanized:** (Ram ko kaha nahi khelna chahiye tha?)
**English answer:** Where shouldn’t Ram have played?

### 61. राम को खाना नहीं बनाना चाहिए।
**Romanized:** (Ram ko khana nahi banana chahiye.)
**English answer:** Ram shouldn’t cook the food.

### 62. यशी को किसके साथ खेलना चाहिए?
**Romanized:** (Yashi ko kiske saath khelna chahiye?)
**English answer:** With whom should Yashi play?

### 63. मुझे ऐसा सोचना तक नहीं चाहिए।
**Romanized:** (Mujhe aisa sochna tak nahi chahiye.)
**English answer:** We shouldn’t even think so.

### 64. मुझे ऐसा सोचना नहीं चाहिए।
**Romanized:** (Mujhe aisa sochna nahi chahiye.)
**English answer:** I shouldn’t think so.

### 65. तुम्हें नल खोलना चाहिए था।
**Romanized:** (Tumhe nal kholna chahiye tha.)
**English answer:** You should’ve turned the tap on.

### 66. तुम्हें मुझे फोन करना चाहिए।
**Romanized:** (Tumhe mujhe phone karna chahiye.)
**English answer:** You should call/phone me.

### 67. हमें कब तक ऑफिस में रहना चाहिए?
**Romanized:** (Hame kab tak office mein rahna chahiye?)
**English answer:** Until when should we stay at work? / How long should we stay at work?

### 68. मुझे पढ़ना चाहिए था।
**Romanized:** (Mujhe padhna chahiye tha.)
**English answer:** I should have studied.

### 69. तुम्हें वहाँ नहीं जाना चाहिए था।
**Romanized:** (Tumhe wahan nahi jana chahiye tha.)
**English answer:** You should not have gone there.

### 70. उसे ऐसा नहीं करना चाहिए था।
**Romanized:** (Use aisa nahi karna chahiye tha.)
**English answer:** He should not have done this.

### 71. तुम्हें वहाँ नौकरी छोड़ देनी चाहिए थी।
**Romanized:** (Tumhe wahan naukari chhod deni chahiye thi.)
**English answer:** You should have quit the job there.

### 72. उसके पिताजी को नौकरी नहीं छोड़नी चाहिए थी।
**Romanized:** (Uske pitaji ko naukri nahi chhodni chahiye thi.)
**English answer:** His father should not have left the job.

### 73. हमें इंग्लिश सीखनी चाहिए थी।
**Romanized:** (Hame English seekhni chahiye thi.)
**English answer:** We should have learned English.

### 74. मुझे नाश्ता कर लेना चाहिए था।
**Romanized:** (Mujhe nashta kar lena chahiye tha.)
**English answer:** I should have taken the breakfast. / I should have eaten the breakfast. / I should have had the breakfast.

### 75. मुझे आज स्कूल नहीं जाना चाहिए था।
**Romanized:** (Mujhe aaj school nahi jana chahiye tha.)
**English answer:** I should not have gone to school today.

### 76. क्या उन्हें पुलिस को रिश्वत देनी चाहिए थी?
**Romanized:** (Kya unhe police ko rishwat deni chahiye thi?)
**English answer:** Should they have given bribe to the police?

### 77. तुम्हें बिना सोचे समझे फैसला नहीं लेना चाहिए था।
**Romanized:** (Tumhe bina soche samjhe faisla nahi lena chahiye tha.)
**English answer:** You should not have taken a leap in the dark.

### 78. उसे छत से नहीं कूदना चाहिए था।
**Romanized:** (Use chhat se nahi kudna chahiye tha.)
**English answer:** He should not have jumped off the terrace.

### 79. मुझे उसे 500 रुपये उधार देने चाहिए थे।
**Romanized:** (Mujhe use Rs. 500 udhar dene chahie the.)
**English answer:** I should have lent him Rs. 500.

### 80. तुम्हें मौका नहीं गँवाना चाहिए था।
**Romanized:** (Tumhe mauka nahi gawana chahiye tha.)
**English answer:** You should not have missed the chance.

### 81. मुझे सुबह जल्दी उठना चाहिए था।
**Romanized:** (Mujhe subah jaldi uthna chahiye tha.)
**English answer:** I should have woken up early in the morning.

### 82. उसे मीटिंग में उपस्थित होना चाहिए था।
**Romanized:** (Use meeting mein upasthit hona chahiye tha.)
**English answer:** He should have attended the meeting.

### 83. हमें उस समय गप्पे नहीं मारने चाहिए थे।
**Romanized:** (Hame us samay gaappe nahi marne chahiye the.)
**English answer:** We should not have gossiped that time.

### 84. तुम्हें ट्रेन से आना चाहिए था।
**Romanized:** (Tumhe train se aana chahiye tha.)
**English answer:** You should have come by train.

### 85. बच्चों को बस से नहीं आना चाहिए था।
**Romanized:** (Bacchon ko bus se nahi aana chahiye tha.)
**English answer:** The children should not have come by bus.

### 86. तुम्हें मुझे पहले बताना चाहिए था।
**Romanized:** (Tumhe mujhe pahle batana chahiye tha.)
**English answer:** You should have told me earlier.

### 87. मेरे पास कार होनी चाहिए थी।
**Romanized:** (Mere paas car honi chahiye thi.)
**English answer:** I should have had a car.

### 88. उसे हमें सूचना दे देनी चाहिए।
**Romanized:** (Use hame soochna de deni chahiye.)
**English answer:** He should inform us.

### 89. इस केस की फिर से जाँच होनी चाहिए।
**Romanized:** (Is case ki phir se jaanch honi chahiye.)
**English answer:** This case should be scrutinized again.

### 90. उसे फाँसी नहीं होनी चाहिए क्योंकि वह निर्दोष है।
**Romanized:** (Use phansi nahi honi chahiye kyonki wah nirdosh hai.)
**English answer:** He should not be hanged because he is innocent.

### 91. सभी बदमाशों को जेल में डाल देना चाहिए।
**Romanized:** (Sabhi badmasho ko jail mein dal dena chahiye.)
**English answer:** All the miscreants should be sent behind the bars.

### 92. मुझे लगता है उसे इस बारे में जितना जल्दी हो सके बता देना चाहिए।
**Romanized:** (Mujhe lagta hai use is bare mein jitna jaldi ho sake bata dena chahiye.)
**English answer:** I think he should be informed about this as soon as possible.

### 93. उसकी पिटाई होनी चाहिए।
**Romanized:** (Uski pitai honi chahiye.)
**English answer:** He should be beaten.

### 94. भ्रष्ट अफसरों को बर्खास्त कर देना चाहिए।
**Romanized:** (Bhrasht officers ko barkhast kar dena chahiye.)
**English answer:** The corrupt officers should be fired/ kicked out.

### 95. हमारे देश में तम्बाकू बंद होना चाहिए।
**Romanized:** (Hamare desh mein tambaku band hona chahiye.)
**English answer:** Tobacco should be banned in our country.

### 96. पूरे देश में खेलों को बढ़ावा देना चाहिए।
**Romanized:** (Pure desh mein khelo ko badhava dena chahiye.)
**English answer:** Sports should be promoted nationwide.

### 97. दिवाली के अवसर पर बल्ब की जगह मोमबत्तियां या दिये जलाने चाहिए।
**Romanized:** (Diwali ke avsar par bulb ki jagah mombattiyaa ya diye jalane chahiye.)
**English answer:** On the occasion of Diwali, candles or diyas should be lighted instead of bulbs.

### 98. बिना सबूत दूसरों पर दोष नहीं लगाना चाहिए।
**Romanized:** (Bina saboot dusro par dosh nahi lagana chahiye.)
**English answer:** One shouldn’t blame others without any proof or evidence.

### 99. उसे नौकरी से नहीं निकाला जाना चाहिए था।
**Romanized:** (Use naukri se ni nikala jana chahie tha.)
**English answer:** He shouldn’t have been fired from the job.

### 100. हमें अदिति को उनके साथ नहीं भेजना चाहिए था।
**Romanized:** (Hame Aditi ko unke sath ni bhejna chahiye tha.)
**English answer:** We shouldn’t have sent Aditi with them.

### 101. यह काम समय से पहले पूरा किया जाना चाहिए था।
**Romanized:** (Yah kam samay se pahle poora kiya jana chahiye tha.)
**English answer:** This work should’ve been completed/ finished before time.

### 102. मुझे आपको भेजना चाहिए।
**Romanized:** (Mujhe apko bhejna chahiye.)
**English answer:** I should send you.

### 103. आपको घर आना चाहिए।
**Romanized:** (Apko ghar aana chahiye.)
**English answer:** You should come home

### 104. हमें एक दूसरे से बात करनी चाहिए।
**Romanized:** (Hamein ek dusre se bat karni chahiye.)
**English answer:** We should talk to each other.

### 105. आपको उसके साथ खेलना चाहिए।
**Romanized:** (Apko uske sath khelna chahiye.)
**English answer:** You should play with him.

### 106. वो इस समय घर पर होना चाहिए।
**Romanized:** (Wo iss Samay ghar par hona chahiye.)
**English answer:** He should be at home right now.

### 107. मुझे आपके साथ यहाँ नहीं होना चाहिए।
**Romanized:** (Mujhe apke sath yahan nahi hona chahiye.)
**English answer:** I shouldn’t be here with you.

### 108. आपको स्वार्थी नहीं होना चाहिए।
**Romanized:** (Apko swarthi nahi hona chahiye.)
**English answer:** You shouldn’t be selfish.

### 109. हमें घमंडी नहीं होना चाहिए।
**Romanized:** (Hamain ghamandi nahi hona chahiye.)
**English answer:** We shouldn’t be arrogant.

### 110. उस लड़की को स्कूल में होना चाहिए।
**Romanized:** (Uss ladki ko school mein hona chahiye.)
**English answer:** That girl Should be in school.

### 111. उसे तुरंत जेल भेज देना चाहिए।
**Romanized:** (Use turant jail bhej dena chahiye.)
**English answer:** He should be sent to jail immediately.

### 112. हमें इस बारे में बताया जाना चाहिए।
**Romanized:** (Hamein iss bare mein bataya jana chahiye.)
**English answer:** We should be told about this.

### 113. उसे इस काम के लिए अच्छी सैलरी दी जानी चाहिए।
**Romanized:** (Use iss kaam ke liye acchi salary di jani chahiye.)
**English answer:** He should be given good salary for this work.

### 114. छोटे बच्चों को मोबाइल नहीं दिया जाना चाहिए।
**Romanized:** (Chote baccho ko mobile nahi diya jana chahiye.)
**English answer:** Small kids shouldn’t be given mobiles.

### 115. उसके पास कुछ पैसे होने चाहिए।
**Romanized:** (Uske pas kuch paise hone chahiye.)
**English answer:** He should have some money.

### 116. आपके पास कम से कम तीन पैन होने चाहिए।
**Romanized:** (Apke pas kam se kam teen pen hone chahiye.)
**English answer:** You should have at least three pens.

### 117. हम सभी के पास बराबर मौके होने चाहिए, साबित करने के लिए कि हम में से सच में बैस्ट कौन है।
**Romanized:** (Hum sabhi ke pas brabar mauke hone chahiye sabit kaarne ke liye ki ham me se sach me best kaun hai.)
**English answer:** We’ll should’ve equal opportunities to prove, who among us is really the best.

### 118. उसे उस दिन मुझसे मिलना चाहिए था।
**Romanized:** (Use uss din mujhse milna chahiye tha.)
**English answer:** He should have met me that day.

### 119. मुझे आपको इस बारे में नहीं बताना चाहिए था, कि वहाँ क्या चल रहा है।
**Romanized:** (Mujhe aapko iss bare mein nahi batana chahiye tha ki wahan kya chal raha hai.)
**English answer:** I shouldn’t told you about what’s going on there.

### 120. उन्हें मुझसे भी पूछना चाहिए था।
**Romanized:** (Unhein mujhse bhi puchna chahiye tha.)
**English answer:** They should have asked me as well.

### 121. वो हमारे साथ यहाँ होना चाहिए था।
**Romanized:** (Wo hmare sath yahan hona chahiye tha.)
**English answer:** He should have been here with us.

### 122. वो एक डॉक्टर है, उसे हॉस्पिटल में होना चाहिए था।
**Romanized:** (Wo ek doctor hai use hospital mein hona chahiye tha.)
**English answer:** He is a doctor, he should have been in hospital that day.

### 123. शाहरुख़ को 7 बजे जिम में होना चाहिए था।
**Romanized:** (Shahrukh ko 7 baje gym mein hona chahiye tha.)
**English answer:** Shahrukh should have been in gym at 7 o’clock.

### 124. आपको यहाँ होना चाहिए था, जब मुझे आपकी ज़रूरत थी।
**Romanized:** (Apko yahan hona chahiye tha jab mujhe apki zarurat thi.)
**English answer:** You should have been here, when I needed you.

### 125. उसे जेल भेज दिया जाना चाहिए था।
**Romanized:** (Use jail bhej diya jana chahiye tha.)
**English answer:** He should have been sent to jail.

### 126. उन्हें इस बारे में पूछा जाना चाहिए था।
**Romanized:** (Unhein is bare mein pucha jana chahiye tha.)
**English answer:** They should have been asked about it.

### 127. आपको मोबाइल नहीं दिया जाना चाहिए था।
**Romanized:** (Apko mobile nhi diya jana chahiye tha.)
**English answer:** You shouldn’t have been given the mobile.

### 128. हमें कल छुट्टी दे देनी चाहिए थी।
**Romanized:** (Humein kal chutti de deni chahiye thi.)
**English answer:** We should have been given an off yesterday.

### 129. उसके पास एक कार होनी चाहिए थी।
**Romanized:** (Uske paas ek car honi chahiye thi.)
**English answer:** He Should have had a car.

### 130. मेरे पास उस दिन एक लैपटॉप होना चाहिए था, तब मैं आपकी मदद कर पाता।
**Romanized:** (Mere pas uss din ek laptop hona chahiye tha, tab mai apki madad kar pata.)
**English answer:** I should have had a laptop that day, I could have helped you then.

### 131. हमारे पास इतने बेहतरीन घर को खरीदने के लिए पर्याप्त पैसे होने चाहिए थे।
**Romanized:** (Humare pas itne behtreen ghar ko kharidne ke liye paryapt paise hone chahiye the.)
**English answer:** We should have had enough money to buy such a luxurious house.

### 132. आपको वहाँ जाना ही चाहिए।
**Romanized:** (Apko wahan jana hi chahiye.)
**English answer:** You should have to go there.

### 133. हमें एक दूसरे से बात करनी ही चाहिए।
**Romanized:** (Hamein ek dusre se bat karni hi chahiye.)
**English answer:** You should have to talk to each other.

### 134. उन्हें इस बारे में कुछ तो करना ही चाहिए।
**Romanized:** (Unhe is bare mein kuch to karna hi chahiye.)
**English answer:** They should have to do something about it.

### 135. मुझे अपने भाई को पढ़ाना ही चाहिए, वरना वो एग्जाम में फेल हो सकता है।
**Romanized:** (Mujhe apne bhai ko padhana hi chahiye warna wo exam mein fail ho sakta hai.)
**English answer:** I should have to teach my brother; or else he might fail the exam.

### 136. मुझे उसे पढ़ाना ही चाहिए था, देखो वह फेल हो गया।
**Romanized:** (Mujhe use padhana hi chahiye tha, dekho wah fail ho gaya.)
**English answer:** I Should have had to teach him; see, he failed.

### 137. उन्हें ये मुद्दा अपने बॉस के साथ विचार-विमर्श करना ही चाहिए था।
**Romanized:** (Unhe ye mudda apne boss ke sath vichar vimarsh karna hi chahiye tha.)
**English answer:** They should have had to discuss this matter with their boss.

### 138. आपको एक लैपटॉप खरीदना ही चाहिए था।
**Romanized:** (Apko ek laptop kharidna hi chahiye tha.)
**English answer:** You should have had to buy a laptop.

### 139. अगर आप कॉल सेंटर ज्वाइन करना चाहते हैं, तो आपके पास अच्छी कम्युनिकेशन स्किल्स इंग्लिश में होनी चाहिए।
**Romanized:** (Agar aap call center join karna chahte hai to apke pass achi communication skills english me honi chahiye.)
**English answer:** If you wanna join a call center, you should have to have good communication skills in English.

### 140. हमारे पास ये किताब होनी ही चाहिए, अगर हम इंग्लिश ग्रामर डिटैल्स में सीखना चाहते है तो।
**Romanized:** (Humare pass ye kitab honi hi chahiye agar ham English grammar details me sikhna chahte hai to.)
**English answer:** We should’ve to have this book if we wanna learn English grammar in details.

### 141. उसके पास कम से कम 20 लाख होने ही चाहिए, हमारे इलाके में 100 गज जमीन खरीदने के लिए।
**Romanized:** (Uske pas kam se kam 20 lakh hone hi chahiye hamare ilake me 100 gaj jameen kharidne ke liye.)
**English answer:** He should’ve to have minimum 20 lakh to buy a 100 yard plot in our locality.

## Source-text notes

- **Item 14:** The printed answer says 'There should be a good weather.'; retained as printed.
- **Item 16, 67, 74, 94, 101:** Printed answer alternatives are preserved as given.
- **Item 113:** The printed answer says 'He should be given good salary for this work.'; retained as printed.
- **Item 117:** The printed answer says 'We’ll should’ve equal opportunities to prove, who among us is really the best.'; retained as printed.
- **Item 119:** The printed answer says 'I shouldn’t told you about what’s going on there.'; retained as printed.
- **Item 128:** The printed answer says 'We should have been given an off yesterday.'; retained as printed.
- **Item 140:** The printed answer uses 'should’ve to have'; retained as printed.
- **Item 141:** The printed answer uses 'should’ve to have'; retained as printed.

**Editorial corrections:** Hindi OCR corrections were checked against the page images for items 15, 34–35, 59, 66, 117, 119, 121, 139 and 141. Romanized item 108 was corrected from “swarthy” to “swarthi”; the source-image text for item 117 and long Romanized lines in items 119, 131, 133, 135, 136, 139 and 141 were repaired or normalized only for obvious letter omissions. Printed English answer wording and alternatives are otherwise preserved verbatim, including the irregular wording called out above.

**Unreadable text:** none identified.

