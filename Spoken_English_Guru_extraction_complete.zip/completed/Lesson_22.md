# Lesson 22 — Imperative Sentences

**PDF pages:** 304–321 (printed pages 303–320)

## Please translate the following sentences into English

1. **Hindi prompt:** मेरे साथ रहो।  
   **Romanized:** Mere saath raho.  
   **English answer:** Be with me.  

2. **Hindi prompt:** अपने दोस्तों से बात करो।  
   **Romanized:** Apne dosto se baat karo.  
   **English answer:** Talk to your friends.  

3. **Hindi prompt:** किसी दोस्त को मत छोड़ो।  
   **Romanized:** Kisi dost ko mat chhodo.  
   **English answer:** Don’t leave any friend.  

4. **Hindi prompt:** मेरे बारे में सोचो।  
   **Romanized:** Mere baare mein socho.  
   **English answer:** Think about me.  

5. **Hindi prompt:** मुझे तुम्हें कुछ बताने दो।  
   **Romanized:** Mujhe tumhe kuch batane do.  
   **English answer:** Let me tell you something.  

6. **Hindi prompt:** विवेक को उन लोगों से मत मिलने दो।  
   **Romanized:** Vivek ko un logo se mat milne do.  
   **English answer:** Don’t let Vivek meet those people.  

7. **Hindi prompt:** इस परेशानी का हल निकालो।  
   **Romanized:** Is pareshanee ka hal nikalo.  
   **English answer:** Find out the solution of this problem.  

8. **Hindi prompt:** मुझे देखने दो।  
   **Romanized:** Mujhe dekhne do.  
   **English answer:** Let me see.  

9. **Hindi prompt:** नाक साफ करो।  
   **Romanized:** Naak saaf karo.  
   **English answer:** Clean your nose.  

10. **Hindi prompt:** कभी-कभी घर आया करो।  
   **Romanized:** Kabhi-kabhi ghar aaya karo.  
   **English answer:** Drop in home sometimes. / Come home sometimes.  

11. **Hindi prompt:** उसे एक इन्च भी मत हिलने दो।  
   **Romanized:** Use ek inch bhi mat hilne do.  
   **English answer:** Don’t let him move even an inch.  

12. **Hindi prompt:** हमेशा समय के पाबन्द रहो।  
   **Romanized:** Hamesha samay ke paaband raho.  
   **English answer:** Always be punctual.  

13. **Hindi prompt:** ऐसे चालाक आदमी से सावधान रहो।  
   **Romanized:** Aise chalaak aadmee se saavdhaan raho.  
   **English answer:** Beware of such a clever man.  

14. **Hindi prompt:** अपनी कमीज के बटन बन्द करो।  
   **Romanized:** Apni kameej ke button band karo.  
   **English answer:** Button up your shirt.  

15. **Hindi prompt:** कृपया दरवाजे की कुंडी लगा दो।  
   **Romanized:** Kripya darvaaje kee kundee laga do.  
   **English answer:** Kindly bolt the door.  

16. **Hindi prompt:** काम से जी मत चुराओ।  
   **Romanized:** Kaam se jee mat churao.  
   **English answer:** Don’t shirk the work.  

17. **Hindi prompt:** उसे ढूंढ़ने दो।  
   **Romanized:** Use dhundhne do.  
   **English answer:** Let him find out / search.  

18. **Hindi prompt:** उसे परेशान मत करो।  
   **Romanized:** Use pareshaan mat karo.  
   **English answer:** Don’t bother him.  

19. **Hindi prompt:** अपनी कार यहाँ खड़ी मत करो।  
   **Romanized:** Apni car yaha khadi mat karo.  
   **English answer:** Don’t park your car here.  

20. **Hindi prompt:** उसे ये मत करने दो।  
   **Romanized:** Use ye mat karne do.  
   **English answer:** Let him not do this. /Don’t let him do this.  

21. **Hindi prompt:** अपने माता-पिता को देखने जाओ।  
   **Romanized:** Apne mata-pita ko dekhne jao.  
   **English answer:** Go to see your parents.  

22. **Hindi prompt:** उस लड़के के साथ ठहरो।  
   **Romanized:** Us ladke ke saath thahro.  
   **English answer:** Stay with that boy.  

23. **Hindi prompt:** गरीबों की मदद करो।  
   **Romanized:** Gareebo ki madad karo.  
   **English answer:** Help the poor.  

24. **Hindi prompt:** इस लड़की को यहाँ काम करने दो।  
   **Romanized:** Is ladki ko yaha kaam karne do.  
   **English answer:** Let this girl work here.  

25. **Hindi prompt:** सभी कपड़े प्रेस(इस्त्री) कर दो।  
   **Romanized:** Sabhi kapde press(istree) kar do.  
   **English answer:** Iron all the clothes.  

26. **Hindi prompt:** जिम्मेदारियों से जी मत चुराओ।  
   **Romanized:** Jimmedariyo se ji mat churao.  
   **English answer:** Don’t shirk responsibilities.  

27. **Hindi prompt:** बाल बना लो।  
   **Romanized:** Baal bana lo.  
   **English answer:** Comb the hair.  

28. **Hindi prompt:** उन्हें जाने दो।  
   **Romanized:** Unhen jane do.  
   **English answer:** Let them go.  

29. **Hindi prompt:** थोड़ा पानी और मिला लो।  
   **Romanized:** Thoda pani aur mila lo.  
   **English answer:** Add a little more water.  

30. **Hindi prompt:** कृपया नमक पास करो।  
   **Romanized:** kripya namak pass karo.  
   **English answer:** Pass the salt please.  

31. **Hindi prompt:** समय देखो।  
   **Romanized:** Samay dekho.  
   **English answer:** Look at the time.  

32. **Hindi prompt:** यहाँ मत उतरो।  
   **Romanized:** Yahaan mat utro.  
   **English answer:** Don’t get off here.  

33. **Hindi prompt:** हमें पढ़ने दो क्योंकि कल हमारा पेपर है।  
   **Romanized:** Hame padhne do kyonki kal hamara paper hai.  
   **English answer:** Let us study as it is our paper tomorrow.  

34. **Hindi prompt:** मोमबत्ती बुझा दो।  
   **Romanized:** Mombattee bujha do.  
   **English answer:** Blow out the candle.  

35. **Hindi prompt:** सबको प्यार करो जो कोई तुम्हारी ज़िंदगी में आये।  
   **Romanized:** Sabko pyar karo jo koi tumharee zindagi mein aaye.  
   **English answer:** Love everyone whoever comes in your life.  

36. **Hindi prompt:** अपना हिसाब कर लो।  
   **Romanized:** Apna hisaab kar lo.  
   **English answer:** Clear your accounts.  

37. **Hindi prompt:** नीले पैन से मत लिखिए।  
   **Romanized:** Neele pen se mat likhiye.  
   **English answer:** Don’t write with a blue pen.  

38. **Hindi prompt:** यहाँ से चले जाओ।  
   **Romanized:** Yahaan se chale jao.  
   **English answer:** Go away from here.  

39. **Hindi prompt:** इस कार से बाहर निकल जाओ।  
   **Romanized:** Is car se bahar nikal jao.  
   **English answer:** Get out of this car.  

40. **Hindi prompt:** खच-पच मत लिखो, साफ-साफ लिखो।  
   **Romanized:** Khach-pach mat likho, saaf-saaf likho.  
   **English answer:** Do not scribble, Write legibly.  

41. **Hindi prompt:** जल्दी ठीक हो जाइए।  
   **Romanized:** Jaldee theek ho jaiyee.  
   **English answer:** Get well soon.  

42. **Hindi prompt:** मुद्दे पर आइए।  
   **Romanized:** Mudde par aaiye.  
   **English answer:** Come to the point.  

43. **Hindi prompt:** अपने वादे से मत मुकरो।  
   **Romanized:** Apne vade se mat mukro.  
   **English answer:** Do not back out of your promise.  

44. **Hindi prompt:** फर्श पर यहाँ वहाँ मत थूको।  
   **Romanized:** Farsh par yaha vaha mat thuko.  
   **English answer:** Don’t spit on the floor here and there.  

45. **Hindi prompt:** खूब मुस्कुराओ।  
   **Romanized:** Khoob muskurao.  
   **English answer:** Smile a lot.  

46. **Hindi prompt:** जल्दी ऑफिस पहुँचो क्योंकि बॉस नाराज़ है।  
   **Romanized:** Jaldi office pahucho kyunki boss naraz hai.  
   **English answer:** Reach office early as boss is angry.  

47. **Hindi prompt:** ज़्यादा मत खाओ।  
   **Romanized:** Zyada mat khao.  
   **English answer:** Do not overeat.  

48. **Hindi prompt:** अपने जूते निकाल लो।  
   **Romanized:** Apne joote nikaal lo.  
   **English answer:** Take off your shoes.  

49. **Hindi prompt:** फालतू बात मत करो।  
   **Romanized:** Faltu baat mat karo.  
   **English answer:** Do not talk nonsense.  

50. **Hindi prompt:** टेबल लगा लो।  
   **Romanized:** Table laga lo.  
   **English answer:** Lay the table.  

51. **Hindi prompt:** नल खुला है उसे बंद करो।  
   **Romanized:** Nal khula hai use band karo.  
   **English answer:** Tap is on switch it off.  

52. **Hindi prompt:** उधर जाकर बैठ जाओ।  
   **Romanized:** Udhar ja kar beth jao.  
   **English answer:** Go and sit there.  

53. **Hindi prompt:** जल्दी से कमरा खाली करो।  
   **Romanized:** Jaldi se kamra khali karo.  
   **English answer:** Clean the room fast.  

54. **Hindi prompt:** एक गाना गाकर सुना दो।  
   **Romanized:** Ek gaana gakar suna do.  
   **English answer:** Please sing a song.  

55. **Hindi prompt:** ये रिमोट फ्रिज के ऊपर रखदो।  
   **Romanized:** Ye remote fridge ke upar rakh do.  
   **English answer:** Put this remote on freeze.  

56. **Hindi prompt:** हल्ला मत करो मुझे सोने दो।  
   **Romanized:** Halla mat karo mujhe sone do.  
   **English answer:** Don’t make noise let me sleep.  

57. **Hindi prompt:** खाना गरम करलो फिर खा लेना।  
   **Romanized:** Khana garam karlo fir kha lena.  
   **English answer:** Heat the food and then eat it.  

58. **Hindi prompt:** मेरे लिए बाजार से कपड़े लाना।  
   **Romanized:** Mere liye bazaar se kapde laana.  
   **English answer:** Bring clothes for me from market.  

59. **Hindi prompt:** कल से मेरे घर मत आना।  
   **Romanized:** Kal se mere ghar mat aana.  
   **English answer:** Don’t come to my home from tomorrow.  

60. **Hindi prompt:** मेरा पेन वापस करो।  
   **Romanized:** Mera pen wapas karo.  
   **English answer:** Give my pen back.  

61. **Hindi prompt:** आशीष को कह देना कि कल मुझसे मिलने आ जाये।  
   **Romanized:** Ashish ko keh dena ki kal mujhse milne aa jaye.  
   **English answer:** Tell Ashish that come to meet me tomorrow.  

62. **Hindi prompt:** जब तक मैं ना आऊं, कहीं मत जाना।  
   **Romanized:** Jab tak main na aaun, kahin mat jaana.  
   **English answer:** Don’t go anywhere until I come.  

63. **Hindi prompt:** मुझे पांच बजे के बाद कॉल करना।  
   **Romanized:** Mujhe panch baje ke baad call karna.  
   **English answer:** Call me after 5’O clock.  

64. **Hindi prompt:** सारे बच्चों को लाइन में खड़ा करो।  
   **Romanized:** Sare bachcho ko line mai khada karo.  
   **English answer:** Stand up all the children in line.  

65. **Hindi prompt:** मेरे फोन को मत छेड़ो।  
   **Romanized:** Mere phone ko mat chedo.  
   **English answer:** Don’t touch my phone.  

66. **Hindi prompt:** जाओ जाके दरवाजा बंद करो।  
   **Romanized:** Jao jake darwaza band karo.  
   **English answer:** Go and close the door.  

67. **Hindi prompt:** कल तुम स्कूल चले जाना।  
   **Romanized:** Kal tum school chale jaana.  
   **English answer:** You go to school tomorrow.  

68. **Hindi prompt:** प्लेट को साइड से उठाओ।  
   **Romanized:** Plate ko side se uthao.  
   **English answer:** Lift plate from side.  

69. **Hindi prompt:** मेरी कार को मत ले जाना।  
   **Romanized:** Meri car ko mat le jaana.  
   **English answer:** Don’t take my car.  

70. **Hindi prompt:** शादी में शैतानी मत करना।  
   **Romanized:** Shadi mein shaitani mat karna.  
   **English answer:** Don’t misbehave in wedding.  

71. **Hindi prompt:** चुप होकर टी.वी देखो।  
   **Romanized:** Chup hokar TV dekho.  
   **English answer:** Be quite to watch TV.  

72. **Hindi prompt:** फालतू में मत हसो।  
   **Romanized:** Faaltoo mein mat haso.  
   **English answer:** Don’t laugh unnecessary.  

73. **Hindi prompt:** इतनी रात को कहीं नहीं जाना।  
   **Romanized:** Itni raat ko kahin nahi jaana.  
   **English answer:** Don’t go anywhere this late at night.  

74. **Hindi prompt:** पानी की बोतल भर के लाओ।  
   **Romanized:** Paani ki bottle bhar ke lao.  
   **English answer:** Go and bring a bottle of water.  

75. **Hindi prompt:** रूम में बॉल से मत खेलो।  
   **Romanized:** Room mein ball se mat khelo.  
   **English answer:** Don’t play in room with ball.  

76. **Hindi prompt:** मेरी बात को समझो जिद्द मत करो।  
   **Romanized:** Meri baat ko samjho zidd mat karo.  
   **English answer:** Get my point don’t be stubborn.  

77. **Hindi prompt:** अपने उन दोस्तो से तुम दूर रहा करो।  
   **Romanized:** Apne un dosto se tum door raha karo.  
   **English answer:** Be away from your friends.  

78. **Hindi prompt:** बड़ो से ऊँची आवाज़ मे बात मत किया करो।  
   **Romanized:** Bado se unchi awaz me baat mat kiya karo.  
   **English answer:** Don’t talk loudly with elders.  

79. **Hindi prompt:** मंदिर में बातें मत करो।  
   **Romanized:** Mandir mein baatein mat karo.  
   **English answer:** Don’t talk in temple.  

80. **Hindi prompt:** मेरे साथ मत चलो, कहीं और जाओ।  
   **Romanized:** Mere saath mat chalo, kahin aur jao.  
   **English answer:** Don’t walk with me, go anywhere else.  

81. **Hindi prompt:** दिन में मत सो रात को सोना।  
   **Romanized:** Din mai mat so raat ko sona.  
   **English answer:** Don’t sleep in afternoon sleep in night.  

82. **Hindi prompt:** मेहनत करो तब ही अच्छे नंबर आयेंगे।  
   **Romanized:** Mehnar karo tab hi achche number aaenge.  
   **English answer:** Work hard then only you will get good marks.  

83. **Hindi prompt:** सीमा जल्दी से घर जाओ यहाँ मत घूमो।  
   **Romanized:** Seema jaldi se ghar jaao yahan mat ghoomo.  
   **English answer:** Seema go home quickly don’t roam here.  

84. **Hindi prompt:** आप लोग बैठो, हम लोग चलते हैं।  
   **Romanized:** Aap log betho, hum log chalte hain.  
   **English answer:** You guys sit, let we go.  

85. **Hindi prompt:** दिव्या एक ग्लास चाय लाना।  
   **Romanized:** Divya ek glass chai laana.  
   **English answer:** Divya bring a glass of tea.)  

86. **Hindi prompt:** मेरे सामने सिगरेट मत पियो।  
   **Romanized:** Mere saamne cigarette mat piyo.  
   **English answer:** Don’t smoke cigarette in front of me.  

87. **Hindi prompt:** जाओ जाके टैक्सी को बुलाओ।  
   **Romanized:** Jao jaake taxi ko bulaao.  
   **English answer:** Go and call a taxi.  

88. **Hindi prompt:** बिना बात के मुझपे मत चिलाओ।  
   **Romanized:** Bina baat kai mujhpe mat chillao.  
   **English answer:** Don’t shout on me unnecessary.  

89. **Hindi prompt:** कल मत आना बल्कि परसों आना।  
   **Romanized:** Kal mat aana balki parson aana.  
   **English answer:** Don’t come tomorrow instead come day after tomorrow.  

90. **Hindi prompt:** मुझे मैसेज करना बंद करो।  
   **Romanized:** Mujhe message karna band karo.  
   **English answer:** Stop texting me.  

91. **Hindi prompt:** उससे कल ज़रूर मिलना वरना वो नाराज़ हो जाएगी।  
   **Romanized:** Usse kal zaroor milna varna vo naraz jo jaegi.  
   **English answer:** Do Meet her tomorrow or else she will get upset.  

92. **Hindi prompt:** पहले होमवर्क खत्म करो तब खेलना।  
   **Romanized:** Pehle homework khatam karo tab khelna.  
   **English answer:** First finish homework then play.  

93. **Hindi prompt:** घर आते हुए सब्जी लेकर आना।  
   **Romanized:** Ghar aate hue sabzi lekar aana.  
   **English answer:** Bring vegetable while coming to home.  

94. **Hindi prompt:** पहले उसे आने दो फिर हम निकलेंगे।  
   **Romanized:** Pehle use aane do fir hum niklenge.  
   **English answer:** First let her come then we will leave.  

95. **Hindi prompt:** बिजली के बिल के पैसे देदो।  
   **Romanized:** Bijli kai bill kai paise dedo.  
   **English answer:** Give money of electricity bill.  

96. **Hindi prompt:** बड़े भाई को पूछो, उसको भी खाना दे दूं?  
   **Romanized:** Bade bhai ko poocho, usko bhi khana de doon?  
   **English answer:** Ask elder brother should I give him food too?  

97. **Hindi prompt:** वो वाली जैकेट पक्का लेना।  
   **Romanized:** Vo wali jacket pakka lena.  
   **English answer:** Do Buy that jacket.  

98. **Hindi prompt:** पढ़ने के बाद अख़बार को टेबल पर रखदो।  
   **Romanized:** Padne kai baad akhbaar ko table par rakhdo.  
   **English answer:** Put newspaper on table after reading.  

99. **Hindi prompt:** मेरी गाड़ी की चाबी देदो।  
   **Romanized:** Meri gadi ki chabi dedo.  
   **English answer:** Give me my vehicle key.  

100. **Hindi prompt:** आप लोग बाहर इंतजार कीजिए।  
   **Romanized:** Aap log bahar intezar kijiye.  
   **English answer:** You guys wait outside.  

101. **Hindi prompt:** जो मैं कह रहा हूँ पहले उसे सुनो।  
   **Romanized:** Jo main keh raha hun pehle use suno.  
   **English answer:** First listen what I am saying.  

102. **Hindi prompt:** इस बैग को संभाल के रखना।  
   **Romanized:** Is bag ko sambhal kai rakhna.  
   **English answer:** Keep this bag safe.  

103. **Hindi prompt:** पनीर मत खाओ उसमें काफी मिर्ची है।  
   **Romanized:** Paneer mat khaao usme kafi mirchi hai.  
   **English answer:** Don’t eat panner it has lot of chilli in it.  

104. **Hindi prompt:** आकाश भैया को यह पेपर दे देना।  
   **Romanized:** Akash bhaiya ko yeh paper dedena.  
   **English answer:** Akash give this paper to bhaiya.  

105. **Hindi prompt:** मुझे यह काम पूरा चाहिए अब तुम अपने हिसाब से करलो।  
   **Romanized:** Mujhe yah kaam pura chahiye ab tum apne hisab se karlo.  
   **English answer:** I want this work done now you do it according to your own accord.  

106. **Hindi prompt:** तुमने कहा था कि तुम आइसक्रीम खिलाओगे अब खिलाओ।  
   **Romanized:** Tumne kaha tha ki tum ice- cream khilaoge ab khilaoge.  
   **English answer:** You said you will feed ice-cream feed it now.  

107. **Hindi prompt:** गीले फर्श पर पैर मत रखना।  
   **Romanized:** Geele farsh par pair mat rakhna.  
   **English answer:** Don’t put your feet on wet floor.  

108. **Hindi prompt:** कमरे की लाइट बंद मत करो।  
   **Romanized:** kamre ki light band mat karo.  
   **English answer:** Don’t switch off the light of room.  

109. **Hindi prompt:** मेरा फोन चार्ज पर लगा दो।  
   **Romanized:** Mera phone charge par laga do.  
   **English answer:** Put my phone on charge.  

110. **Hindi prompt:** चैनल चेंज करो मेरे सिरियल का टाईम हो गया।  
   **Romanized:** Channel change karo mere serial ka time ho gaya.  
   **English answer:** Change the channel it’s time for my serial.  

111. **Hindi prompt:** ये रोटी गाय को देकर आओ।  
   **Romanized:** Yai roti gay ko deke aao.  
   **English answer:** Give this chapatti to cow.  

112. **Hindi prompt:** किशन का फ़ोन आया है लो उससे बात करो।  
   **Romanized:** Kishan ka phone aaya hai lo usse baat karo.  
   **English answer:** Kishan call has come talk to him.  

113. **Hindi prompt:** राजेश सर, आज ही क्लास की मीटिंग करवाइए।  
   **Romanized:** Rajesh sir, aaj hi class ki meeting karwaeye.  
   **English answer:** Rajesh sir, get the class meeting done today only.  

114. **Hindi prompt:** इस फाइल को सर को देदो।  
   **Romanized:** Is file ko sar ko dedo.  
   **English answer:** Give this file to sir.  

115. **Hindi prompt:** बाइक धीरे चलाओ मुझे डर लग रहा है।  
   **Romanized:** Bike dheere chalao mujhe dar lag raha hai.  
   **English answer:** Drive bike slowly I am afraid.  

116. **Hindi prompt:** कार से हाथ बाहर मत निकालो।  
   **Romanized:** Car se hath bahar mat nikalo.  
   **English answer:** Don't take your hand out of car.  

117. **Hindi prompt:** अमित ये टेबल को साफ करो बहुत गन्दी है।  
   **Romanized:** Amit yai table ko saaf karo bahut gandi hai.  
   **English answer:** Amit clean this table its very dirty.  

118. **Hindi prompt:** मेरे फोन से यह सारे एप डिलीट करो।  
   **Romanized:** Mere phone se yah sare app delete karo.  
   **English answer:** Delete all these app from my phone.  

119. **Hindi prompt:** सड़क को ध्यान से पार किया करो।  
   **Romanized:** Sadak ko dhyan se paar kiya karo.  
   **English answer:** Cross the road carefully.  

120. **Hindi prompt:** अपने जुराब धो दो काफी बदबू आ रही है।  
   **Romanized:** Aapne juraab dho do bahut badbu aa rahi hai.  
   **English answer:** Wash your socks it smells bad.  

121. **Hindi prompt:** टी.वी की आवाज कम करो, मुझे सोना है।  
   **Romanized:** TV ki aawaz kam karo, mujhe sona hai.  
   **English answer:** Turn down the volume of TV, I want to sleep.  

122. **Hindi prompt:** तुम कल की छुट्टी मत लेना, कल बहुत काम है।  
   **Romanized:** Tum kal ki chutti mat lena, kal bahut kaam hai.  
   **English answer:** Don’t take tomorrow leave, tomorrow have lot of work.  

123. **Hindi prompt:** दुबारा मुझसे झूठ बोलने की कोशिश मत करना।  
   **Romanized:** Dobara mujhse jhoot bolne ki koshish mat karna  
   **English answer:** Don’t try to lie to me again.  

124. **Hindi prompt:** अभी के लिए अपना मुंह बंद रखो।  
   **Romanized:** Abhi kai liye apna muh band rakho.  
   **English answer:** Keep your mouth shut for now.  

125. **Hindi prompt:** मेरी शर्ट को इस्त्री कर दो।  
   **Romanized:** Meri shirt ko stree kardo.  
   **English answer:** Iron my shirt.  

126. **Hindi prompt:** सीधे - सीधे बोलो बात को घुमाओ मत।  
   **Romanized:** Seedhe – seedhe bolo baat ko ghumao mat.  
   **English answer:** Speak straight, don’t turn things around.  

127. **Hindi prompt:** टाइम से आ जाना लेट मत करना।  
   **Romanized:** Time se aa jaana late mat karna.  
   **English answer:** Come one time don’t be late.  

128. **Hindi prompt:** गमले में पानी डाल दो।  
   **Romanized:** Gamle mai paani dal do.  
   **English answer:** Pour water into the pot.  

129. **Hindi prompt:** केबल वाले को कॉल करो चैनल नहीं आ रहे है।  
   **Romanized:** Cable wale ko call karo channel nahi aa rahe hai.  
   **English answer:** Call to cable person, channel is not coming.  

130. **Hindi prompt:** कभी नाना- नानी के घर भी आया करो।  
   **Romanized:** Kabhi nana-nani kai ghar bhi aaya karo.  
   **English answer:** Sometimes come to maternal grandparent’s house.  

131. **Hindi prompt:** टारगेट को पूरा किया बिना मत जाना।  
   **Romanized:** Target ko poora kiya bine mat jaana.  
   **English answer:** Don’t go without completing the target.  

132. **Hindi prompt:** मैंने पर्स तुमको दिया था, अब ढूंढो।  
   **Romanized:** Maine purse tumko diya tha, ab dhoondo.  
   **English answer:** I gave you the purse, now find it.  

133. **Hindi prompt:** हितेश के उपर हंसना बंद करो।  
   **Romanized:** Hitesh kai upar hasna band karo.  
   **English answer:** Stop laughing on Hitesh.  

134. **Hindi prompt:** हमे रोज़ सुबह भगवान की पूजा करनी चाहिए।  
   **Romanized:** Hume roz subah bhagwan kee Pooja karni chahiye.  
   **English answer:** We should worship god every morning.  

135. **Hindi prompt:** मेरा पीछा छोड़ दो, मैं अब तुम्हारी कोई मदद नहीं कर सकता।  
   **Romanized:** Mera peecha chod do, main ab tumhaari koi madad nahin kar sakta.  
   **English answer:** Stop following me, I can’t help you anymore.  

136. **Hindi prompt:** गैस खत्म हो गयी है, आज खाना बाहर से ऑर्डर करदो।  
   **Romanized:** Gas khatam ho gayi hai, aaj khaana bahar se order kardo.  
   **English answer:** The gas is out, order food from outside today.  

137. **Hindi prompt:** जब तक पंकज नहीं आता मेरे साथ रहो।  
   **Romanized:** Jab tak Pankaj nahi aata mere sath raho.  
   **English answer:** Stay with me till Pankaj comes.  

138. **Hindi prompt:** आप पूरा पानी पी गये, किसी और के बारे में तो सोचो।  
   **Romanized:** Aap poora pani pee gaye, kisi or kai bare main to socho.  
   **English answer:** You drank all the water, think of someone else.  

139. **Hindi prompt:** बाल बहुत बढ़ गए हैं, जाकर कटवा कर आओ।  
   **Romanized:** Baal bahut bad gaye hai, jakar katwa kar aao.  
   **English answer:** The hair is too long, go and get it cut.  

140. **Hindi prompt:** शराब पीना गलत होता है।  
   **Romanized:** Sharab peena galat hota hai.  
   **English answer:** Drinking alcohol is wrong.  

141. **Hindi prompt:** पानी पी लो हिचकी बंद हो जाएगी।  
   **Romanized:** Paani peelo hichki band ho jaegi.  
   **English answer:** Drink water, hiccups will stop.  

142. **Hindi prompt:** शिवानी से अपना गिफ्ट ले लेना।  
   **Romanized:** Shivani se apna gift le lena.  
   **English answer:** Take your gift from Shivani.  

143. **Hindi prompt:** हमें नये साल पर सबसे प्यार बाँटना चाहिए।  
   **Romanized:** Hume naye saal par sabse pyar baatna chahiye.  
   **English answer:** We should spread love to all on New year.  

144. **Hindi prompt:** कुकर को मत छूना अभी वो गर्म है।  
   **Romanized:** Cooker ko mat choona abhi vo garam hai.  
   **English answer:** Don’t touch cooker its hot right now.  

145. **Hindi prompt:** तुमने दोबारा यह हरकत की तो मेरे घर से निकल जाना।  
   **Romanized:** Tumne dobara yah harkat kee to mere ghar se nikal jaana.  
   **English answer:** If you repeat this act again then get out of my house.  

146. **Hindi prompt:** जेब चैक करलो कहीं मेरा रूमाल तुम्हारे पास तो नहीं है।  
   **Romanized:** Jeb check karlo kahin mera roomal tumhaare pass to nahin hai.  
   **English answer:** Check your pocket weather you have my handkerchief with you.  

147. **Hindi prompt:** हारने के बाद रोना बंद करो।  
   **Romanized:** Harne mai bad rona band karo.  
   **English answer:** Stop crying after losing.  

148. **Hindi prompt:** खाना खाने से पहले हाथ को अच्छी तरह धो लो।  
   **Romanized:** Khana khane se pehle hath ko achi tarah dho lo.  
   **English answer:** Before eating food wash your hand properly.  

149. **Hindi prompt:** जिम से आते हुए केले लेकर आना।  
   **Romanized:** Gym se aate huwe kele lekar aana.  
   **English answer:** Bring bananas while coming from the gym.  

150. **Hindi prompt:** कल निकलने से पहले मुझे फोन कर देना।  
   **Romanized:** Kal nikalne se pehle mujhe phone kar dena.  
   **English answer:** Call me before leaving tomorrow.  

151. **Hindi prompt:** पैन में तेल डाल दो।  
   **Romanized:** Pan main tel daal do.  
   **English answer:** Put oil in pan.  

152. **Hindi prompt:** सारे बिस्किट मत खाना।  
   **Romanized:** Saare biscuit mat khana.  
   **English answer:** Don’t eat all biscuit.  

153. **Hindi prompt:** रात का बचा हुआ खाना कुत्ते को दे देना।  
   **Romanized:** Raat ka bacha huwa khaana kutte ko de dena.  
   **English answer:** Give night leftover food to dog.  

154. **Hindi prompt:** इस ड्रेस के साथ अपना काला वाला चश्मा पहनना।  
   **Romanized:** Is dress kai sath apna kala wala chasma pehenna.  
   **English answer:** Wear your black one glasses with this dress.  

155. **Hindi prompt:** उसकी शादी में 1000 रू देना।  
   **Romanized:** Uski shadi mai 1000 rupee dena.  
   **English answer:** Give 1000 rupee in her wedding.  

156. **Hindi prompt:** वहाँ जाने के लिए आपको अभी निकलना होगा।  
   **Romanized:** Vahan jaane kai liye apko abhi nikalna hoga.  
   **English answer:** You have to leave now to get there.  

157. **Hindi prompt:** मेरे लिए चावल रात के लिए भी बना देना।  
   **Romanized:** Mere liye chawal raat kai liye bhi bana dena.  
   **English answer:** Make rice for me for dinner also.  

158. **Hindi prompt:** आप मेरा ए.टी.एम कार्ड किसी को मत देना।  
   **Romanized:** Aap mera ATM card kisi ko mat dena.  
   **English answer:** Don’t give my ATM card to anyone.  

159. **Hindi prompt:** दिल्ली जाओगे तो, ताज महल ज़रूर जाना।  
   **Romanized:** Delhi jaoge to, Taj Mahal zaroor jana.  
   **English answer:** If you go to Delhi, must go to Taj Mahal.  

160. **Hindi prompt:** यह काम अच्छे से करना तब ही तुमको ईनाम मिलेगा।  
   **Romanized:** Yah kaam ache se karna tab hi tumko inaam milega.  
   **English answer:** Do this work well then only you will get reward.  

161. **Hindi prompt:** ये दो जोड़ी जूते पॉलिश करदो।  
   **Romanized:** Yah do Jodi joote polish krdo.  
   **English answer:** Polish this 2 Pair of shoes.  

162. **Hindi prompt:** मेरी कल की टिकट बुक करदो।  
   **Romanized:** Meri kal ki ticket book kardo.  
   **English answer:** Book my ticket for tomorrow.  

163. **Hindi prompt:** छत से सारे कपड़े उतार के लेकर आओ।  
   **Romanized:** Chat se saare kapde utar ke lekar aao.  
   **English answer:** Take off all the clothes from roof and bring them.  

164. **Hindi prompt:** सोने से पहले गेट पर ताला लगा देना।  
   **Romanized:** Sone se pehle gate par tala laga dena.  
   **English answer:** Lock the gate before sleeping.  

165. **Hindi prompt:** बैंक से दस हजार रूपये निकाल देना।  
   **Romanized:** Bank se das hazaar rupaye nikal dena.  
   **English answer:** Withdraw Ten thousand rupees from bank.  

166. **Hindi prompt:** मेरा अमेज़ोन का ऑर्डर केंसिल करवा देना।  
   **Romanized:** Mera amazon ka order cancel karwa dena.  
   **English answer:** Cancel my amazon’s order.  

167. **Hindi prompt:** मेरी घड़ी के सैल चैंज करवा देना।  
   **Romanized:** Meri ghadi kai cell change karwa dena.  
   **English answer:** Get the cell of my watch changed.  

168. **Hindi prompt:** छोटे भाई को मत मारो।  
   **Romanized:** Chote bhai ko mat maaro.  
   **English answer:** Don’t beat younger brother.  

169. **Hindi prompt:** जब तक मैं बाजार से आती हूँ तब तक शैतानी मत करना।  
   **Romanized:** Jab tak main bazaar se aati hun tab tak shaitaani mat karna.  
   **English answer:** Until I come from market don’t misbehave.  

170. **Hindi prompt:** रास्ते में कोई कुछ दे तो, उसे खाना मत।  
   **Romanized:** Raaste mai koi kuch de to, use khaana mat.  
   **English answer:** If anyone gives you something on road, don’t eat it.  

171. **Hindi prompt:** मुझे यह शक्ल कभी मत दिखाना।  
   **Romanized:** Mujhe yah shakal kabhi mat dikhaana.  
   **English answer:** Never show me this face again.  

172. **Hindi prompt:** मेरी साइकिल का पंचर बना दो।  
   **Romanized:** Meri cycle ka puncture bana do.  
   **English answer:** Make puncture of my cycle.  

173. **Hindi prompt:** शीतल कल हम सोहन के घर जाएँगे।  
   **Romanized:** Sheetal kal hum Sohan kai ghar jayenge.  
   **English answer:** Sheetal tomorrow we will go to Sohan house.  

174. **Hindi prompt:** रोहन को जाने दो, तुम मेरे साथ चल लेना।  
   **Romanized:** Rohan ko jaane do, tum mere saath chal lena.  
   **English answer:** Let Rohan go, you go with me.  

175. **Hindi prompt:** बस यहाँ नहीं आगे रोकना।  
   **Romanized:** Bus yahan nahin aage rokna.  
   **English answer:** Don’t stop bus here, stop ahead.  

176. **Hindi prompt:** मेरे सर की मालिश करदो।  
   **Romanized:** Mere sar ki malish kardo.  
   **English answer:** Massage my head.  

177. **Hindi prompt:** चलो आज पिज़्ज़ा खाते हैं, बहुत भूख लग रही है।  
   **Romanized:** Chalo aaj pizza khaate hai, bahut bhook lag rahi hai.  
   **English answer:** Let’s eat pizza today, I am feeling very hungry.  

178. **Hindi prompt:** परेशान मत हो, मैं ठीक हूँ।  
   **Romanized:** Pareshan mat ho, main thik hun.  
   **English answer:** Don’t worry, I am fine/ok.  

179. **Hindi prompt:** कहीं मत जाओ, मुझे तुम्हारी ज़रूरत है।  
   **Romanized:** Kahin mat jaao, mujhe tumhaari zarurat hai.  
   **English answer:** Don’t go anywhere, I need you.  

180. **Hindi prompt:** जब मैं तुमसे बात कर रहा हूँ तो खड़े हो जाओ।  
   **Romanized:** Jab mai tumse baat kar raha hun to khade ho jao.  
   **English answer:** Stand up when I speak to you.  

181. **Hindi prompt:** मशीन ऑन करने के लिए हरा बटन दबाओ।  
   **Romanized:** Machine on karne kai liye hara button dabao.  
   **English answer:** Press green button to on the machine.  

182. **Hindi prompt:** सुबह उठकर व्यायाम करना चाहिए।  
   **Romanized:** Subah uthkar vyayam karna chahiye.  
   **English answer:** Do exercise after getting up in morning.  

183. **Hindi prompt:** हर बार चालाकी मत दिखाया करो।  
   **Romanized:** Har baar chalaaki mat dikhaya karo.  
   **English answer:** Don’t be clever every time.  

184. **Hindi prompt:** सारी ईंटो को एक जगह रखदो।  
   **Romanized:** Saari inton ko ek jagah rakhdo.  
   **English answer:** Put all bricks at one place.  

185. **Hindi prompt:** बेडशीट को मत फैलाओ।  
   **Romanized:** Bedsheet ko mat failao.  
   **English answer:** Don’t spread bedsheet.  

186. **Hindi prompt:** मास्क पहन लो, यहाँ बदबू आ रही है।  
   **Romanized:** Mask pehen lo, yahan badbu aa rahi hai.  
   **English answer:** Wear mask, here smell is coming.  

187. **Hindi prompt:** पापा को मैसेज करदो कि दूध लेकर आना।  
   **Romanized:** Papa ko message kardo ki dhoodh lekar aana.  
   **English answer:** Message papa to bring milk.  

188. **Hindi prompt:** अंकल को बोल दो कि रजत घर पर नहीं है।  
   **Romanized:** Uncle ko bol do ki Rajat ghar par nahin hai.  
   **English answer:** Tell to uncle that Rajat is not at home.  

189. **Hindi prompt:** अंदर मत आना मैं झाड़ू लगा रही हूँ।  
   **Romanized:** Andar mat aana mai jhadu laga rahi hun.  
   **English answer:** Don’t come in, I am sweeping.  

190. **Hindi prompt:** मुझे कल की फाइल मेल करदो।  
   **Romanized:** Mujhe kal ki file mail krdo.  
   **English answer:** Mail me yesterday’s file.  

191. **Hindi prompt:** राहुल के साथ तुम बैंक चले जाओ।  
   **Romanized:** Rahul kai sath tum bank chale jao.  
   **English answer:** You go to bank with Rahul.  

192. **Hindi prompt:** पैर उस तरफ कर के लेटो।  
   **Romanized:** Pair us taraf kar ke leto.  
   **English answer:** Lie on that side with your feet.  

193. **Hindi prompt:** घड़ी का टाइम गलत है उसे सही करो।  
   **Romanized:** Ghadee kaa time galat hai use sahi karo.  
   **English answer:** Watch time is incorrect, correct it.  

194. **Hindi prompt:** तुमने आज की तारीख दी थी, अब मेरे पैसे दो।  
   **Romanized:** Tumne aaj ki tareekh di thi, ab mere paise do.  
   **English answer:** You gave me today’s date, now give me my money.  

195. **Hindi prompt:** कंचन को मेरा फोन नंबर दे देना।  
   **Romanized:** Kanchan ko mera phone number de dena.  
   **English answer:** Give my phone number to Kanchan.  

196. **Hindi prompt:** हीटर चला दो ठंड हो रही है।  
   **Romanized:** Heater chala do thand ho rahi hai.  
   **English answer:** Turn on the heater it getting cold.  

197. **Hindi prompt:** बारिश का मौसम आने वाला है, रेनकोट खरीद लो।  
   **Romanized:** Barish ka mausam aane wala hai, raincoat khareed lo.  
   **English answer:** The rainy season is about to start, buy a raincoat.  

198. **Hindi prompt:** पहले दुकान से चीनी ले कर आओ, तब चले जाना।  
   **Romanized:** Pehle dukaan se cheeni le kar aao, tab chale jaana.  
   **English answer:** First bring sugar from shop, then leave.  

199. **Hindi prompt:** पानी की बालटी भरके रख दो।  
   **Romanized:** Pani kee baalti bharke rakh do.  
   **English answer:** Keep a bucket of water.  

200. **Hindi prompt:** जैकेट की चैन बंद करो।  
   **Romanized:** Jacket kee chain band karo.  
   **English answer:** Lock the chain of the jacket.  

201. **Hindi prompt:** वो बुलाये तो भी वहाँ मत जाना।  
   **Romanized:** Vo bulaye to bhi vahan mat jaana.  
   **English answer:** Even if he calls, don’t go there.  

202. **Hindi prompt:** पढ़ाई करलो, टाइमपास मत करो।  
   **Romanized:** Padaai karlo, timepass mat karo.  
   **English answer:** Do study, don’t time pass.  

203. **Hindi prompt:** मेरे घर के आगे कूड़ा मत फेंको।  
   **Romanized:** Mere ghar kai aage kooda mat fainko.  
   **English answer:** Don’t throw garbage in front of my house.  

204. **Hindi prompt:** मेरे मना करने पर भी तुमने यह किया, अब तुम दफ़ा हो जाओ।  
   **Romanized:** Mere mana karne par bhi tumne yah kiya, ab tum dafa ho jao.  
   **English answer:** You did this despite my refusal, now you get lost.  

205. **Hindi prompt:** दाएँ - बाएँ मत देखो, सीधा देखो।  
   **Romanized:** Dayein-bayein mat dekho seedha dekho.  
   **English answer:** Don’t look left-right, look straight.  

206. **Hindi prompt:** तमीज़ से बात करो, मैं तुम्हारा नौकर नहीं हूँ।  
   **Romanized:** Tameez se baat karo, main tumhara naukar nahin hun.  
   **English answer:** Talk with manner; I am not your servant.  

207. **Hindi prompt:** मेरे बारे में किसी से भी बात मत करो।  
   **Romanized:** Mere bare mai kisi se bhi baat mat karo.  
   **English answer:** Don’t talk about me with anyone.  

208. **Hindi prompt:** झूठी कसम खाने की ज़रूरत नहीं है।  
   **Romanized:** Jhooti kasam khane kee zaroorat nahi hai.  
   **English answer:** No need to swear falsely.  

209. **Hindi prompt:** पंखा बहुत गंदा हो गया है, साफ़ करदो।  
   **Romanized:** Pankha bahut ganda ho gya hai, saaf kardo.  
   **English answer:** The fan has become very dirty, clean it.  

210. **Hindi prompt:** मैथ्स की बुक निकालो।  
   **Romanized:** Maths kee book nikalo.  
   **English answer:** Take out a Maths book.  

211. **Hindi prompt:** मेरी सारी फ़ोटोज़ मुझे भेज दो।  
   **Romanized:** Meri saari photos mujhe bhej do.  
   **English answer:** Send me my all photos.  

212. **Hindi prompt:** उसके बारे में बुरा बोलना बंद करो।  
   **Romanized:** Uske bare main bura bolna band karo.  
   **English answer:** Stop talking shit/bad about him.  

213. **Hindi prompt:** मुझे इस तरह से घूरना बंद करो।  
   **Romanized:** Mujhe is tarah se ghoorna band karo.  
   **English answer:** Stop staring at me like this.  

214. **Hindi prompt:** दीवार पर लिखना बंद करो।  
   **Romanized:** Deewar par likhna band karo.  
   **English answer:** Stop writing on walls.  

215. **Hindi prompt:** आज का हिसाब बताओ, मुझे आगे भेजना है।  
   **Romanized:** Aaj ka hisab batao, aage bhejna hai.  
   **English answer:** Tell me today’s account; I have to send it forward.  

216. **Hindi prompt:** अपना यह बेसुरा गाना बंद करो।  
   **Romanized:** Aapna yai besura gana band karo.  
   **English answer:** Stop singing this disgraceful song of yours.  

217. **Hindi prompt:** अलमारी में से तोलिया निकाल दो।  
   **Romanized:** Almaari mai se toliya nikal do.  
   **English answer:** Take out the towel from almirah.  

218. **Hindi prompt:** मेरे घर के आगे की रोड एकदम साफ़ करदो।  
   **Romanized:** Mere ghar kai aage kee road ekdum saaf kardo.  
   **English answer:** Clean the road in front of my house completely.  

219. **Hindi prompt:** बिल्ली ने रास्ता काट दिया, आगे मत जाओ।  
   **Romanized:** Billi nai raasta kaat diya, aage mat jaao.  
   **English answer:** The cat has crossed the path, don’t go ahead.  

220. **Hindi prompt:** खाने का बिल नितिन तुम पे करदो।  
   **Romanized:** Khane ka bill nitin tum pay kardo.  
   **English answer:** Nitin you pay the food bill.  

221. **Hindi prompt:** भैया, दो रोटी और ले आओ।  
   **Romanized:** Bhaiyaa, do roti or le aao.  
   **English answer:** Bhaiya, bring two more chapattis.  

222. **Hindi prompt:** बाहर जाने के लिए पापा से पूछो।  
   **Romanized:** Bahar jaane kai liye papa ko poocho.  
   **English answer:** Ask dad to gooutside.  

223. **Hindi prompt:** टेबल से गन्दे बरतन उठा दो।  
   **Romanized:** Table se gande bartan utha do.  
   **English answer:** Pick up the dirty dishes from the table.  

224. **Hindi prompt:** बेवकूफों की तरह बातें मत करो।  
   **Romanized:** Bekoofo ki tarah batein mat karo.  
   **English answer:** Don’t talk like an ediot.  

225. **Hindi prompt:** 5 किलो के डम्बल ले कर आओ।  
   **Romanized:** 5 Kilo kai dumbbell lekar aao.  
   **English answer:** Bring 5 kg dumbbells.  

226. **Hindi prompt:** गाड़ी को कपड़े से ढक दो।  
   **Romanized:** Gaadi ko kapde se dhak do.  
   **English answer:** Cover the vehicle with clothes.  

227. **Hindi prompt:** उसको वहीं जॉब करने दो, तुम यहाँ करलो।  
   **Romanized:** Usko vahin job karne do, tum yaha karlo.  
   **English answer:** Let him work there, you do it here.  

228. **Hindi prompt:** शर्मा का सामान सबसे पहले ले जाना।  
   **Romanized:** Sharma ka samaan sabse pehle le jaana.  
   **English answer:** Carry Sharma luggage very first.  

229. **Hindi prompt:** दोनों एक दूसरे पर चिल्लाना बंद करो।  
   **Romanized:** Dono ek doosre par chilaana band karo.  
   **English answer:** Stop shouting at each other.  

230. **Hindi prompt:** नीले पैन से नहीं काले पैन से लिखो।  
   **Romanized:** Neele pen se nahin kale pense likho.  
   **English answer:** Write with black pen not with blue pen.  

231. **Hindi prompt:** जिम की फीस आज ही पे कर देना।  
   **Romanized:** Gym kee fees aaj hi pay kar dena.  
   **English answer:** Pay the gym fees today only.  

232. **Hindi prompt:** कल ऑफिस से जल्दी आना।  
   **Romanized:** Kal office se jaldi aana.  
   **English answer:** Come early from office tomorrow.  

233. **Hindi prompt:** बच्चे का डाइपर चेंच कर दो।  
   **Romanized:** Bachche ka diaper change kar do.  
   **English answer:** Change the diaper of kid.  

234. **Hindi prompt:** आम का जूस बना दो।  
   **Romanized:** Aam ka juice bana do.  
   **English answer:** Make mango juice.  

235. **Hindi prompt:** जो पैसे बचे हैं वापस करो।  
   **Romanized:** Jo paise bache hai wapas karo.  
   **English answer:** Return the money that is left.  

236. **Hindi prompt:** जूते और चप्पलों को उनकी जगह पर रख दो।  
   **Romanized:** Joote or chappalo ko unki jagah par rakhdo.  
   **English answer:** Put shoes and slippers in their place.  

237. **Hindi prompt:** मेरी मम्मी से फोन पर बात करो।  
   **Romanized:** Meri mummy se phone par baat karo.  
   **English answer:** Talk with my mom on call.  

238. **Hindi prompt:** दो हाफ चाऊमीन पैक कर दो।  
   **Romanized:** Do half chowmein pack kardo.  
   **English answer:** Pack 2 half chowmein.  

239. **Hindi prompt:** सब्जी वाले को पैसे देकर आओ।  
   **Romanized:** Sabzi wale ko paise dekar aao.  
   **English answer:** Give money to vegetable seller and come.  

240. **Hindi prompt:** अँधेरे में दौड़ो मत।  
   **Romanized:** Andhere mai daudo mat.  
   **English answer:** Don’t run in the dark.  

241. **Hindi prompt:** कल एणग्ज़ाम है उसके बारे में सोचो।  
   **Romanized:** Kal exam hai uske bare main socho.  
   **English answer:** Tomorrow is the exam think about it.  

242. **Hindi prompt:** ए.सी कम कर दो बहुत तेज़ हो रखी है।  
   **Romanized:** AC kam kar do bahut tezz ho rakhi hai.  
   **English answer:** Turn down the AC its very fast.  

243. **Hindi prompt:** कार में पैट्रोल डलवालो खत्म होने वाला है।  
   **Romanized:** Car main petrol dalwalo khatam hone wala hai.  
   **English answer:** Put petrol in car its about to run out.  

244. **Hindi prompt:** मेले में इधर-उधर मत जाना।  
   **Romanized:** Mele main idhar-udhar mat jaana.  
   **English answer:** Don’t go anywhere in the fair.  

245. **Hindi prompt:** शाम को मूवी देखने जाना है तैयार रहना।  
   **Romanized:** Shaam ko movie dekhne jaana hai taiyaar rehna.  
   **English answer:** Be ready to go to the movie in the evening.  

246. **Hindi prompt:** टी.वी पर भारत-पाकिस्तान का मैच आ रहा होगा, लगा दो।  
   **Romanized:** TV par Bharat-Pakistan ka match aa raha hoga, laga do.  
   **English answer:** India-Pakistan match would be coming on TV, tune in.  

247. **Hindi prompt:** मिठाई बाद में खाना, पहले खाना खाओ।  
   **Romanized:** Mithae bad me khana, pehle food khao.  
   **English answer:** Eat food first then eat sweets.  

248. **Hindi prompt:** पूजा करने से पहले नहा लो।  
   **Romanized:** Pooja karne se pehle naha lo.  
   **English answer:** Take a bath before worshiping.  

249. **Hindi prompt:** दुकानदार के साथ बहस मत करो।  
   **Romanized:** Dukandaar kai sath behes mat karo.  
   **English answer:** Don’t argue with the shopkeeper.  

250. **Hindi prompt:** पर्दे लगा दो, धूप आ रही है।  
   **Romanized:** Parde laga do, dhoop aa rahi hai.  
   **English answer:** Put the curtains on, the Sun is coming.  

## Source-text and verification notes

- All 250 Hindi prompts and printed Romanized lines on PDF pages 304–314 were OCRed and visually checked against the scans; clear OCR, spacing, spelling, numeral, and punctuation artifacts were corrected. No unreadable prompt sections.
- The answer key begins on PDF page 314 after prompts 241–250 and runs through page 321. All 250 English answers were visually reviewed and paired with the same-number prompts; the sequence is unique and continuous from 1 to 250.
- Prompt 250 is printed on PDF page 314 above the Answers heading; it is retained as a prompt, followed by answer-key items 1–18 on that same page.
- The answer key continues through PDF page 321 and contains entries 1–250 in order; all are paired by number.
- The Hindi scan confirms 1000 rupees in item 155; OCR had read 000. Several row-level OCR punctuation, spacing, and spelling artifacts were corrected. Romanized lines were retained as printed except for clear row-extraction corruption and the listed scan-verified corrections.
- Romanized item 168 is printed as ‘mar maro’ although the Hindi means ‘mat maaro’; item 213 is printed as ‘ghoomna’ although the Hindi/answer indicate ‘ghoorna/staring’. These two Romanized mismatches are corrected to agree with the Hindi prompts.
- Printed English source wording and alternatives are preserved. In item 55 the printed English answer says ‘Put this remote on freeze’ while the Hindi says to put the remote on the fridge; the printed answer is retained and the source mismatch is flagged.

**Unreadable text:** none identified.

