# Lesson 7 — Placement of Adverbs

**PDF pages:** 56–58 (printed pages 55–57)

## Sentences and printed answers

### 1. You should breathe deeply in this exercise.
**Printed answer:** You should breathe deep in this exercise.

### 2. He quickly writes.
**Printed answer:** He writes quickly.

### 3. Mayank only came here last Sunday.
**Printed answer:** Mayank came here only last Sunday.

### 4. The farmer regularly comes to the field.
**Printed answer:** The farmer comes to the field regularly.

### 5. I have not laptop with me.
**Printed answer:** I have no laptop with me.

### 6. I go often to that temple.
**Printed answer:** I often go to that temple.

### 7. Call me anything else than your brother.
**Printed answer:** Call me anything else but your brother.

### 8. I was too tired after running.
**Printed answer:** I was very tired after running.

### 9. Repeat again.
**Printed answer:** Repeat.

### 10. He is much sorry for that.
**Printed answer:** He is very sorry for that.

### 11. I was fortunately not present there.
**Printed answer:** Fortunately, I was not present there.

### 12. I am feeling comparatively better now.
**Printed answer:** I am feeling better now.

### 13. He quickly ran away from there.
**Printed answer:** He ran away quickly from there.

### 14. Firstly you think and then say.
**Printed answer:** First you think and then say.

### 15. No one hardly comes here.
**Printed answer:** Hardly any one comes here.

### 16. They could not get it nowhere.
**Printed answer:** They could not get it anywhere.

### 17. I only did 2 questions.
**Printed answer:** I did only 2 questions.

### 18. Do you know to speak English?
**Printed answer:** Do you know how to speak English?

### 19. It is very cold to go for shopping today.
**Printed answer:** It is too cold to go for shopping today.

### 20. I visited her frequently when I was there.
**Printed answer:** I frequently visited her when I was there.

### 21. He runs fastly than me.
**Printed answer:** He runs faster than me.

### 22. He writes neat.
**Printed answer:** He writes neatly.

### 23. I hit the ball hardly.
**Printed answer:** I hit the ball hard.

### 24. He is much old.
**Printed answer:** He is very old.

### 25. The poem is much interesting.
**Printed answer:** The poem is very interesting.

### 26. Aman visits here seldom.
**Printed answer:** Aman seldom visits here.

### 27. The bus will shortly arrive.
**Printed answer:** The bus will arrive shortly.

### 28. The serial was mostly over when you came.
**Printed answer:** The serial was almost over when you came.

### 29. Try hardly to finish it.
**Printed answer:** Try hard to finish it.

### 30. He cautiously does this work.
**Printed answer:** He does this work cautiously.

### 31. It was nothing else than his negative mentality.
**Printed answer:** It was nothing else but his negative mentality.

### 32. There were everywhere people in the park.
**Printed answer:** There were people everywhere in the park.

### 33. He already has finished his task.
**Printed answer:** He has already finished his task.

### 34. He takes generally his dinner at 7 pm.
**Printed answer:** Generally, he takes his dinner at 7 pm.

### 35. I talk to her frequently.
**Printed answer:** I frequently talk to her.

### 36. I am too satisfied with this salary.
**Printed answer:** I am very satisfied with this salary.

### 37. They were unfortunately injured.
**Printed answer:** Unfortunately, they were injured.

### 38. I was too tired when he dropped in here.
**Printed answer:** I was much tired when he dropped in here.

### 39. The water is too cold.
**Printed answer:** The water is very cold.

### 40. This news is much interesting.
**Printed answer:** This news is very interesting.

### 41. I went directly to Delhi.
**Printed answer:** I went direct to Delhi.

### 42. Go at 9 am to the office.
**Printed answer:** Go to the office at 9 am.

### 43. They last Sunday, went to Delhi.
**Printed answer:** They went to Delhi last Sunday.

### 44. I do not know to dance.
**Printed answer:** I do not know how to dance.

### 45. He heartily loves you.
**Printed answer:** He loves you heartily.

### 46. He left this place five minutes before.
**Printed answer:** He left this place five minutes ago.

### 47. He ran fastly.
**Printed answer:** He ran fast.

### 48. He doesn’t speak clear.
**Printed answer:** He doesn’t speak clearly.

### 49. They left quicker than I expected.
**Printed answer:** They left quickly than I expected.

### 50. He is perfect correct.
**Printed answer:** He is perfectly correct.

---
**Source notes:**
- Spelling/spacing normalized without changing meaning: “Noone” → “No one” in prompt 15; “every where” → “everywhere” in prompt and printed answer 32.
- Printed answer-key wording retained at items 38 (“I was much tired…”) and 49 (“They left quickly than I expected.”); both appear grammatically questionable, and no replacement was invented.

No Hindi text or unreadable sections appear in this lesson.

