# Lesson 40 — Test Papers
Source: PDF pages 687–788 (printed pages 686–787).

## Test – 1

```text
[[PDF PAGE 687]]
Lesson – 40
                                 Test Papers
                                              Test – 1
  Q1: Translate the following sentences into English:                         Marks -20
        1.   मैं तु म्हारा सबसे बाा भाई हूँ । (Main tumhaara sabse bada bhaee hun.)
        2.   क्या तु म मेरे द स्त नहीों ह ? (Kya tum mere dost nahi ho?)
        3.   राम मेरे साथ हमेशा था। (Ram mere sath humesha tha.)
        4.   क्या तु म्हारे दस भाई नहीों हैं ? (Kya tumhare dus bhaae nahi hai?)
        5.   राकेश के कई द स्त हैं । (Rakesh kai kaee dost hain.)
        6.   मेरे पास 4 म बाईल नहीों थे। (Mere paas 4 mobile nahi the.)
        7.   िे ल ग हमारे साथ हैं । (Ve log humare sath hain.)
        8.   हम सब तुम्हारे भाई के पास ही हैं । (Hum sab tumhaare bhaee kai paas hi hai.)
        9.   मैं अपने पापा का सबसे बाा लाका हूँ । (Main apne papa ka sabse bada ladka hu.)
        10. सभी ल ग ों के पास प्रकताबें नहीों हैं । (Sabhi logo kai paas kitabein nahi hain.)
        11. ि आदमी एक अच्छा इन्ऱान नहीों है । (Vo aadmi ek acha insaan nahi hai.)
        12. क्या राम के पास पै न नहीों है ? (Kya Ram kai paas pen nahi hai.)
        13. तु म्हारे पास प्रदमाग क्य ों नहीों है ? (Tumhaare paas dimaag kyun nahi hai?)
        14. सभी मेरे प्रिय हैं । (Sabhi mere priya hain.)
        15. मैं तु म्हारे प्रलए अच्छा क्य ों नहीों हूँ ? (Main tumhaare liye acha kyun nahi hun.)
        16. तु म हर प्रकसी के प्रलए अच्छे थे । (Tum har kisi kai liye ache the.)
        17. क्या तु म्हारे द भाई हैं ? (Kya tumhaare do bhaee hain?
        18. क्या हमारे पास पैसे थे ? (Kya humare paas paise the?)
        19. ि बच्ा उनका सबसे छ टा लाका है । (Vo bacha unka sabse chotaa ladka hai.)
        20. मेरे पापा डाक्टर हैं । (Mere papa Doctor hain.)
Q2: Which 8 of the following are singulars? (प्रनम्नप्रलखखत में से कौन से 8 एकिचन हैं )      8
Ram, People, She, I, We, These, That, This, Those, It, He, Man, Women, They
Q3: Which 7 of the following are Plurals? (प्रनम्नप्रलखखत में से कौन से 7 बहिचन हैं )        7
Ram & Shyam, People, I, We, Pens, These, That, This, Those, It, He, Men, Woman, Sky, Water,
Jeans

[[PDF PAGE 688]]
Answers
   1. I am your eldest brother.
   2. Are you not my friend?
   3. Ram was always with me.
   4. Do you not have 10 brothers?
   5. Rakesh has many friends.
   6. I didn’t have 4 mobiles.
   7. They people are with us.
   8. We all are with your brother only.
   9. I am the eldest son of my father.
   10. All the people don’t have books.
   11. That man is not a good person/human.
   12. Does Ram not have a pen?
   13. Why do you not have mind/brain?
   14. All are my dear.
   15. Why am I not good for you?
   16. You were good for all.
   17. Do you have two brothers?
   18. Did we have money?
   19. That boy is their youngest son.
   20. My father is a doctor.
Q2: Singulars: Ram, She, I, That, This, It, He, Man
Q3: Plurals: Ram & Shyam, People, We, Pens, These, Men, Jeans
```

## Test – 2

```text
[[PDF PAGE 689]]
Test – 2
Q1: Translate the following sentences into English:                        Marks -30
 1. क्या तुम क ई और ह ? (Kya tum koi aur ho?)
 2. मैं प्रकसी का भी द स्त नहीों हूँ । (Main kisi ka bhi dost nahi hun.)
 3. तुम्हारे प्रकतने भाई हैं ? (Tumhaare kitane bhaee hai?)
 4. उसके स चने का तरीका मुझसे थ ाा अलग है । (Uske sochne ka tarika mujhse thoda
 alag hai.)
 5. राम सबसे बुरा इन्ऱान है । (Ram sabse bura insaan hai.)
 6. िे ल ग ऐसे क्य ों हैं ? (Ve log ese kyun hai?)
 7. हमारी िजह से उसके पास आज कुछ भी नहीों है । (Humari vajah se uske paas aaj kuchh
 bhi nahi hai.)
 8. क्या तुम सबसे बाे भाई ह ? (Kya tum sabse bade bhaae ho?)
 9. मेरी हथेली पर कुछ रखा हआ था, क्या था ि ? (Meri hatheli par kuch rakha huwa tha,
 kya tha vo?)
 10. ि प्रकसके साथ िहाूँ गया और क्य ों ? (Vo kiske saath vaha gaya aur kyun?)
 11. क्या पै से नहीों थे उसके पास ? (Kya mere paise nahi the uske paas?)
 12. जहाूँ कही ों भी तुम ह , खुश रह । (Jahaan kahi bhi tum ho, khush raho.)
 13. प्रजन्दगी क ई मऽाक है क्या ? (Zindagi koi mazaak hai kya?)
 14. मेरे पास सबसे कम पानी है । (Mere paas sabse kam paani hai.)
 15. क ई प्रम0 राम बाहर खाे हैं ? (Koi Mr Ram bahar khade hain.)
 16. क ई राहल क्लास में बैठा हआ है । (Koi Rahul class mai betha huwa hai.)
 17. प्रजस प्रकसी के भी साथ ि है , भगिान उसे आशीिाद दे । (Jis kisi kai bhi sath vo hai,
 bhagwan use aashirwad de.)
 18. उसके कपाे िटे हए थे शायद। (Uske kapde fate huwe the shayad.)
 19. क्या तु म्हारे पास कुछ है ? (Kya tumhare paas kuch hai.)
 20. रानी उनकी सबसे छ टी बेटी है । (Rani unki sabse choti beti hai.)
 21. जानिर प्यार के भू खे ह ते हैं । (Janwar pyar kai bhooke hote hain)
 22. मेरे चलने का तरीका कैसा है ? (Mere chalne ka tareeka kaisa hai?)
 23. प्रकस बच्े का पास मेरा पै न है ? (Kis bache ka paas mera pen hai?)
 24. िहाूँ प्रकतने बच्े बैठे हैं ? (Vahan kitne bache baithe hain?)
 25. ज क ई भी यहाूँ है , मेरा द स्त है । (Jo koi bhi yahan hai, mera dost hai.)
 26. ज क ई भी िहाूँ है , मेरा दु िन है । (Jo koi bhi vahan hai, mera dushman hai.)
 27. मेरे बगल में प्रसिि द बच्े थे। (Mere bagal main sirf do bachche the.)
 28. उसके खाने का तरीका ठीक नहीों है । (Uske khane ka tareeka thik nahi hai.)
 29. नाश्ते में आज क्या है ? ( Nashte mai aaj kya hai?)

[[PDF PAGE 690]]
30. मेरे प्रदल में क्या है ? (Mere dil mai kya hai?)
Q2: Translate the following sentences into Hindi:                     Marks -20
       1. Why are your friends not here?
       2. For what are you here?
       3. Which one is mine?
       4. Mine are three brothers.
       5. His is this book.
       6. They were better than me.
       7. Am I no one to you?
       8. Seeta is a friend of mine.
       9. How much petrol do you have at this moment?
       10. I am your better than the best friend.
       11. Relation of a mom with her children is unique.
       12. Nothing is impossible in this world.
       13. Government’s endeavor for poor’s uplift is praiseworthy.
       14. Are you trustworthy?
       15. Such people are not trustworthy.
       16. Life is beautiful for those, who are happy.
       17. I don’t have any friend in this locality.
       18. Glasses are half empty.
       19. Dictionary is good source of words.
       20. Today’s life is very hectic.

[[PDF PAGE 691]]
Answers
Q1:
      1. Are you someone else?
      2. I am not anybody’s friend.
      3. How many brothers do you have?
      4. His way of thinking is a bit different than that of mine.
      5. Ram is the worst person.
      6. Why are they people so?
      7. He has nothing today because of us.
      8. Are you the eldest brother?
      9. There was something in my palm, what was that?
      10. With whom did he go there and why?
      11. Did he not have money?
      12. Wherever you are, be happy.
      13. Is life a joke?
      14. I have the least water.
      15. A/Some Mr. Ram is standing outside.
      16. A/Some Rahul is sitting in the class.
      17. With whoever he is, may God bless him!
      18. Perhaps his clothes were torn.
      19. Do you have something?
      20. Rani is their youngest daughter.
      21. Animals are hungry for love. / Animals need love.
      22. How is my way of walking?
      23. Which kid has my pen?
      24. How many children are sitting there?
      25. Whoever is here, is my friend.
      26. Whoever is there, is my enemy.
      27. There were only two children beside me.
      28. His way of eating is not good.
      29. What is there in breakfast today?
      30. What is there in my heart?
Q2:
  1.    तु म्हारे द स्त यहाूँ क्य ों नहीों हैं ? (Tumhaare dost yahan kyun nahi hain?)
  2.    तु म यहाूँ प्रकसप्रलए ह ? (Tum yahan kisliye ho?)
  3.    कौन सा िाला मेरा है ? (Kaun saw ala mera hai?)
  4.    मेरे तीन भाई हैं । (Mere teen bhaae hain.)
  5.    उसकी है ये प्रकताब। (Uski hai ye kitaab.)

[[PDF PAGE 692]]
6.      िे मुझसे बेहतर थे । (Ve mujhse behtar the.)
7.      क्या मैं तु म्हारा क ई नहीों हूँ ? (Kya main tumhaara koi nahi hun?)
8.      सीता मेरी द स्त है । (Seeta meri dost hai.)
9.      तु म्हारे पास इस िक्त प्रकतना पे टर ल है ? (Tumhaare paas is waqt kitana petrol hai?)
10. मैं तु म्हारा सबसे अच्छे से भी अच्छा द स्त हूँ । (Main tumhara sabse achhe se bhi
achha dost hu.)
11. अपने बच्े के साथ एक माूँ का ररश्ता अन खा ह ता है । (Aapne bache kai sath ek ma ka
rishta anokha hota hai.)
12. इस दु प्रनया में कुछ भी असम्भि नहीों है । (Is duniya main kuch bhi asambhav nahi
hai.)
13. सरकार का ियास िशों सा य ग्य है । (Sarkaar ka prayas prashansha yogya hai.)
14. क्या तु म भर से के लायक ह ? (Kya tum bharose kai layak ho?)
15. ऐसे ल ग भर से लायक नहीों ह ते । (Aise log bharose layak nahi hote.)
16. प्रऽन्दगी उन ल ग ों के प्रलए खूबसू रत ह ती है , ज खु श हैं । (Zindagi un logo kai liye
khoobsurat hoti hai, jo khush hain.)
17. इस जगह मेरा क ई द स्त नहीों है । (Is jagah mera koi dost nahi hai.)
18. प्रगलास आधे खाली हैं । (Glass aadhe khaali hai.)
19. प्रडक्शनरी शब्द ों का अच्छा स्र त है । (Dictionary sabdho ka acha strot hai.)
20. आजकल की प्रऽन्दगी बहत व्यस्त है । (Aajkal ki zindagi bahut vyast hai.)
```

## Test – 3

```text
[[PDF PAGE 693]]
Test – 3
Q1: Translate the following sentences into Hindi:             44 x 1 = 44
   1. Am I your friend?
   2. Who is this boy?
   3. Whose book is that?
   4. They are my friends.
   5. Until when were you in office?
   6. A book is lying on the bed.
   7. These are not pencils.
   8. Who has money?
   9. Since when are you at home?
   10. He is someone else’s father.
   11. You are no one to me.
   12. Those boys were not with me.
   13. I didn’t have a pen.
   14. Who didn’t have pen?
   15. He is with someone else.
   16. Are chairs of white color?
   17. Are they your relatives?
   18. This is a sweet dog.
   19. That is a mobile phone.
   20. Mine are two children. / I have two children.
   21. What is he to you?
   22. His heart is broken.
   23. His behavior was pretty awkward there.
   24. Her father’s name is Mr. R K Sharma.
   25. I am a nice boy.
   26. His way of thinking is different altogether.
   27. In which home was he?
   28. Was he awake that time?
   29. Mansi and Paras are good students.
   30. This is not a laptop.
   31. Who was that boy to Ram?
   32. Death is a bitter truth of life.
   33. Road is bent ahead.
   34. I have six books.
   35. I don’t have 15 pencils.
   36. How many books do you have?
   37. Here is a book.

[[PDF PAGE 694]]
38. What are these people to you?
  39. There are a few notebooks.
  40. His uncle is very nice.
  41. I am your best friend.
  42. The condition of my rattraps is pathetic.
  43. My dad is a nice man.
  44. How many brothers does he have?
                                             Answers
1.   क्या मैं तु म्हारा द स्त हूँ ? (Kya main tumhaara dost hun?)
2.   ये लाका कौन है ? (Ye ladka kaun hai?)
3.   ि प्रकसकी प्रकताब है ? (Vo kiski kitaab hai?)
4.   िे मेरे द स्त हैं । (Ve mere dost hain.)
5.   तु म कब तक ऑप्रिस में थे ? (Tum kab tak office main the?)
6.   एक प्रकताब प्रबस्तर पर पाी हई है । (Ek kitaab bistar par padee hui hai.)
7.   ये पेखन्ऱलें नही ों हैं । (Ye pencil nahin hain.)
8.   पैसे प्रकसके पास हैं ? (Paise kiske paas hai?)
9.   तु म घर पर कब से ह ? (Tum ghar par kab se ho?)
10. ि प्रकसी और के पापा हैं । (Vo kisi aur kai papa hain.)
11. तु म मेरे क ई नहीों ह । (Tum mere koi nahi ho.)
12. ि लाके मेरे साथ नहीों थे। (Vo ladke mere sath nahi the.)
13. मेरे पास पैन नही ों था। (Mere paas pen nahi tha.)
14. प्रकसके पास पै न नहीों था? (Kiske paas pen nahi tha?)
15. िे प्रकसी और के साथ हैं । (Ve kisi aur kai sath hain.)
16. क्या कुप्रसियाूँ सिेद रों ग की हैं ? (Kya kursiyaan safed rang ki hain?)
17. क्या िे आपके सों बोंधी हैं ? (Kya ve aapke sambandhi hain?)
18. यह एक प्यारा कुत्ता है । (Yah ek pyara kutta hai.)
19. ि म बाइल ि न है । (Vo mobile phone hai.)
20. मेरे द बच्े हैं । (Mere do bachche hain.)
21. ि तु म्हारा क्या लगता है ? (Vo tumhaara kya lagta hai?)
22. उसका प्रदल टू टा हआ है । (Uska dil toota huwa hai.)
23. उसका व्यिहार िहाूँ बहत अजीब था। (Uska vyavahaar vahan bahut ajeeb tha.)
24. उसके पापा का नाम प्रम0 आर के शमाि है । (Uske papa ka nam Mr RK Sharma hai.)
25. मैं अच्छा लाका हूँ । (Mai acha ladka hun.)
26. उसके स चने का तरीका बहत अलग है । (Uske sochne ka tareeka bahut alag hai.)
27. ि प्रकस घर में था? (Vo kis ghar main tha?)
28. क्या ि उस िक्त उठा हआ था? (Kya vo us waqt utha huwa tha?)

[[PDF PAGE 695]]
29. मानसी और पारस अच्छे प्रिधाथी हैं । (Mansi aur Paras ache vidhyarti hain.)
30. ये लेपटाप नहीों है । (Ye laptop nahi hai.)
31. ि लाका राम का कौन था? (Vo ladka Ram ka kaun tha?)
32. मुत्र्यु जीिन का एक कटु सत्य है । (Mirtyu jeevan ka ek katu satya hai.)
33. र ड आगे से मुाी हई है । (Road aage se mudi hui hai.)
34. मेरे पास 6 प्रकताबें हैं । (Mere paas 6 kitaabein hai.)
35. मेरे पास 15 पैखन्ऱलें नहीों हैं । (Mere paas 15 pencilein nahi hai.)
36. तु म्हारे पास प्रकतनी प्रकताबें हैं ? (Tumhaare paas kitni kitaabein hai?)
37. यहाूँ एक प्रकताब है । (Yahaan ek kitaab hai.)
38. ये ल ग तु म्हारे क्या लगते हैं ? (Ye log tumhaare kya lagte hai?)
39. िहाूँ कुछ काप्रपयाूँ हैं । (Vahan kuch kapiyan hai.)
40. उसके अोंकल बहत अच्छे हैं । (Uske uncle bahut ache hai.)
41. मैं तुम्हारा सबसे अच्छा द स्त हूँ । (Main tumhaara sabse acha dost hun.)
42. मेरी चू हेदाप्रनय ों की हालत बहत ऻराब है । (Meri chuhedaniyo ki halat bahut kharab h.)
43. मेरे पापा एक अच्छे इन्ऱान हैं । (Mere papa ek ache insaan hain.)
44. उसके प्रकतने भाई हैं ? (Uske kitne bhaae hain?)
```

## Test – 4

```text
[[PDF PAGE 696]]
Test – 4
Q1: Translate the following sentences into Hindi:             50 x 1 = 50
   1. Were you there?
   2. Who is there at the door?
   3. There was a king.
   4. How much petrol is there in your car?
   5. Until when were you there in office?
   6. There is a book on the bed.
   7. How many students were there in the class?
   8. Is there money in your pocket?
   9. No one is there.
   10. There is a boy standing.
   11. Is someone there?
   12. There were 29 people in total.
   13. Why were you there?
   14. With whom is he there?
   15. There was a lion in that forest.
   16. There is a ghost, whose name is Rahul.
   17. When you were there, I was not there.
   18. There were 15 students in that class.
   19. There is a phone call for you.
   20. A friend of yours is there at the door.
   21. There is no Rahul in my class.
   22. There are no pens in my bag.
   23. How much is there in your pocket?
   24. How many stars are there in the sky?
   25. His dad is there with my dad.
   26. Her sister is there in Japan.
   27. There is a tap in his kitchen, which is very old.
   28. There is a boy with him, who is very thin.
   29. There is a girl in his class, for whom he is mad.
   30. There is no friend of mine in this photograph.
   31. Is there any friend of yours in this photograph?
   32. There are numerous hotels in Shimla.
   33. There is a beautiful lake in Mussorie.
   34. There is a laptop on my bed.
   35. Is there a mobile on my table?
   36. There is no letter underneath the pillow.
   37. There is no one standing ahead of me.

[[PDF PAGE 697]]
38. How many people are there next to you?
39. Ram is there in the car.
40. There is a bridge over the Yamuna River.
41. How many books are there in your bag?
42. Nothing is there.
43. Nobody is there in your room.
44. Some people are eating food there.
45. My life lies in you.
46. I am always there with you.
47. The condition is pathetic there.
48. My dad was never there.
49. Weather conditions were phenomenal there.
50. How many brothers of yours were standing there?
                                        Answers
1.    क्या तुम िहाूँ थे ? (Kya tum vahaan the?)
2.    दरिाजे पर कौन है ? (Darwaaze par kaun hai?)
3.    एक राजा था। /िहाूँ एक राजा था। (Ek Raja tha. / Vahan ek Raja tha.)
4.    तु म्हारी कार में प्रकतना पेटर ल है ? (Tumhaari car main kitna petrol hai?)
5.    तु म ऑप्रिस में कब तक थे? (Tum office main kab tak the?)
6.    प्रबस्तर पर एक प्रकताब है । (Bistar par ek kitaab hai.)
7.    क्लास में प्रकतने बच्े थे ? (Class mai kitane bachche the?)
8.    क्या तुम्हारी जे ब में पैसे हैं ? (Kya tumhaari jeb mai paise hain?)
9.    िहाूँ क ई नहीों है । (Vahan koi nahi hai.)
10. िहाूँ एक लाका खाा है । (Vahan ek ladka khada hai.)
11. क्या िहाूँ क ई है ? (Kya vahaan koi hai?)
12. कुल प्रमलाकर 29 ल ग थे । (Kul milakar 29 log the.)
13. तु म िहाूँ क्य ों थे ? (Tum vahan kyun the?)
14. ि िहाूँ प्रकसके साथ है ? (Vo vahaan kiske saath hai?)
15. उस जों गल में एक शे र था। (Us jungle main ek sher tha.)
16. िहाूँ एक भूत है प्रजसका नाम राहल है । (Vahan ek bhoot hai jiskaa naam Rahul h.)
17. जब तुम थे, मैं नहीों था । (Jab tum the, main nahi tha.)
18. उस क्लास में 15 बच्े थे । (Us class main 15 bachche the.)
19. तु म्हारे प्रलए एक ि न कॉल है । (Tumhaare liye ek phone call hai.)
20. तु म्हारा क ई द स्त दरिाजे पर है । (Tumhaara koi dost darwaaze par hai.)
21. मेरी क्लास में क ई राहल नहीों है । (Meri class mai koi Rahul nahi hai.)
22. मेरे बैग में पैन नहीों है । (Mere bag main pen nahi hai.)

[[PDF PAGE 698]]
23. तु म्हारी जे ब में प्रकतना है ? (Tumhaari jeb mai kitna hai?)
24. आसमान में प्रकतने तारे हैं ? (Aasman main kitane tare hain?)
25. उसके पापा मेरे पापा के साथ हैं । (Uske papa mere papa kai sath hain.)
26. उसकी बहन जापान में है । (Uski behen Japan main hai.)
27. उसके प्रकचन में एक नल है , ज बहत पु राना है । (Uske kitchen me ek nal hai, jo
bahut purana hai.)
28. उसके साथ एक लाका है , ज बहत पतला है । (Uske sath ek ladka hai, jo bahut
patla hai.)
29. उसकी क्लास में एक लाकी है , प्रजसके प्रलए ि पागल है । (Uski class mai ek ladki
hai, jiske liye vo pagal hai.)
30. इस ि ट में मेरा क ई द स्त नहीों है । (Is photo me mera koi dost nahi hai.)
31. क्या इस ि ट में तुम्हारा क ई द स्त है ? (Kya is photo mai tumhaara koi dost hai?)
32. प्रशमला में कई ह टल हैं ? (Shimla mai kaee hotel hain?)
33. मसूरी में एक सुन्दर झील है । (Mussoorie mai ek sundar jheel hai.)
34. मेरे प्रबस्तर पर एक लेपटॉप है । (Mere bistar par ek laptop hai.)
35. क्या मेरी टे बल में क ई म बाइल है ? (Kya meri table main koi mobile hai?)
36. तप्रकए के नीचे क ई पत्र नहीों है । (Takiye kai neeche koi patra nahi hai.)
37. मेरे आगे क ई नहीों खाा। (Mere aage koi nahi khada.)
38. तु म्हारे बगल में प्रकतने ल ग हैं ? (Tumhaare bagal main kitane log hain?)
39. राम कार में है । (Raam car main hai.)
40. यमुना नदी के ऊपर एक पुल है । (Yamuna nadee kai upar ek pul hai.)
41. तु म्हारे बैग में प्रकतनी प्रकताबें हैं ? (Tumhaare bag main kitni kitaabein hain?)
42. िहाूँ कुछ नही ों है । (Vahan kuch nahi hai.)
43. तु म्हारे कमरें में क ई नहीों है । (Tumhaare kamre mai koi nahi hai.)
44. िहाूँ कुछ ल ग खाना खा रहे हैं । (Vahan kuch log khaana kha rahe hain.)
45. मेरी प्रऽन्दगी तुम में है । (Meri zindaagi tum main hai.)
46. मैं हमेशा तुम्हारे साथ हूँ । (Main humesha tumhaare sath hun.)
47. िहाूँ हालत बहत बुरी है । (Vahan haalat bahut bhuri hai.)
48. मेरे पापा िहाूँ कभी नहीों थे । (Mere papa vahan kabhi nahi the.)
49. मौसम बाा जबरदस्त था िहाूँ । (Mausam bada jabardast tha vahan.)
50. तु म्हारे प्रकतने भाई िहाूँ खाे थे? (Tumhare kitane bhaee vahan khade the?)
```

## Test – 5

```text
[[PDF PAGE 699]]
Test – 5
Q1: Translate the following sentences into English:                         45 x 1 = 45
   1.   उस घर में एक छ टा बच्ा था। (Us ghar main ek chota bacha tha.)
   2.   िहाूँ कुछ नहीों था शायद। (Vahan kuch nahi tha shayad.)
   3.   बाल्टी के नीचे कुछ है । (baalti kai neeche kuch hai.)
   4.   सभी ल ग िहाूँ ह ग
                        ों े। (Sabhi log vahan honge.)
   5.   क्या मेरा भाई िहाूँ ह गा? (Kya mera bhaae vahan hoga.)
   6.   िहाूँ पहनने क कुछ नहीों है । (Vahan pehenne ko kuch nahi hai.)
   7.   कहने की ऽरूरत नहीों है । (Kehne ki zaroorat nahi hai.)
   8.   जब कभी तु म थे , राम नहीों था। (Jab kabhi tum the, Ram nahi tha.)
   9.   उसके भाई के प्रदल में क ई बात नहीों है । (Uske bhaae kai dil main koi baat nahi hai.)
   10. बात करने की क ई ऽरूरत नहीों है । (Baat karne kee koi zaroorat nahi hai.)
   11. ऐसा कुछ नहीों है । (Aisa kuch nahi hai.)
   12. हमारे बीच ऐसा कुछ नहीों था। (Humaare beech aisa kuch nahi tha.)
   13. प्रकतने ल ग हैं ? (Kitane log hain?)
   14. कुछ है क्या? (Kuch hai kya?)
   15. उस घर में कुछ है । (Us ghar main kuch hai.)
   16. प्रकतना पैसा था? (Kitna paisa tha?)
   17. तु म प्रकसके साथ थे ? (Tum kiske sath the?)
   18. इस प्रदल में क्या है , कौन जानता है ? (Is dil mai kya hai, kaun jaanta hai?)
   19. एक राजा था। उसकी तीन राप्रनयाूँ थीों। (Ek Raja tha, Uski teen raniya thi.)
   20. दरिाजे पर कौन था? (Darwaaze par kaun tha?)
   21. घर में प्रकतने ल ग हैं ? (Ghar mai kitne log hain?)
   22. मन में क्या है तु म्हारे ? (Man mai kya hai tumhaare?)
   23. कम्प्प्यूटर में प्रकतने गेम हैं ? (Computer mai kitne game hain?)
   24. राम और श्याम के बीच में कौन है ? (Ram aur shyam kai beech mai kaun hai?)
   25. मेरे आगे क ई नहीों है । (Mere aage koi nahi hai.)
   26. तु म्हारे पीछे कौन था? (Tumhaare peeche kaun tha?)
   27. राम के साथ कौन है ? (Ram kai sath kaun hai?)
   28. पापा के सामने मम्मी थी। (Papa kai samne mummy thi.)
   29. मेरे बगल में क ई है क्या? (Mere bagal mai koi hai kya?)
   30. एक आदमी खाा है । (Ek aadmi khada hai.)
   31. क ई लाकी है । (Koi ladki hai.)
   32. कई बातें हैं ज मैं जानता हूँ । (kaee batein hain jo main jaanta hun.)
   33. प्यार में दू ररयाूँ नहीों ह ती। (Pyar mai dooriyan nahi hoti.)

[[PDF PAGE 700]]
34. द स्ती में थैंक्स नहीों ह ता। (Dosti mai Thanks nahi hota.)
35. हमारे बीच कुछ नहीों है । (Humare beech kuch nahi hai.)
36. नल में पानी नहीों है । (Nal mai paani nahi hai.)
37. प्रदल क प्यार है । (Dil ko pyar hai.)
38. तु म्हारे प्रदल में क्या है ? (Tumhaare dil mai kya hai?)
39. कमरे में खखाप्रकयाूँ हैं । (kamre main khidkiyan hai.)
40. पैन में स्ाही नहीों है । (Pen mai syahi nahi hai.)
41. कार में पे टर ल था । (Car mai petrol tha.)
42. उसके प्रदल में बहत ददि है । (Uske dil mai bahut dard hai.)
43. उसकी आिाऽ में जादू है । (Uski aawaz mai jadoo hai.)
44. तु म्हारे गाने के तरीके में कुछ त बात है । (Tumhare gaane k tarike me kuch to bat h.)
45. कुछ और भी है । (Kuch aur bhi hai.)
                                        Answers
1. There was a small kid in that home.
2. Perhaps/probably there was nothing.
3. There is something beneath the bucket.
4. All the people will be there.
5. Will my brother be there?
6. There is nothing to wear.
7. There is no need to say.
8. Whenever you were there, Ram wasn’t there.
9. There is nothing in his brother’s heart.
10. There is no need to talk.
11. There is nothing as such.
12. There was nothing as such between us.
13. How many people are there?
14. Is there something? / Is something there?
15. There is something in that house.
16. How much money was there?
17. With whom were you?
18. What’s in this heart, who knows?
19. There was a king. He had three queens.
20. Who was there at the door?
21. How many people are there at home?
22. What is there in your mind/heart?

[[PDF PAGE 701]]
23. How many games are there in computer?
24. Who is there between Ram and Shyam?
25. Nobody is there ahead of me.
26. Who was there behind you?
27. Who is there with Ram?
28. There was mom in front of dad.
29. Is someone there beside me?
30. There is a man standing.
31. There is some girl. / There is a girl.
32. There are lot many things/secrets that I know.
33. There are no differences in love.
34. There is no thanks in friendship.
35. There is nothing between us.
36. There is no water in the tap.
37. There is love in heart.
38. What is there in your heart?
39. There are windows in the room.
40. There is no ink in the pen.
41. There was petrol in the car.
42. There is so much pain in his heart.
43. There is a magic in his voice.
44. There is something in your way of singing.
45. Something else is there.
```

## Test – 6

```text
[[PDF PAGE 702]]
Test – 6
                         Teacher- Pooja Madam
Anjali         Bikrant              Aditya            Archana               Yashi
Binita          Aman                  Amit            Kuldeep              Dimpal
Seema            Soni               Ayushi            Abhishek            Kalpana
 1. Who is sitting next to Ayushi?
 2. Who is sitting next to Seema?
 3. Who is sitting immediate right to Kalpana?
 4. Who is sitting adjacent Kuldeep?
 5. Where is Pooja Madam standing?
 6. How many people are sitting right to Bikrant?
 7. Who is sitting behind Archana?
 8. Who is sitting right to Binita?
 9. Who is sitting immediate left to Yashi?
 10. Who is sitting beside Aman?
 11. Who are sitting at corners?
 12. Who are sitting at the extreme right?
 13. Who are sitting at the extreme left?
 14. Where is Anjali Sitting?
 15. Who is sitting right to Dimpal?
 16. Who is sitting immediate left to Abhishek?
 17. Who is sitting left to Soni?
 18. Who are sitting in row number 2?
 19. Who are sitting in column number 4?
 20. Who are sitting in column number 1?

[[PDF PAGE 703]]
Answers
 1. Soni and Abhishek.
 2. Soni.
 3. Nobody.
 4. Amit and Dimpal.
 5. In front of students
 6. Three - Aditya, Archana and Yashi.
 7. Kuldeep.
 8. Aman, Amit, Kuldeep and Dimple.
 9. Archana.
 10. Binita and Amit.
 11. Anjali, Yashi, Seema & Kalpana.
 12. Yashi, Dimple and Kalpana.
 13. Anjali, Binita and Seema.
 14. 1st row extreme left corner.
 15. Nobody.
 16. Ayushi.
 17. Seema.
 18. Binita, Aman, Amit, Kuldeep & Dimple
 19. Archana, Kuldeep & Abhishek.
 20. Anjali, Binita and Seema
```

## Test – 7

```text
[[PDF PAGE 704]]
Test – 7
  Q1: Translate the following sentences into Hindi:                      20 x 1 = 20
      1. Do you really feel the pain of those who are poor and hungry?
      2. Will he ever realize that he was in the wrong?
      3. Which one are you looking for at the moment?
      4. How many times have I told you not to disturb me?
      5. Why did you back out of your promise?
      6. Sometimes, He takes things pretty lightly.
      7. I will seldom go to the US because I feel myself an alien there.
      8. Have you ever been in Agra?
      9. I don’t know what to do.
      10. He has not been working for money since beginning.
      11. For how long have you been waiting for me in the airport?
      12. It sounded good but I know it’s not worthwhile.
      13. I will sue you in court.
      14. Prime Minister addressed the gathering.
      15. Shyam unnecessarily elongates the matter.
      16. Most of the People are traveling by metro these days.
      17. He feeds his animals thrice a day.
      18. Are you feeling like going there?
      19. These two aren’t looking to be twins as their faces are different altogether.
      20. He is fighting for his self respect and dignity.
Q2: Choose the correct alternative in each sentence:                        10 x 1 = 10
      1. He has been in Delhi (since/for) a long.
      2. I never (tells/tell) a lie.
      3. He didn’t go (somewhere/anywhere).
      4. Do you love (to watch / watching) TV?
      5. I like (to play / playing) cricket.
      6. He (founded/found) peace nowhere.
      7. I (was/were) watching you.
      8. Shalini (does/do) not go to parties.
      9. Rahul (looks / looked) tired that day.
      10. (Do/Does) you know how to speak in English?
Q3: Translate the following sentences into English?                  10 x 1 = 10
 1. तुम िहाूँ प्रकस रास्ते से ह ते हए जाते ह ? (Tum vahan kis raaste se hote huwe jaate ho?)

[[PDF PAGE 705]]
2. इतने सारे प्रगले प्रशकिे लेकर कहाूँ जाओगे तु म ? (Itne saare gile shikve lekar kahan
jaaoge tum?)
3. रहते कहाूँ ह द स्त? अक्सर प्रदखते नहीों! (Rehte kahan ho dost? Aksar dikhte nahi!)
4. दिाई खाने के बाद अच्छा महसू स ह रहा है मुझे। (Dawaai khane kai baad acha
mehsoos ho raha hai mujhe.)
5. मैं कािी दे र से उसे ढूूँढ रहा था। (Main kaafi der se use dhoond raha tha.)
6. सरकार गरीब ों के प्रलए सही मायन ों में क्या कर रही है ? (Sarkaar gareebon kai liye sahi
mayno mai kya kar rahi hai?)
7. सच कहूँ त मुझे नहीों पता प्रक मैं आगे क्या करने िाला हूँ । (Sach kahoon to mujhe nahi
pata ki mai aage kya karne wala hoon.)
8. क्या ि मुझे जानता था ? (Kya vo mujhe jaanta tha?)
9. मैनें उसे इतना प्यार प्रकया प्रजतना क ई उसे कभी नही ों करे गा ? (Maine use itna pyaar kiya
jitna koi use kabhi nahi karega.)
10. बात ों से पे ट नहीों भरता। (Baton se pet nahi bharta.)
                                         Answers
Q1:
 1. क्या तु म िाकई उन ल ग ों का ददि महसूस करते ह ज गरीब और भू खे हैं ? (Kya tum vakaae
 un logo ka dard mehsoos karte ho jo gareeb aur bhookhe hai?)
 2. क्या ि कभी महसू स करे गा प्रक ि गलत था? (Kya vo kabhi mehsoos karega ki vo galat
 tha?)
 3. इस समय तुम कौन सा िाला ढूोंढ रहे ह ? (Is samay tum kaun sa wala dhoond rahe
 ho?)
 4. मैंने तु म्हें प्रकतनी बार कहा है प्रक मुझे परे शान मत प्रकया कर ? (Maine tumhe kitni baar
 kaha hai ki mujhe pareshan mat kiya karo?)
 5. तु म अपने िादे से क्य ों मुकरे ? (Tum apne wade se kyu mukre?)
 6. कभी-कभी ि चीज ों क बहत हल्के में लेता है । (Kabhi – kabhi vo cheezon ko bahut
 halke mai letaa hai.)
 7. मैं शायद ही कभी अमेररका जाऊूँगा क्य प्रों क मैं िहाूँ अपने आप क अजनबी महसू स करता हूँ ।
 (Main shayad hee kabhi America jaunga kyunki mai vahan apne aap ko ajnabi
 mehsoor karta hun.)
 8. क्या तु म कभी आगरा में रहे ह ? (Kya tum kabhi Agra me rahe ho?)
 9. मैं नहीों जानता प्रक क्या करू
                                ूँ ? (Main nahi jaanta ki kya karun?)
 10. ि शुरू से ही पैस ों के प्रलए काम नहीों कर रहा है । (Vo shuru se hi paison kai liye kaam
 nahi kar raha hai.)

[[PDF PAGE 706]]
11. तु म एअरप टि पर मेरा इन्तऽार कब से कर रहे ह ? (Tum airport par mera intzaar kab se
 kar rahe ho?)
 12. सुनने में अच्छा लगा लेप्रकन मैं जानता हूँ प्रक ये िायदे का सौदा नहीों है । (Sunne mai acha
 laga lekin mai jaanta hun ki yai fayde kaa soda nahi hai.)
 13. मैं तुम्हें क टि में घसीटू ूँ गा।/ मैं तुम्हारे खखलाि मुकदमा दायर करू
                                                                         ूँ गा। (Main tumhe court
 mai ghassetunga. / Main tumhaare khilaaf mukadma dayar karunga.)
 14. िधानमोंत्री ने भीा क सम्ब प्रधत प्रकया/भाषण प्रदया। (Pradhan Mantri nai bheed ko
 sambhodit kiya/bhasan diya.
 15. श्याम िालतू में मामले क लम्बा कर दे ता है । (Shyam faaltoo mai maamle ko lamba
 kar deta hai.)
 16. इन प्रदन ों अप्रधकतर ल ग मैटर से यात्रा कर रहे हैं । (In dino adhiktar log metro se yatra
 kar rahe hain.)
 17. ि अपने जानिर ों क प्रदन में तीन बार खखलाता है । (Vo apne janvaron ko din mai teen
 baar khilaata hai.)
 18. क्या तु म्हारा िहाूँ जाने का मन कर रहा है ? (Kya tumhaara vahan jaane ka man kar
 raha hai?)
 19. ये द न ों जु ािा नहीों लग रहे हैं क्य प्रों क इनके चे हरे प्रबल्कुल अलग हैं । Yai dono judwa nahi
 lag rahe hai kyunki inke chehre bilkul alag hai.)
 20. ि अपने आत्म सम्मान और िप्रतष्ठा के प्रलए ला रहा है । (Vo apne aatm samman aur
 pratishta kai liye lad rahe hai.)
Q2: Correct alternative is Bold & Underlined.
      1. He has been in delhi (since/for) a long.
      2. I never (tells/tell) a lie.
      3. He didn’t go (somewhere/anywhere).
      4. Do you love (to watch / watching) TV?
      5. I like (to play / playing) cricket.
      6. He (founded/found) peace nowhere.
      7. I (was/were) watching you.
      8. Shalini (does/do) not go to parties.
      9. Rahul (looks / looked) tired that day.
      10. (Do/Does) you know how to speak in English?
Q3:
      1. Via which way do you go there?
      2. Where will you go with these many differences/rifts?
      3. Where are you mate? Not seen very often!
      4. I am feeling good after having/eating medicine.

[[PDF PAGE 707]]
5. I had been searching him for a long.
  6. What is government ideally doing for the poor?
  7. To be honest I don’t know what I am going to do further.
  8. Did he know me?
  9. I loved her so much that nobody will ever do.
  10. Action is better than words.
```

## Test – 8

```text
[[PDF PAGE 708]]
Test – 8
Translate the sentences from Hindi to English:                                        35 x 1 = 35
 1. तुमने मुझे प्रकतना प्यार प्रकया? (Tumne mujhe kitna pyar kiya?)
 2. मैं कैसे जानूूँ प्रक तुम्हारे प्रलए मैं कौन था। (Main kaise jaanu ki tumhaare liye main kaun
 tha.)
 3. जब मैं तुमसे प्रमलने आऊूँगा, मुझे लगता है प्रक तुम स रहे ह गे। (Jab main tumse milne
 aaunga, mujhe lagta hai kee tum so rahe honge.)
 4. तुम कल 6 बजे आना, तब तक त मैं तु म्हारा काम कर चु का हूँ गा। (Tum kal 6 baje aana,
 tab tak main tumhaara kaam kar chukaa hoonga.)
 5. तुम्हें ऐसा क्य ों लगता है प्रक मेरे पास बहत पै सा है । (Tumhe aisa kyun lagta hai ki mere
 paas bahut paisa hai.)
 6. प्रऽन्दगी हमें बहत कुछ प्रसखाती है । (Zindaagi hume bahut kuch sikhaati hai.)
 7. आज हमारे पास कुछ नहीों है । (Aaj humaare paas kuch nahi hai.)
 8. तुम कब तक िहाूँ रह गे ? (Tum kab tak vahan rahoge.)
 9. हम कहीों नहीों जा रहे थे। (Hum kahin nahi ja rahe the.)
 10. ि आदमी एक बच्े क कािी दे र से मार रहा है । (Vo aadmi ek bachche ko kafi der se
 maar raha hai.)
 11. राम कई प्रदन ों से तुम्हारे यहाूँ जा रहा था। (Ram kaee dino se tumhaare yahan jaa rahaa
 tha.)
 12. मैं प्रक्रक्रेट खे लना कैसे प्रसखूूँगा? (Main cricket khelna kaise seekhunga?)
 13. ि बच्े तुम्हारे घर कैसे आये ? (Vo bachche tumhaare ghar kaise aaye?)
 14. मैं सभी ल ग ों से प्रमल चुका हूँ । (Main sabhi logo se mil chukka hun.)
 15. तुम्हारे सभी द स्त मुझसे प्रमल चु के थे । (Tumhaare sabhi dost mujhse mil chuke the.)
 16. तुम कब तक मेरे घर रुक गे ? (Tum kab tak mere ghar rukoge.)
 17. राम कब से कम्प्प्यूटर पर बैठा हआ है ? (Ram kab se computer par betha huwa hai?)
 18. मैंने तुम्हारे बारे में बहत कुछ स चा। (Mene tumhaare baare mai bahut kuchh socha.)
 19. मुझे एक प्यारी सी घाी प्रमली है । (Mujhe ek pyaari si ghadee mili hai.)
 20. तुम्हारे प्रकतने भाई हैं ? (Tumhaare kitne bhaee hain?)
 21. मेरे चार ों भाई खाना खा चु के हैं । (Mere chaaro bhaee khaana kha chuke hain.)
 22. मैंने सारे प्रदन गााी चलाई। (Maine saare din gadee chalaae.)
 23. तुमने मुझे हर जगह ढूोंिा। (Tumne mujhe har jagah dhoonda.)
 24. तुम मेरे पीछे क्य ों छु प रहे ह ? (Tum mere peeche kyun chup rahe ho?)
 25. ि तुम्हारा क्या है ? (Vo tumhara kya hai?)
 26. मैं मम्मी क कई प्रदन ों से याद कर रहा था। (Main mummy ko kaee dino se yaad kar
 raha tha.)

[[PDF PAGE 709]]
27. तुम्हारा नाम मेरे प्रदल की धाकन ों पर प्रलखा है । (Tumhara naam mere dil ki dhadkano
par likha hai.)
28. तुमने हमेशा मुझे गलत समझा। (Tumne humesha mujhe galat samjha.)
29. मैं तुमसे सच कह रहा हूँ । (Main tumse sach keh raha hun.)
30. मुझे प्रबल्कुल नहीों पता प्रक तु म कौन ह ? (Mujhe bilkul nahi pata ki tum kaun ho?)
31. क्या तुमने कभी प्रकताबें खरीदी? (Kya tumne kabhi kitaabein khareedi?)
32. मुझे तुम्हारे बारे में सब कुछ पता है । (Mujhe tumhaare bare main sab kuch pata hai.)
33. राम ने सभी प्रकताबें टे बल पर रखी। (Ram nai sabhi kitaabein table par rakhi.)
34. तुम क्य ों स च रहे ह प्रक मैं नहीों आऊूँगा। (Tum kyun soch rahe ho ki main nahi
aaunga.)
35. तुम जब से आये ह , प्रसिि उसके बारे में बात कर रहे ह । (Tum jab se aaye ho, sirf uske
bare mai baat kar rahe ho.)
                                       Answers
 1. How much did you love me?
 2. How do I know, who I was for you.
 3. When I come to meet you, I think you will be sleeping.
 4. You come at 6 o’clock; I will have finished your work by then.
 5. Why do you think that I have lots of money?
 6. Life teaches us a lot.
 7. We have nothing today. / We don’t have anything today.
 8. Until when will you be/stay/live there?
 9. We were not going anywhere./We were going nowhere.
 10. That man has been beating a kid for a long.
 11. Ram had been going to your place for many days.
 12. How will I learn to play cricket?
 13. How did those children come to your house?
 14. I have met all the people.
 15. All of your friends had met me.
 16. Until when will you stay at my home?
 17. Since when has Ram been sitting on the computer?
 18. I thought a lot about you.
 19. I have found a nice watch.
 20. How many brothers do you have?
 21. All of my 4 brothers have taken/eaten/had the food.

[[PDF PAGE 710]]
22. I drove the car throughout the day.
23. You sought/searched me everywhere.
24. Why are you hiding behind me?
25. What/Who is he to you?
26. I had been missing mom for many days.
27. Your name is written on my heartbeats.
28. You always took me wrong.
29. I am telling you the truth.
30. I really don’t know who you are.
31. Did you ever buy books?
32. I know everything about you.
33. Ram put/kept all the books on the table.
34. Why are you thinking that I will not come?
35. Ever since you have come, you are only talking about him/her.
```

## Test – 9

```text
[[PDF PAGE 711]]
Test – 9
Q1: Translate the sentences from Hindi to English:                            20 x 1 = 20
 1. तुमने मुझे कभी कुछ कहा क्या? (Tumne mujhe kabhi kuch kaha kya?)
 2. मैं कैसे बताऊूँ प्रक तु म मेरे क्या ह । (Main kaise bataun ki tum mere kya ho.)
 3. जब कभी मैं तुमसे प्रमलने आऊूँगा, क्या तु म मुझे ि सारी प्रकताबें द गी? (jab kabhi main
     tumse milne aaunga, kya tum mujhe vo saree kitaabein dogi?)
 4. कई प्रदन ों से मुझे तुम कुछ याद प्रदला रही ह । (Kaee dino se mujhe tum kuch yaad dila
     rahi ho.)
 5. तुम्हें कैसे मालूम प्रक मेरे पास इतना पै सा है । (Tumhe kaise maloom ki mere paas itna
     paisa hai.)
 6. प्रऽन्दगी के हसीन पल हम सब के प्रलए एक जै से ही हैं । (Zindagi kai haseen pal hum sab
     kai liye ek jaise hi hai.)
 7. आज हमारे पास कुछ नहीों है । (Aaj humaare paas kuch nahi hai.)
 8. तुम प्रसिि प्रबऽनेस करने के प्रलए ही बने ह । (Tum sirf business karne kai liye hi bane
     ho.)
 9. हम ल ग उन आिाज ों क समझने की क प्रशश कर रहे थे । (Hum log un aawazo ko
     samjhne ki koshish kar rahe the.)
 10. ि ल ग उस बच्े की बात ों क मऽाक में ले रहे थे । (Vo log us bachche ke baton ko
     mazaak mai le rahe the.)
 11. राम कई प्रदन और कई रात ों से प्रबना रुके पि रहा था। (Ram kaee din aur kaee raton se
     bina ruke pad raha tha.)
 12. मैंने तुम्हें डाूँ टा और तुमने र ना शु रु कर प्रदया। (Maine tumhe danta aur tumne rona
     shuru kar diya.)
 13. ि बच्े तुम्हारे घर की दीिार के पीछे प्रछप गये थे । (Vo bachche tumhaare ghar ki
     deewar kai peeche chip gaye the.)
 14. मैं सभी क उस भू प्रतया घर के बारे में बता चु का था। (Main sabhi ko us bhootiya ghar kai
     bare mai bata chukka tha.)
 15. तुम मेरे साथ कभी भी नहीों थे । (Tum mere saath kabhi bhi nahi the.)
 16. तुम कब से मेरे घर में रह रहे ह ? (Tum kab se mere ghar me reh rahe ho?)
 17. राम हमारी उम्मीद ों पर खरा उतर रहा है । (Ram humaari ummedon par khara utar raha
     hai.)
 18. माूँ और बच् ों का ररश्ता बहत खू बसू रत ह ता है । (Ma aur bachcho ka rishta bahut
     khoobsurat hota hai.)
 19. मैं भीगा हआ था इसप्रलए ठों ड लग गयी। (Main bheega huwa tha isliye thand lag gayi.)
 20. जहाूँ कहीों भी तुम जाओगे , ि तुम्हें नहीों छ डे़ गा। (Jahan kahin bhi tum jaaoge, vo
     tumhein nahi chodega.)

[[PDF PAGE 712]]
Q2: Correct the following sentences:                                 10 x 1 = 10
  1. He is walking in the park for a long.
  2. My friend did not found peace anywhere.
  3. I didn’t went there.
  4. Ram worked with me never.
  5. Life teach us thousand things.
  6. I looked at the calender for the dates.
  7. He is not walking because he is so week.
  8. Have you seen my 3 story building?
  9. He was sweeting when he came to me.
  10. There were 5 students. There parents had also come.
                                       Answers
Q1:
  1.Did you ever say something to me?
  2.How do I tell, what you are to me.
  3.Whenever I come, will you give me all those books?
  4.You have been reminding me of something for many days.
  5.How do you know that I have this much money?
  6.Life’s romantic moments are same for all of us.
  7.We have nothing today.
  8.You are only meant / made for business.
  9.We people were trying to understand those voices.
  10. Those people were taking that child lightly.
  11. Ram had been continuously studying for many days.
  12. I scolded you and you started weeping.
  13. Those children had hidden behind the wall of your house.
  14. I had told everyone about that haunted house.
  15. You were never with me.
  16. Since when have you been living at my home?
  17. Ram is living up to our expectations.
  18. Mother and children’s relation is very beautiful.
  19. I was drenched hence got cold.
  20. Wherever you go, he will not spare you.

[[PDF PAGE 713]]
Q2: The correct sentences are:
1. He has been walking in the park for a long.
2. My friend did not find peace anywhere.
3. I didn’t go there.
4. Ram never worked with me.
5. Life teaches us thousand things.
6. I looked at the calendar for the dates.
7. He is not walking because he is so weak.
8. Have you seen my 3 storey building?
9. He was sweating when he came to me.
10. There were 5 students. Their parents had also come.
```

## Test – 10

```text
[[PDF PAGE 714]]
Test – 10
Translate the following sentences into English:                                    50 x 1 = 50
     1.   क्या आप ल ग उस लाके से प्रमले थे ? (Kya aap log us ladke se mile the?)
     2.   मैंने उसकी बहन क पहचान प्रलया था। (Maine uski behen ko pehchaan liya tha.)
     3.   खे ल के दौरान ि थका हआ सा लगा। (Khel kai dauraan vo thaka huwa sa laga.)
     4.   तु म मुझे बहत अच्छे लगते ह । (Tum mujhe bahut ache lagte ho.)
     5.   मैंने उसे पैसा कभी नहीों प्रदया। (Maine use paisa kabhi nahi diya.)
     6.   कई ल ग साक पर प्रचल्रा रहे थे । (Kaee log sadak par chilla rahe the.)
     7.   उसने तु म्हें अपनी प्रऽन्दगी से भी ज़्यादा प्यार प्रकया। (Usne tumhein apni zindagi se
     bhi zyada pyar kiya.)
     8.   ये टू टा हआ प्रगलास प्रकसने रखा यहाूँ ? (Ye toota huwa glass kisne rakha yahan?)
     9.   क्या ि स्कूल गया ह गा? (Kya vo school gaya hoga?)
     10. तु म इतनी तेऽ क्य ों दौा रहे ह ? (Tum itni tezz kyun daud rahe ho?)
     11. कौन कौन जायेगा मेरे साथ? Kaun kaun jayega mere sath.)
     12. प्रकस आदमी का बेटा तु म्हारे पापा के साथ जॉब करता है ? (Kis aadmi ka beta
     tumhaare papa kai sath job karta hai?)
     13. मैं अक्सर उसके यहाूँ जाता हूँ । (Main aksar uske yahan jaata hun.)
     14. ि प्रदन रात क्य ों पिता है ? (Vo din raat kyun padhta hai?)
     15. ि कभी-कभी मेरे घर आता है । (Vo kabhi kabhi mere ghar aata hai.)
     16. हम बहत दे र तक उठे रहते हैं । (Hum bahut der tak uthe rehte hai.)
     17. तु म्हारा द स्त कौन सी कार चलाता है ? (Tumhaara dost kaun si car chalaata hai?)
     18. मैं प्रकसके भाई के साथ नाच रहा था? (Main kiske bhaae kai sath nach raha tha?)
     19. तु म द पहर से कुछ ढूूँढ रहे ह ? (Tum dopeher se kuch dhoond rahe ho?)
     20. मैं जानता हूँ प्रक ये ह गा। (Mai jaanta hun ki yai hoga.)
     21. तु म िहाूँ गये थे । (Tum vahan gaye the.)
     22. मैंने राम क दे खा है । (Maine Ram ko dekha hai.)
     23. उसके पापा मेरे घर आये। (Uske papa mere ghar aaye.)
     24. उन् न
             ों े मुझे बताया है । (Unhone mujhe bataya hai.)
     25. क्या उसने कहा? (Kya usne kaha?)
     26. ि कभी नहीों गया। (Vo kabhi nahi gaya.)
     27. सु रेश मुझसे प्रमलेगा। (Suresh mujhse milega.)
     28. हम 7 बजे स्कूल के प्रलए प्रनकले। (Hum 7 baje school kai liye nikle.)
     29. बच्े कभी नहीों गये। (Bachche kabhi nahi gaye.)
     30. मुझे ये अच्छा नहीों लगता। (Mujhe yai acha nahi lagta.)
     31. राम उसे प्यार करता है । (Ram use pyar karta hai.)
     32. िक्त के साथ सब बदल जाता है । (Waqt kai sath sab badal jaata hai.)

[[PDF PAGE 715]]
33. पै सा आदमी की नीयत बदलता है । (Paisa admi ki neeyat badalta hai.)
 34. उसे कुछ प्रमला है , शायद क ई पै न। (Use kuch mila hai, shayad koi pen.)
 35. मैंने ये िश्न पहले भी हल प्रकया है । (Maine ye prashan bhi hal kiya hai.)
 36. उसने 4 घों टे मेरा इन्तऽार प्रकया। (Usme 4 ghante mera intzaar kiya.)
 37. बच्े चु पचाप क्य ों नहीों रहते ? (Bachche chupchaap kyun nahi rehte?)
 38. मैंने उसे हर जगह ढूूँढा। (Maine use har jagah dhoonda.)
 39. अपना रास्ता उसने खु द बनाया। (Apna raasta usne khud banaya.)
 40. मुझे प्रकसी ने नहीों कहा, मैंने खुद प्रकया। (Mujhe kisi nai nahi kaha, maine khud
 kiya.)
 41. ि मुझे परे शान कर रहा है । (Vo mujhe pareshan kar raha hai.)
 42. ल ग आये थे। (Log aaye the.)
 43. मैंने अक्सर उसे यहाूँ दे खा है । (Maine aksar use yahan dekha hai.)
 44. राम नहीों करता। (Ram nahi karta.)
 45. उसने मुझे सारी बात बतायी। (Usne mujhe saari baat batayi.)
 46. ि कई प्रदन ों से लगातार पि रहा है । (Vo kaee dino se lagatar pad raha hai.)
 47. मैंने ऐसा नही ों स चा था। (Maine aisa nahi socha tha.)
 48. इस िक्त ि पि रहा ह गा। (Is waqt vo pad raha hoga.)
 49. मैंने कुछ भी नहीों पू छा। (Maine kuch bhi nahi poocha.)
 50. हम प्रिल्म दे ख रहे थे उस िक्त, जब ि आया। (Hum film dekh rahe the us waqt,
 jab vo aaya.)
                                     Answers
1. Had you people met that boy?
2. I had recognized his/her sister.
3. He seemed/looked tired during the game.
4. I like you a lot.
5. I never gave him money.
6. There were many people shouting on the road.
7. He loved you more than his life.
8. Who kept this broken glass here?
9. Will he have gone to school?
10. Why are you running this fast?
11. Who all will go with me?
12. Which man’s son works with your dad?
13. I often go to his place/home.
14. Why does he study day and night?
15. He sometimes comes my home.
16. We wake up till late.

[[PDF PAGE 716]]
17. Which car does your friend drive?
18. With whose brother was I dancing?
19. You’ve been searching something since afternoon.
20. I know it will happen.
21. You had gone there.
22. I have seen Ram.
23. His father came to my home.
24. He has told me.
25. Did he say?
26. He never went.
27. Suresh will meet me.
28. We left for school at 7.
29. Children never went.
30. I don’t like this.
31. Ram loves him/her.
32. Everything changes with time.
33. Money changes one’s character.
34. He has found something, probably a pen.
35. I have solved this question before as well.
36. He waited for me for 4 hours.
37. Why do children not keep quiet?
38. I searched him everywhere.
39. He made his way himself.
40. Nobody said to me, I did myself.
41. He is bothering me.
42. People had come.
43. I have seen him here quite often.
44. Ram doesn’t do.
45. He told me everything.
46. He has been studying continuously for many days.
47. I hadn’t thought so.
48. He will be studying at this time/moment.
49. I didn’t ask anything at all.
50. We were watching a movie, when he came.
```

## Test – 11

```text
[[PDF PAGE 717]]
Test – 11
Q1: Translate the following sentences into English:                 50 x 1 = 50
1. 5 साल ह गये हैं । (5 saal ho gaye hain.)
2. उसे कई साल ह गये हैं । (Use kaee saal ho gaye hain)
3. राम क खत्म करने में बहत समय लगा। (Ram ko khatam karne mai bahut samay laga.)
4. तुम्हें कम समय लगेगा। (Tumhe kam samay lagega.)
5. मुझे 2 प्रदन लगे। (Mujhe 2 din lage.)
6. बच् ों की छु ट्टी है आज। (Bachcho kee chutti hai aaj.)
7. िहाूँ पहूँ चने में 2 प्रदन लगते हैं । (Vahan pahuchne mai 2 din lagte hain.)
8. तुम्हारी सालप्रगरह कब है ? (Tumhaari salgirah kab hai?)
9. उसे कािी समय ह गया है । (Use kaafi samay ho gaya hai.)
10. बाररश ह रही थी। (Baarish ho rahi thi.)
11. क्या ये क ई प्रगट है ? (Kya yai koi gift hai?)
12. 8 प्रदन ह गये थे। (8 din ho gaye the.)
13. शायद कल बाररश ह गी। (Shayad kal baarish hogi.)
14. परस ों ओले पाे थे । (Parson ole pade the.)
15. मेरा जन्मप्रदन था। (Mera janamdin tha.)
16. आज कुछ है । (Aaj kuch hai.)
17. ये प्रकताब पिते हए मुझे 3 महीने ह चु के हैं । ( Yai kitaab padhte huwe mujhe 3
   maheene ho chuke hai.)
18. कल स्कुल की छु ट्टी ह गी। (kal school ki chutti hogi.)
19. आज ओले पक्का पाें गे। (Aaj ole pakka padenge.)
20. कािी समय ह गया था। (Kaafi samay ho gya tha.)
21. क्या उस प्रदन कुछ था? (Kya us din kuch tha?)
22. उस प्रदन स मिार था। (Us din somvaar tha.)
23. मुझे यहाूँ रहते हए 10 साल ह गये हैं । (Mujhe yahan rehte huwe 10 saal ho gaye hain.)
24. तुम पर प्रनभि र करता है । (Tum par nirbhar karta hai.)
25. कई सप्रदयाूँ बीत गई हैं । (Kaee sadiyan beet gayi hain.)
26. इतनी बाररश क्य ों ह ती है यहाूँ ? (Itni baarish kyun hoti hai yahan?)
27. ये करते हए हमें 2 साल ह चु के थे। (Yai karte huwe hume 2 saal ho chuke the.)
28. अगर बाररश हई त मैं भीग जाऊूँगा। (Agar barish hui to mai bheeg jaunga.)
29. स चने की बात है । (Sochne kee baat hai.)
30. जब हम प्रमले थे उस प्रदन बाररश ह रही थी। (Jab hum mile the us din barish ho rahi
   thi.)
31. उस प्रदन क्या था ? सोंडे या मोंडे? (Us din kya tha? Sunday ya Monday?)
32. उसे ये बताने में समय क्य ों लगा? (Use yai batane mai samay kyun laga?)

[[PDF PAGE 718]]
33. अच्छा लगता है । (Acha lagta hai.)
34. िहाूँ अक्सर बाररश ह ती थी। (Vahan aksar barish hoti thi.)
35. खाना खाये हए हमें कई प्रदन ह गये थे । (Khana khaye huwe hume kai din ho gaye the.)
36. प्रकतने प्रदन ह गये हैं ? (Kitne din ho gaye hain?)
37. बाररश ह सकती थी पर हई नहीों। (Baarish ho sakti thi par hui nahi.)
38. ये कुछ और नहीों तु म्हारी स च है । (Yai kuch aur nahi tumhaari soch hai.)
39. ये अच्छी बात नहीों है । (Yai achi baat nahi hai.)
40. उसे प्रमले हए तु म्हें प्रकतने साल ह गये हैं ? (Use mile huwe tumhe kitne saal ho gaye h?
41. बाररश िहाूँ कभी नहीों ह ती। (Baarish vahan kabhi nahi hotee.)
42. हमें कई प्रदन लग जायें गे। (Hume kaee din lag jaaenge.)
43. ये कुछ और नहीों भ्रष्टाचार है । (Yai kuch aur nahi bharastachaar hai.)
44. ये नाटक दे खे मुझे पू रे 2 महीने ह गये हैं । (Yai natak dekhe mujhe poore 2 mahine ho
    gaye hain.)
45. िहाूँ गये हए तु म्हें प्रकतने साल ह गये । (vahan gaye huwe tumhein kitne saal ho gaye.)
46. परस ों बाररश हई थी। (Parson barish hui thi.)
47. ये कुछ और नहीों पागलपन है । (Yai kuch aur nahi pagalpan hai.)
48. उस प्रदन बाररश जमकर ह गी। (Us din baarish jamkar hogee.)
49. आज ओले पा सकते हैं । (Aaj ole pad sakte hain.)
50. आज बाररश नहीों ह नी चाप्रहए क्य प्रों क मेरी बहन की शादी है । (Aaj barish nahi honi chahiye
    kyunki meri bhen ke shadi hai.)
                                         Answers
  1. It has been 5 years.
  2. It has been many years to him.
  3. Ram took a long to finish.
  4. You will take less time.
  5. I took me 2 days./ I took 2 days.
  6. It’s children’s holiday today.
  7. It takes 2 days to reach there.
  8. When is your anniversary?
  9. It has been a long to him.
  10. It was raining.
  11. Is it some/a gift?
  12. It had been 8 days.
  13. It may/might rain tomorrow.
  14. It had hailed yesterday.
  15. It was my birthday.

[[PDF PAGE 719]]
16. It’s something today.
17. It has been 3 months to me reading this book.
18. It will be school’s off tomorrow.
19. It must hail today. / It will definitely hail today.
20. It had been a long time.
21. Was it something that day?
22. It was Monday that day.
23. It has been 10 years to me living here.
24. It depends on you.
25. It has been many centuries.
26. Why does it rain this much here?
27. It had been 2 years to us doing this.
28. If it rains, I will be drenched.
29. It is a matter to think.
30. The day we had met, it was raining.
31. What was it that day? Sunday or Monday?
32. Why did he take time to tell this?
33. It seems good./It feels good.
34. It used to rain there quite often.
35. It had been many days to us having taken the food.
36. How many days has it been?
37. It could have rained but didn’t.
38. It is nothing else but your thinking.
39. It’s not good.
40. How many years has it been to you having met him?
41. It never rains there.
42. We will take many days. / It’ll take us many days.
43. It is nothing else but corruption.
44. It’s been complete 2 months to me having seen this serial.
45. How many years has it been to you having gone there?
46. It had rained day before yesterday.
47. It is nothing else but obsession.
48. It will rain heavily that day.
49. It may/might hail today.
50. It mustn’t rain as it is my sister’s marriage today.
```

## Test – 12

```text
[[PDF PAGE 720]]
Test – 12
Translate the following sentences into Hindi:                                 50 x 1 = 50
 1. It took me lots of time.
 2. Did it hail there?
 3. Does it make a difference?
 4. How much time will you take?
 5. It has been about a year having seen him.
 6. It was nothing but his vision.
 7. It’s hailing continuously.
 8. It’s hailing intermittantly.
 9. It didn’t make any difference.
 10. It was Monday that day.
 11. It might rain today.
 12. It might change your mind.
 13. It has been years to me having seen you.
 14. It is nothing else but a try.
 15. It was taking long time.
 16. It’s holiday tomorrow.
 17. It takes just 2 minutes to reach home.
 18. Did I take more than 5 minutes?
 19. Will you take much time?
 20. He had taken 3 hours to read the whole book.
 21. Does it matter?
 22. It has been centuries having someone come here.
 23. Will it bother you?
 24. It could have been delayed.
 25. It will be better to go there.
 26. It will be raining there.
 27. It took me a while to repair that mobile.
 28. What does it do?
 29. What is it today?
 30. It’s my birthday.
 31. It wasn’t my cup of tea.
 32. Did it take much of your time?
 33. It can’t bother me.

[[PDF PAGE 721]]
34. It is nothing else but a pen.
  35. It depends on your mentality.
  36. What is it in your pocket?
  37. Why is it taking time? Is it because you are new?
  38. It’s because I don’t know about this.
  39. It’s because I had no knowledge.
  40. Is it a machine kind/sort of?
  41. It is something of that sort.
  42. Is it a mobile kind/sort of?
  43. No, it is nothing of that sort.
  44. Did it really rain heavily?
  45. It is not your cup of tea.
  46. How old is it?
  47. It seems to be very old.
  48. It seemed to be new one.
  49. Should it be told to him?
  50. How can it be improved?
                                             Answers
1. मुझे कािी/बहत समय लगा। (Mujhe kafee/bahut samay laga.)
2. क्या िहाूँ ओले पाे ? (Kya vahan ole pade?)
3. क्या इससे क ई िकि पाता है ? (Kya isse koi farak padhta hai?)
4. तुम्हें प्रकतना समय लगेगा? (Tumhein kitna samay lagega.)
5. उसे दे खे हए करीब एक साल ह गया है । (Use dekhe huwe kareeb ek saal ho gaya hai.)
6. ये कुछ और नहीों बखल्क उसका दृप्रष्टक ण(स च) था। (Yai kuch aur nahi balki uska
    dhristikon(soch) tha.)
7. लगातार ओले पा रहे हैं । (Lagataar ole pad rahe hain.)
8. रुक-रुक कर ओले पा रहे हैं । (Ruk-ruk kar ole pad rahe the.)
9. इससे क ई िकि नहीों पाा। (Isse koi farak nahi pada.)
10. उस प्रदन स मिार था। (Us din somvaar tha.)
11. आज शायद बाररश ह सकती है । (Aaj shayad barish ho sakti hai.)
12. ये बात तु म्हारा मन बदल सकती है । (Yai baat tumhaara man badal sakti hai.)
13. तुम्हें दे खे हए मुझे साल ों ह गए हैं । (Tumhe dekhe huwe mujhe salon ho gaye hain.)
14. ये कुछ और नहीों, एक क प्रशश है । (Yai kuch aur nahi, ek koshish hai.)
15. कािी समय लग रहा था। (Kafee samay lag raha tha.)
16. कल छु ट्टी है । (kal chutti hai.)

[[PDF PAGE 722]]
17. घर पहूँ चने में बस 2 प्रमनट लगते हैं । (Ghar pahuchne mai bas 2 minute lagte hain.)
18. क्या मुझे 5 प्रमनट से ज़्यादा लगे ? (Kya mujhe 5 minute se zyada lage?)
19. क्या तुम्हें बहत समय लगेगा? (Kya tumhe bahut samay lagega.)
20. उसे पूरी प्रकताब पिने में 3 घों टे लगे । (Use poori kitaab padhne me 3 ghante lage.)
21. िकि पाता है क्या? (Farak padhta hai kya?)
22. सप्रदयाूँ बीत गई हैं , यहाूँ क ई आये हए। (Sadiyan beet gayi hain, yahan koi aaye huwe.)
23. क्या ये तुम्हें परे शान करे गा? (Kya yai tumhein pareshan karega.)
24. दे री ह सकती थी। (Deri ho sakti thi.)
25. िहाूँ जाना बेहतर ह गा। (Vahan jaana behtar hoga.)
26. िहाूँ बाररश ह रही ह गी। (Vahan barish ho rahi hogee.)
27. मुझे उस म बाइल क ठीक करने में थ ाा समय लगा। (Mujhe us mobile ko theek karne
    mai thoda samay laga.)
28. ये क्या करता है ? (Ye kya karta hai?)
29. आज क्या है ? (Aaj kya hai?)
30. मेरा जन्मप्रदन है । (Mera janamdin hai.)
31. ये मेरे बस की बात नहीों थी। (Yai mere bas kee baat nahi thi.)
32. क्या इसने तुम्हारा कािी समय प्रलया? (Kya isne tumhaara kafee samay liya?)
33. ये बात मुझे परे शान नहीों कर सकती। (Yai baat mujhe pareshaan nahi kar sakti.)
34. ये कुछ और नहीों, एक पैन है । (Yai kuch aur nahi, ek pen hai.)
35. ये तुम्हारी स च पर प्रनभि र करता है । (Yai tumhaari soch par nirbhar karta hai.)
36. तुम्हारी जे ब में क्या है ? (Tumhaari jeb mai kya hai?)
37. समय क्य ों लग रहा है ? इसप्रलए क्य प्रों क तु म नये ह ? (Samay kyun lag raha hai? Isliye
    kyunki tum naye ho?)
38. इसप्रलए क्य प्रों क मैं इसके बारे में नहीों जानता। (Isliye kyunki mai iske bare mai nahi
    jaanta.)
39. इसप्रलए क्य प्रों क मुझे ज्ञान नहीों था। (Isliye kyunki mujhe gyan nahi tha.)
40. क्या ये क ई मशीन जै सा है ? (Kya yai koi machine jaisa hai.)
41. ये कुछ िै सा ही है । (Yai kuch vaisa hee hai.)
42. क्या ये म बाइल जैसा कुछ है ? (Kya yai mobile jaisa kuch hai.)
43. नही ों, ये उस तरह का कुछ नहीों है । (Nahi, yai us tarah ka kuch nahi hai.)
44. क्या िाकई में भारी बाररश हई? (Kya vakaae mai bharee barish huwi?)
45. ये तुम्हारे बस की बात नहीों है । (Yai tumhaare bas kee baat nahi hai.)
46. ये प्रकतना पु राना है ? (Yai kitna poorana hai?)
47. ये बहत पुराना लगता है । (Yai bahut poorana lagta hai.)
48. ये नया सा लगा। (Yai naya sa laga.)
49. क्या ये बात उसे बतायी जानी चाप्रहए? (Kya yai baat batayi jaani chahiye.)
50. इसे कैसे सु धारा जा सकता है ? (Ise kaise sudhara ja sakta hai?)
```

## Test – 13

```text
[[PDF PAGE 723]]
Test – 13
Q1: Translate the following sentences into English:                 35 x 1 = 35
1. तुम मेरे घर आ सकते थे पर तु म नहीों आये । (Tum mere ghar aa sakte the par tum nahi
    aaye.)
2. हमें आज प्रमलना था। (Hume aaj milna tha.)
3. मुझे उससे बात करनी है । (Mujhe usse baat karni hai.)
4. उसे प्रकसी भी हालत में िहाूँ जाना चाप्रहए। (Use kisi bhi haalat main vahan jaana
    chahiye.)
5. राहल क आना पाे गा। (Rahul ko aana padega.)
6. तुम उसके घर क्य ों जाते थे ? (Tum uske ghar kyun jaate the?)
7. क्या तुम मुझसे प्रमलना चाह गे ? (Kya tum mujhse milna chahoge?)
8. शायद ि आज आये । (Shayad vo aaj aaye.)
9. क्या उसे जाना है ? (Kya use jaana hai?)
10. अगर मैंने तुम्हें दे खा ह ता, क्या तुमसे बात नहीों करता? (Agar maine tumhein dekha hota,
    kya tumse baat nahi karta?)
11. मुझे तुम्हारी ऽरुरत नहीों है , बखल्क मुझे त मेरी माूँ चाप्रहए। (Mujhe tumhaaree zaroorat
    nahi hai, balki mujhe to meri maa chahiye.)
12. उसने कहा था प्रक ि स्कूल नहीों आये गा। (Usne kaha tha ki vo school nahi aayega.)
13. मैं पिने के बजाय खेलना पसन्द करता हूँ । (Main padhne kai bajaye khelna pasand
    karta hun.)
14. मैं पक्का जाऊूँगा िहाूँ । (Main pakka jaunga vahan.)
15. मैं जीतना चाहता था पर कभी जीत नहीों पाया। (Main jeetna chahta tha par kabhi jeet
    nahi paya.)
16. ि खेलना नहीों चाहता। (Vo khelna nahi chahta.)
17. अगर मैं आया, त तुमसे प्रमलूूँगा। (Agar main aaya, to tumse miloonga.)
18. हमें प्यार चाप्रहए, कुछ और नहीों। (Hume pyar chahiye, kuch aur nahi.)
19. शायद बाररश ह रही ह । (Shayad barish ho rahi hai.)
20. उसे प्रकसी की ऽरुरत नहीों है , ि खुद ही कािी है । (Use kisi kee zaroorat nahi hai, vo
    khud hee kafee hai.)
21. तुमने हमेशा मुझे सम्मान प्रदया, मैं भू ल नहीों सकता। (Tumne humehsa mujhe samman
    diya, mai bhool nahi sakta.)
22. चाहे ज ह , हमारा प्यार हमेशा प्रजन्दा रहना चाप्रहए। (Chahe jo ho, humaara pyar
    humesha jinsa rehna chahiye tha.)
23. मुझे उसे प्यार नहीों करना चाप्रहए था। (Mujhe use pyar nahi karna chahiye tha.)
24. शायद ि आये गी। (Shayad vo aaegi.)

[[PDF PAGE 724]]
25. राम यहाूँ क्य ों आता था? (Ram yahan kyun aata tha?)
 26. मैं स्कूल के प्रदन ों में खूब खेला करता था। (Main school kai dino mai khoob khela karta
       tha.)
 27. राकेश क स चना चाप्रहए था। (Rakesh ko sochna chahiye tha.)
 28. क्या पता बस प्रनकल गयी ह । (Kya pata bus nikal gayi ho.)
 29. मैं तुमसे प्रमलने कभी नहीों आ सकता। (Main tumse milne kabhi nahi aa sakta.)
 30. मैं तुमसे कभी नहीों कह सका। (Main tumse kabhi nahi keh saka.)
 31. राम क पैन नहीों चाप्रहए, बखल्क उसे त प्रकताब चाप्रहए। (Ram ko pen nahi chahiye, balki
       use to kitaab chahiye.)
 32. क्या तुम कभी िहाूँ जा पाये ? शायद कभी नहीों। (kya tum kabhi vaha ja paaye? Shayad
       kabhi nahi.)
 33. क्या तुम मेरे प्रलए रुक नहीों सकते ? (Kya tum mere liye ruk nahi sakte?)
 34. क्या तुम्हें कुछ नहीों चाप्रहए? (Kya tumhein kuch nahi chahiye?)
 35. तुम्हारा क्या ख्याल है , मुझे िहाूँ जाना चाप्रहए ? (Tumhaara kya khyaal hai, mujhe vahan
       jaana chahiye?)
Q 2: Write the meaning of the following similar & confusing words:                5x1=5
         i) Cast         ii) Weak       iii) Fond              iv) Story           v) People
          Caste             Week           Found                     Storey          Pupil
Q 3: Write three forms of the following verbs:                                10 x 1 = 10
       Drive, Bite, Ride, Hold, Put, Seek, Drink, See, Read, Teach
                                           Answers
 Q1:
   1. You could have come my home but you didn’t.
   2. We had to meet today.
   3. I have to talk to him.
   4. He must go there at any cost.
   5. Rahul will have to come.
   6. Why did you use to go his home?
   7. Would you like to meet me?
   8. He might come today.
   9. Has he to go?
   10. If I had seen you, wouldn’t I have talked to you?
   11. I don’t need you, rather I need my mom.

[[PDF PAGE 725]]
12. He had said that he would not come to school.
   13. I prefer playing rather than studying. /I prefer to play rather than to study.
   14. I must go there. / I’ll definitely go there.
   15. I wanted to win but I could never.
   16. He doesn’t want to play.
   17. If I come, I will meet you.
   18. We need love, nothing else.
   19. It may/might be raining.
   20. He doesn’t need anyone, he himself is good enough.
   21. You always respected me, I can not forget.
   22. No matter what, our love must remain alive forever.
   23. I shouldn’t have loved her.
   24. She might/may come.
   25. Why did Ram use to come here?
   26. I used to play a lot in school days.
   27. Rakesh should have thought.
   28. Bus may/might have left/gone.
   29. I can never come to meet you.
   30. I could never say to you./ I could never tell you.
   31. Ram doesn’t need a pen, rather he needs a book.
   32. Could you ever go there? Never, I think.
   33. Can’t you wait for me?
   34. Don’t you need anything?
   35. What do you think, should I go there?
Q 2:
        i) Cast कास्ट            - List of people in a drama or film
            Caste कास्ट         - A class (जाप्रत)
        ii) Weak िीक            - कमऽ र
             Week िीक           - सप्ताह
        iii) Fond (िॉन्ड)       - शौकीन
             Found (िाउन्ड)     - Second form of ‚Find‛
        iv) Story (स्ट री)      - कहानी
             Storey (स्ट री)    - प्रकसी प्रबखल्डों ग की मोंप्रजलें
        v) People (पीपल)        -लग
        vi) Pupil (प्यूप्रपल)   - प्रशष्य

[[PDF PAGE 726]]
Q 3:
       Drive   Drove                  Driven
       Bite    Bit                    Bitten
       Ride    Rode                   Ridden
       Hold    Held                   Held
       Put     Put                    Put
       Seek    Sought                 Sought
       Drink   Drank                 Drunk
       See     Saw                    Seen
       Read    Read (रै ड)            Read(रै ड)
       Teach   Taught                 Taught
```

## Test – 14

```text
[[PDF PAGE 727]]
Test – 14
Q1: Translate the following sentences into Hindi:                   50 x 1 = 50
  1. Could he achieve what he wanted?
  2. She would not like to dance with you.
  3. You should have thought about his condition.
  4. Does he need your help?
  5. Did he use to come to your home?
  6. They might have left for school.
  7. Seeta must be studying at this point of time.
  8. He might be coming.
  9. If I had gone there, I would have given him the money.
  10. They are used to such a climate.
  11. Has he to go?
  12. I had told you that I would not go there.
  13. He is used to his car now.
  14. We ought to respect whoever is older than we.
  15. I was watching TV, rather than studying.
  16. They should have left by now.
  17. There should be good weather.
  18. I would rather buy a pen than a pencil.
  19. I already knew that he would win.
  20. I couldn’t protest against Government’s decision.
  21. Can you meet that guy?
  22. There can be anybody.
  23. I don’t love you; rather I love your sister.
  24. I had to fight till the end.
  25. You can’t compare love with anything.
  26. Could you please spare some time for me?
  27. This girl used to meet Ram quite often.
  28. Will he be able to come here?
  29. It must hail tomorrow.
  30. I would rather meet my dad than meet him.
  31. Could I speak with Mr. Batra?
  32. I would get up at 6 when I was a kid.
  33. They didn’t want to meet me.
  34. Mom needed help because she was unwell.
  35. Shall I go?
  36. I wanted my mom not to work.
  37. Mobile couldn’t divert me from my study.
  38. I was used to his abuses.
  39. He prefers singing over dancing.

[[PDF PAGE 728]]
40. Had he loved me, he would have been here.
41. Seeta used to come. She would prepare food and study here.
42. He must leave.
43. If he meets me, I will tell him about you.
44. Had you known the truth, you would have told me.
45. They might have left.
46. It may rain tomorrow.
47. He prefers me over you.
48. It might be a rumour.
49. May I go now?
50. He used to go and I would come.
                                       Answers
1. क्या ि पा सका ज ि चाहता था? (Kya vo paka saka jo vo chahta tha?)
2. ि तु म्हारे साथ डाूँ स नहीों करना चाहे गी। (Vo tumhaare sath dance nahi karna
    chahegi.)
3. तु म्हें उसकी हालत के बारे में स चना चाप्रहए था। (Tumhein uski halat kai bare main
    sochna chahiye tha.)
4. क्या उसे तु म्हारी मदद की ऽरूरत है ? (Kya use tumhaari madad kee zaroorat hai?)
5. क्या ि तु म्हारे घर आता था? (Kya vo tumhaare ghar aata tha?)
6. शायद ि स्कूल के प्रलए प्रनकल गये ह /ों ह ग
                                            ों े। (Shayad vo school kai liye nikal gaye
    ho/honge.)
7. सीता इस िक्त पि रही ह गी। (Seeta is waqt pad rahi hogi.)
8. शायद ि आ रहा ह /ह गा। (Shayad vo aa raha ho/hoga.)
9. अगर मैं िहाूँ गया ह ता, मैंने उसे पै से दे प्रदये ह ते । (Agar mai vahan gaya hota, maine
    use paise de diye hote.)
10. उन्ें इस तरह के मौसम की आदत ह गई है । (Unhe is tarah kai mausam kee aadat
    ho gyi hai.)
11. क्या उसे जाना है ? (Kya use jaana hai?)
12. मैंने तु म्हें बताया था प्रक मैं िहाूँ नहीों जाऊूँगा। (Maine tumhe batay tha ki main vahan
    nahi jaunga.)
13. उसे अपनी कार की अब आदत ह गई है । (Use apni car ki ab aadat ho gayi hai.)
14. हमें अपन ों से बा़ ों का आदर करना चाप्रहए। (Hume apno se bado ka aadar karna
    chahiye.)
15. मैं पिने के बजाय टी िी दे ख रहा था। (Main padne kai bajay TV dekh raha tha.)
16. ि अब तक प्रनकल गये ह ग
                         ों े। (Vo ab tak nikal gaye honge.)
17. िहाूँ अच्छा मौसम ह ना चाप्रहए। (Vahan acha mausam hona chahiye.)

[[PDF PAGE 729]]
18. मैं पै खन्ऱल के बजाय पै न खरीदू ूँ गा। (Main pencil kai bajaye pen khareedunga.)
19. मैं पहले से ही जानता था प्रक ि जीते गा। (Main pehle se hi jaanta tha ki vo jeetega.)
20. मैं सरकार के िैसले के प्रिरूि प्रिद्र ह नहीों कर सका। (Main sarkaar kai faisle kai
   virudh vidroh nahi kar saka.)
21. क्या तु म उस लाके से प्रमल सकते ह ? (Kya tum us ladke se mil sakte ho?)
22. िहाूँ क ई भी ह सकता है । (vahan koi bhi ho sakta hai.)
23. मैं तुम्हें नहीों बखल्क तुम्हारी बहन क प्यार करता हूँ । (Main tumhe nahi balki tumhaari
   bhen ko pyar karta hun.)
24. मुझे अन्त तक लडना था/पाा। (Mujhe ant tak ladka tha/pada.)
25. तु म प्यार की तुलना प्रकसी चीऽ़ के साथ नहीों कर सकते । (Tum pyar ki tulna kisi cheez
   kai sath nahi kar sakte.)
26. क्या आप मेरे प्रलए थ ाा समय प्रनकाल सकते हैं ? (Kya aap mere liye thoda samay
   nikaal sakte hain?)
27. ये लाकी राम से अक्सर (बहत ही ज़्यादा) प्रमलती थी। (Yai ladki Ram se aksar (bahut hi
   zyada) milti thi.
28. क्या ि यहाूँ आ पायेगा? (Kya vo yahaan aa payega?)
29. कल पक्का ओले पाें गे। (Kal pakka ole padenge.)
30. मैं उससे प्रमलने के बजाय अपने पापा से प्रमलूूँगा। (Main usse milne milne kai bajaye
   apne papa se milunga.)
31. क्या मैं प्रम0 बत्रा से बात कर सकता हूँ ? (Kya main Mr Batra se baat kar sakta hun?)
32. मैं 6 बजे उठता था जब मैं एक बच्ा था। (Main 6 baje uthta tha jab main ek bachcha
   tha.)
33. ि मुझसे प्रमलना नहीों चाहते थे । (Vo mujhse milna nahi chahte the.)
34. मम्मी क मदद चाप्रहए थी क्य प्रों क ि बीमार थीों। (Mummy ko madad chahiye thi kyunki
   vo beemar thi.)
35. क्या मुझे जाना चाप्रहए? (Kya mujhe jaana chahiye?)
36. मैं नहीों चाहता था प्रक मेरी मम्मी काम करें । (Main nahi chahta tha ki meri mummy
   kaam karein.)
37. म बाइल मुझे मेरी पिाई से भटका नहीों सका। (Mobile mujhe meri padhai se bhatka
   nahi saka.)
38. मुझे उसकी गाप्रलय ों की आदत पा गयी थी। (Mujhe uski galtiyon ki aadat pad gayi
   thi.)
39. ि डाूँ स करने के बजाय गाने क तिज्ऽ दे ता है । (Vo dance karne kai bajaye gaane ko
   tavaazoo deta hai.)
40. अगर उसने मुझे प्यार प्रकया ह ता, त ि यहाूँ ह ता। (Agar usne mujhe pyar kiya hota,
   to vo yahan hota.)
41. सीता आती थी। खाना बनाती थी और यहाूँ पिती थी। (Seeta aati thi. Khaana banati thi
   or yahaan padhti thi.)

[[PDF PAGE 730]]
42. उसे पक्का चले जाना चाप्रहए। (Use pakka chale jaana chahiye.)
43. अगर ि मुझसे प्रमला, त मैं उसे तु म्हारे बारे में बताऊूँगा। (Agar vo mujhse mila, to mai
   use tumhaare bare mai bataunga.)
44. अगर तु म्हें सच्ाई का पता ह ता, त तु म मुझे बता चु के ह ते। (Agar tumhein sachchai ka
   pata hota, to tum mujhe bata chuke hote.)
45. शायद िे चले गये ह /ों ह ग
                            ों े। (Shayad ve chale gaye ho/honge.)
46. शायद कल बाररश ह /ह गी। (Shayad kal barish ho/hogee.)
47. ि तु म्हारे बजाय मुझे ज़्यादा मानता है । (Vo tumhaare bajaye mujhe zyada manta hai.)
48. यह एक अििाह भी ह सकती है । (Yah ek afwah bhi ho sakti hai.)
49. क्या मैं अब जा सकता हूँ ? (Kya main ab jaa sakta hun?)
50. ि जाता था और मैं आता था। (Vo jaata tha aur main aata tha.)
```

## Test – 15

```text
[[PDF PAGE 731]]
Test – 15
Q1: Translate the following sentences into English:                           20 x 1 = 20
   1. भले ही ये दू ररयाूँ बहत गहरी हैं प्रिर भी तु म मेरे प्रदल के सबसे करीब ह । (Bhale hee ye
       dooriyaan bahut gahri hain fir bhee tum mere dil ke sabse kareeb ho.)
   2. राम न मेरा द स्त था न है । (Ram na mera dost than a hai.)
   3. मैं अभी भी स च रहा हूँ । (Main abhi bhee soch raha hoon.)
   4. ि यही त चाहती है । (Vo yahi to chaahati thi.)
   5. न ि मेरे प्रजतना ग रा था न तु म्हारे प्रजतना काला। (Na wo mere jitana gora tha n
       tumhare jitna kala.)
   6. राम के दस भाई हैं जबप्रक मेरे केिल द । (Ram ke das bhai hai jabki mere kewal do.)
   7. हम सब इस तरह खे लते हैं जै से प्रक भाई भाई ह ।ों (Hum sab esh tarah khelate hai, jaise
       ki bhai bhai hon.)
   8. ि िैसे ही लाा जै सा तु मने उसे प्रसखाया था। (Vo vaise hee lada jaisa tumne use
       sikhayaa tha.)
   9. मैं राजे न्द्र नही ों सलमान हूँ । (Main Rajendra nahi Salmaan hoon.)
   10. मैंने तु म्हें मैसेज भेजा ही था प्रक तु मने कॉल कर दी। (Maine tumhe message behja hee
       tha ki tumane call kar di.)
   11. मैं सब कुछ दे ख सकता हूँ पर नहीों दे ख सकता तु म्हें र ते हए। (Main sub kuch dekh sakta
       hoon par nahi dekh sakta tumhe rote hue.)
   12. उसने प्रकताब तक नहीों ख ली थी पर पास ह गया। (Usne kitab tak nahi kholi thi par
       paas ho gaya.)
   13. मेरे साथ रह ताप्रक कुछ सीख सक । (Mere sath raho taki kuch seekh sako.)
   14. मेरे पास भी पैन नहीों है । (Mere paas bhee pen nahi hai.)
   15. प्रजतनी जल्दी ह सके मेरे घर आओ। (Jitani jaldi ho sake mere gahr aao.)
   16. मेरा ऑप्रिस भी तु म्हारे ऑप्रिस प्रजतना ही दू र है । (Mere office bhee tumhare office
       jitana door hai.)
   17. आसमान के प्रजतना ऊूँचा बन । (Aashmaan ke jitna uncha bano.)
   18. उसका शरीर ल हे की तरह मजबूत था पर प्रदल एक बच्े की तरह प्रनदोष। (Uska sahreer
       lohe ki tarah majaboot tha par dil ek bachhe ki tarah nirdosh.)
   19. बच्े ही नही ों टीचसि भी आये थे । (Bachhe hee nahi teachers bhee aaye the.)
   20. मैं तुम्हें प्रकताब दू ूँ गा पर तब जब तु म इसे र ऽ पि । (Main tumhe kitab dunga par tab
       jab tum ese roz padho.)

[[PDF PAGE 732]]
Q2: Choose the correct alternative:                                 10 x 1 = 10
   1) My father always scolds me ………….. he was Hitler.
      i) Even      ii) However   iii) As though iv) So that               v) None of these
   2) I have not met him ……….
      i) Till now  ii) As Yet iii) So far              iv) Still          v) None of these
   3) Work hard lest you…….fail.
      i) will      ii) should    iii) can              iv) might          v) None of these
   4) I can’t say ……..he will come.
      i) If         ii) That      iii) Whether         iv) as             v) None of these
   5) Either you or he ……….wrong.
      i) Am         ii) Are    iii) Is                 iv) Were           v) None of these
   6) Did you not go there ……….?
      i) also     ii) even   iii) Either               iv) too            v) None of these
   7) Although I am your friend, ………it doesn’t mean you make me fool.
      i) then also ii) yet     iii) however iv) still      v) but
   8) He can’t…….go there.
      i) even    ii) either           iii) yet        iv) still           v) also
   9) He as well as his friends ……….coming.
      i) is        ii) are       iii) were  iv) have been                 v) None of these
   10) Whether he ……..or not, I must go.
       i) comes       ii) came        iii) come       iv) will come       v) None of these
Q3: Correct the following sentences:                                      10 x 2 = 20
   1. I will give you the book provided you will read that daily.
   2. My friends have not reached till now.
   3. I will see whether he is at home.
   4. Read the whole book thoroughly lest you may fail.
   5. Even if he will go, I don’t care.
   6. I am even now thinking about her.

[[PDF PAGE 733]]
7. As soon as Dad came, I started study.
 8. You ordered me as if you are my boss.
 9. Because I lost everything, I am depressed.
 10. While walk, he was studying.
                                     Answers
 Q1:
 1. Even if the differences are quite deep, still you are the closest to my heart.
 2. Ram was neither my friend nor he is.
 3. I am still thinking.
 4. That’s what she wants.
 5. Neither he was as fair as I nor as dark as you.
 6. Ram has 10 brothers whereas/while I have two.
 7. We all play as if we are brothers.
 8. He fought as/the way you had trained him.
 9. I am not Rajendra but Salman.
 10. No sooner had I messaged you than you called.
 11. I can see anything happening but cannot see you crying.
 12. He had not even opened the book but he passed.
 13. Be with me so that you could learn something.
 14. I don’t have a pen either. / Even, I don’t have a pen.
 15. Come my home as soon as possible.
 16. Even my office is as far as your office is.
 17. Be as high/tall as sky.
 18. His body was as strong as Iron but his heart was as innocent as a kid.
 19. Not only students but also teachers had come.
 20. I’ll give you the book provided you read it daily.
Q2: Correct alternative are:
  1. iii) As though
  2. ii) As Yet
  3. ii) should
  4. i) If
  5. iii) Is
  6. iii) either
  7. ii) yet

[[PDF PAGE 734]]
8. i) even
  9. i) is
  10. i) comes
Q3: The correct sentences are:
   1. I will give you the book provided you read that daily.
   2. My friends have not reached yet / as yet.
   3. I will see if he is at home.
   4. Read the whole book thoroughly lest you should fail.
   5. Even if he goes, I don’t care.
   6. I am thinking about her even now. / I am still thinking about her.
   7. As soon as Dad came, I started studying.
   8. You ordered me as if you were my boss.
   9. Since/As/For I lost everything, I am depressed.
   10. While walking, he was studying.
```

## Test – 16

```text
[[PDF PAGE 735]]
Test – 16
Q1: Translate the following sentences into English:                          30 x 1 = 30
   1. मेरा घर तु म्हारे घर प्रजतना ही दू र है । (Mera ghar tumhare ghar jitna hee door hai.)
   2. मैं राहल नहीों र हन हूँ । (Main Rahul nahi Rohan hoon.)
   3. मैं तुम्हारे घर के प्रसिाय कहीों भी जा सकता हूँ । (Main tumhare ghar ke sivaay kahi
       bhee ja sakta hoon.)
   4. तु म न अच्छे ह न बुरे। (Tum na ache ho na bure.)
   5. तु म या त कम्प्प्यूटर ले ल या लै पटाप। (Tum ya to computer lelo ta laptop.)
   6. राम कुछ भी कर सकता है पर प्रकसी का प्रदल नहीों दु खा सकता। (Ram kuch bhee kar
       sakta hai par kisi ka dil nahi dukha sakta.)
   7. तु म एक अच्छे इन्ऱान नहीों ह । मैं भी नहीों। (Tum ek ache insaan nahi ho. Main bhee
       nahi.)
   8. मैं आम नहीों खाता, तुम भी नहीों खाते । (Main aam nahi khata, tum bhee nahi khate.)
   9. भले ही ि कभी स्कूल नहीों गया, प्रिर भी गजब की अोंग्रेऽी ब लता है । (Bhale hi vo kabhi
       school nahi gaya, phir bhee gazab ki angreji bolta hai.)
   10. राकेश के पास कई गाप्रायाूँ है जै से मप्रसिडीऽ, ह न्डा आप्रद। (Rakesh ke paas kai gadiya
       hai jaise Marcedes, Honda aadi,)
   11. ि इतना अच्छा द स्त था प्रक मैं बता नहीों सकता। (Wo itna acha dost tha ki main bata
       nahi sakta.)
   12. तु म उतनी दू र तक कभी नही ों दौा सकते प्रजतना मैं दौा सकता हूँ । (Tum utni door kabhi
       nahi daud sakte jitna mein doud sakta hoon.)
   13. तु म प्रमलने आ सकते ह जब तक मैं ऑप्रिस में हूँ । (Tum milane aa sakte ho jab tak
       main office mein hoon.)
   14. प्रजतनी जल्दी ह सके खाना खा ल । (Jitani jaldi ho sake khana kha lo.)
   15. न मैंने खाया, न प्रपया। (Na mene khaaya, na piya.)
   16. मेहनत कर ताप्रक इग्ऽाम में पास ह सक । (Mehnat karo taki exam mein paas ho
       sako.)
   17. मैं अभी तक उससे नहीों प्रमला हूँ । (Main abhi tak usse nahi mila hoon.)
   18. इस तरह के ल ग प्रकसी से नहीों प्रमलते । (Is tarah ke log kisi se nahi milate hai.)
   19. जब तक तु म मेहनत नहीों करते , सिल नहीों ह गे। (Jab tak tum mehant nahi karte ,
       safal nahi honge.)
   20. चाहे तु म आओ या न आओ, मैं जा रहा हूँ । (Chahe tum aao ya na aao, main ja raha
       hoon.)
   21. मैं कह नही ों सकता ि आयेगा या नहीों। (Main kah nahi sakta wo aayega ya nahi.)

[[PDF PAGE 736]]
22. ि 5000 रु कमा रहा है जबप्रक तु म 10000। (Wo 5000 rup kma raha hai jabki tum
         10000.)
      23. यही त मैंने तु म्हें कहा। (Yahi to mene tumhe kaha.)
      24. न तुमने कुछ कहा, न उसने । (Na tumne kuch kaha, na usne.)
      25. ल ग अभी भी उससे ला रहे हैं । (Log abhi bhee usse lad rahe hai.)
      26. भले ही तु म मुझे पै से दे द , मैं ये नहीों करुूँगा। (Bhale hee tum mujhe paise de do, main
         yeh nahin krunga.)
      27. मैं तुमसे लाने क तै यार हूँ बशते तु म उसे छ ा द । (Main tumse ladne ko tyaar hoon
         beshart tum use chod do.)
      28. अगर तु म प्रदल्री आओ त मुझसे ऽरुर प्रमलना। (Agar tum Delhi aao to mujhse zaroor
         milna.)
      29. मैं िही ों त जा रहा हूँ । (Main vahi to jaa raha hoon.)
      30. तु म न केिल एक भाई ह बखल्क एक प्रपता भी ह । (Tum na kewal ek bhai ho balki ek
         pita bhee ho.)
Q 2: Correct the following sentences if there is an error:              10 X 2 = 20
      1.You don’t like me. I don’t like you too.
      2.If I will go to market, I will meet you.
      3.My hair is black.
      4.Wheather you go or not, I will go to Shimla.
      5.That’s what I am telling you since morning.
      6.He is not only a manager, but a student as well.
      7.He is not in the office since he is unwell.
      8.He is working like a manager.
      9.He has as much pencils as you have.
      10. I, as well as, he are to blame.
                                             Answers
Q1:
      1. My house is as far as your house.
      2. I am not Rahul but Rohan.
      3. I can go anywhere but/except your home.
      4. You are neither good nor bad.
      5. You either take a computer or a laptop.
      6. Ram can do anything but hurt someone.
      7. You are not a good person. Neither do I.

[[PDF PAGE 737]]
8. I don’t eat mango, neither do you.
 9. Even if he never went to school, yet he speaks English fluently.
 10. Rakesh has many cars such as Mercedez, Honda etc.
 11. He was such a good friend that I can’t even tell you.
 12. You can never run as far as I can.
 13. You can come to meet till I am in office.
 14. Eat the food as soon as possible.
 15. Neither I ate nor drank.
 16. Work hard so that you could pass the exam.
 17. I have not met him yet.
 18. Such people don’t meet anyone.
 19. Until/Unless you work hard, can’t succeed.
 20. Whether you come or not, I am going.
 21. I can’t say whether he will come or not.
 22. He is earning Rs 5000 whereas you earn 10000.
 23. That’s what I said to you.
 24. Neither you said anything nor he.
 25. People are still fighting with him.
 26. Even if you give me money, I will not do it.
 27. I am ready to fight you, provided you leave him.
 28. If you visit Delhi, meet me for sure.
 29. That’s where I am going.
 30. You are not only a brother but also a father.
Q 2: The Correct Sentences are:
  1. You don’t like me. I don’t like you either.
  2. If I will go to market, I will meet you.
  3. Already correct.
  4. Whether you go or not, I will go to Shimla.
  5. That’s what I have been telling you since morning.
  6. He is not only a manager, but also a student.
  7. He is not in the office because he is unwell.
  8. He is working as a manager.
  9. He has as many pencils as you have.
  10. I, as well as, he am to blame.
```

## Test – 17

```text
[[PDF PAGE 738]]
Test – 17
Q1: Translate the following sentences into English:                         50 x 1 = 50
 1. समय मत दे ख । (Samay mat dekho.)
 2. यहाूँ से मत जाओ। (Yahaan se mat jao.)
 3. हमें पिने द क्य प्रों क परस ों हमारा पे पर है । (Hame padhne do kyoki parso hamara
     paper hai.
 4. म मबत्ती जला ल । (Mombatti jala lo.)
 5. नीले पै न से ही प्रलख । (Neele pain se hee likho.)
 6. यहाूँ आ जाओ। (Yahaan aa jao.)
 7. इस घर से बाहर प्रनकल जाओ। (Es ghar se bahar nikal jao.)
 8. साि-साि प्रलखने की क प्रशश कर । (Saaf –Saaf likhane ki kosis karo.)
 9. जल्दी ठीक ह जाओ, हमें बहत काम करने हैं । (Jaldi thik ho jao, hame bahut kaam
     karne hain.)
 10. मुद्दे पर आइए क्य प्रों क समय बहत कम है । (Mudde pr aiye kyoki samay bahut kam hai.)
 11. अपना िादा मत त ाना। (Apna wada mat todna.)
 12. तुम खूब मुस्कुराओ। (Tum khub muskrao.)
 13. ऽल्दी कर क्य प्रों क हम लेट ह रहे हैं । (Jaldi karo kyoki hum late ho rahe hain.)
 14. ज़्यादा मत खाओ, पेट िट जाये गा। (Jayaada mat khao, pet fat jaayega.)
 15. जूते पहन ल । (Joote pahan ho.)
 16. कम्बल ओि ल । (Kambal odh lo.)
 17. कम्बल ओि कर स ओ। (Kambal odh ker soo.)
 18. िालतू बात मत कर , प्रदमाग खराब ह ता है । (Faltu baat mat karo, dimag kharab hota
     hai.)
 19. प्रबस्तर लगा ल । (Bistar laga lo.)
 20. उसके बारे में बात मत कर । (Uske bare mein baat mat karo.)
 21. कम से कम पैन त खरीद ल । (Kam se kam pen to khareed lo.)
 22. नोंगे पैर साक पर मत चल । (Nange pair sadak par mat chalo.)
 23. बाकी सब प्रकस्मत पर छ ा द । (Baki sab kismet par chod do.)
 24. बाकी सब मुझ पर छ ा द । (Baki sab mujh par chod do.)
 25. प्रकसी क भी दु ख मत द । (Kisi ko bhee dukh mat do.)
 26. प्रदन में कम से कम एक बार नहा प्रलया कर । (Din mein kam se kam ek baar naha liya
     karo.)
 27. अपनी सु ख सुप्रिधाओों पर ज़्यादा खचि मत कर । (Apni sukh suvidha par zyada kharch
     mat karo.)
 28. पैन में इों क डाल ल । (Pen mein ink daal lo.)

[[PDF PAGE 739]]
29. ब तलें भर ल । पानी आ रहा है । (Bottale bhar lo. Paani aa raha hai.)
30. कार से जल्दी उतर । (Car se jaldi utaro.)
31. िहाूँ जाने की भूल मत करना। (wahaan jaane ki bhool mat karna.)
32. मुझे डाक्टर मत समझ । मैं त चपरासी हूँ । (Mujhe doctor mat samjho. Main to
   chapraashi hoon.)
33. ल ग ों से घु ल प्रमल कर रहा कर । (Logo se ghul mil kar raha karo.)
34. प्रकचन में एक म मबत्ती का पै केट रख ल । (Kitchen me ek mombatti ka packet rakh lo)
35. उसकी कहानी मत सु नाओ, मैं पक गया हूँ । (Uski kahani mat sunao, main pak gaya hu.)
36. िहाूँ प्रबल्कुल मत जाना, िहाूँ कुछ नहीों है । (Vahan bilkul mat jana, wahan kuchh nahi h.)
37. मुझसे मत कप्रहए, क ई िायदा नहीों। (Mujhse mat kahiye, koi fayada nahi.)
38. दरिाजा बन्द मत कर । (Darwaza band mat karo.)
39. थ ाा सा पानी दे द । (Thoda sa paani dedo.)
40. थ ाी प्रकताबें रख ल । (Thodi kitabe rakh lo.)
41. थ ाी चाय दे दीप्रजए। (Thodi chaaye de dijiye.)
42. लाइट ऑि मत कर । (Light off mat karo.)
43. म बाइल क सायलेन्ट म ड में रख । (Mobile ko silent mode mein rakho.)
44. पहले उसे जाने द । (Pahale use jaane do.)
45. कम्प्प्यूटर ऑन करने की गलती मत करना। (Computer on karne ki galti mat karna.)
46. मेरे साथ साथ चल । (Mere sath sath chalo.)
47. दायीों तरि चल । (Daayi taraf chalo.)
48. मेरा हाथ पका ल । (Mera hath pakad lo.)
49. कल्पना कर प्रक तुम प्रकसी पहाा पर ह । (Kalpana karo ki tum kisi pahad par ho.)
50. अोंदाजा मत लगाओ। (Andaza mat lagao.)
                                       Answers
 1. Don’t see the time.
 2. Don’t go from here.
 3. Let us study as it is our paper day after tomorrow.
 4. Light the candle.
 5. Write only with a blue pen.
 6. Come here.
 7. Go out of this home.
 8. Try to write clear / legible.
 9. Get well soon, we have lots of work to do.
 10. Come to the point as we have less time.
 11. Don’t back out of your promise.
 12. I wish you smile a lot.

[[PDF PAGE 740]]
13. Hurry up as we are getting late.
14. Don’t overeat, stomach might blow up.
15. Put on the shoes.
16. Take a blanket.
17. Sleep with a blanket.
18. Don’t talk rubbish/nonsense, I am fed up.
19. Make the bed.
20. Don’t talk about him/her.
21. At least purchase a pen.
22. Don’t walk bare footed on the road.
23. Leave rest on luck/destiny/God.
24. Leave rest on me.
25. Don’t hurt anyone.
26. Take a bath at least once in a day.
27. Don’t spend a lot on your luxuries.
28. Put the ink into the pen.
29. Fill the bottles. Water is running.
30. Quickly get off the car.
31. Don’t mistake to go there.
32. Don’t mistake me the doctor. I am a peon.
33. Mingle with people.
34. Keep a packet of candles in kitchen.
35. Don’t tell me his story, I am fed up / bored / tired.
36. Don’t go there at all, there is nothing.
37. Don’t tell me, it is of no use.
38. Don’t shut the door.
39. Give me some water. / Give me a little water.
40. Keep a few books.
41. Give me some/a little tea.
42. Don’t turn/switch off the light.
43. Keep the mobile in silent mode.
44. Let him go first.
45. Don’t mistake to switch on the computer.
46. Walk with me. / Pace with me. /Follow me.
47. Walk to the right.
48. Hold my hand.
49. Imagine that (as if) you are in a mountain.
50. Don’t guess.
```

## Test – 18

```text
[[PDF PAGE 741]]
Test – 18
Q1: Translate the following sentences into Hindi:                       50 x 1 = 50
   1. Let me find out what he has.
   2. Sometimes try to visit him.
   3. He dropped in to my place.
   4. Always be nice to people.
   5. Don’t do it. You’ll repent sooner or later.
   6. Kindly do the needful.
   7. Don’t lisp.
   8. Do it because you are good at it.
   9. Teach them something.
   10. Look at me.
   11. Have a look at it.
   12. Have something.
   13. Have a look at this page.
   14. Get off the car.
   15. Always behave like a literate.
   16. Don’t misbehave with others.
   17. Don’t defame me.
   18. Never give up.
   19. Switch on the mobile after a while.
   20. Put on new clothes & take off the old ones.
   21. Be my friend.
   22. Don’t befool me.
   23. Remind me of it tomorrow.
   24. Love your real ones.
   25. Don’t scold that kid.
   26. Bear the charges yourself.
   27. Don’t watch such movies.
   28. Repair it as soon as possible.
   29. Let me purchase something for her.
   30. Let me tell you something.
   31. Be regular in gym.
   32. Always believe in yourself.
   33. Kindly help the poor.

[[PDF PAGE 742]]
34. Don’t rip off the people.
 35. Do good deed.
 36. Let his father come.
 37. Come and play with us.
 38. Go and meet him.
 39. Just do it, don’t think much.
 40. Wash the utensils.
 41. Hang this poster on the wall.
 42. Keep on the right.
 43. Let go.
 44. Let him try.
 45. Count the stars.
 46. Kindly meet me today.
 47. Have atleast one burger.
 48. Have a little food with me.
 49. Have some water.
 50. Let God decide what we achieve in life.
                                      Answers
1. मुझे पता लगाने द प्रक उसके पास क्या है । (Mujhe pata lagane do ki uske paas kya h.)
2. कभी-कभी उसके यहाूँ जाने की क प्रशश कर । (Kabhi-kabhi uske yahaan jane ki kosis
   karo.)
3. ि मेरे यहाूँ टपक गया/आया। (Vo mere yahan tapak gaya.)
4. हमेशा ल ग ों के प्रलए अच्छे बन । (Hamesha logo ke liye ache bano.)
5. ऐसा मत कर । तुम आज नहीों त कल पछताओगे। (Esa mat karo. Tum aaj nahi to kal
   pachtaoge.)
6. कृपया ये कर दीप्रजए। (Kripya ye kar dijiye.)
7. मत तुतलाओ। (Mat tutlao.)
8. ये कर क्य प्रों क तुम ये करने में अच्छे ह । (Ye karo kyoki tum ye karne mein ache ho.)
9. उन्ें कुछ पिाओ। (Unhe kuch padhao.)
10. मुझे दे ख । (Mujhe dekho.)
11. इसे दे ख । (ese dekho.)
12. कुछ ल /कुछ खाल । (Kuch lo/ Kuch khalo.)
13. इस पेज क दे ख । (Es page ko dekho.)
14. कार से उतर । (Car se utaro.)
15. हमेशा पिे प्रलखे इन्ऱान जैसा व्यिहार कर । (Hamesha padhe likhe insaan jaisa
   vayvhaar karo.)

[[PDF PAGE 743]]
16. प्रकसी के साथ गलत व्यिहार मत कर । (Kisi ke sath galat vayvhaar mar karo.)
17. मुझे बदनाम मत कर । (Mujhe badnaam mat karo.)
18. कभी हार मत मान । (Kabhi haar mat maano.)
19. थ ाी दे र में म बाइल ऑन कर दे ना। (Thodi der mein mobile on kar dena.)
20. नये कपाे पहन , पुराने कपाे उतार द । (Naye kapde pehno, purane kapde utaar do.)
21. मेरे द स्त बन ।/मेरे द स्त बने रह । (Mere dost bano/ mere dost bane raho.)
22. मुझे बेिकूि मत बनाओ। (Mujhe bewkuf mat banao.)
23. मुझे कल इसकी याद प्रदलाना। (Mujhe kal eski yaad dilana.)
24. अपन ों क प्यार कर । (Apno ko pyaar karo.)
25. उस बच्े क मत डाूँ ट (Us bachhe ko mat dato.)
26. खचाि अपने आप उठाओ। (Kharcha apne aap uthao.)
27. ऐसी प्रिल्में मत दे खा कर । (Esy film mat dekha karo.)
28. प्रजतनी जल्दी ह सके इसे ररपे यर/ठीक कर द । (Jitani jaldi ho sake ese thik kar do.)
29. मुझे उसके प्रलए कुछ खरीदने द । (Mujhe uske liye kuch khareedne do.)
30. मुझे तुम्हें कुछ बताने द । (Mujhe tumhe kuch batane do.)
31. प्रजम हमेशा जाओ। (GYM hamesha jao.)
32. हमेशा अपनी काप्रबप्रलयत पे प्रिश्वास रख । (Hamesha apni kabiliyat pe vishvaash rakho.)
33. कृपया गरीब ों की मदद कर । (Kripya gareebo ki madad karo.)
34. ल ग ों क मत लूट । (Logo ko mat luto.)
35. अच्छे कमि कर । (Ache karm karo.)
36. उसके प्रपता क आने द । (Uske pita ko aane do.)
37. आओ हमारे साथ खेल । (Aao hamare sath khelo.)
38. जाओ उससे प्रमल । (Jao usse milo.)
39. बस कर द , ज़्यादा मत स च । (Bus kar do, jayaada mat socho.)
40. बतिन ध ओ। (Bartan dhoo.)
41. इस प स्टर क दीिार पर लटका द । (Es postar ko deewar par latka do.)
42. दायें चल ।/दायीों तरि रह । (Daaye chalo/ dayi taraf raho.)
43. जाने द । (Jaane do.)
44. उसे क प्रशश करने द । (Use koshish karne do.)
45. तारे प्रगन । (Taare gino.)
46. प्लीऽ आज मुझसे प्रमल ल ।(Please aaj mujhse mil lo.)
47. कम से कम एक बगिर त खाओ। (Kam se kam ek burger to khao.)
48. मेरे साथ थ ाा खाना खा ल । (Mere sath thoda khana kha lo.)
49. थ ाा पानी पील । (Thoda paani peelo.)
50. भगिान क िैसला करने द प्रक हमें जीिन में क्या प्रमले। (Bhagwan ko faisla karne do ki
    hume jeevan mein kya mile.)
```

## Test – 19

```text
[[PDF PAGE 744]]
Test – 19
Q1: Translate the following sentences into Hindi:                   30 x 1 = 30
     1. I will let him meet her.
     2. They don’t let you work.
     3. She doesn’t let you write.
     4. Dad wasn’t letting me go.
     5. Will you please let us play?
     6. I will let you take this book provided you give money.
     7. Then, I might let you go there.
     8. Dad doesn’t let me sing.
     9. I will not let you do this.
     10. Why did you let me go?
     11. You never let us go.
     12. I will not let you beat my brother.
     13. They will never let you win.
     14. You didn’t let him study that’s why he failed.
     15. Government can never let us do this.
     16. Mom didn’t let dad scold me.
     17. Mom lets me eat whatever I want.
     18. You didn’t even let us talk.
     19. Ram doesn’t let me go either.
     20. I’ll neither let you write nor read.
     21. We’ll not let you enter even once.
     22. I’ll let you purchase provided you don’t tell you dad.
     23. She lets only Ram eat in the class.
     24. He doesn’t let me eat.
     25. Let me go with people.
     26. Ram will never let you earn profit.
     27. Why did he let me do this?
     28. He doesn’t let go.
     29. Either you do yourself or let me do.
     30. My financial problem doesn’t let me do business.
                                          Answers
 1. मैं उसे उससे प्रमलने दू ूँ गा। (Main use usse milane doonga.)
 2. िे तुम्हें काम नहीों करने दे ते। (Ve tumhe kaam nahi karne dete.)
 3. ि तुम्हें प्रलखने नहीों दे ती । (Vo tumhe likhane nahi deti.)

[[PDF PAGE 745]]
4. पापा मुझे जाने नहीों दे रहे थे। (Papa mujhe jaane nahi de rahe the.)
5. क्या तुम प्लीऽ हमें खेलने द गे ? (Kya tum please hame khelane doge.)
6. मैं तुम्हें ये प्रकताब लेने दू ूँ गा बशतें तु म पै से दे द । (Main tumhe ye kitab lene dunga
    beshart tum paise de do.)
7. तब शायद मैं तुम्हें िहाूँ जाने दू ूँ । (Tab shayad main tumhe vahaan jaane doon.)
8. पापा मुझे गाने नहीों दे ते। (Papa mujhe gaane nahi dete.)
9. मैं तुम्हें ये नहीों करने दू ूँ गा । (Main tumhe ye nahi karne doonga.)
10. तुमने मुझे जाने क्य ों प्रदया ? (Tumane mujhe jaane kyu diya.)
11. तुम हमें कभी जाने नहीों दे ते। /तुमने हमें कभी जाने नहीों प्रदया। (Tum hame kabhi jaane nahi
    dete/ tumne hame kabhi jaane nahi diya.)
12. मैं तुम्हें अपने भाई क पीटने नहीों दू ूँ गा । (Main tumhe apne bahi ko pitane nahi dunga.)
13. िे तुम्हें कभी जीतने नहीों दें गे। (Ve tumhe kabhi jeetane nahi denge.)
14. तुमने उसे पिने नहीों प्रदया इसप्रलए ि िेल ह गया । (Tumane use padhne nahi diya
    esliye vo fail ho gaya.)
15. सरकार हमें ये कभी नहीों करने दे सकती । (Sarkar hame ye kabhi nahi karne de sakti.)
16. मम्मी ने पापा क मुझे डाूँ टने नहीों प्रदया । (Mummy ne papa ko mujhe dantne nahi
    diya.)
17. मम्मी मुझे खाने दे ती है ज कुछ मैं चाहता हूँ । (Mummy mujhe khaane deti hai jo kuch
    mein chaahta hoon.)
18. तुमने हमें बात तक नहीों करने दी। (Tumne hame baat tak nahi karne di.)
19. राम भी मुझे जाने नहीों दे ता । (Raam bhee mujhe jaane nahi deta.)
20. न मैं तुम्हें प्रलखने दू ूँ गा न पिने । (Na main tumhe likhne doonga na padhne.)
21. हम तुम्हें एक बार भी नहीों घु सने दें गे। (Hum tumhe ek baar bhee nahi ghusane denge.)
22. मैं तुम्हें खरीदने दू ूँ गा पर तब जब तु म पापा क न बताओ। (Main tumhe khareedne
    doonga par tab jab tum papa ko na btao.)
23. ि क्लास में केिल राम क खाने दे ती है । (Vo class mein kewal raam ko khana deti hai.)
24. ि मुझे खाने नहीों दे ता । (Vo mujhe khaane nahi deta.)
25. मुझे ल ग ों के साथ जाने द । (Mujhe logo ke sath jaane do.)
26. राम आपक मुनािा कभी नहीों कमाने दे गा । (Ram apko munafa kabhi nahi kamane
    dunga.)
27. उसने मुझे ये क्य ों करने प्रदया ? (Usne mujhe ye kyon karne diya?)
28. ि जाने नही ों दे ता । (Vo jaane nahi deta.)
29. या त तु म खुद कर या मुझे करने द । (Ya to tum khud karo ya mujhe karne do.)
30. मेरी आप्रथिक परे शानी मुझे व्यिसाय नहीों करने दे ती। (Meri arthik paresaani mujhe
    vayvsaay nahi karne deti.)
```

## Test – 20

```text
[[PDF PAGE 746]]
Test – 20
Q1: Translate the following sentences into English:                              30 x 1 = 30
 1. राहल ने प्रकसी क भी उसकी लाश क छु ने नही ों प्रदया । (Rahul ne kisi ko bhee uski lash
     ko chune nahi diya.)
 2. मेरे अपन ों ने कभी मुझे ये महसू स नहीों ह ने प्रदया प्रक मैं अकेला हूँ । (Mere apno ne kabhi
     mujhe ye mehsoos nahi hone diya ki main akela hoon.)
 3. उसने तु म्हें मुझसे क्य ों नहीों प्रमलने प्रदया ? (Usne tumhe mujhse kyo nahi milane diya.)
 4. िक्त ने कभी मुझे इस बारे में स चने नहीों प्रदया । (Waqt ne kabhi mujhe es baare mein
     sochane nahi diya.)
 5. पापा मुझे कार नहीों खरीदने दें गे। (Papa mujhe car nahi khareedne denge.)
 6. मैं िादा करता हूँ , मैं अपने जीते जी तु म्हें कभी झुकने नहीों दू ूँ गा। (Main wada karta hoon,
     main apne jeete jee tumhe kabhi jhukne nahi doonga.)
 7. हम सब उसे जाने नहीों दें गे। (Hum sab use jaane nahi denge.)
 8. हमें बच् ों क खे लने दे ना चाप्रहए। (Hame bachho ko khelane dena chahiye.)
 9. हमें िहाूँ जाने द । (Hame wahaan jaane do.)
 10. मुझे ये कहने द । (Mujhe ye kehane do.)
 11. उसे राहल के साथ प्रबल्कुल मत जाने द । (Use Rahul ke sath bilkul mat jaane do.)
 12. मुझे घाी दे खने द । (Mujhe ghadi dekhane do.)
 13. मामाजी क घर िापस आने द , तब बात करें गे। (Mamaji ko ghar vapas aane do, tab
     baat karenge.)
 14. ल ग
       ों क ज कहना है , कहने द । (Logo ko jo kehna hai, kehne do.)
 15. रात क गुऽर जाने द । (Raat ko guzar jaane do.)
 16. सभी क आ जाने द । (Sabhi ko aa jane do.)
 17. एक बार मेरे सपने क सच ह जाने द । (Ek bar mere sapne ko sach ho jaane do.)
 18. मुझे उस लाकी से शादी करने द । (Mujhe us ladki se saadi karne do.)
 19. हमें उसके घर जाने द । (Hame uske ghar jaane do.)
 20. मुझे कम्प्प्यूटर सीख लेने द । (Mujhe computer seekh lene do.)
 21. बच् ों क आ जाने द । (Bachho ko aa jaane do.)
 22. पापा क ऑप्रिस चले जाने द । प्रिर हम खे लेंगे। (Papa ko office chale jaane do. Fir hum
     khelenge.)
 23. मुझे उससे प्रमल लेने द । (Mujhe usse mil lene do.)
 24. उन्ें तै यार ह जाने द । (Unhe tyaar ho jaane do.)
 25. मैंने तुम्हें उस प्रदन आने नहीों प्रदया। मुझे बेहद अिस स है । (maine tumhe us din aane
     nahi diya. Mujhe behad afsoos hai.)
 26. बाल्टी में पानी भरने द । (Balti mein paani bharne do.)

[[PDF PAGE 747]]
27. बाल्टी क पूरा भरने द । (Balti ko poora bharne do.)
28. ज ह ता है , ह ने द । (Jo hota hai, hone do.)
29. याप्रत्रय ों क िहाूँ पहूँ चने त द । (Yaatriyo ko vahaan pahuchane do.)
30. मेरी बात पू री ह ने द , प्रिर तु म अपनी बात रखना। (Meri baat poori hone do, phir tum
   apni baat rakhna.)
                                        Answers
 1. Rahul didn’t let anyone touch his dead body.
 2. My real ones never let me feel that I was alone.
 3. Why didn’t he let you meet me?
 4. Time never let me think about it.
 5. Dad will not let me purchase a car.
 6. I promise that I will never let you down till I’m alive.
 7. We all won’t let him go.
 8. We should let children play.
 9. Let us go there.
 10. Let me say this.
 11. Don’t ever let him go with Rahul.
 12. Let me see the watch.
 13. Let Maternal uncle return, then we’ll talk.
 14. Let people say whatever they want to.
 15. Let the night passby.
 16. Let everyone come.
 17. Let my dream come true once.
 18. Let me marry that girl.
 19. Let us go his home.
 20. Let me learn computer.
 21. Let children come.
 22. Let Dad go to office. Then we’ll play.
 23. Let me meet him/her.
 24. Let them get ready.
 25. I didn’t let you come that day. I am so sorry.
 26. Let the bucket be filled.
 27. Let the bucket be fully filled.
 28. Let it happen, whatsoever it is.
 29. Let passenger reach there at least.
 30. Let me complete, then you lay/put your point.
```

## Test – 21

```text
[[PDF PAGE 748]]
Test – 21
Q1: Translate the following sentences into Hindi:             50 x 1 = 50
 1. I got it done myself.
 2. Can you make him come?
 3. Ram made him go.
 4. People makes you fool.
 5. Pen made me remember you.
 6. They should not make you work in place of study.
 7. Get me something to read.
 8. He got me nothing to eat.
 9. Rohit is making me understand.
 10. He used to make me eat the food.
 11. By whom will you get this done?
 12. Rahul got the bucket filled by me.
 13. He makes only me write his homework.
 14. My circumstances made me work there.
 15. Your thinking got you good money.
 16. He makes you smile.
 17. I made him join there.
 18. Computer was got repaired.
 19. He made me drink coke.
 20. Do you want to get this done by me?
 21. I made him beat Rahul.
 22. I made Rahul beat him
 23. I am getting the hair cut.
 24. I couldn’t make you feel happy.
 25. Seeta makes Ram cry.
 26. He can never make me go there.
 27. I got this mobile repaired by Sagar.
 28. He was making me understand.
 29. Saleem made Sagar call Rahul.
 30. Saleem made Sagar come.
 31. Why are you making us fool?
 32. I will make him fool.
 33. They both make her do their homework.
 34. Aren’t you getting food prepared?
 35. Life is making me go where I don’t want to.
 36. As soon as Dad came, he made us work.
 37. Mom makes us feel comfortable.
 38. He makes us feel that we are nothing.

[[PDF PAGE 749]]
39. Ram made us realize how important money is.
40. You make me realize how bad I am.
41. I am trying to make to understand.
42. I have to get this work done.
43. From where did you get the hair cut?
44. Life will make you realize one day.
45. That boy makes me angry.
46. I was in the exam. He got me the answers.
47. Such incidences make us realize.
48. Nobody can make you fool.
49. How can you make him go there?
50. You made me tell a lie.
                                          Answers
1. मैंने ये खु द करिाया। (Maine ye khud karvaaya.)
2. क्या तुम उसे बुलिा सकते ह ? (Kya tum use bulwa sakte ho?)
3. राम ने उसे प्रभजिाया। (Ram ne use bhijvaaya.)
4. ल ग तुम्हें बेिकूि बनाते हैं । (Log tumhe bewkoof banate hai.)
5. पैन ने मुझे तु म्हारी याद प्रदलाई। (Pen ne mujhe tumhari yaad dilayi.)
6. उन्ें तु मसे पिाई के बजाय काम नही ों करिाना चाप्रहए। (Unhe tumse padhai ke bajaaye
    kaam nahi karvana chahiye.)
7. मुझे पिने क कुछ प्रदलिा द । (Mujhe padhne ko kuch dilwa do.)
8. उसने मुझे खाने क कुछ नहीों प्रदलिाया। (Usne mujhe khane ko kuch nahi dilwaya.)
9. र प्रहत मुझे समझा रहा है । (Rohit mujhe samjha raha hai.)
10. ि मुझे खाना खखलिाता था। (Vo mujhe khana khilwata tha.)
11. तुम ये प्रकससे करिाओगे ? (Tum ye kisse karwaaoge.)
12. राहल ने मुझसे पानी भरिाया। (Rahul ne mujhse paani bharwaya.)
13. ि केिल मुझसे अपना ह मिकि प्रलखिाता है । (Vo kewal mujhse apna homework
    likhwata hai.)
14. मेरे हालात ों ने मुझसे िहाूँ काम करिाया। (Mere halato ne mujhse vahaan kaam
    karwaaya.)
15. तुम्हारी स च ने तु म्हें अच्छा पैसा प्रदलिाया। (Tumhari soch ne tumhe acha paise
    dilwaya.)
16. ि तुम्हें हूँ साता है । ( Vo tumhe hansata hai.)
17. मैंने उसे िहाूँ जॉईन करिाया। (Maine use wahaan join karvaya.)
18. कम्प्प्यूटर ठीक करिाया गया। (Computer thik karvaaya gaya.)
19. उसने मुझे क क प्रपलाई/प्रपलिाई। (Usne mujhe cock pilaee/ pilvaee.)
20. क्या ये तुम मुझसे करिाना चाहते ह ? (Kya ye tum mujhse karvaana chahate ho?)
21. मैंने राहल क उससे प्रपटिाया। (Mene Rahul ko usse pitvaaya.)

[[PDF PAGE 750]]
22. मैंने उसक राहल से प्रपटिाया। (Mene usko Rahul se pitvaaya.)
23. मैं बाल कटिा रहा हूँ । (Main baal katva raha hoon.)
24. मैं तुम्हें खु श नहीों कर पाया। (Main tumhe khush nahi kar paya.)
25. सीता राम क रूलाती है । (Seeta Ram ko rulati hai.)
26. ि मुझे िहाूँ कभी नहीों प्रभजिा सकता। (Vo mujhse vahaan kabhi nahi bhijwa sakta.)
27. मैंने ये म बाइल सागर से ठीक करिाया। (Mene ye mobile sagar se thik karvaaya.)
28. ि मुझे समझा रहा था। (Vo mujhe samajh raha tha.)
29. सलीम ने राहल क सागर से कॉल करिायी। (Saleem ne Rahul ko Sagar se call
    karvaee.)
30. सलीम ने सागर क बुलिाया। (Saleem ne Sagar ko bulvaaya.)
31. तुम हमें बेिकूि क्य ों बना रहे ह ? (Tum hame bewkoof kyo bana rahe ho.)
32. मैं उसे बेिकूि बनाऊूँगा। (Main use bewkoof banaunga.)
33. ि द न ों उससे अपना ह मिकि करिाते हैं । (Vo dono usse apna homework karvate hai.)
34. क्या तुम खाना नहीों बनिा रहे ? (Kya tum khana nahi banwa rahe.)
35. प्रऽन्दगी मुझे िहाूँ प्रभजिा रही है , जहाूँ मैं जाना नहीों चाहता। (Zindagi mujhe vahaan bhijwa
    rahi hai.)
36. जैसे ही पापा आये , उन् न
                           ों े हमसे काम करिाया । (Jaise hee papa aaye, unhone hamse
    kaam karvaya.)
37. माूँ हमें आराम महसू स करिाती है । (Maa hame aaram mahsoos karvati hai.)
38. ि हमें महसू स करिाता है प्रक हम कुछ नहीों हैं । ( Vo hame mehsoos karvata hai ki hum
    kuch nahi hai.)
39. राम ने हमें महसूस करिाया प्रक पै सा क्या मायाने रखता है । (Ram ne hame mehsoos
    karvaaya ki paisa kya maayne rakhta hai.)
40. तुम मुझे अहसास प्रदलाते ह प्रक मैं प्रकतना बुरा हूँ । (Tum mujhe ahsaas dilate ho ki main
    kitna bura hoon.)
41. मैं तुम्हें समझाने की क प्रशश कर रहा हूँ । (Main tumhe samjhane ki kosis kar raha
    hoon.)
42. मुझे ये काम करिाना है । (Mujhe ye kaam karvana hai.)
43. तुमने बाल कहाूँ से कटिाये ? (Tumne baal khaan se katvaye.)
44. प्रऽन्दगी तुम्हें एक प्रदन महसू स करिाये गी। (Zindagi tumhe ek din mehsoos karvaegi.)
45. ि लाका मुझे गुस्सा प्रदलाता है । (Vo ladka mujhe gussa dilata hai.)
46. मैं इग्ऽाम में था। उसने मुझे उत्तर प्रदलिाये । (Main exam mein tha. Usne mujhe uttar
    dilvaye.
47. ऐसी घटनाएूँ हमें महसूस करिाती है । (Esy ghatnaaye hume mehsoos karvati hai.)
48. तुम्हें क ई भी बेिकूि नहीों बना सकता । (Tumhe koi bhee bewkoof nahi bana sakta.)
49. तुम उसे िहाूँ कैसे प्रभजिाओगे ? (Tum use vahaan kaise bhijwaoge.)
50. तुमने मुझसे झूठ बुलिाया। (Tumne mujhse jooth bulvaya.)
```

## Test – 22

```text
[[PDF PAGE 751]]
Test – 22
Q1: Translate the following sentences into Hindi:              30 x 1 = 30
   1. Child made me come.
   2. Rahul had got the work done.
   3. I wanted to make you meet Seeta.
   4. I must get the work done by you.
   5. You can make me do this.
   6. I will make them go somewhere else.
   7. We have to get the hair cut.
   8. Ram used to make me go.
   9. I have to get mom a saree.
   10. Ram will get it done himself.
   11. Children will make you happy.
   12. Papa got me a watch.
   13. Friend made me meet his family members.
   14. I had made Rahul purchase a pen.
   15. Why did he get the hair cut from there?
   16. I made my mom apply Mahendi onto my hair.
   17. He made me spend money.
   18. You always make me cry.
   19. I can make him laugh.
   20. Meet him lest he should make you go America.
   21. Get the food cooked.
   22. Get the poor few clothes.
   23. You must get us something.
   24. Make me meet him once.
   25. Make us listen to this story once.
   26. Make Ram come from there lest he should die.
   27. I got my heart broken.
   28. Don’t make me fool.
   29. He is making us laugh.
   30. They were making us fight each other.

[[PDF PAGE 752]]
Answers
1. बच्े ने मुझे बुलिाया। (Bachhe ne mujhe bulvaya.)
2. राहल ने काम करिाया था। (Rahul ne kaam karvaaya tha.)
3. मैं तुम्हें सीता से प्रमलिाना चाहता था। (Main tumhe sita se milvana chahta tha.)
4. मुझे तुमसे काम ऽरूर करिाना चाप्रहए। (Mujhe tumse kaam zaroor karvana chahiye.)
5. तुम मुझसे ये करिा सकते ह । (Tum mujhse ye karva sakte ho.)
6. मैं उन्ें कहीों और प्रभजिा दू ूँ गा। (Main unhe kahi or bhijva doonga.)
7. हमें बाल कटिाने हैं । (Hame baal katwane hai.)
8. राम मुझे प्रभजिाता था। (Ram mujhe bhijvata tha.)
9. मुझे मम्मी क एक सााी प्रदलिानी है । (Mujhe mummy ko ek saree dilvani hai.)
10. राम ये खुद करिाये गा। (Ram ye khud karvaeyga.)
11. बच्े तुम्हें खुश करें गे। (Bachhe tumhe khush karenge.)
12. पापा ने मुझे घाी प्रदलिायी। (Papa ne mujhe ghadi dilvayi.)
13. द स्त ने मुझे अपने घरिाल ों से प्रमलिाया। (Dost ne mujhe apne gharvalo se milvaaya.)
14. राहल क मैंने एक पैन खरीदिाया था। (Rahul ko mene ek pen kharidvaaya tha.)
15. उसने बाल िहाूँ से क्य ों कटिाये ? (Usne baal vahaan se kyo katvaaye?)
16. मैंने अपनी मम्मी से बाल ों में मेंहदी लगिाई। (Mene apni mummy se balo mein mehndi
   lagvaae.)
17. उसने मुझसे पैसे खचि करिाये । (Usne mujhse paise kharch karvaaye.)
18. तुम हमेशा मुझे रूलाते ह । (Tum hamesa mujhe rulate ho.)
19. मैं उसे हूँ सा सकता हूँ । (Main use hansa sakta hoon.)
20. उससे प्रमल ऐसा न ह ि तुम्हें अमेररका प्रभजिा दे । (Usse milo esa na ho vo tumhe
   America bhijwa de.)
21. खाना बनिा ल । (Khaana banwa lo.)
22. गरीब ों क कुछ कपाे प्रदलिा द । (Gareebo ko kuch kapde dilva do.)
23. तुम्हें हमें कुछ त प्रदलिाना ही चाप्रहए। (Tumhe hame kuch to dilwana hee chahiye.)
24. मुझे उससे एक बार प्रमलिा द । (Mujhe usse ek baar milva do.)
25. हमें ये कहानी एक बार सुनिा द । (Hame ye kahani ek baar sunva do.)
26. राम क िहाूँ से िापस बुलिा ल कहीों ि मर न जाए। (Ram ko vahaan se vapas bulwa lo
   kahin wo mar na jaaye.)
27. मैंने अपना प्रदल तु ािा प्रलया। (mene apna dil tudwa liya.)
28. मुझे बेिकूि मत बनाओ। (Mujhe bewkoof mat banao.)
29. ि हमें हूँ सा रहा है । (Vo hame hansa raha hai.)
30. ि हमें एक दू सरे से लािा रहे थे । (Vo hame ek doosare se ladva rahe hai.)
```

## Test – 23

```text
[[PDF PAGE 753]]
Test – 23
Q1: Choose the best alternatives:                                  16 x 1 = 16
   1. हमे भे ज़ा गय़ा। (Hume bheja gaya.)
      a) We were sent.           b) We were to go.
      c) We were made go.        d) We were let go.
   2. ऱाम को ड़ाँट़ा ज़ा रह़ा थ़ा। (Ram ko daanta ja raha tha.)
      a) Ram was scolding.             b) Ram was being scold.
      c) Ram was being scolded. d)Ram was made scolded.
   3. उसे मुझसे दमलव़ाय़ा ज़ायेग़ा। (Use mujhse milwaya jayega.)
      a) He will be meeting me.                 b) He will be made meet me.
      c) He will be made to meet me.            d) He will make me meet.
   4. तुम्हें क्य़ा दसख़ाय़ा ज़ात़ा है? (Tumhein kya sikhaya jaata hai?)
      a) What are you taught?                        b) What are you be taught?
      c) What do you be taught?                      d) What are you learned?
   5. मुझे दभजव़ाय़ा गय़ा। (Mujhe bhijwaya gaya.)
      a) I was sent.        b) I was made sent.
      c) I was made go. d) I made go.
   6. उन्हें बत़ाय़ा गय़ा थ़ा। (Unhe bataya gaya tha.)
      a) They were told.              b) They had been told.
      c) They were informed.          d) They were been told.
   7. तुम्हें क्यों नही ं ज़ाने ददय़ा गय़ा? (Tumhein kyun nahi jane diya gaya?)
      a) Why did you not go?                    b) Why did you not let go?
      c) Why were you not let go?               d) Why were you not let gone?
   8. क्य़ा हमें खे लने ददय़ा ज़ायेग़ा आज? (Kya hume khelne diya jayega aaj?)
      a) Will we be let play today?          b) Will we be made play today?
      c) Will we let play today?             d) Will we get the play today?
   9. मुझसे क़ाम करव़ाय़ा ज़ा सकत़ा है । (Mujhse kaam karwaya ja sakta hai.)
      a) I can get the work done.               b) The work can be done by me.
      d) I can made do the work.                d) I can be made to do the work.

[[PDF PAGE 754]]
10. क्य़ा तुम्हें पीट़ा ज़ात़ा थ़ा? (Kya tumhein peeta jata tha?)
   a) Had you to be beaten?               b) Were you use to beat?
   c) Did you use to be beaten?           d) Were you use to be beaten?
   e) Had you been to be beaten?
11. सीत़ा को हॉद्धस्पटल ले ज़ाय़ा गय़ा थ़ा। (Seeta ko hospital le jaya gaya tha.)
    a) Seeta was brought to hospital.          b) Seeta had been brought to hospital.
    c) Seeta was made bring to hospital. d) Seeta was got brought to hospital.
12. आज हमें क्ल़ास में नय़ा टॉदपक पढ़़ाय़ा ज़ाऩा है ।
    (Aaj hume class mai naya topic padaya jaana hai.)
    a) We have to be taught a new topic in the class today.
    b) We are to be taught a new topic in the class today.
    c) We have been to teach a new topic in the class today.
    d) We have to teach a new topic in the class today.
13. सबको ज़ाने ददय़ा ज़ायेग़ा। (Sabko jaane diya jayega.)
    a) All will let go.
    b) All will be gone.
    c) All will let be gone.
    d) All will be let go.
14. हमें ख़ाऩा नही ं ददय़ा ज़ात़ा थ़ा। (Hume khaana nahi diya jata tha.)
    a) We were not given the food.
    b) We didn’t be given the food.
    c) We didn’t use to be given the food.
    d) We were not to be given the food.
15. तुम मुझे पढ़ने क्यों नही ं दे रहे? (Tum mujhe padne kyu nahi de rahe?)
    a) Why are you not letting me study?
    b) Why do you not let me study?
    c) Why are you not let me study?
    d) Why are you not let me studying?
16. ये क़ाम दकस से करव़ाय़ा गय़ा थ़ा? (Yai kaam kis se karwaya gaya tha?)
   a) By whom was this work got done?
   b) By whom did this work get done?
   c) By whom had this work been got done?
   d) By whom had this work been get done?

[[PDF PAGE 755]]
Answers
      1. (a) Answer hint: Past Indefinite Tense Passive Sentence
      2. (c) Answer hint: Past Continuous Tense Passive Sentence
      3. (b) Answer hint: Future Indefinite Tense Passive Sentence of causative
        verb (make)
      4. (a) Answer hint: Present Indefinite Tense Passive Sentence
      5. (c) Answer hint: Past Indefinite Tense Passive Sentence of causative verb
        (make)
      6. (b) Answer hint: Past Perfect Tense Passive Sentence
      7. (c) Answer hint: Past Indefinite Tense Passive Sentence (Verb - Let)
      8. (a) Answer hint: Future Indefinite Tense Passive Sentence (Verb - Let)
      9. (d) Answer hint: Modal (can) Passive Sentence of Causative verb (make)
      10. (c) Answer hint: Modal (use to) Passive Sentence
      11. (b) Answer hint: Past Perfect Tense Passive Sentence
      12. (a) Answer hint: Modal (have to) Passive Sentence
      13. (d) Answer hint: Future Indefinite Tense Passive Sentence (Verb - Let)
      14. (c) Answer hint: Modal (use to) Passive Sentence
      15. (a) Answer hint: Present Continuous Tense Passive Sentence (Verb - Let)
      16. (c) Answer hint: Past Perfect Tense - Passive of Causative Verb (Get)
```

## Test – 24

```text
[[PDF PAGE 756]]
Test – 24
Q1: Translate the following sentences into English:                          50 x 1 = 50
   1. हमें पूछा जा रहा है प्रक हम कौन हैं । (Hume poocha jaa raha hai ki hum kaun hai.)
   2. तु म्हें भे जा जा सकता है । (Tumhein bhejaa jaa sakta hai.)
   3. मुझे र ऽ पीटा जाता था। (Mujhe roz peeta jaata tha.)
   4. उसे घसीट के घर से बाहर प्रनकाला गया। (Use ghaseet kai ghar se bahar nikaala
       gaya.)
   5. राम क र ऽ हॉखिटल ले जाया जाता है । (Ram ko roz hospital le jaya jaata hai.)
   6. हमें आज कुछ नया पिाया जाना चाप्रहए। (Hume aaj kuch naya padaya jaana
       chahiye.)
   7. तु म च र ह । क्या तुम्हें पीटा नहीों जाना चाप्रहए? (Tum chor ho. Kya tumhein peeta nahi
       jaana chahiye?)
   8. ये काम राम के द्वारा करिाया गया। (Yai kaam Ram kai dwara karwaya gaya.)
   9. मुझे भी प्रकताब दी जा सकती थी पर आप मुझे प्यार नहीों करते इसप्रलए आपने नहीों दी।
       (Mujhe bhi kitaab di jaa sakti thi par aap mujhe pyar nahi karte isliye aapne
       nahi di.)
   10. मुझे यहाूँ भे जा गया है । (Mujhe yahan bheja gaya hai.)
   11. बच् ों क क्या प्रदया जाएगा? (Bachcho ko kya diya jaega?)
   12. मुझे िहाूँ जाने नहीों प्रदया गया। (Mujhe vahaan jaane nahi diya gaya.)
   13. मुझे पीटा जायेगा। (Mujhe peeta jayega.)
   14. उसे बेिजह िहाूँ प्रभजिाया गया। (Use bewajah vahan bhijwaaya gaya.)
   15. राम क डों डे से पीटा गया। (Ram ko dhande se peeta gaya.)
   16. तु म्हें प्रभजिाया जा रहा है । (Tumhein bhijwaya jaa raha hai.)
   17. जब तुम गलत काम करते ह , क्या तु म्हें डाूँ टा नहीों जाता? (Jab tum galat kaam karte ho,
       kya tumhein daanta nahi jaata?)
   18. उसे बताया जा रहा था। (Use bataya jaa raha tha.)
   19. उसे िहाूँ क्य ों भेजा जाता है ? (Use vahaan kyun bheja jaata hai?)
   20. खूनी क प्रतहाा जेल ले जाया गया। (Khooni ko Tihar jail le jaaya gaya.)
   21. राम क नहीों भे जा जाएगा। (Ram ko nahi bheja jayega.)
   22. तु म्हें स्कूल में क्या प्रसखाया जाता है ? (Tumhein school mai kya seekhaaya jaata hai?)
   23. मुझसे चार िश्न पूछे गये । (Mujhse chaar prashn poochhe gaye.)
   24. उसे कभी नहीों पीटा गया। (Use kabhi nahi peeta gaya.)
   25. राम की मम्मी क बाऽार में दे खा गया था। (Ram ki mummy ko bazaar mai dekha
       gaya tha.)
   26. क्या उसे बुलाया गया? (Kya use bulaaya gaya?)
   27. उसके प्रपता क जान से मार प्रदया गया। (Uske pita ko jaan se maar diya gaya.)

[[PDF PAGE 757]]
28. उन्ें कहाूँ भे जा जा रहा है ? (Use kahaan bheja jaa raha hai?)
29. अब हमारी सैलेरी बिाई जानी चाप्रहए। (Ab humaari salary badaai jaani chahiye.)
30. राहल क कहा गया था प्रक उसे 2 घों टे पिना है । (Rahul ko kaha gaya tha ki use 2
    ghante padhna hai.)
31. हमें प्रभजिाया जाये गा। (Hume bhijwaaya jayega.)
32. मुझे कुछ भी नहीों प्रदया गया। (Mujhe kuch bhi nahi diya gaya.)
33. राहल क स्कूल से प्रनकाल प्रदया गया ह गा। (Rahul ko school se nikaal diya gaya
    hoga.)
34. बच् ों क आज कुछ नहीों पिाया गया। (Bachcho ko aaj kuch nahi padaya gaya.)
35. राहल क सु लाया जा रहा है । (Rahul ko sulaya jaa raha hai.)
36. मुझे सब कुछ प्रदया गया ज कुछ मैंने माूँ गा। (Mujhe sab kuch diya gaya jo kuch maine
    manga.)
37. हमें प्रकसी और के साथ भेजा गया। (Hume kisi or kai sath bhejaa gaya.)
38. उसे खाना नहीों प्रदया जाता था। (Use khaana nahi diya jaata tha.)
39. क्या उसे क ई अिाडि प्रदया जाना है ? (Kya use koi award diya jaana hai?)
40. तु म्हें उसके साथ कहाूँ भेजा गया था? (Tumhein uske sath kaha bheja gaya tha?)
41. पापा क अमेररका भेजा जा सकता है । (Papa ko America bheja jaa sakta hai.)
42. प्रदल की बात क भी पिा जा सकता है । (Dil kee baat ko bhi pada jaa sakta hai.)
43. सब बच् ों क चॉकलेट दी गयी हैं । (Sach bachco ko chocolate dee gayi hai.)
44. मुझसे एक गाना गिाया गया। (Mujhse ek gaana gavaya gaya.)
45. उसे प्रकसके साथ प्रबठाया गया? (Use kiske sath bithaaya gaya?)
46. पापा क मेरे बारे मे गलत बताया गया। (Papa ko mere bare mai galat bataya gaya.)
47. िहाूँ एक पु ल बनाया जाये गा। (Vahan ek pul banaya jayega.)
48. हमें अगले महीने सूचना दी जाये गी। (Hume agle mahine soochna dee jayegi.)
49. क्या तु म्हें पैसे प्रदये जाते हैं स्कूल में ? (Kya tumhein paise diye jaate hai school main?)
50. बच् ों क क्या प्रदया गया? (Bachcho ko kya diya gaya?)
                                       Answers
1. We are being asked who we are.
2. You may/can be sent.
3. I used to be beaten daily.
4. He was dragged out of the house.
5. Ram is taken to hospital daily.
6. We should be taught something new today.
7. You are a thief. Should you not be beaten?
8. This work was got done by Ram.

[[PDF PAGE 758]]
9. Even I could have been given the book but you don’t love me that’s why you
   didn’t.
10. I have been sent here.
11. What will children be given?
12. I was not let go there.
13. I will be beaten.
14. He was unnecessarily made go there.
15. Ram was beaten with a stick.
16. You are being made go.
17. When you do wrong, are you not scolded?
18. He was being told.
19. Why is he sent there?
20. The criminal was taken to the Tihar Jail.
21. Ram will not be sent.
22. What are you taught in school?
23. I was asked four questions.
24. He was never beaten.
25. Ram’s mother had been seen in the market.
26. Was he called?
27. His father was killed.
28. Where are they being sent?
29. Now, our salary must be increased.
30. Ram had been told that he had to study for 2 hours.
31. We will be made go.
32. I was not given anything.
33. Rahul will have been expelled from the school.
34. Children were not taught anything today.
35. Rahul is being made sleep.
36. I was given everything that I demanded.
37. We were sent with someone else.
38. He didn’t use to be given the food.
39. Has he to be given an award?
40. Where had you been sent with him?
41. Dad can be sent to America.
42. Even, the heart can be read.
43. All the children have been given chocolates.
44. I was made sing a song.
45. With whom was he made sit?

[[PDF PAGE 759]]
46. Dad was told wrong about me.
47. A bridge will be constructed there.
48. We will be informed next month.
49. Are you given money in school?
50. What were children given?
```

## Test – 25

```text
[[PDF PAGE 760]]
Test – 25
Q1: Translate the following sentences into Hindi:                          10 x 1 = 10
      1. If you are meant for each other, no one can separate you.
      2. You may get cold.
      3. Sachin was fond of playing Cricket.
      4. This mobile is not meant for playing games.
      5. Is it made by you?
      6. Does he know how to prepare the food?
      7. You keep on irritating me.
      8. Having met your friends, I can guess why you don’t study.
      9. How do I express my feelings?
      10. You are not preparing for exams. It suggests you are least bothered.
Q2: Translate the following sentences into English:                                10 x 1 = 10
      1. लगता है प्रक तुम ज़्यादा स चते ह । (Lagta hai ki tum zyada sochte ho.)
      2. ये म बाईल सै मसोंग का है । (Yai mobile Samsung kai hai.)
      3. मैं खु द क नहीों र क सकता। (Main khud ko nahi rok sakta.)
      4. मैं काप्रबल इन्ऱान हूँ । (Main kabil insaan hun.)
      5. सीता िही लाकी त है ज उस प्रदन आयी थी। (Seeta vahi ladki to hai jo us din aayi
          thi.)
      6. हम एकाद प्रदन में आ सकते हैं । (Hum ekaad din mai aa sakte hain.)
      7. राम ि लाका है प्रजसने तु म्हारी मदद की थी। (Ram vo ladka hai jisne tumhaari
          madad kee thi.)
      8. हमें सदी लग गयी थी। (Hume sardi lag gaye thi.)
      9. मैं प्रसिि तु म्हारे प्रलए ही बना हूँ । (Main sirf tumhaare liye hi baana hun.)
      10. मैं पों जाबी प्रलखना जानता हूँ । (Main punjaabi likhna jaanta hun.)
                                             Answers
Q1:
      1. अगर तु म एक दू सरे के प्रलए बने ह त तु म्हें क ई अलग नहीों कर सकता। (Agar tum ek
          doosre kai liye bane ho to tumhein koi alag nahi kar sakta.)
      2. तु म्हें सदी लग सकती है । (Tumhein sardi lag sakti hai.)

[[PDF PAGE 761]]
3. सप्रचन प्रक्रकेट खेलने का शौकीन था। (Sachin cricket khelne ka shaukeen tha.)
      4. यह म बाईल गेम्स खे लने के प्रलए नहीों बना है । (Yah mobile games khelne kai liye nahi
          bana hai.)
      5. क्या ये तु मने बनाया है ? (Kya yai tumne banaya hai?)
      6. क्या ि खाना बनाना जानता है ? (Kya vo khaana banana janta hai?)
      7. तु म मुझे परे शान करते रहते ह । (Tum mujhe pareshan karte rhte ho.)
      8. तु म्हारे द स्त ों से प्रमलने के बाद, मैं अों दाजा लगा सकता हूँ प्रक तु म पिाई क्य ों नहीों करते ।
          (Tumhaare dosto se milne kai bad, main andaaza laga sakta hun ki tum padaai
          kyun nahi karte.)
      9. मैं अपनी भािनाओों क कैसे व्यक्त करुूँ? (Main apni bhavnaao ko kese vyakt karun?)
      10. आप इग्जै़ म्स के प्रलए तैयारी नहीों कर रहे । इससे लगता है प्रक आपक रत्ती भर भी परिाह
          नही ों। (Aap exams kai liye taiyaari nahi kar rahe. Isse lagta hai ki apko ratti bhar
          bhi parwah nahi.)
Q2:
      1. It seems, you think a lot.
      2. This mobile is made by Samsung. / It’s a Samsung mobile.
      3. I can’t hold myself.
      4. I am an able man.
      5. Seeta is the very/same girl who had come the other day.
      6. We can come in a day or so.
      7. Ram is the boy who had helped you.
      8. We had got cold.
      9. I am meant only for you.
      10. I know how to write Punjabi.
```

## Test – 26

```text
[[PDF PAGE 762]]
Test – 26
Q1: Translate the following sentences into English:                    30 x 1 = 30
 1. मैं कई ल ग ों के बीच बैठा था। (Main kaee logo kai beech baitha tha.)
 2. बोंदर पेा से कूदा। (Bandar ped se kooda.)
 3. राम क मुझसे प्रमलिाया जाये गा। (Ram ko mujhse milwaaya jayega.)
 4. मुझे प्रभजिाया गया। (Mujhe bhijwaaya gaya.)
 5. मुझे र ऽ प्रसखाया जाता था। (Mujhe roz sikhaya jaata tha.)
 6. मैं पूछ रहा हूँ प्रक तुम कौन ह । (Main pooch raha hun ki tum kaun ho.)
 7. अगर मैं ठीक ह ता, त हम साथ खे लते। (Agar mai thik hota, to hum saath khelte.)
 8. मैं सुबह से यहाूँ हूँ । (Main subah se yahan hun.)
 9. प्रकताब तप्रकये के नीचे थी। (Kitaab takiye kai neeche thi.)
 10. राम क खेलने नहीों प्रदया गया। (Ram ko khelne nahi diya gaya.)
 11. मुझे समझाया जा रहा था। (Mujhe samjhaaya ja raha tha.)
 12. ये तुम्हें मैं कैसे बताऊूँ प्रक तु म मेरे प्रलए क्या मायने रखते ह ? (Yai tumhe mai kese bataaun
     ki tum mere liye kya mayne rakhte ho?)
 13. उसकी हरकत ों से लगता है प्रक ि अभी भी बच्ा है । (Uski harkaton se lagta hai ki vo
     abhi bhi bachcha hai.)
 14. ये सुनने में अच्छा लगता है पर कर के दे ख , मऽाक नहीों है । (Yai sunne mai acha lagta hai
     par kar ke dekho, mazaak nahi hai.)
 15. िक्त ने तुम्हारी याद ों क धुूँधला कर प्रदया था। (Waqt nai tumhaari yadon ko dhundla kar
     diya tha.)
 16. उसने तु म्हें ध खा प्रदया, तुम उसे अब भी चाहते ह ? (Usne tumhein dhokha diya, tum use
     ab bhi chahte ho?)
 17. इतना आसान नहीों ह ता। (Itna aasan nahi hota.)
 18. स चने की बात ये है प्रक हम ये करें गे कैसे ? (Sochne kee baat yai hai ki hum yai karenge
     kaise?)
 19. तुम मेरी मजबूरी का िायदा उठा रहे ह । (Tum meri majburi ka fayda utha rahe ho.)
 20. ऐसा करना प्रकसी पाप से कम नहीों है । (Aisa karna kisi paap se kam nahi hai.)
 21. बार-बार बुलाकर उसका समय खराब मत कर । (Baar-Baar bulakar uska samay kharaab
     mat karo.)
 22. अपने आप क ज़्यादा चालाक समझने की गलती मत कर । (Apne aap ko zyaada chalaak
     samjhne ki galti mat karo.)
 23. क्या पता कब मेरी प्रकस्मत बदल जाये ! (Kya pata kab meri kismat badal haye!)
 24. बेकार की बातें करने से क ई िायदा नहीों। (Bekaar ki batein karne se koi fayda nahi.)
 25. ऐसा स चना प्रबल्कुल जायऽ नहीों है । (Aisa sochna nilkul zayaz nahi hai.)

[[PDF PAGE 763]]
26. मैं ये सब करके छ ा चु का हूँ ज तु म अब कर रहे ह । (Main yai sab karke chod chukka
       hun jo tum ab kar rahe ho.)
 27. यही त प्रकताब है ज मैंने तुम्हें दी थी। (Yahi to kitaab hai jo maine tumhein di thi.)
 28. हम ि हैं ज दु प्रनया जीत सकते हैं । (Hum vo hain jo duniya jeet sakte hain.)
 29. उसकी हालत दे खकर मैं अपने आूँ सू नहीों र क पाया। (Usk haalat dekhkar main apne
       aansoo nahi rok paaya.)
 30. मेरे सारे द स्त िहीों पर थे । (Mere saare dost vahin par the.)
Q2: Correct the following sentences if incorrect:                     10 x 2 = 20
        1. He, as well as his friends, is good.
        2. The Director & Producer is dead.
        3. A Mr. Ram is sitting outside and waiting. He is wearing a blue shirt.
        4. I took the mobile from the table.
        5. The Table, which is my favourite is expensive.
        6. You, he & I are to blame.
        7. You, he & I are doing a good job.
        8. He along with the members of his team has seen the Taj.
        9. If he will come, he will scold you.
        10. He is older than me.
        11. I will see whether he is there.
        12. He is 3 years younger than me.
        13. Even if he will go, I don’t care.
        14. I am here for 3 days.
        15. The moment he come, baby starts weeping.
        16. You looks tired today.
        17. Because you are my friend, I will help you.
        18. I have got 3 hair on my head.
        19. He was used to my anger.
        20. He hide behind the wall.
                                         Answers
Q1:
      1. I was sitting amongst many people.
      2. Monkey jumped off the tree.

[[PDF PAGE 764]]
3. Ram will be made meet me.
   4. I was made go.
   5. I used to be taught every day.
   6. I am asking who you are.
   7. If I was fit, we would play together.
   8. I have been here since morning.
   9. Book was underneath/beneath the pillow.
   10. Ram was not let play.
   11. I was being made understand.
   12. How do I tell you what you are to me.
   13. His acts suggest as he isn’t mature yet.
   14. It sounds good but if you do it, it’s not a joke.
   15. Time had diminished your memories.
   16. He cheated on you, do you still love him?
   17. It’s not that easy.
   18. The matter of concern is, how we will do it?
   19. You’re taking advantage of my helplessness.
   20. Doing so is not less than a sin.
   21. Don’t waste his time by calling him again & again.
   22. Don’t mistake thinking yourself too clever.
   23. Who knows, when my fate turns.
   24. There is no point of talking nonsense.
   25. It’s not ethical thinking so.
   26. I’ve already gone through, that you’re doing now.
   27. This is the very book that I had given to you.
   28. We are the ones who can win the world.
   29. Seeing his condition, I couldn’t hold tears.
   30. All of my friends were very much there.
Q2: Correct Sentences are -
      1. Already correct
      2. Already correct
      3. Already correct
      4. I took the mobile off the table.
      5. The Table which is my favourite is expensive.
      6. I, you & he are to blame.

[[PDF PAGE 765]]
7. Already correct
  8. Already correct
  9. If he comes, he will scold you.
  10. He is older than I.
  11. I will see if he is there.
  12. He is 3 years younger to me.
  13. Even if he goes, I don’t care.
  14. I have been here for 3 days.
  15. The moment he comes, baby starts weeping.
  16. You look tired today.
  17. Since/as/for you are my friend, I will help you.
  18. Already correct
  19. Already correct
  20. He hides behind the wall. / He hid behind the wall.
```

## Test – 27

```text
[[PDF PAGE 766]]
Test – 27
Q 1: Choose the correct spelling:                                     5x1=5
1)      i) Grammar             ii) Grammer            iii) Gremmar           iv) Gremmer
2)      i) Tommorrow           ii) Tomorow            iii) Tommorow          iv) Tomorrow
3)      i) Parhaps             ii) Perheps            iii) Perhaps           iv) Parheps
4)      i) Pronounciation      ii) proununciation     iii) Pronunciation
5)      i) Calendar            ii) Calendir           iii) Calander          iv) Celender
Q 2: Tick whether the sentence is correct or incorrect:               15 x 1 =15
     1. I am working ever since you went out.                         Correct/Incorrect
     2. He is not such person who can fight till the end.             Correct/Incorrect
     3. My parents got me written a letter.                           Correct/Incorrect
     4. He keep on calling me fool.                                   Correct/Incorrect
     5. He gets up early in the morning.                              Correct/Incorrect
     6. His awkward behavior suggests me that he is not social.       Correct/Incorrect
     7. None of Ram & Shyam is my friend.                             Correct/Incorrect
     8. Did you not tell him something?                               Correct/Incorrect
     9. I don’t like burger too.                                      Correct/Incorrect
     10. People don’t like me much.                                   Correct/Incorrect
     11. Rain has started.                                            Correct/Incorrect
     12. Today is my birthday.                                        Correct/Incorrect
     13. He had told me that he will not go.                          Correct/Incorrect
     14. I am going to the school.                                    Correct/Incorrect
     15. The Earth is revolving around Sun.                           Correct/Incorrect
Q 3: Translate the following sentences into Hindi                       15 x 2 =30
     1. तु म्हारी बात ों से लगता है प्रक तु म सचमुच पागल ह । (Tumhaari baton se lagta hai ki
        tum sachmuch pagal ho.)
     2. उसे गुस्सा आ गया। (Use gussa aa gya.)
     3. मुझे घर लाया गया। उसके बाद मैं स पाया। (Mujhe ghar laaya gaya. Uske baad main
        so paaya.)
     4. उसे कहा गया था प्रक तु म मारे जाओगे। (Use kaha gaya tha ki tum mare jaoge.)
     5. मैं तुम्हें कैसे बताऊूँ प्रक तुम मेरे क्या ह । (Main tumhein kaise batau ki tum mere kya
        ho.)

[[PDF PAGE 767]]
6. उसने मुझे बहत रुलाया था। (Usne mujhe bahut rulaaya tha.)
   7. मैं ि हूँ ज कभी नहीों हारा। (Main vo hun jo kabh nahi haara.)
   8. उसने मुझे क्य ों जाने प्रदया? (Usne mujhe kyun jaane diya?)
   9. जब ि था, तुम नहीों थे। (Jab vo tha, tum nahi the.)
   10. मुझे उससे बात करने में कई साल लगे। (Mujhe usse baat karne mai kaee saal lage.)
   11. कई साल ह गये हैं । (Kaee saal ho gaye hain.)
   12. प्रजसने मुझे चाहा ि अब इस दु प्रनया में नहीों है । (Jisne mujhe chaaha vo ab is duniyaa
       main nahi hai.)
   13. बाररश ह रही है , है ना? (Baarish ho rahi hai, hai na?)
   14. ि एकाद प्रदन में आ जाये गा। (Vo ek aad din mai aa jayega.)
   15. तु म चाहे प्रजतना पि ल , पास नही ों ह सकते । (Tum chahe jitna padh lo, paas nahi ho
       sakte.)
                                        Answers
Q 1: Correct spellings are:
 1) i) Grammar
 2) iv) Tomorrow
 3) iii) Perhaps
 4) iii) Pronunciation
 5) i) Calendar
Q 2: The corrected ones are:
   1. I have been working ever since you went out.
   2. He is not such a person who can fight till the end
   3. My parents made me write a letter. / My parents got a letter written by me.
   4. He keeps on calling me fool. (Correct)
   5. Already correct
   6. Already correct
   7. Already correct
   8. Did you not tell him anything?
   9. Already correct
   10. Already correct
   11. It has started raining.
   12. It’s my birthday today.
   13. He had told me that he would not go.
   14. I am going to school.

[[PDF PAGE 768]]
15. The Earth is revolving around the Sun.
Q 3:
   1. Your talks suggest that you are really mad.
   2. He turned angry.
   3. I was brought to home. Thereafter, I could sleep.
   4. He was told that you would be killed.
   5. How do I tell you what you are to me.
   6. He had made me cry a lot.
   7. I am the one who never lost.
   8. Why did he let me go?
   9. When he was there, you weren’t.
   10. It took me many years to have a word with him.
   11. It has been many years.
   12. The one who loved me is no more.
   13. It’s raining, isn’t it?
   14. He will come in a day or so.
   15. No matter how much you study, you can’t pass.
```

## Test – 28

```text
[[PDF PAGE 769]]
Test – 28
Q1. Correct the following sentences:                                           10 x 1 = 10
   1. He do not has a pen.
   2. Does people have computers?
   3. Why does you not do this?
   4. It don’t sound good to me.
   5. Why doesn’t we work together?
   6. Ram and Shyam works together.
   7. Those peoples are doing something.
   8. My brother’s friend have not come.
   9. My brother has been studying for 2 pm.
   10. I have saw off my mother.
Q2. Translate the following sentences into English:                            10 x 1 = 10
 1. मैं तुम्हारे बारे में क्य ों नहीों स चता हूँ ? (Main tumhare bare main kyun nahi sochta hun.)
 2. राम और आप्रदत्य प्रकस ऑप्रिस से आ रहे हैं ? (Ram or Aditya kis office se aa rahe hai?)
 3. ि आदमी तु म्हें धमकी कैसे दे ता है ? (Vo aadmi tumhein dhamki kaise deta hai?)
 4. यह सु नने में अच्छा लग रहा है पर मेरा प्रदल खु श नहीों है । (Yah sunne main acha lag raha
     hai par mera dil khush nahi hai.)
 5. क्या तुम सबने उसके कदम ों की आिाऽ सु नी है ? (Kya tum sabne uske kadmo ki aawaz
     suni hai?)
 6. सीता भगिान की पूजा कब से कर रही है ? (Seeta baghwaan ki pooja kab se kar rahi
     hai?)
 7. मैं ऑप्रिस के अन्दर पहले ही अच्छी तरह से दे ख चु का हूँ । (Main office kai andar pehle hi
     achi tarah se dekh chukaa hun.)
 8. तुम कब तक ऑप्रिस में रहते ह ? (Tum kab tak office main rehte ho?)
 9. ि इस जनिरी से प्रकस कम्पनी के प्रलए गाना गा रहा है ? (Vo is January se kis company
     kai liye gaa raha hai?)
 10. मैं 2 घोंटे से ठों ड से काूँ प रहा हूँ । (Main 2 ghante se thand se kaanp raha hun.)
Q3. Write three forms of the following verbs:                          10 x 1 = 10
          1. Feed – खखलाना (Khilaana)
          2. Begin - शु रू करना (Shuru karna)

[[PDF PAGE 770]]
3. Hurt - च ट पहूँ चाना (Chot pahuchana)
            4. Hold – पकाना (Pakadna)
            5. Hide – प्रछपना (Chipna)
            6. Seek – ढूूँढना (Dhoondna)
            7. Run – दौाना (Daudna)
            8. Come – आना (Aana)
            9. Bring – लाना (Laana)
            10. Ride - चलाना (chalaana)
                                          Answers
Q1 - Corrected sentences are given below:
      1. He does not have a pen.
      2. Do people have computers?
      3. Why do you not do this?
      4. It doesn’t sound good to me.
      5. Why don’t we work together?
      6. Ram and Shyam work together.
      7. Those people are doing something.
      8. My brother’s friend has not come.
      9. My brother has been studying since 2 pm.
      10. I have seen off my mother.
Q2:
       1. Why do I not think about you?
       2. From which office are Ram & Aditya coming?
       3. How does that man threaten you?
       4. It is sounding good but my heart is not happy.
       5. Have you all heard his footfall?
       6. Since when has Seeta been worshiping God?
       7. I have already seen properly inside the office.
       8. Until when do you stay in office?
       9. For which company has he been singing since this January?
       10. I have been shivering with the cold for 2 hours.

[[PDF PAGE 771]]
Q3: Three forms of the verbs:
     1. Feed               fed (िैड)              fed
     2. Begin              began                  begun
     3. Hurt               hurt                   hurt
     4. Hold               held                   held
     5. Hide               hid (प्रहड)            hidden
     6. Seek               sought                 sought
     7. Run                ran                    run
     8. Come               came                   come
     9. Bring              brought                brought
     10. Ride              rode                   ridden
```

## Test – 29

```text
[[PDF PAGE 772]]
Test – 29
Q1: Translate the following sentences in English:                            30 marks
     1. बाहर ओले पा रहे हैं । (Bahar ole pad rahe hain.)
     2. ये कुछ और नहीों मेरा प्यार है । (Yai kuch aur nahi mera pyar hai.)
     3. माूँ ने हमें जन्म प्रदया। (Ma ne hume janam diya.)
     4. ये र ा कहाूँ जाती है ? (Yai road kahan jaati hai?)
     5. ि पैसा मेरे प्रकसी काम का नहीों। (Vo paisa mere kisi kaam ka nahi.)
     6. राम यहीों पर था। (Ram yahi par tha.)
     7. आखखरकार शादी के शु भ प्रदन की घ षणा ह चुकी है । (Aakhirkaar shadi kai shubh
        din ki ghosna ho chuki hai.)
     8. ध्यान रखना तुम्हें मेरे घर आना है । (Dhyan rakhna tumhein mere ghar aana hai.)
     9. मैं क ई कसर नहीों छ ाूूँगा। (Mai koi kasar nahi chodunga.)
     10. मुझे कई साल लगे उसे भू लने में। (Mujhe kaee saal lage use bhoolne mai.)
     11. चाहे क ई कुछ भी कहे मैं तु म्हारा साथ दू ूँ गा। (Chahe koi kuch bhi kahe mai
        tumhaara sath doonga.)
     12. दहे ज िथा एक अप्रभशाप है । (Dahej pratha ek abhishaap hai.)
     13. मूँहगाई भ्रष्टाचार क जन्म दे ती है । (Mehengaai bharastachar ko janam deti hai.)
     14. प्रजनकी ऊूँगली पकाकर तुमने चलना सीखा उनके कन् ों क कभी झुकने मत दे ना। (Jinki
        ungli pakadkar tumne chalna seekha unke kandho ko kabhi jhukne mat
        dena.)
     15. उसने साि मना कर प्रदया। (Usne saaf mana kar diya.)
     16. तु म क्या शति रखना चाहते ह ? (Tum kya shart rakhna chahte ho?)
     17. प्रहन्दू मरे हए क जलाते हैं और मुखिम दिनाते । (Hindi mare huwe ko jalate hain
        aur muslim dafnaate.)
     18. मैं अपनी सिलता का श्रे य तुम्हें दे ता हूँ । (Main apni safalta ka shrey tumhe deta
        hun.)
     19. आग बुझा द ऐसा न ह प्रक िैल जाए। (Aag bhuja do aisa na ho ki fail jaye.)
     20. उस षायोंत्र का पदाि िाश मैं करुूँगा। (Us sharyantra ka pardafash mai karunga.)
     21. आसपास ही रहना, मैं बस अभी आ रहा हूँ । (Aaspaas hi rehna, mai bus abhi aa raha
        hun.)
     22. सप्रचन का आउट ह ना एक जबरदस्त झटका है । (Sachin ka out hona ek jabarsdast
        jhatka hai.)
     23. अच्छा हआ तु म आ गये , मैं बस अभी प्रनकल गया ह ता। (Acha huwa tum aa gye, main
        bas abhi nikal gaya hota.)

[[PDF PAGE 773]]
24. मुझे भ ला भाला समझने की गलती मत कर, पछताएगा। (Mujhe bhola bhala samjhne
         ki galti mat kar pahctaega.)
     25. एक कहाित है , ‚निरत पाप से कर पापी से नही ों।‚ (Ek kahawat hai, ‚nafrat paap se
         karo papi se nahi.‛
     26. प्रजम्मेदारी से भागना लगता है तु म्हारे खू न में है । (Jimeedaari se bhagna lagta hai
         tumhaare khoon mai hai.)
     27. मान सप्रदयाूँ बीत गई ह ों हमें प्रमले हए। (Mano sadiyan beet gayi hon hume mile
         huwe.)
     28. प्रजतना मैं स चूूँ गा, उतना ही पागल ह जाऊूँगा। (Jitna mai sochunga, utna hi pagal
         hojaunga.)
     29. मैंने जानबूझकर कभी तु म्हारा प्रदल नहीों दु खाया। (Maine jaanbujhkar kabhi tumhaara
         dil nahi dukhaya.)
     30. एक बात कहूँ , पास ह कर भी बहत दू र ह तु म। (Ek bata kahun, paas hokar bhi
         bahut door ho tum.)
Q 2: Write the meaning of the following words:                            40 X 1 = 40 marks
Shirk, Shy away, Bury, Off hand, Enchant, Fiasco, Totter, Dacoit, Abase, Sigh of relief,
Delve, Imbibe, Lisp, Notorious, Hover, Retaliate, Havoc, Trifles, Indebted, Altogether,
Instincts, Ascribe, Thoroughfare, Mist, Fist, Demise, Lately, Vigilance, Fumble,
Auspicious, Assess, Confess, Unearth, Malediction, Aloof, Rip off, Negligence,
Deliberately, Legislative assembly, Ointment
                                         Answers
Q1: Translated Sentences:
   1. It’s hailing outside.
   2. It’s nothing but my love.
   3. Mother bred us.
   4. Where does this road lead to?
   5. That money is of no use to me.
   6. Ram was very much here.
   7. Finally, auspicious date of marriage is announced.
   8. Keep in mind, you have to come to my home
   9. I’ll not leave any stone unturned.
   10. It took me many years to forget her.

[[PDF PAGE 774]]
11. Irrespective of what anyone says, I’ll stand by you.
    12. Dowry system is a malediction.
    13. Inflation breeds corruption.
    14. Those whose fingers you resorted to walk, don’t let them ever down.
    15. He refused a point blank.
    16. What condition do you want to lie?
    17. Hindus burn the dead bodies and Muslims bury.
    18. I ascribe my success to you.
    19. Put out the fire lest it should spread out.
    20. I’ll unearth that conspiracy.
    21. Stick around, I am just coming.
    22. Sachin’s departure is big blow.
    23. Thank God you dropped in, I would have just left.
    24. Don’t mistake me for a credulous, you would regret.
    25. There is a saying, ‚Hate sin, not a sinner.‛
    26. To shirk responsibility seems to be in your blood.
    27. As if centuries have passed since we met.
    28. Deeper I think, more I’ll go mad.
    29. I never hurt you unknowingly.
    30. You know what, although near, yet afar you are.
Q 2:
जी चुराना; दू र भागना; दिनाना; प्रबना तैयारी के; खु श करना; घ र असिलता; लाखााना; डाकू;
अपमान करना; चैन की साूँ स लेना; घु सना; ग्रहण करना; तु तलाना; कुख्यात; झूलना; करारा जिाब दे ना;
तहलका; छ टा म टा झगाा; कजिदार; पूरी तरह से ; ििृप्रत; श्रे य दे ना; आम रास्ता; ओस; मुट्ठी; मृत्यु; हाल
ही में; दे खरे ख करना; टट लना; शु भ ; आूँ कना; गलती मान लेना; उजागर करना; अप्रभशाप; उदासीन;
लूटना; लापरिाही; जानबूझकर; प्रिधानसभा; क्रीम
```

## Test – 30

```text
[[PDF PAGE 775]]
Test – 30
Fill in the blanks with appropriate verbs or helping verbs:
1. You ………spoken with me.
   a) have          b) has                  c) do          d) does      e) none of these
2. She ……….walking for a long.
   a) have been     b) has been             c) do          d) does      e) none of these
3. He ………..found a watch.
   a) have          b) has                  c) do          d) did       e) none of these
4. I will study provided he ………me money.
   a) give          b) will give            c) gives       d) gave      e) none of these
5. I have …….you.
   a) seeked        b) sought               c) founded     d) finded    e) none of these
6. I ……….left by the time you reach my home.
   a) will          b) have                 c) will have   d) had       e) none of these
7. He and his father ………..taking part in this competition.
   a) have been     b) has been             c) are         d) was       e) is
8. My hair ………black.
   a) are           b) is                   c) look        d) were      e) none of these
9. You didn’t ……….money.
   a) have          b) has                  c) got         d) kept      e) none of these
10. I firmly …….. that you have an extraordinary career.
   a) belief        b) believe              c) faith       d) want      e) none of these
11. I ………..him.
   a) love          b) loves                c) loved       d) a & c     e) none of these
12. He has ……………this car.
   a) drive         b) drove                c) driven      d) driving   e) none of these
13. He ………asleep at that time.

[[PDF PAGE 776]]
a) has          b) had               c) have       d) was        e) none of these
14. I am ………..today.
   a) tire         b) tyre              c) tired      d) tear       e) none of these
15. All ……well.
   a) do           b) are               c) is         d) all of the above
16. Sumit …………went to America.
   a) has          b) had               c) was        d) has been e) none of these
17. Those guys …………not study at all.
   a) have         b) has               c) do         d) does       e) none of these
18. Aditya ……….for a walk.
   a) gone         b) went              c) go         d) going      e) none of these
19. Speed Bike ……….is thrilling.
   a) rider        b) riding            c) ride       d) drive      e) none of these
20. Children ………..excuses if they don’t like your advice.
   a) make         b) makes             c) made       d) does       e) none of these
21. I have …………up bad habits.
   a) give         b) gave              c) given      d) leave      e) none of these
22. Things ……….going tough these day.
   a) have         b) is                c) are        d) have been e) none of these
23. The stone ………..not move itself.
   a) have         b) has               c) do         d) does       e) none of these
24. Mom is not ……….around.
   a) see          b) seen              c) seeing     d) saw        e) none of these
25. Blood ……….from the wound.
   a) ooze         b) come              c) oozes      d) oozing     e) none of these
26. Why ………they fight with Ram?
   a) have         b) has               c) do         d) does       e) none of these
27. I will …….with you.
   a) have         b) be                c) been       d) have to    e) none of these

[[PDF PAGE 777]]
28. Life …………us thousand things.
   a) teaches            b) teach                 c) learn         d) teached     e) none of these
29. He ………….waiting for you since Monday.
   a) have               b) has been              c) is            d) was         e) none of these
30. It ………..not matter to me.
   a) has                b) does                  c) do            d) have        e) none of these
31. I am ………….TV.
   a) watching           b) looking               c) seeing        d) seen        e) none of these
32. They both …………..sleeping at this time.
   a) are                b) were        c) will be        d) all of these         e) none of these
33. My trousers …………black.
   a) is        b) are                  c) have           d) has            e) none of these
34. I ……..at fault.
   a) have               b) has         c) do             d) am             e) none of these
35. He …………her of murder.
   a) accuse             b) accuses     c) accusing       d) a & b          e) none of these
36. You have ………….. me.
   a) found              b) get         c) find           d) founded        e) none of these
37. She will …….. been mad.
   a) have               b) has         c) had            d) not            e) none of these
38. He……..not work with me.
   a) have               b) has         c) do             d) does           e) none of these
39. He………lived in Delhi for about two years.
   a) have               b) did         c) do             d) does           e) none of these
40. The road …….bent ahead.
   a) have               b) has         c) is             d) had            e) none of these
41. The glass …………broken.
   a) have               b) has         c) is             d) are            e) none of these

[[PDF PAGE 778]]
42. Mobile ……………ringing for a long.
   a) have           b) has         c) has been    d) did            e) none of these
43. I …………still look for her.
   a) have           b) has         c) am          d) was            e) none of these
44. He does not …………brain.
   a) have           b) has         c) had         d) all of these         e) none of these
45. …… you go to school?
   a) have           b) has         c) do          d) does                 e) none of these
46. He was sweating when he ………up to me.
   a) came           b) comes       c) come        d) coming               e) none of these
47. If he………….., he will meet you.
   a) will come      b) came        c) comes       d) has come             e) none of these
48. Your success……on your stars.
   a) depended       b) depending c) depend        d) depends              e) none of these
49. I don’t………in luck.
   a) believe        b) belief      c) faith       d) rely                 e) none of these
50. He is …………..from one company to another.
   a) hoping         b) leaving     c) departing d) switching              e) a & d
Answer Sheet
1a, 2b, 3b, 4c, 5b, 6c, 7c, 8b, 9a, 10b, 11d, 12c, 13d, 14c, 15d, 16e, 17c, 18b, 19b, 20a,
21c, 22c, 23d, 24b, 25c, 26c, 27b, 28a, 29b, 30b, 31a, 32d, 33b, 34d, 35b, 36a, 37a,
38d, 39e, 40c, 41c, 42c, 43e, 44a, 45c, 46a, 47c, 48d, 49a, 50e
```

## Test – 31

```text
[[PDF PAGE 779]]
Test – 31
Fill in the blanks with appropriate Articles (A, An, The):
1. I am at ………home.
   a) the           b) a         c) an         d) No article
2. She invited me to ……….dinner.
   a) the           b) a         c) an         d) No article
3. I was studying in ………..Delhi university.
   a) the           b) a         c) an         d) No article
4. I was born in ………….Calcutta.
   a) the           b) a         c) an         d) No article
5. He is one of …………..most intelligent students of mine.
   a) the           b) a         c) an         d) No article
6. You are……..honest boy.
   a) the           b) a         c) an         d) No article
7. You are……..honest.
   a) the           b) a         c) an         d) No article
8. I have four and …………half years of experience with international BPOs.
   a) the           b) a         c) an         d) No article
9. He is …………..greatest warrior of today.
   a) the           b) a         c) an         d) No article
10. He is weak in……….mathematics.
   a) the           b) a         c) an         d) No article
11. All………..boys are naughty.
   a) the           b) a         c) an         d) No article
12. He lives in………….US.
   a) the           b) a         c) an         d) No article

[[PDF PAGE 780]]
13. I am from……………Delhi
   a) the          b) a         c) an        d) No article
14. She lives in……………Dilshad Colony.
   a) the          b) a         c) an        d) No article
15. I have read………..whole book.
   a) the          b) a         c) an        d) No article
16. He is one of…………best students of mine.
   a) the          b) a         c) an        d) No article
17. I met with …………accident yesterday.
   a) the          b) a         c) an        d) No article
18. He is ……….PM of India.
   a) the          b) a         c) an        d) No article
19. You should go by……………bus.
   a) the          b) a         c) an        d) No article
20. I am not ……….best.
   a) the          b) a         c) an        d) No article
21. A woman is more sensitive than………..man.
   a) the          b) a         c) an        d) No article
22. I will meet you on………..Sunday.
   a) the          b) a         c) an        d) No article
23. Don’t make……….noise.
   a) the          b) a         c) an        d) No article
24. I have been working for………….hour.
   a) the          b) a         c) an        d) No article
25. He is ………….union leader.
   a) the          b) a         c) an        d) No article
26. He is working for …….university.
   a) the          b) a         c) an        d) No article

[[PDF PAGE 781]]
27. I am at………….fault.
   a) the           b) a            c) an      d) No article
28. I have only one and……………half kilos rice.
   a) the           b) a            c) an      d) No article
29. I will meet you in…….morning.
   a) the           b) a            c) an      d) No article
30. He studies at………..night.
   a) the           b) a            c) an      d) No article
31. ……….Earth is revolving around the Sun.
   a) the           b) a            c) an      d) No article
32. It is not…..book but a novel.
   a) the           b) a            c) an      d) No article
33. I have been waiting for …….reply since I questioned you.
   a) the           b) a            c) an      d) No article
34. I don’t expect ………answer from you.
   a) the           b) a            c) an      d) No article
35. He was going to …….school.
   a) the           b) a            c) an      d) No article
36. I was coming from………..market.
   a) the           b) a            c) an      d) No article
37. People took the injured guy to ……….hospital.
   a) the           b) a            c) an      d) No article
38. Police has been looking into ……matter for quite a long.
   a) the           b) a            c) an      d) No article
39. ………Gold is a precious metal.
   a) the           b) a            c) an      d) No article
40. Ram is a brother of ………guy who I had met the other day.
   a) the           b) a            c) an      d) No article

[[PDF PAGE 782]]
41. He was in ……….Australia last year.
   a) the              b) a         c) an         d) No article
42. Honesty is ………best policy.
   a) the              b) a         c) an         d) No article
43. My watch is made in ……..India.
   a) the              b) a         c) an         d) No article
44. Mobile has been ringing for ……. long.
   a) the              b) a         c) an         d) No article
45. I loved ……..way she spoke with me.
   a) the              b) a         c) an         d) No article
46. He does not have ……..brain.
   a) the              b) a         c) an         d) No article
47. …….love is life.
   a) the              b) a         c) an         d) No article
48. I distributed ………pens, you had given me, to all the students.
   a) the              b) a         c) an         d) No article
49. I am ……..one who doesn’t talk to many people.
   a) the              b) a         c) an         d) No article
50. It is your ………..best attempt.
   a) the              b) a         c) an         d) No article
Answer Sheet
1d, 2d, 3d, 4d, 5a, 6c, 7d, 8b, 9a, 10d, 11a, 12a, 13d, 14d, 15a, 16a, 17c, 18a, 19d, 20a,
21b, 22d, 23b, 24c, 25b, 26b, 27d, 28b, 29a, 30d, 31a, 32b, 33b, 34c, 35d, 36d, 37d,
38a, 39d, 40a, 41d, 42a, 43d, 44b, 45a, 46d, 47d, 48a, 49a, 50d
```

## Test – 32

```text
[[PDF PAGE 783]]
Test – 32
Fill in the blanks with appropriate Prepositions:
1. You must not look down…………the poor.
   b)      at      b) on          c) in         d) upon       e) to
2. She invited me…………dinner.
   a) at           b) on          c) in         d) upon       e) to
3. The day proved fatal………….his plan.
   a) at           b) on          c) in         d) upon       e) to
4. I was born………..Calcutta.
   a) at           b) on          c) in         d) upon       e) over
5. He is very bad…………..expressing himself.
   a) at           b) on          c) in         d) upon       e) into
6. You should look……………the matter.
   a) at           b) on          c) in         d) into       e) over
7. I was tired…………your rubbish talk.
   a) by           b) on          c) of         d) upon       e) over
8. Take care…………your parents
   a) off          b) on          c) of         d) upon       e) over
9. Pour some more milk……….the jug.
   a) inside       b) on          c) in         d) upon       e) into
10. I can ride……………the horse back.
   a) at           b) on          c) in         d) upon       e) over
11. The stone came……….me.
   a) down upon    b) down at     c) onto       d) upon       e) over
12. She lives………Dilshad Garden.
   a) at           b) on          c) in         d) upon       e) over

[[PDF PAGE 784]]
13. Wipe the dust…………..the table.
   a) from            b) by          c) off        d) with       e) onto
14. He is older…………..I.
   a) to              b) than        c) then       d) from       e) above
15. You are younger …………me.
   a) at              b) to          c) in         d) upon       e) over
16. He is far ahead………….others.
   a) by              b) on          c) of         d) than       e) over
17. I am running short………money.
   a) at              b) with        c) off        d) of         e) by
18. He has lived in Delhi………..two years.
   a) in              b) for         c) about      d) since      e) over
19. He is content ………this amount.
   a) in              b) with        c) by         d) for        e) over
20. Letter is kept ……….the pillow.
   a) under           b) beneath     c) over       d) below      e) down
21. She has married …………… him last year.
   a) to              b) with        c) within     d) by         e) No Preposition
22. You should be ashamed ……………yourself.
   a) at              b) on          c) by         d) of         e) No Preposition
23. I told him to be careful……………the traffic.
   a) at              b) on          c) in         d) by         e) of
24. He is ………….blame.
   a) at              b) on          c) in         d) to         e) with
25. I am…….. fault.
   a) at              b) on          c) in         d) to         e) by
26. A leaf is kept ……….the Mathematics book.
   a) under           b) above       c) over       d) below      e) underneath

[[PDF PAGE 785]]
27. I have seen …….my parents.
   a) of           b) to          c) off        d) above      e) by
28. I prefer studying ……night.
   a) at           b) on          c) in         d) upon       e) over
29. He studies …….the evening.
   a) at           b) on          c) in         d) by         e) over
30. The Earth is revolving……. the Sun.
   a) by           b) surround     c) around    d) about      e) over
31. Does it make any difference ……….you?
   a) at           b) on          c) with       d) to         e) beneath
32. I was looking ……..a room as I had to relocate immediately.
   a) at           b) for         c) on         d) over       e) onto
33. I went for the interview ……..hand but I got selected.
   a) of           b) in          c) off        d) with       e) over
34. Ram is younger ……..me.
   a) to           b) than        c) by         d) below      e) before
35. I will blame you ………that negligence.
   a) for          b) about       c) under      d) to         e) over
36. He assures you ………assistance.
   a) for          b) with        c) of         d) upon       e) over
37. What’s…….?
   a) at           b) up          c) into       d) upon       e) than
38. He was sitting ……….10 people.
   a) among        b) between     c) in         d) under      e) underneath
39. Can you see the man …………the road?
   a) at           b) across      c) in         d) beyond     e) off
40. Your imagination is ……………….dreams.
   a) at           b) across      c) off        d) beyond     e) over

[[PDF PAGE 786]]
41. He got………….the bus and rushed to school.
   a) from          b) by         c) of         d) off        e) over
42. This mobile is ……..no use …….me.
   a) of, to        b) to, of     c) of, of     d) off, to    e) to, off
43. I will always remain indebted ………..my parents.
   a) at            b) of         c) to         d) by         e) over
44. Put out the fire lest it should spread ……..
   a) out           b) off        c) away       d) onto       e) over
45. I got very happy, the moment I saw my best friend dropped………
   a) at            b) on         c) in         d) upon       e) over
46. I came ……..your home but didn’t courage to knock ……the door.
   a) at, at        b) up to, on c) up to, at   d) till, at   e) till, on
47. We had…….return to home quickly as it was getting dark.
   a) on            b) to         c) by         d) off        e) No Preposition
48. I run ……….money.
   a) by            b) before     c) after      d) ahead      e) No Preposition
49. You are addicted……………gambling.
   a) to            b) of         c) with       d) by         e) beneath
50. She died………….hard work.
   a) of            b) from       c) with       d) onto       e) over
51. My house is adjacent……..his house.
   a) to            b) by         c) with       d) across     e) No preposition
52. She is married…………Ram.
   a) to            b) with       c) by         d) along      e) No preposition
53. You should investigate………….the matter.
   a) about         b) into       c) over       d) onto       e) No preposition
54. I discussed……….the issue.
   a) about         b) into       c) over       d) onto       e) No preposition

[[PDF PAGE 787]]
55. You should look after……………..your parents.
   a) out           b) off      c) away       d) onto        e) No preposition
56. He was applying the cream……………..his face.
   a) on            b) onto     c) up to      d) in          e) over
57. He will come home………….Holi.
   a) on            b) in       c) at         d) onto        e) over
58. The convict escaped………..the punishment.
   a) off           b) of       c) from       d) onto        e) No preposition
59. I was tired…………listening to his excuses.
   a) out           b) off      c) of         d) onto        e) over
60. I opened………..the fiftieth page of the book.
   a) out           b) off      c) at         d) in          e) No preposition
61. He killed his brother…………an arrow.
   a) of            b) off      c) with       d) onto        e) over
62. He is a friend ………mine.
   a) than          b) to       c) from       d) of          e) then
63. He is……….weak that he can’t talk.
   a) too           b) to       c) so      d) All of these      e) No Preposition
64. He is sitting………………the auditorium.
   a) out           b) at       c) in         d) into e) over
65. I am running short…………time.
   a) out           b) off      c) away       d) of          e) over
66. I wish……..early rains.
   a) for           b) off      c) of         d) on          e) No preposition
67. She broke……….. the house to steal something.
   a) in            b) on       c) away       d) onto        e) No preposition
68. I broke……….with Priya.
   a) out           b) off      c) away       d) onto        e) up

[[PDF PAGE 788]]
69. I made him………..go there.
   a) in               b) on         c) at           d) onto        e) No preposition
70. This chain is made………..Gold.
   a) by               b) of         c) in           d) inside      e) upon
71. This computer is made…………America.
   a) by               b) of         c) in           d) inside      e) upon
72. I am ……….the wrong.
   a) in               b) on         c) at           d) onto        e) No preposition
73. This cloth is inferior……….my cloth.
   a) than     b) to           c) then       d) rather than         e) over
74. I will reach office………….6 o’clock.
   a) by               b) at         c) before       d) All of these          e) No
   Preposition
75. His car is parked………….the road.
   a) to               b) by         c) along        d) upon        e) with
Answer Sheet
1d, 2e, 3e, 4c, 5c, 6d, 7c, 8c, 9e, 10b, 11a, 12c, 13c, 14b, 15b, 16c, 17d, 18b, 19b, 20b, 21a,
22d, 23c, 24d, 25a, 26e, 27c, 28a, 29c, 30c, 31d, 32b, 33c, 34a, 35a, 36c, 37b, 38a, 39b,
40d, 41d, 42a, 43c, 44e, 45c, 46c, 47b, 48c, 49a, 50b, 51e, 52a, 53e, 54e, 55e, 56b, 57c,
58c, 59c, 60c, 61c, 62d, 63c, 64c, 65d, 66a, 67a, 68e, 69e, 70b, 71c, 72a, 73b, 74d, 75c
```

## Source notes

Source notes
The PDF was extracted page-by-page with pdftotext -layout. Running book headers, footers, standalone page numbers, and blank layout lines were removed only; all printed instructions, question stems, choices, Hindi/English lines, answer lines, explanations, and answer sheets are retained in source order. Printed wording, grammar, spelling, punctuation, duplicated choices, and source/key mismatches are not silently normalized. The explicit numbered answer blocks in Tests 1–29 are retained adjacent to their source test pages. Tests 30–32 retain their printed Answer Sheet letter keys; the verification record pairs each key number with its question number and choice letter. No missing answer was inferred.

Coverage: PDF pages 687–788 inclusive (102 pages), Test 1–32. See lesson40_review/section_map.json and page-bounded parts for page-level boundaries.
