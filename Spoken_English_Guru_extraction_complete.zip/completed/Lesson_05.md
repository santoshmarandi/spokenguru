# Lesson 5 — Three Degrees of Adjectives

**PDF pages:** 50–53 (printed pages 49–52)

## Adjectives and their three degrees

### 1. Big
**Hindi:** बड़ा
**Answer:** Big (बड़ा) - Bigger (ज़्यादा बड़ा) - Biggest (सबसे ज़्यादा बड़ा)

### 2. Small
**Hindi:** छोटा
**Answer:** Small (छोटा) - Smaller (ज़्यादा छोटा) - Smallest (सबसे ज़्यादा छोटा)

### 3. Tall
**Hindi:** लम्बा
**Answer:** Tall (लम्बा) - Taller (ज़्यादा लम्बा) - Tallest (सबसे ज़्यादा लम्बा)

### 4. Short
**Hindi:** छोटा
**Answer:** Short (छोटा) - Shorter (ज़्यादा छोटा) - Shortest (सबसे ज़्यादा छोटा)

### 5. Long
**Hindi:** लम्बा
**Answer:** Long (लम्बा) - Longer (ज़्यादा लम्बा) - Longest (सबसे ज़्यादा लम्बा)

### 6. Wide
**Hindi:** चौड़ा
**Answer:** Wide (चौड़ा) - Wider (ज़्यादा चौड़ा) - Widest (सबसे ज़्यादा चौड़ा)

### 7. High
**Hindi:** ऊँचा
**Answer:** High (ऊँचा) - Higher (ज़्यादा ऊँचा) - Highest (सबसे ज़्यादा ऊँचा)

### 8. Deep
**Hindi:** गहरा
**Answer:** Deep (गहरा) - Deeper (ज़्यादा गहरा) - Deepest (सबसे ज़्यादा गहरा)

### 9. Lengthy
**Hindi:** लम्बा
**Answer:** Lengthy (लम्बा) - Lengthier (ज़्यादा लम्बा) -Lengthiest (सबसे ज़्यादा लम्बा)

### 10. Great
**Hindi:** महान
**Answer:** Great (महान) - Greater (ज़्यादा महान) -Greatest (सबसे ज़्यादा महान)

### 11. Rich
**Hindi:** अमीर
**Answer:** Rich (अमीर) - Richer(ज़्यादा अमीर) - Richest (सबसे ज़्यादा अमीर)

### 12. Slow
**Hindi:** हल्का
**Answer:** Slow (हल्का) - Slower (ज़्यादा हल्का) - Slowest (सबसे ज़्यादा हल्का)

### 13. Sweet
**Hindi:** मीठा
**Answer:** Sweet (मीठा) - Sweeter (ज़्यादा मीठा) - Sweetest (सबसे ज़्यादा मीठा)

### 14. Bitter
**Hindi:** कड़वा
**Answer:** Bitter (कड़वा) - Bitterer (ज़्यादा कड़वा) - Bitterest (सबसे ज़्यादा कड़वा)

### 15. Sour
**Hindi:** खट्टा
**Answer:** Sour (खट्टा) - Sourer (ज़्यादा खट्टा) - Sourest (सबसे ज़्यादा खट्टा)

### 16. Tough
**Hindi:** कठोर
**Answer:** Tough (कठोर) - Tougher (ज़्यादा कठोर) - Toughest (सबसे ज़्यादा कठोर)

### 17. Poor
**Hindi:** गरीब
**Answer:** Poor (गरीब) - Poorer(ज़्यादा गरीब) - Poorest (सबसे ज़्यादा गरीब)

### 18. Hot
**Hindi:** गर्म
**Answer:** Hot (गर्म) - Hotter (ज़्यादा गर्म) - Hottest (सबसे ज़्यादा गर्म)

### 19. Dirty
**Hindi:** गंदा
**Answer:** Dirty (गंदा) - Dirtier (ज़्यादा गंदा) - Dirtiest (सबसे ज़्यादा गंदा)

### 20. Clean
**Hindi:** साफ
**Answer:** Clean (साफ) - Cleaner (ज़्यादा साफ) - Cleanest (सबसे ज़्यादा साफ)

### 21. Cold
**Hindi:** ठंडा
**Answer:** Cold (ठंडा) - Colder (ज़्यादा ठंडा) - Coldest (सबसे ज़्यादा ठंडा)

### 22. Fast
**Hindi:** तेज़
**Answer:** Fast (तेज़) - Faster (ज़्यादा तेज़) - Fastest (सबसे ज़्यादा तेज़)

### 23. Hard
**Hindi:** कठोर
**Answer:** Hard (कठोर) - Harder (ज़्यादा कठोर) - Hardest (सबसे ज़्यादा कठोर)

### 24. Soft
**Hindi:** मुलायम/कोमल
**Answer:** Soft (मुलायम/कोमल) - Softer (ज़्यादा मुलायम/कोमल) - Softest (सबसे ज़्यादा मुलायम)

### 25. Weak
**Hindi:** कमज़ोर
**Answer:** Weak (कमज़ोर) - Weaker(ज़्यादा कमज़ोर) - Weakest (सबसे ज़्यादा कमज़ोर)

### 26. Strong
**Hindi:** मजबूत
**Answer:** Strong (मजबूत) - Stronger(ज़्यादा मजबूत) - Strongest (सबसे ज़्यादा मजबूत)

### 27. Heavy
**Hindi:** भारी
**Answer:** Heavy (भारी) - Heavier(ज़्यादा भारी) - Heaviest (सबसे ज़्यादा भारी)

### 28. Bright
**Hindi:** चमकीला
**Answer:** Bright (चमकीला) - Brighter (ज़्यादा चमकीला) - Brightest (सबसे ज़्यादा चमकीला)

### 29. Near
**Hindi:** करीब
**Answer:** Near (करीब) - Nearer(ज़्यादा करीब) - Nearest (सबसे ज़्यादा करीब)

### 30. Light
**Hindi:** हल्का
**Answer:** Light (हल्का) - Lighter(ज़्यादा हल्का) - Lightest (सबसे ज़्यादा हल्का)

### 31. Dear
**Hindi:** प्यारा
**Answer:** Dear (प्यारा) - Dearer (ज़्यादा प्यारा) - Dearest (सबसे ज़्यादा प्यारा)

### 32. Pure
**Hindi:** पवित्र, साफ
**Answer:** Pure (पवित्र, साफ) - Purer(ज़्यादा पवित्र, साफ) - Purest (सबसे ज़्यादा पवित्र, साफ)

### 33. Loud
**Hindi:** ऊँची आवाज
**Answer:** Loud (ऊँची आवाज) - Louder(ज़्यादा ऊँची आवाज) - Loudest (सबसे ऊँची आवाज)

### 34. Soon
**Hindi:** जल्दी
**Answer:** Soon (जल्दी) - Sooner(ज़्यादा जल्दी) - Soonest (सबसे ज़्यादा जल्दी)

### 35. Wise
**Hindi:** बुद्धिमान
**Answer:** Wise (बुद्धिमान) - Wiser(ज़्यादा बुद्धिमान) - Wisest (सबसे ज़्यादा बुद्धिमान)

### 36. Beautiful
**Hindi:** सुन्दर
**Answer:** Beautiful (सुन्दर) - More Beautiful(ज़्यादा सुन्दर) - Most Beautiful (सबसे ज़्यादा सुन्दर)

### 37. Intelligent
**Hindi:** बुद्धिमान
**Answer:** Intelligent (बुद्धिमान) - More Intelligent (ज़्यादा बुद्धिमान) - Most Intelligent (सबसे ज़्यादा बुद्धिमान)

### 38. Patient
**Hindi:** धैर्यवान
**Answer:** Patient (धैर्यवान) - More Patient (ज़्यादा धैर्यवान) - Most Patient (सबसे ज़्यादा धैर्यवान)

### 39. Active
**Hindi:** तेज़तर्रार
**Answer:** Active (तेज़तर्रार) - More Active (ज़्यादा तेज़तर्रार) - Most Active (सबसे ज़्यादा तेज़तर्रार)

### 40. Cheerful
**Hindi:** खुश
**Answer:** Cheerful (खुश) - More Cheerful (ज़्यादा खुश) - Most Cheerful (सबसे ज़्यादा खुश)

### 41. Honest
**Hindi:** ईमानदार
**Answer:** Honest (ईमानदार) - More Honest (ज़्यादा ईमानदार) - Most Honest (सबसे ज़्यादा ईमानदार)

### 42. Careful
**Hindi:** सावधान
**Answer:** Careful (सावधान) - More Careful (ज़्यादा सावधान) - Most Careful (सबसे ज़्यादा सावधान)

### 43. Interesting
**Hindi:** रोचक
**Answer:** Interesting (रोचक) - More Interesting (ज़्यादा रोचक) - Most interesting (सबसे ज़्यादा रोचक)

### 44. Difficult
**Hindi:** मुश्किल
**Answer:** Difficult (मुश्किल) - More Difficult (ज़्यादा मुश्किल) - Most Difficult (सबसे ज़्यादा मुश्किल)

### 45. Useful
**Hindi:** उपयोगी
**Answer:** Useful (उपयोगी) - More useful (ज़्यादा उपयोगी) - Most Useful (सबसे ज़्यादा उपयोगी)

### 46. Industrious
**Hindi:** मेहनती
**Answer:** Industrious (मेहनती) - More Industrious (ज़्यादा मेहनती) - Most Industrious (सबसे ज़्यादा मेहनती)

### 47. Diligent
**Hindi:** मेहनती
**Answer:** Diligent (मेहनती) - More Diligent (ज़्यादा मेहनती) - Most Diligent (सबसे ज़्यादा मेहनती)

### 48. Famous
**Hindi:** प्रसिद्ध
**Answer:** Famous (प्रसिद्ध) - More Famous (ज़्यादा प्रसिद्ध) - Most Famous (सबसे ज़्यादा प्रसिद्ध)

### 49. Powerful
**Hindi:** शक्तिशाली
**Answer:** Powerful (शक्तिशाली) - More Powerful (ज़्यादा शक्तिशाली) - Most Powerful (सबसे ज़्यादा शक्तिशाली)

### 50. Dangerous
**Hindi:** खतरनाक
**Answer:** Dangerous (खतरनाक) - More Dangerous (ज़्यादा खतरनाक) - Most Dangerous (सबसे ज़्यादा खतरनाक)

### 51. Urgent
**Hindi:** ज़रुरी
**Answer:** Urgent (ज़रुरी) - More Urgent (ज़्यादा ज़रुरी) - Most urgent (सबसे ज़्यादा ज़रुरी)

### 52. Harmful
**Hindi:** हानिकारक
**Answer:** Harmful (हानिकारक) - More Harmful (ज़्यादा हानिकारक) - Most Harmful (सबसे ज़्यादा हानिकारक)

### 53. Important
**Hindi:** महत्वपूर्ण
**Answer:** Important (महत्वपूर्ण) - More Important (ज़्यादा महत्वपूर्ण) - Most Important (सबसे ज़्यादा महत्वपूर्ण)

### 54. Foolish
**Hindi:** मूर्ख
**Answer:** Foolish (मूर्ख) - More Foolish (ज़्यादा मूर्ख) - Most Foolish (सबसे ज़्यादा मूर्ख)

### 55. Popular
**Hindi:** प्रसिद्ध
**Answer:** Popular (प्रसिद्ध) - More Popular (ज़्यादा प्रसिद्ध) - Most Popular (सबसे ज़्यादा प्रसिद्ध)

### 56. Much, Many
**Hindi:** ज़्यादा, कई
**Answer:** Much, Many (ज़्यादा, कई) - More (और ज़्यादा) - Most(सबसे ज़्यादा)

### 57. Good, Well
**Hindi:** अच्छा, ठीक
**Answer:** Good, Well (अच्छा, ठीक) - Better (बेहतर) - Best(सबसे ज़्यादा अच्छा)

### 58. Little
**Hindi:** थोड़ा, कम
**Answer:** Little (थोड़ा, कम) - Less, Lesser(और थोड़ा कम) - Least(सबसे ज़्यादा कम)

### 59. Bad, ill
**Hindi:** बुरा
**Answer:** Bad, ill (बुरा) - Worse(ज़्यादा बुरा) - Worst(सबसे ज़्यादा बुरा)

---
**Verification:** All 59 prompts and all 59 printed answer entries are paired by item number. Prompt Hindi glosses were OCR-read from individual PDF text rows and visually corrected where needed; English degree forms were retained from the answer key, and Hindi comparative/superlative phrases were checked against the printed answer pages. No unreadable text.

