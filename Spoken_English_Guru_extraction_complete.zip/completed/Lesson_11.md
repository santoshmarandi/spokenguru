# Lesson 11 — Modal Verbs

**PDF pages:** 117–127 (printed pages 116–126)

**Instruction:** Translate the following sentences into English.

## Bilingual prompts and printed English answers

### 1. मुझे देखना है।
**Romanized:** (Mujhe dekhna hai.)
**English answer:** I have to see.

### 2. उसे बताना पड़ा।
**Romanized:** (Use batana pada.)
**English answer:** He had to tell.

### 3. राम को खेलना पड़ेगा।
**Romanized:** (Ram ko khelna padega.)
**English answer:** Ram will have to play.

### 4. उसे मेरी बात माननी पड़ेगी।
**Romanized:** (Use meri baat maanni padegi.)
**English answer:** He will have to follow my instructions.

### 5. मुझे जाना चाहिए था।
**Romanized:** (Mujhe jana chahiye tha.)
**English answer:** I should have gone.

### 6. हम खेला करते थे।
**Romanized:** (Hum khela karte the.)
**English answer:** We used to play.

### 7. लोग मुझे अक्षय कुमार बुलाते थे।
**Romanized:** (Log mujhe Akshay Kumar bulate the.)
**English answer:** People used to call me Akshay Kumar.

### 8. क्या तुम जा पाये?
**Romanized:** (Kya tum ja paye?)
**English answer:** Could you go?

### 9. क्या तुम यहाँ सो पाओगे?
**Romanized:** (Kya tum yahan so paoge?)
**English answer:** Will you be able to sleep here?

### 10. हम कभी नहीं भुला सके।
**Romanized:** (Ham kabhee nahi bhula sake.)
**English answer:** We could never forget.

### 11. मुझे अपने आस-पास कोई नहीं चाहिए।
**Romanized:** (Mujhe apne aas-paas koi nahi chahiye.)
**English answer:** I don’t need anybody around me.

### 12. शायद वो जा रहा हो।
**Romanized:** (Shayad vo ja raha ho.)
**English answer:** He may/could/might be going.

### 13. उसे मुझे बताना चाहिए था।
**Romanized:** (Use mujhe batana chahiye tha.)
**English answer:** He must have told me.

### 14. अब उसके खर्चे तुम्हें उठाने पड़ेंगे।
**Romanized:** (Ab uske kharche tumhe uthane padenge.)
**English answer:** Now, you will have to bear his expenses.

### 15. मैं आता था और वो जाता था।
**Romanized:** (Main aata tha aur vo jata tha.)
**English answer:** I used to come and he would go.

### 16. बच्चे को माँ की ज़रूरत होती है।
**Romanized:** (Bachche ko maa ki zaroorat hoti hai.)
**English answer:** Child needs mother.

### 17. शायद बस आ रही होगी।
**Romanized:** (Shayad bus aa rahi hogi.)
**English answer:** Bus may/could/might be coming.

### 18. किसी को प्यार नहीं चाहिए।
**Romanized:** (Kisi ko pyar nahi chahiye.)
**English answer:** Nobody needs love.

### 19. दोनों कभी भी आ सकते हैं।
**Romanized:** (Dono kabhi bhi aa sakte hain.)
**English answer:** Both can come anytime.

### 20. मैं पक्का जाऊँगा।
**Romanized:** (Main pakka jaunga.)
**English answer:** I must go.

### 21. ये प्रश्न कोई नहीं कर पायेगा।
**Romanized:** (Ye prashna koi nahi kar payega.)
**English answer:** Nobody will be able to solve this question.

### 22. मुझे कुछ कहना है।
**Romanized:** (Mujhe kuch kehna hai.)
**English answer:** I have to say something.

### 23. हम खेलने चले जाते थे।
**Romanized:** (Hum khelne chale jaate the.)
**English answer:** We used to go to play.

### 24. मुझे किसी की ज़रूरत नहीं है।
**Romanized:** (Mujhe kisi ki Zaroorat nahi hai.)
**English answer:** I don’t need anybody.

### 25. मुझे तुम याद करते थे।
**Romanized:** (Mujhe tum yaad karte the.)
**English answer:** You used to miss/remember me. / You missed me.

### 26. सीता पक्का बस पकड़ चुकी होगी।
**Romanized:** (Seeta pakka bus pakad chuki hogi.)
**English answer:** Seeta must have taken/caught the bus.

### 27. शायद वो तुमसे मिले।
**Romanized:** (Shayad vo tumse mile.)
**English answer:** He may/might/could meet you.

### 28. बचपन में हम दोनों साथ-साथ खेलते थे।
**Romanized:** (Bachpan me hum dono saath-2 khelte the.)
**English answer:** We both used to play together in childhood.

### 29. उसे क्या कहना है?
**Romanized:** (Use kya kehna hai?)
**English answer:** What has he to say?

### 30. मैं आ सकता था पर मैं नहीं आ पाया।
**Romanized:** (Main aa sakta tha par main nahi aa paya.)
**English answer:** I could have come but I could not.

### 31. मैं घूमने कभी नहीं जा सकता।
**Romanized:** (Main ghumne kabhi nahi ja sakta.)
**English answer:** I can never go for a walk.

### 32. तुम्हें झूठ बोलने की आदत है।
**Romanized:** (Tumhe jhooth bolne ki aadat hai.)
**English answer:** You are in the habit of telling a lie.

### 33. तुम नल खोल सकते थे पर तुमने नहीं खोला।
**Romanized:** (Tum nal khol sakte the pr tumne ni khola.)
**English answer:** You could have turned the tap on but you didn’t.

### 34. कुछ भी हो सकता है। मैं कह नहीं सकता।
**Romanized:** (Kuch bhi ho sakta hai. Main keh ni sakta.)
**English answer:** Anything may happen. I can’t say.

### 35. तुम्हें पहाड़ों में रहना चाहिए क्योंकि तुम्हें दिल की बीमारी है।
**Romanized:** (Tumhe pahado mein rehna chahiye kyunki tumhe dil ki bimari hai.)
**English answer:** You must live in hills because you are suffering from a heart disease.

### 36. वो मुझसे दूर कभी नहीं जा सकती।
**Romanized:** (Wo mujhse door kabhi nahi ja sakti.)
**English answer:** She can never go away from me.

### 37. राम मिठाई खा सकता था।
**Romanized:** (Ram mithai kha sakta tha.)
**English answer:** Ram could have eaten the sweets.

### 38. विद्यार्थी स्कूल से घर आ सकते हैं।
**Romanized:** (Vidyarthi school se ghar aa sakte hai.)
**English answer:** Students can come home from school.

### 39. मैं कभी गाना नहीं गा सका।
**Romanized:** (Main kabhi gaana nahi ga saka.)
**English answer:** I could never sing song.

### 40. तुम मुझसे मिलने आ सकते हो।
**Romanized:** (Tum mujhse milne aa sakte ho.)
**English answer:** You can come to meet me.

### 41. तुम समय पे क्यों नहीं आ सके?
**Romanized:** (Tum samay pe kyon nahi aa sake?)
**English answer:** Why could you not come in time?

### 42. तुम कभी किसी को प्यार नहीं कर सकते।
**Romanized:** (Tum kabhee kisee ko pyar nahi kar sakte.)
**English answer:** You can never love anyone.

### 43. राजेश अपने दिल की बात कभी नहीं कह सका।
**Romanized:** (Rajesh apne dil ki baat kbhi ni kh saka)
**English answer:** Rajesh could never say his feelings.

### 44. अंगूर खट्टे हो सकते थे।
**Romanized:** (Angoor khatte ho sakte the.)
**English answer:** Grapes could have been sour.

### 45. तुम्हें मेरा आभारी होना चाहिए।
**Romanized:** (Tumhe mera abhari hona chahiye.)
**English answer:** You should be grateful to me.

### 46. हम तुझे बर्दाश्त कभी नहीं कर सकते।
**Romanized:** (Hum tujhe bardaasht kabhi nahi kar sakte.)
**English answer:** We can never tolerate you.

### 47. क्या मुझे चेहरे पर कुछ लगाना चाहिए?
**Romanized:** (Kya mujhe chehre par kuch lagana chahiye?)
**English answer:** Should/Shall I apply something on my face?

### 48. राम किसी तरह वहाँ पहुँच सकता था।
**Romanized:** (Ram kisi tarah vaha pahunch sakta tha.)
**English answer:** Ram could have somehow reached there.

### 49. राम को उससे कभी नहीं मिलना चाहिए।
**Romanized:** (Ram ko usse kabhi nahi milna chahiye.)
**English answer:** Ram should never meet him.

### 50. लोग तुम्हारे बारे में सोच सकते थे।
**Romanized:** (Log tumhare baare mein soch sakte the.)
**English answer:** People could have thought about you.

### 51. जिंदगी आसान होनी चाहिए थी पर नहीं थी।
**Romanized:** (Zindagi aasan honi chahie thi par nahi thi.)
**English answer:** Life should have been easy but wasn’t.

### 52. मुझे वक्त का पाबंद होना चाहिए।
**Romanized:** (Mujhe Waqt ka paband hona chahiye.)
**English answer:** I must be punctual.

### 53. उसने कहा कि वो हमारी मदद करेगा।
**Romanized:** (Usne kaha ki wo hamari madad karega.)
**English answer:** He said, he would help us.

### 54. दूल्हा दुल्हन को बात करनी चाहिए थी।
**Romanized:** (Dulha dulhan ko baat karni chahiye thi.)
**English answer:** Groom and bride should have spoken.

### 55. लोग तुम्हारे बारे में गलत सोच सकते हैं।
**Romanized:** (Log tumhare baare me galat soch sakte hai.)
**English answer:** People can think wrong/otherwise about you.

### 56. राकेश को लड़कियाँ नहीं छेड़नी चाहिए।
**Romanized:** (Rakesh ko ladkiyan nahi cheedni chahiye.)
**English answer:** Rakesh shouldn’t tease girls.

### 57. तुम्हें मुझे याद दिलाना चाहिए था।
**Romanized:** (Tumhen mujhe yaad dilana chahiye tha.)
**English answer:** You should have reminded me.

### 58. राम को मुझसे ज़रूर मिलना चाहिए था।
**Romanized:** (Ram ko mujhse jaroor milna chahiye tha.)
**English answer:** Ram must have met me.

### 59. उसे कहाँ जाना है?
**Romanized:** (Use kaha jana hai?)
**English answer:** Where has he to go?

### 60. वो कहाँ से आता था?
**Romanized:** (Wo kaha se aata tha?)
**English answer:** Where did he use to come from?

### 61. क्या वो जाना चाहता है?
**Romanized:** (Kya wo jana chahta hai?)
**English answer:** Does he want to go?

### 62. क्या उसे कुछ चाहिए था?
**Romanized:** (Kya use kuch chahiye tha?)
**English answer:** Did he need something?

### 63. तुम्हें इतनी जल्दी नहीं सोना चाहिए।
**Romanized:** (Tumhen itni jaldi nahi sona chahiye.)
**English answer:** You should not sleep this early.

### 64. तुम जब चाहो आ सकते हो।
**Romanized:** (Tum jab chaho aa sakte ho.)
**English answer:** Whenever you want, you can come.

### 65. तुम्हें कम से कम वहाँ जाना चाहिए था।
**Romanized:** (Tumhen kam se kam vaha jana chahiye tha.)
**English answer:** You should have at least gone there.

### 66. तुम जल्द ही अंग्रेज़ी बोल सकोगे।
**Romanized:** (Tum jald hee angreji bol sakoge.)
**English answer:** You will be able to speak English soon.

### 67. मैंने कभी नहीं सोचा था कि वह स्वार्थी होगा।
**Romanized:** (Maine kabhi nahi socha tha ki Wah swarthi hoga.)
**English answer:** I had never thought that he would be selfish.

### 68. तुम जब तक चाहो तब तक काम कर सकते हो।
**Romanized:** (Tum jab tak chaho tab tak kaam kar sakte ho.)
**English answer:** You can work as long as you want.

### 69. क्या वो ये काम कर सकेगा?
**Romanized:** (Kya wo ye kaam kar sakega?)
**English answer:** Will he be able to do this work?

### 70. बच्चा कुछ दिनों में ही अच्छी तरह बोल सकेगा।
**Romanized:** (Bachcha kuch dino mein hi acchi tarah bol sakega.)
**English answer:** Child will be able to speak within only a few days.

### 71. तुम्हें उसके घर वापिस जाना चाहिए।
**Romanized:** (Tumhen uske ghar wapis jana chahiye.)
**English answer:** You must go back to his home.

### 72. मुझे मालूम था कि वो जीतेगा।
**Romanized:** (Mujhe maloom tha ki wo jeetega.)
**English answer:** I knew that he would win.

### 73. तुम इम्तिहान पास नहीं कर सकते।
**Romanized:** (Tum imtihaan pass nahi kar sakte.)
**English answer:** You can’t pass the exam.

### 74. मैं आपको धन्यवाद देना चाहूँगा।
**Romanized:** (Mai aapko dhanyavad dena chahunga.)
**English answer:** I would like to thank you.

### 75. मुझे संदेह नहीं था कि तुम जीतोगे।
**Romanized:** (Mujhe sandeh nahi tha ki tum jeetoge.)
**English answer:** I had no doubt that you would win.

### 76. तुम खा सकते हो, चाहे ये या चाहे वो।
**Romanized:** (Tum kha sakte ho,chahe ye ya chahe wo.)
**English answer:** You can eat; either this or that.

### 77. मुझे लगा कि वो कभी नहीं आयेगा।
**Romanized:** (Mujhe laga ki vo kabhi nahi aayega.)
**English answer:** I thought that he will never come.

### 78. मैं तुमसे सिर्फ एक बार मिलना चाहूँगा।
**Romanized:** (Main tumse sirf ek baar milna chahunga.)
**English answer:** I would like to meet you only once.

### 79. वह पक्का बस से गया होगा।
**Romanized:** (Vah pakka bus se gaya hoga.)
**English answer:** He must have gone by bus.

### 80. तुम्हारे प्रयत्न सफल होने चाहिए।
**Romanized:** (Tumhare prayatan safal hone chahiye.)
**English answer:** Your efforts must be fruitful.

### 81. तुम किससे बात करना चाहोगे?
**Romanized:** (Tum kisse baat karna chahoge?)
**English answer:** Whom would you like to talk?

### 82. राम पढ़ने के बजाय खेलना पसन्द करेगा।
**Romanized:** (Ram padhne ke bajaye khelna pasand karega.)
**English answer:** Ram would like to play than study. / Ram would prefer to play over study.

### 83. मुझे गाली सुनने की आदत है।
**Romanized:** (Mujhe gaali sunne ki aadat hai.)
**English answer:** I am used to abuses.

### 84. तुम्हें इस तरह के माहौल में रहने की आदत हो चुकी है।
**Romanized:** (Tumhe is tarah ke maahaul mein rahne ki aadat ho chuki hai.)
**English answer:** You are used to live in such an environment.

### 85. तुम्हें कल उससे मिलना था।
**Romanized:** (Tumhen kal usse milna tha.)
**English answer:** You had to meet him yesterday.

### 86. आज मुझे शॉपिंग के लिए जाना चाहिए था।
**Romanized:** (Aaj mujhe shopping ke lie jana chahiye tha.)
**English answer:** I should have gone for shopping today.

### 87. पहले मैं तुमसे एक सवाल पूछना चाहूँगा।
**Romanized:** (Pehle main tumse ek sawal puchna chahunga.)
**English answer:** First, I would like to ask you a question.

### 88. तुम्हें मेरे परिवार से मिलना चाहिए था।
**Romanized:** (Tumhe mere pariwar se milna chahiye tha.)
**English answer:** You should have met my family.

### 89. क्या मुझे रात भर जगे रहने की आदत है?
**Romanized:** (Kya mujhe raat bhar jage rahne ki aadat h?)
**English answer:** Am I used to remain awaked/awoken whole night?

### 90. क्या मैं अंदर आ सकता हूँ?
**Romanized:** (Kya main andar aa sakta hoon?)
**English answer:** May I come in?

### 91. तुम्हें कम से कम आज तो काम करना चाहिए था।
**Romanized:** (Tumhe kam se kam aaj to kaam karna chahiye tha.)
**English answer:** You should have worked at least today.

### 92. क्या मैं अब जा सकता हूँ?
**Romanized:** (Kya main ab ja sakta hoon?)
**English answer:** May I go now?

### 93. भगवान हमें माफ करे।
**Romanized:** (Bhagwan hame maaf kare.)
**English answer:** May God forgive us!

### 94. क्या राम वहाँ जाता था?
**Romanized:** (Kya ram vaha jata tha?)
**English answer:** Did Ram use to go there?

### 95. मैं जा सकता हूँ।
**Romanized:** (Main ja sakta hoon.)
**English answer:** I can go.

### 96. मैं नहीं जा सकता।
**Romanized:** (Main nahi ja sakta.)
**English answer:** I can’t go.

### 97. क्या मैं जा सकता हूँ?
**Romanized:** (Kya main ja sakta hoon?)
**English answer:** Can I go?

### 98. क्या मैं नहीं जा सकता?
**Romanized:** (Kya main nahi ja sakta?)
**English answer:** Can I not go?

### 99. मैं कहाँ जा सकता हूँ?
**Romanized:** (Main kahan ja sakta hoon?)
**English answer:** Where can I go?

### 100. मैं कहाँ-कहाँ जा सकता हूँ?
**Romanized:** (Main kahan-kahan ja sakta hoon?)
**English answer:** Where all can I go?

### 101. आप किसके साथ बैठ सकते हो?
**Romanized:** (Aap kiske saath baith sakte ho?)
**English answer:** With whom can you sit?

### 102. वो अमेरिका नहीं जा पाया।
**Romanized:** (Woh America nahi ja paya.)
**English answer:** He couldn’t go to America.

### 103. क्या आप स्कूल जा पाए?
**Romanized:** (Kya aap school ja paye?)
**English answer:** Could you go to school?

### 104. क्या वो घर आ पाया?
**Romanized:** (Kya vo ghar aa paya?)
**English answer:** Could he come home?

### 105. मैं ये नहीं कर सका।
**Romanized:** (Main ye nahi kar saka.)
**English answer:** I couldn’t do it.

### 106. आप मेरे घर आ सकते थे।
**Romanized:** (Aap mere ghar aa sakte the.)
**English answer:** You could have come my home.

### 107. आप मुझसे मिल सकते थे पर आप नहीं मिल पाए।
**Romanized:** (Aap mujhse mil sakte the par aap nahi mil paye.)
**English answer:** You could have met me but you couldn’t.

### 108. आपको अपने दोस्तों से बात करनी चाहिए।
**Romanized:** (Aapko apne dosto se baat karni chahiye.)
**English answer:** You should talk to your friends.

### 109. आपको मुझे फोन नहीं करना चाहिए।
**Romanized:** (Aapko mujhe phone nahin karna chahiye.)
**English answer:** You should not call me.

### 110. मुझे वहाँ ज़रूर जाना चाहिए।
**Romanized:** (Mujhe wahan zarur jana chahiye.)
**English answer:** I must go there.

### 111. आपको वहाँ जाना ही चाहिए था।
**Romanized:** (Aapko wahan jana hi chahiye tha.)
**English answer:** You must have gone there.

### 112. हमें अपने देश के लिए लड़ना चाहिए।
**Romanized:** (Hame apane desh ke liye ladnaa chahiye.)
**English answer:** We ought to fight for our nation.

### 113. उसे अपने देश के लिए लड़ना चाहिए था।
**Romanized:** (Use apne desh ke lie ladna chahiye tha.)
**English answer:** He ought to have fought for his nation.

### 114. आज बारिश हो सकती है।
**Romanized:** (Aaj barish ho sakti hai.)
**English answer:** It may/might/could rain today.

### 115. कल बारिश हो सकती थी।
**Romanized:** (Kal barish ho sakti thi.)
**English answer:** It may have rained yesterday.

### 116. क्या मैं अंदर आ सकता हूँ?
**Romanized:** (Kya main andar aa sakta hoon?)
**English answer:** May I come in?

### 117. क्या मैं आपसे बात कर सकता हूँ?
**Romanized:** (Kya main aapse bat kar sakta hoon?)
**English answer:** May I talk to you?

### 118. क्या मैं राहुल से बात कर सकता हूँ?
**Romanized:** (Kya main Rahul se bat kar sakta hoon?)
**English answer:** Could I talk to Rahul please?

### 119. क्या मैं आपके साथ बैठ सकता हूँ?
**Romanized:** (Kya main aapke saath baith sakta hoon?)
**English answer:** Could I sit with you?

### 120. राहुल को जाना है।
**Romanized:** (Rahul ko jana hai.)
**English answer:** Rahul has to go.

### 121. राहुल को नहीं जाना है।
**Romanized:** (Rahul ko nahi jana hai.)
**English answer:** Rahul has not to go.

### 122. क्या राहुल को जाना है?
**Romanized:** (Kya Rahul ko jana hai?)
**English answer:** Has Rahul to go?

### 123. क्या राहुल को नहीं जाना है?
**Romanized:** (Kya Rahul ko nahi jana hai?)
**English answer:** Has Rahul not to go?

### 124. राहुल को कहाँ जाना है?
**Romanized:** (Rahul ko kaha jana hai?)
**English answer:** Where has Rahul to go?

### 125. मुझे वहाँ जाना पड़ता है।
**Romanized:** (Mujhe wahan jana padta hai.)
**English answer:** I have to go there.

### 126. उसे घर आना पड़ता है।
**Romanized:** (Use ghar aana padta hai.)
**English answer:** He has to come home.

### 127. उसे क्यों जाना पड़ता है?
**Romanized:** (Use kyon jana padta hai?)
**English answer:** Why has he to go?

### 128. मुझे जाना था।
**Romanized:** (Mujhe jana tha.)
**English answer:** I had to go.

### 129. मुझे जाना पड़ा।
**Romanized:** (Mujhe jana pada.)
**English answer:** I had to go.

### 130. मुझे जाना पड़ता था।
**Romanized:** (Mujhe jana padata tha.)
**English answer:** I had to go.

### 131. मुझे जाना नहीं पड़ा।
**Romanized:** (Mujhe jana nahi pada.)
**English answer:** I had not to go.

### 132. क्या मुझे जाना पड़ा?
**Romanized:** (Kya mujhe jana pada?)
**English answer:** Had I to go?

### 133. क्या मुझे जाना नहीं पड़ा।
**Romanized:** (Kya mujhe jana nahi pada.)
**English answer:** Had I not to go?

### 134. मुझे कहाँ जाना पड़ा?
**Romanized:** (Mujhe kahan jana pada?)
**English answer:** Where had I to go?

### 135. राहुल को स्कूल जाना पड़ेगा।
**Romanized:** (Rahul ko school jana padega.)
**English answer:** Rahul will have go to school.

### 136. पूजा को स्कूल से आना पड़ेगा।
**Romanized:** (Pooja ko school se aana padega.)
**English answer:** Pooja will have to come from school.

### 137. मैं आपके साथ डाँस करना चाहूँगा।
**Romanized:** (Main aapke saath dance karna chahunga.)
**English answer:** I would like to dance with you.

### 138. मैं आपके साथ बैठना चाहूँगा।
**Romanized:** (Main aapke saath baithna chahunga.)
**English answer:** I would like to sit with you.

### 139. मैं आपके साथ बात नहीं करना चाहूँगा।
**Romanized:** (Main aapke saath bat nahi karna chahunga.)
**English answer:** I would not like to talk to you.

### 140. क्या आप मुझसे बात करना चाहेंगे?
**Romanized:** (Kya aap mujhse bat karna chahenge?)
**English answer:** Would you like to talk to me?

### 141. क्या आप मुझसे मिलना चाहेंगे?
**Romanized:** (Kya aap mujhse milna chahenge?)
**English answer:** Would you like to meet me?

### 142. आप मुझसे कहाँ मिलना चाहेंगे?
**Romanized:** (Aap mujhse kahan milna chahenge?)
**English answer:** Where would you like to meet me?

### 143. आप क्या खाना चाहेंगे?
**Romanized:** (Aap kya khana chahenge?)
**English answer:** What would you like to eat?

### 144. आप क्या करना चाहेंगे?
**Romanized:** (Aap kya karna chahenge?)
**English answer:** What would you like to do?

### 145. मैं फुटबॉल खेलता था।
**Romanized:** (Main football khelta tha.)
**English answer:** I used to play football.

### 146. मैं फुटबॉल नहीं खेलता था।
**Romanized:** (Main football nahi khelta tha.)
**English answer:** I didn’t use to play football.

### 147. क्या आप फुटबॉल खेलते थे?
**Romanized:** (Kya aap football khelte the?)
**English answer:** Did you used to play football?

### 148. क्या आप फुटबॉल नहीं खेलते थे?
**Romanized:** (Kya aap football nahi khelte the?)
**English answer:** Did you not use to play football?

### 149. वो घर क्यों जाता था?
**Romanized:** (Wo ghar kyo jata tha?)
**English answer:** Why did he used to go home?

### 150. वो मुझसे क्यों मिलता था?
**Romanized:** (Wo mujhse kyo milta tha?)
**English answer:** Why did he used to meet me?

### 151. वो जाएगा।
**Romanized:** (Wo jaega.)
**English answer:** He will go.

### 152. वो ज़रूर जायेगा।
**Romanized:** (Wo zarur jayega.)
**English answer:** He must go. / He will definitely go.

### 153. शायद वो जाएगा।
**Romanized:** (Shayad vo jaega.)
**English answer:** He may/might go.

### 154. वो जा रहा होगा।
**Romanized:** (Wo ja raha hoga.)
**English answer:** He will be going. (Future) / He would be going. (Present)

### 155. वो ज़रूर जा रहा होगा।
**Romanized:** (Wo zarur ja raha hoga.)
**English answer:** He must be going.

### 156. शायद वो जा रहा होगा।
**Romanized:** (Shayad wo ja raha hoga.)
**English answer:** He may/might be going.

### 157. शायद बारिश हो रही होगी।
**Romanized:** (Shayad barish ho rahi hogi.)
**English answer:** It may/might be raining.

### 158. क्या आप चाहोगे कि मैं आपके साथ बैठूँ?
**Romanized:** (Kya aap chahoge ki main aapke saath baithun?)
**English answer:** Would you like me to sit with you?

### 159. क्या आप चाहते हो कि राहुल आपके साथ खेले?
**Romanized:** (Kya aap chahte ho ki Rahul aapke sath khele?)
**English answer:** Would you like Rahul to play with you?

### 160. क्या आप चाहोगे कि हम आपके घर आयें?
**Romanized:** (Kya aap chahoge ki ham apke ghar aaye?)
**English answer:** Would you like to us to come your home?

### 161. सोनम इस समय खेल रही होगी।
**Romanized:** (Sonam is samay khel rahi hogi.)
**English answer:** Sonam would be playing right now.

### 162. सोनम अब तक खेल चुकी होगी।
**Romanized:** (Sonam ab tak khel chuki hogi.)
**English answer:** Sonam would have played by now.

### 163. वो अब तक निकल चुके होंगे।
**Romanized:** (Wo ab tak nikal chuke honge.)
**English answer:** They will have left by now.

### 164. मैं आपसे नहीं मिल पाऊँगा।
**Romanized:** (Main aapse nahi mil paunga.)
**English answer:** I will not be able to meet you.

### 165. मैं आपके घर नहीं आ पाऊँगा।
**Romanized:** (Main aapke ghar nahin aa paunga.)
**English answer:** I will not be able to come your home.

### 166. क्या आप राकेश को फोन कर पाओगे?
**Romanized:** (Kya aap rakesh ko phone kar paoge?)
**English answer:** Will you be able to call Rakesh?

### 167. क्या राकेश राहुल से मिल पाएगा?
**Romanized:** (Kya rakesh Rahul se mil paega?)
**English answer:** Will Rakesh be able to meet Rahul?

## Source-text notes

- **Item 80:** The printed English key says 'You efforts must be fruitful'; 'Your' is restored as an obvious one-letter typo without changing the intended meaning.
- **Item 106:** The printed English key says 'You could have come my home.'; retained as printed despite its awkward grammar.
- **Item 121:** The printed key says 'Rahul has not to go.'; retained as printed.
- **Item 135:** The printed key says 'Rahul will have go to school.'; retained as printed.
- **Item 147:** The printed key uses 'Did you used to play football?'; retained as printed.
- **Item 149–150:** The printed key uses 'Why did he used to…?' in both entries; retained as printed.

**Editorial corrections:** Obvious Hindi OCR readings were corrected against the page images in items 33, 80, 110, 152 and 155; the Romanized spelling at item 66 was normalized; and the printed answer at item 80 was corrected from “You” to “Your” as an obvious typo. Other English answer-key wording and alternatives are preserved as printed.

**Unreadable text:** none identified.

