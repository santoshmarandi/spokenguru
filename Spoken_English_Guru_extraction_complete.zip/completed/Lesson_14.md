# Lesson 14 — Would + Be, Have & Been

**PDF pages:** 146–156 (printed pages 145–155)

**Instruction:** Translate the following sentences into English.

## Bilingual prompts and printed English answers

### 1. उसने कहा कि वो हमारी मदद करेगा।
**Romanized:** (Usne kha ki vo hamari madad karega.)
**English answer:** He said that he would help us.

### 2. मुझे मालूम था कि वह जीतेगा।
**Romanized:** (Mujhe maloom tha ki vah jitega.)
**English answer:** I knew that he would win.

### 3. मैंने कभी नहीं सोचा था कि वह इतना स्वार्थी होगा।
**Romanized:** (Maine kabhi nahi socha ki vah itna swarthi hoga.)
**English answer:** I had never imagined that he would be such a selfish.

### 4. मुझे संदेह नहीं था कि तुम जीतोगे।
**Romanized:** (Mujhe sandeh nahi tha ki tum jitoge.)
**English answer:** I had no doubt that you would win.

### 5. मुझे लगा कि वो कभी नहीं आयेगा।
**Romanized:** (Mujhe laga ki vo kabhi nahi aayega.)
**English answer:** I thought that he would never come.

### 6. क्या तुम मेरी मदद करोगे?
**Romanized:** (Kya tum meri madad karoge?)
**English answer:** Would you help me?

### 7. क्या तुम कृपया दरवाजा खोल दोगे?
**Romanized:** (Kya tum kripya darwaja khol doge?)
**English answer:** Would you please open the door?

### 8. राम पढ़ने के बजाय खेलना पसंद करेगा।
**Romanized:** (Ram padhne ke bajay khelna pasand karega.)
**English answer:** Ram would like to play than study.

### 9. क्या तुम मुझसे मिलना चाहोगे?
**Romanized:** (Kya tum mujhse milna chahoge?)
**English answer:** Would you like to meet me?

### 10. मैं 6 बजे उठता था जब मैं एक बच्चा था।
**Romanized:** (Mai 6 baje uthta tha jab mai ek baccha tha.)
**English answer:** I would wake up at 6 when I was a kid.

### 11. उसने कहा था कि वो मुम्बई जाएगा।
**Romanized:** (Usne kha tha ki Wo Mumbai jaega.)
**English answer:** He had said that he would go to Mumbai.

### 12. राम ने कहा कि वह बर्गर नहीं खाएगा।
**Romanized:** (Ram ne kaha ki vah burger nahi khayega.)
**English answer:** Ram said that he would not eat burger.

### 13. मैंने आपको सूचित किया था कि मैं ऑफिस 11 बजे तक पहुँचूँगा।
**Romanized:** (Maine aapko suchit kiya tha ki mai office 11 baje tak pahunchunga.)
**English answer:** I had informed you that I would reach office by 11 am.

### 14. अगर मैं जाता, तो वो घर आता।
**Romanized:** (Agar mai jata, to wo ghar aata.)
**English answer:** If I went, he would come home.

### 15. अगर मैं प्रधानमंत्री होता, तो आपकी मदद करता।
**Romanized:** (Agar mai Pradhan Mantri hota to aap ki madad karta.)
**English answer:** If I were the PM, I would help you.

### 16. जब मैं एक बच्चा था, मैं अमन के साथ खेलता था। वो हमेशा अपनी बॉल देता था। हम दूसरे छात्रों को तंग करते थे। शिक्षक हमें अक्सर डाँटते थे।
**Romanized:** (Jab mai ek baccha tha. Main Aman ke saath khelta tha. Vo hamesha apni ball deta tha. Hum dusre chhatron ko tang karte the. Shikshak hamein aksar daantte the.)
**English answer:** When I was a kid, I would play with Aman. He would always give me his ball. We would bother other students. Teachers would often scold us.

### 17. क्या आप मेरे साथ डाँस करेंगे?
**Romanized:** (Kya aap mere saath dance karenge?)
**English answer:** Would you dance with me?

### 18. क्या आप अयांश के साथ खेलेंगे?
**Romanized:** (Kya aap Ayansh ke saath khelenge?)
**English answer:** Would you play with Ayansh?

### 19. क्या आप मेरे साथ रहेंगे क्योंकि मैं अकेला हूँ?
**Romanized:** (Kya aap mere saath rahenge kyonki mai akela hun?)
**English answer:** Would you join me as I am alone?

### 20. क्या आप मेरे साथ डाँस करना पसंद करेंगे/चाहेंगे?
**Romanized:** (Kya aap mere saath dance karna pasand karenge/chahenge?)
**English answer:** Would you like to dance with me?

### 21. क्या आप वहाँ जाना पसंद करेंगे/चाहेंगे?
**Romanized:** (Kya aap wahan jana pasand karenge/chahenge?)
**English answer:** Would you like to go there?

### 22. क्या आप अयांश के साथ खेलना पसंद करेंगे/चाहेंगे?
**Romanized:** (Kya aap Ayansh ke saath khelna pasand karenge/chahenge?)
**English answer:** Would you like to play with Ayansh?

### 23. मैं अब पढ़ाई करना पसंद करूँगा/चाहूँगा।
**Romanized:** (Mai ab padhai karna pasand karunga/chahunga.)
**English answer:** I would like to study now.

### 24. वो एक पुराना गाना गाना पसंद करेगा/चाहेगा।
**Romanized:** (Wo ek purana gana gana pasand karega/chahega.)
**English answer:** He would like to sing an old song.

### 25. क्या आप चाहेंगे कि मैं जाऊँ?
**Romanized:** (Kya aap chahenge ki mai jao?)
**English answer:** Would you like me to go?

### 26. क्या तुम चाहोगे कि मैं खेलूँ?
**Romanized:** (Kya tum chahoge ki mai khelu?)
**English answer:** Would you like me to play?

### 27. क्या राम चाहेगा कि मैं खेलूँ?
**Romanized:** (Kya Ram chahega ki mai khelu?)
**English answer:** Would Ram like me to play?

### 28. क्या मैं चाहूँगा कि तुम न खेलो?
**Romanized:** (Kya mai chahunga ki tum na khelo?)
**English answer:** Would I like you not to play?

### 29. क्या उसे बुरा लगेगा यदि मैं घर चला जाऊँ?
**Romanized:** (Kya use bura lagega yadi mai ghar chala jaun?)
**English answer:** Would he mind if I go home?

### 30. क्या उनको बुरा लगेगा यदि मैं अपनी फुटबॉल उन्हें न दूँ?
**Romanized:** (Kya unko bura lagega yadi mai apni football unhe na du?)
**English answer:** Would they mind if I don’t give them my football?

### 31. क्या उसे बुरा लगेगा यदि वे इस प्रतियोगिता के लिए उसे न चुनें?
**Romanized:** (Kya use bura lagega yadi ve is pratiyogita ke liye use na chune?)
**English answer:** Would he mind if they don’t select him for this competition?

### 32. आपको वहाँ जाने में कोई दिक्कत परेशानी तो नहीं?
**Romanized:** (Aapko wahan jane mein koi dikkat pareshani to nahi?)
**English answer:** Would you mind going there?

### 33. आपको कोई दिक्कत तो नहीं अगर आप मुझसे रविवार को मिलें?
**Romanized:** (Aapko koi dikkat to nahi agar aap mujhse ravivar ko milen?)
**English answer:** Would you mind meeting me on Sunday?

### 34. क्या उसे मुझे फोन करने में दिक्कत होगी?
**Romanized:** (Kya use mujhe phone karne mein dikkat hogi?)
**English answer:** Would he mind calling me?

### 35. उसे हम लोगों के साथ खेलने में परेशानी तो नहीं होगी?
**Romanized:** (Use hum logon ke saath khelne mein pareshani to nahi hogi?)
**English answer:** Would he mind playing with us?

### 36. क्या ये ठीक होगा यदि वो आपके घर आये/आयेगा?
**Romanized:** (Kya ye thik hoga yadi wo aapke ghar aaye/aayega?)
**English answer:** Would it be Ok, if he comes your home?

### 37. क्या ये ठीक होगा अगर मैं आपको 50 रुपये दूँ?
**Romanized:** (Kya ye thik hoga agar mai aapko 50 rupay du?)
**English answer:** Would it be OK if I give you Rs. 50?

### 38. क्या ये ठीक होगा यदि वो आपका दिल दुखाए?
**Romanized:** (Kya ye thik hoga yadi vo aapka dil dukhaye?)
**English answer:** Would it be fine if he hurts you?

### 39. मैं खेलता।
**Romanized:** (Mai khelta.)
**English answer:** I would play.

### 40. मैं जाता।
**Romanized:** (Mai jata.)
**English answer:** I would go.

### 41. वो आता।
**Romanized:** (Wo aata.)
**English answer:** He would come.

### 42. वो गिटार बजाता।
**Romanized:** (Wo guitar bajata.)
**English answer:** He would play the guitar.

### 43. मैं क्रिकेटर होता।
**Romanized:** (Mai cricketer hota.)
**English answer:** I would be a cricketer.

### 44. मैं गायक होता।
**Romanized:** (Mai gayak hota.)
**English answer:** I would be a singer.

### 45. राहुल डाँसर होता।
**Romanized:** (Rahul dancer hota.)
**English answer:** Rahul would be a dancer.

### 46. राहुल डाँसर नहीं होता।
**Romanized:** (Rahul dancer nahi hota.)
**English answer:** Rahul would not be a dancer.

### 47. क्या राहुल डाँसर होता?
**Romanized:** (Kya Rahul dancer hota?)
**English answer:** Would Rahul be a dancer?

### 48. वो जा रहा होता।
**Romanized:** (Wo ja raha hota.)
**English answer:** He would be going.

### 49. मैं घर आ रहा होता।
**Romanized:** (Mai ghar aa raha hota.)
**English answer:** I would be coming home.

### 50. बच्चे सो रहे होते।
**Romanized:** (Bacche so rahe hote.)
**English answer:** Kids would be sleeping.

### 51. राम को राहुल के द्वारा भेजा जाता।
**Romanized:** (Ram ko Rahul ke dwara bheja jata.)
**English answer:** Ram would be sent by Rahul.

### 52. हमें गिटार दिया जाता।
**Romanized:** (Hame guitar diya jata.)
**English answer:** We would be given the guitar.

### 53. मेरे पास पेन होता।
**Romanized:** (Mere paas pen hota.)
**English answer:** I would have a pen.

### 54. राहुल के पास किताब होती।
**Romanized:** (Rahul ke paas kitab hoti.)
**English answer:** Rahul would have a book.

### 55. हमारे पास पैसे नहीं होते।
**Romanized:** (Hamare paas paise nahi hote.)
**English answer:** We wouldn’t have money.

### 56. मैं घर आ चुका होता।
**Romanized:** (Mai ghar aa chuka hota.)
**English answer:** I would have come home.

### 57. वो दिल्ली जा चुका होता।
**Romanized:** (Wo Delhi ja chuka hota.)
**English answer:** He would have left for Delhi.

### 58. मैंने आपका खेल नहीं देखा था, वरना मैं आपका फैन हो चुका होता।
**Romanized:** (Maine aapka khel nahi dekha tha, varna mai aapka fan ho chuka hota.)
**English answer:** I hadn’t seen your play/game; or else I would’ve been a fan of yours.

### 59. मैं डॉक्टर बन चुका होता।
**Romanized:** (Mai doctor ban chuka hota.)
**English answer:** I would’ve become a doctor.

### 60. मैं सुबह से खेल रहा होता।
**Romanized:** (Mai subah se khel raha hota.)
**English answer:** I would have been playing since morning.

### 61. वो 2 घंटे से पढ़ रही होती।
**Romanized:** (Wo 2 ghante se padh rahi hoti.)
**English answer:** She would have been studying for 2 hours.

### 62. मुझे राहुल के द्वारा भेजा जा चुका होता।
**Romanized:** (Mujhe Rahul ke dwara bheja ja chuka hota.)
**English answer:** I would have been sent by Rahul.

### 63. हमें पानी दिया जा चुका होता।
**Romanized:** (Hame pani diya ja chuka hota.)
**English answer:** We would have been given water.

### 64. आज मैं ऑफिस जाता पर मेरा मन नहीं कर रहा।
**Romanized:** (Aaj main office jata par mera man nahi kar raha.)
**English answer:** I would go to office today but I’m not feeling like.

### 65. अगर मेरे पास पैसे होते, तो मैं आपकी मदद करता।
**Romanized:** (Agar mere paas paise hote to main aapki madad karta.)
**English answer:** If I had money, I would help you.

### 66. उन दिनों मैं 5 बजे उठता था। फिर मैं अपने दोस्त के साथ जिम जाता था। हम बहुत मज़े करते थे।
**Romanized:** (Un dino main 5 baje uthata tha. Fir main apane dost ke saath gym jaata tha. Ham bahut maze karate the.)
**English answer:** Those days, I would wake up at 5. Then, I would go to gym with my friend. We would enjoy a lot.

### 67. वो हमेशा मुझे बिना किसी कारण के डाँटता था इसलिए मुझे कभी उससे बात करने का मन नहीं हुआ।
**Romanized:** (Vo hamesha mujhe bina kisee kaaran ke daantata tha isalie mujhe kabhee usase baat karane ka man nahin hua.)
**English answer:** He’d always scold me for no reason, that’s why I never felt like talking to him.

### 68. उसने कहा कि वह बाजार से कुछ खरीदेगी।
**Romanized:** (Usane kaha ki vah baajaar se kuchh khareedegi.)
**English answer:** She said that she would buy something from the market.

### 69. मुझे पहले से ही अंदाजा था कि वह यहाँ नहीं आएगा।
**Romanized:** (Mujhe pahale se hee andaaza tha ki vah yahaan nahin aaega.)
**English answer:** I already had an idea that he wouldn’t come here.

### 70. जहाँ तक मैं तेरे पापा को जानता हूँ, वो इस प्रस्ताव को स्वीकार नहीं करेंगे।
**Romanized:** (Jahaan tak main tere papa ko janata hoon, vo is prastaav ko sweekar nahi karenge.)
**English answer:** As far as I know your father, he would not accept this proposal.

### 71. मुझे लगता है कि आज बारिश होगी।
**Romanized:** (Mujhe lagata hai ki aaj baarish hogi.)
**English answer:** I think it would rain today.

### 72. क्या आप मेरे साथ लॉन्ग ड्राइव पर जाना चाहेंगे?
**Romanized:** (Kya aap mere saath long drive par jaana chaahenge?)
**English answer:** Would you like to go on a long drive with me?

### 73. क्या आप ब्लॉगिंग के ज़रिए पैसा कमाना चाहेंगे?
**Romanized:** (Kya aap blogging ke zariye paisa kamaana chaahenge?)
**English answer:** Would you like to earn money through blogging?

### 74. क्या आप कृपया शांत रहेंगे?
**Romanized:** (Kya aap krpaya shaant rahenge?)
**English answer:** Would you please be quiet?

### 75. क्या आप कृपया इस प्रश्न को हल करने में मेरी मदद करेंगे?
**Romanized:** (Kya aap krpaya is prashn ko hal karane mein meree madad karenge?)
**English answer:** Would you please help me solve this question?

### 76. मैं आज आपसे मिलना चाहूँगा।
**Romanized:** (Main aaj aapase milana chaahoonga.)
**English answer:** I would like to meet you today.

### 77. मैं और अधिक पैसा कमाना चाहूँगा ताकि मैं अपने लिए एक नई स्कूटी खरीद सकूं।
**Romanized:** (Main aur adhik paisa kamaana chaahoonga taaki main apane lie ek naee scooty khareed sakoon.)
**English answer:** I would like to earn more money so that I could buy a new scooty for myself.

### 78. वो आज एक डाँसर होता।
**Romanized:** (Vo aaj ek dancer hota.)
**English answer:** He would be a dancer today.

### 79. मैं इस वक्त अमेरिका में होता।
**Romanized:** (Main is waqt America mein hota.)
**English answer:** I would be in America right now.

### 80. जब भी मैं उसके घर जाता, वो घर पर होता था।
**Romanized:** (Jab bhee main usake ghar jaata, vah ghar par hota tha.)
**English answer:** Whenever I would go to his house, he would be at home.

### 81. जब भी मुझे उसकी ज़रूरत पड़ती, वो मेरे साथ होता था।
**Romanized:** (Jab bhi mujhe usaki zaroorat padti, vo mere saath hota tha.)
**English answer:** Whenever I needed him, he would be with me.

### 82. आज वो उस कम्पनी में काम कर रहा होता।
**Romanized:** (Aaj vo us company me kaam kar raha hota.)
**English answer:** He would be working in that company today.

### 83. काश मैं उसे इंग्लिश सिखा रहा होता।
**Romanized:** (Kaash main use English sikha raha hota.)
**English answer:** I wish I would be teaching him English.

### 84. धोनी इस वक्त खेल रहा होगा।
**Romanized:** (Dhoni is waqt khel raha hoga.)
**English answer:** Dhoni would be playing right now.

### 85. क्या वह इन दिनों ऑफिस जा रहा होगा? मुझे नहीं लगता।
**Romanized:** (Kya vo in dinon office ja raha hoga? Mujhe nahin lagta.)
**English answer:** Would he be going to office these days? I don’t think.

### 86. अगर मैंने ड्राइवर से रिक्वेस्ट न की होती, तो बस अब तक निकल चुकी होती।
**Romanized:** (Agar maine driver se request na ki hoti, to bus ab tak nikal chuki hoti.)
**English answer:** If I hadn’t requested the driver, the bus would have left by now.

### 87. मुझसे गलती हो गयी होती! भगवान का शुक्र है, मैंने आखिर में एक सही फैसला लिया।
**Romanized:** (Mujhse galati ho gayi hoti! Bhagavaan ka shukr hai, mainne aakhir mein ek sahee faisala liya.)
**English answer:** I would have made a mistake! Thank God, I finally made the right decision.

### 88. धोनी इस वक्त तक खेल चुका होगा।
**Romanized:** (Dhoni is waqt tak khel chuka hoga.)
**English answer:** Dhoni would have played by now.

### 89. बस अब तक निकल चुकी होगी।
**Romanized:** (Bus ab tak nikal chuki hogi.)
**English answer:** The bus would have left by now.

### 90. अगर उसने अच्छी पढ़ाई की होती, तो वह आज डॉक्टर होता।
**Romanized:** (Agar usane achchhee padhaee kee hotee, to vah aaj doctor hota.)
**English answer:** If he had studied well, he would have been a doctor today.

### 91. अगर उसने चुनावों में मेरा साथ दिया होता तो आज वो मेरे साथ होता।
**Romanized:** (Agar usne elections mein mera saath diya hota to aaj vo mere saath hota.)
**English answer:** If he had supported me in elections, he would have been with me now.

### 92. वो सुबह से खेल रहा होता, अगर मैं उसे नहीं डांटता।
**Romanized:** (Vo subah se khel raha hota, agar main use nahin daantata.)
**English answer:** He would have been playing since morning if I hadn’t scolded him.

### 93. अगर उसने उस दिन वो घर ले लिया होता, तो वो मुम्बई में आज 10 साल से रह रहा होता।
**Romanized:** (Agar usane us din vo ghar le liya hota, to vo Mumbai mein aaj 10 saal se rah raha hota.)
**English answer:** If he had taken that house that day, he would have been living in Mumbai for 10 years today.

### 94. आज मेरे पास ये सब होता, पर मैंने उस दिन बहुत बड़ी गलती की।
**Romanized:** (Aaj mere paas ye sab hota, par maine us din bahut badee galatee kee.)
**English answer:** I would have had all this, but I made a huge mistake that day.

### 95. अगर आपने मुझे एक मौका दिया होता, तो आज मेरे पास कई फिल्में होतीं।
**Romanized:** (Agar aapane mujhe ek mauka diya hota, to aaj mere paas kaee films hoteen.)
**English answer:** If you had given me a chance, I would have had many films today.

### 96. शुक्र है, सरकार ने पॉलिसी बदल दी, वरना ये सारा माल आज ही बेचना पड़ता।
**Romanized:** (Shukr hai, sarakaar ne policy badal dee, varana ye saara maal aaj hee bechana padata.)
**English answer:** Thank God, the government changed the policy; or else I would have to sell all this stuff today itself. / Thank God, the government changed the policy; or else I would have had to sell all this stuff today itself.

### 97. अगर आपने मदद न की होती, तो मुझे आज ऑफिस जाना पड़ जाता।
**Romanized:** (Agar aapane madad na kee hotee, to mujhe aaj office jaana pad jaata.)
**English answer:** If you had not helped me, I would have to go to office today. / If you had not helped me, I would have had to go to office today.

### 98. आपको वहाँ रोज़ जाना पड़ता होगा।
**Romanized:** (Aapako vahaan roz jaana padata hoga.)
**English answer:** You would have to go there every day.

### 99. आपको वहाँ रोज़ जाना पड़ा होगा।
**Romanized:** (Aapako vahaan roz jaana pada hoga.)
**English answer:** You would have had to go there every day.

### 100. वहाँ हर व्यक्ति को रूल्स मानने पड़ते होंगे।
**Romanized:** (Vahaan har vyakti ko rules maanane padate honge.)
**English answer:** There, every person would have to follow the rules.

### 101. वहाँ हर व्यक्ति को रूल्स मानने पड़े होंगे।
**Romanized:** (Vahaan har vyakti ko rules maanane pade honge.)
**English answer:** There, every person would have had to follow the rules.

### 102. क्या वह इन दिनों स्कूल जा रही होगी?
**Romanized:** (Kya vah in dinon school ja rahee hogee?)
**English answer:** Would she be going to school these days?

### 103. मुझे यकीन है कि वह हार के बारे में नहीं सोच रहा होगा।
**Romanized:** (Mujhe yakeen hai ki vah haar ke baare mein nahin soch raha hoga.)
**English answer:** I am sure he wouldn’t be thinking about the defeat.

### 104. उसने कहा कि वो हम सबकी मदद करेगा।
**Romanized:** (Usne kha ki vo ham sabki madad karega.)
**English answer:** He said that he would help all of us.

### 105. मुझे संदेह बिल्कुल नहीं था कि तुम जीतोगे।
**Romanized:** (Mujhe sandeh bilkul nahi tha ki tum jitoge.)
**English answer:** I had no doubt at all that you would win.

### 106. मुझे मालूम नहीं था कि वह जीतेगा।
**Romanized:** (Mujhe maloom nahi tha ki vah jitega.)
**English answer:** I didn’t know that he would win.

### 107. क्या तुम आज मेरी मदद करोगे?
**Romanized:** (Kya tum aaj meri madad karoge?)
**English answer:** Would you please help me today?

### 108. क्या तुम उससे मिलना चाहोगे?
**Romanized:** (Kya tum usse milna chahoge?)
**English answer:** Would you like to meet him?

### 109. मैं सुबह 4 बजे उठता था जब मैं एक बच्चा था।
**Romanized:** (Mai subah 4 baje uthta tha jab mai ek baccha tha.)
**English answer:** I would wake up at 4 in the morning when I was a kid.

### 110. मैंने कभी सोचा तक नहीं था कि वह इतना स्वार्थी होगा।
**Romanized:** (Mene kabhi socha tak nahi tha ki vah itna swarthi hoga.)
**English answer:** I had never even thought that he would be such a selfish.

### 111. अगर मैं वहाँ जाता, तो वो घर आता।
**Romanized:** (Agar main vahaan jata, to wo ghar aata.)
**English answer:** If I went there, he would come home.

### 112. अगर मैं पैसे वाला होता, तो आपकी मदद करता।
**Romanized:** (Agar main paise vala hota to aapki madad karta.)
**English answer:** If I were rich, I would help you.

### 113. क्या आप चाहेंगे कि मैं आऊँ?
**Romanized:** (Kya aap chahenge ki main aaoon?)
**English answer:** Would you like me to come?

### 114. क्या आप नहीं चाहेंगे कि मैं आऊँ?
**Romanized:** (Kya aap nahi chahenge ki main aaoon?)
**English answer:** Would you not like me to come?

### 115. क्या आप चाहेंगे कि मैं न आऊँ?
**Romanized:** (Kya aap chahenge ki main na aaoon?)
**English answer:** Would you like me not to come?

### 116. वो 4 घंटे से पढ़ रही होती।
**Romanized:** (Wo 4 ghante se padh rahi hoti.)
**English answer:** She would have been studying for 4 hours.

### 117. वो दिल्ली से जा चुका होता।
**Romanized:** (Wo Delhi se ja chuka hota.)
**English answer:** He would have left from Delhi.

### 118. मैं इस वक्त तक घर आ चुका होता।
**Romanized:** (Mai is waqt tak ghar aa chuka hota.)
**English answer:** I would have come home by this time.

### 119. मेरे पास किताब होती पर नहीं है।
**Romanized:** (Mere paas kitab hoti par nahi hai.)
**English answer:** I would have had a book but I don’t have any.

### 120. मुझे लगता है कि आज बारिश नहीं होगी।
**Romanized:** (Mujhe lagata hai ki aaj baarish nahi hogi.)
**English answer:** I think it would not rain today.

### 121. मुझे लगता है कि आज ओले पड़ेंगे।
**Romanized:** (Mujhe lagata hai ki aaj ole padenge.)
**English answer:** I think it would hail today.

### 122. वह 7 बजे उठता था। वो मुझे 8 बजे फोन करता था फिर वह अपनी किताबें खोल देता था।
**Romanized:** (Vah 7 baje uthta tha. Wo mujhe 8 baje phone karta tha phir vah apni kitabe khol deta tha.)
**English answer:** He used to wake up at 7. He’d call me at 8. Then, he’d open his books.

### 123. वो आज एक बॉक्सर होता।
**Romanized:** (Vo aaj ek boxer hota.)
**English answer:** He would be a boxer today.

### 124. मैं इस वक्त स्कूल में होता।
**Romanized:** (Main is waqt school mein hota.)
**English answer:** I would be in school right now.

### 125. काश मैं उसके साथ रह रहा होता।
**Romanized:** (Kaash main uske sath rah raha hota.)
**English answer:** I wish I would be living with him.

### 126. काश मैं डॉक्टर बन गया होता।
**Romanized:** (Kaash main Doctor ban gaya hota.)
**English answer:** I wish I would have become a doctor.

### 127. वो इस वक्त मुझे कहीं से देख रहा होगा।
**Romanized:** (Vo is waqt mujhe kaheen se dekh raha hoga.)
**English answer:** He would be watching me from somewhere right now.

### 128. हमारे पास पैसे नहीं होते थे, पर फिर भी हम हिम्मत नहीं हारते थे।
**Romanized:** (Hamare paas paise nahi hote the, par fir bhi ham himmat nahi haarte the.)
**English answer:** We wouldn’t have money; still, we would not lose courage.

### 129. क्या वह इन दिनों जिम जा रही होगी?
**Romanized:** (Kya vah in dinon gym ja rahee hogee?)
**English answer:** Would she be going to gym these days?

### 130. वो अब तक निकल चुकी होगी।
**Romanized:** (Vo ab tak nikal chuki hogi.)
**English answer:** She would have left by now.

### 131. आपको रोज़ उसे फोन करना पड़ता होगा।
**Romanized:** (Aapako roz use phone karna padata hoga.)
**English answer:** You would have to call him every day.

### 132. उसे ये न चाहकर भी करना पड़ा होगा।
**Romanized:** (Use ye na chaahkar bhi karna pada hoga.)
**English answer:** He would have had to do it unwillingly.

### 133. जब भी मैं उसे कॉल करता, वो प्यार से बात करता था।
**Romanized:** (Jab bhee main use call karta, vo pyar se baat karta tha.)
**English answer:** Whenever I would call him, he would talk politely.

### 134. बचपन में हम किसी की नहीं सुनते थे।
**Romanized:** (Bachpan me ham kisi ki nahi sunte the.)
**English answer:** We would not listen to anyone, when we were kid.

## Source-text notes

- **Items 3, 110:** The printed answer uses 'such a selfish'; retained as printed.
- **Items 8:** The printed answer says 'Ram would like to play than study.'; retained as printed.
- **Items 31:** The printed answer asks 'Would he mind if they don’t select him for this competition?'; retained as printed.
- **Items 58, 96, 97:** Printed alternatives separated by slashes are preserved as given.
- **Items 64:** The printed answer says 'I would go to office today but I’m not feeling like.'; retained as printed.
- **Items 85:** The printed answer ends 'I don’t think.'; retained as printed.
- **Items 134:** The printed answer says 'when we were kid.'; retained as printed.

**Editorial corrections:** Hindi OCR on items 13, 16, 53, 66, 67, 86, 93 and 121 was corrected against the page images; recurring OCR readings of पसंद were normalized. The long Romanized line for item 16 was checked against the printed page. Answer-key alternatives and unusual English wording are otherwise preserved and flagged above.

**Unreadable text:** none identified.

