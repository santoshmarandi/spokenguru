# Lesson 26 — Use of “Have, Having...”

**PDF pages:** 356–359 (printed pages 355–358)

## Please translate the following sentences into English:

1. **Hindi prompt:** मेरा दिन अच्छा गुजर रहा है।  
   **Romanized:** Mera din acha guzar raha hai.  
   **English answer:** I am having a good day. / I am going through a good day.  

2. **Hindi prompt:** तुम्हारे पास क्या है?  
   **Romanized:** Tumhare paas kya hai?  
   **English answer:** What do you have?  

3. **Hindi prompt:** मैंने खाना खा लिया है।  
   **Romanized:** Maine khana kha liya hai.  
   **English answer:** I have eaten the food. / I have taken the food. / I have had the food.  

4. **Hindi prompt:** राहुल ने खाना खा लिया है।  
   **Romanized:** Rahul ne khana kha liya hai.  
   **English answer:** Rahul has eaten the food. / Rahul has taken the food. / Rahul has had the food.  

5. **Hindi prompt:** आपके पास क्या है?  
   **Romanized:** Aapke pas kya hai?  
   **English answer:** What do you have?  

6. **Hindi prompt:** आप ये अपने पास रखिए।  
   **Romanized:** Aap ye apne pas rakhiye.  
   **English answer:** You keep it with yourself. / You have it with yourself.  

7. **Hindi prompt:** ये लीजिए।  
   **Romanized:** Ye lijiye.  
   **English answer:** Have it please. / Here it is.  

8. **Hindi prompt:** आपके पास क्या था?  
   **Romanized:** Aapke pas kya tha?  
   **English answer:** What did you have?  

9. **Hindi prompt:** वो पानी पी रहा है।  
   **Romanized:** Wo paani pee raha hai.  
   **English answer:** He is drinking water. / He is taking water. / He is having water.  

10. **Hindi prompt:** आपसे मिलने के बाद मैं निकल गया।  
   **Romanized:** Aapse milne ke bad mai nikal gaya.  
   **English answer:** Having met you, I left.  

11. **Hindi prompt:** तुम्हें देखने के बाद, मैं तुम्हारे सपनों में खो गया।  
   **Romanized:** Tumhe dekhne ke baad mai tumhare sapno mein kho gaya.  
   **English answer:** Having seen you, I got lost in your dreams.  

12. **Hindi prompt:** ऐसा घर मेरे पास हो, मेरा सपना था।  
   **Romanized:** Aisa ghar mere pas ho, mera sapna tha.  
   **English answer:** To have such a house was my dream.  

13. **Hindi prompt:** ऐसा पति मिलना मेरी ख्वाहिश थी।  
   **Romanized:** Aisa pati milna meri khwahish thi.  
   **English answer:** To have such a husband was my desire.  

14. **Hindi prompt:** आप जैसा अध्यापक पाकर मैं खुश हूँ।  
   **Romanized:** Aap jaisa adhyapak pakar main khush hun.  
   **English answer:** I am happy to have such a teacher like you.  

15. **Hindi prompt:** आप जैसा स्टूडेंट पाना मेरा सौभाग्य है।  
   **Romanized:** Aap jaisa student pana mera saubhagya hai.  
   **English answer:** I am lucky to have such a student like you.  

16. **Hindi prompt:** कार होना मेरी दिली इच्छा है।  
   **Romanized:** Car hona meri dili iccha hai.  
   **English answer:** To have a car is my whole-hearted will.  

17. **Hindi prompt:** तुम्हें पाना मेरी जिंदगी की दिली ख्वाहिश रहेगी।  
   **Romanized:** Tumhe pana meri zindagi ki dili khwahish rahegi.  
   **English answer:** To have you will remain the whole-hearted desire of my life.  

18. **Hindi prompt:** उसके पास कार हो सकती है।  
   **Romanized:** Uske paas car ho sakti hai.  
   **English answer:** He may/could/might have a car.  

19. **Hindi prompt:** राहुल के पास शायद पैसे न हों।  
   **Romanized:** Rahul ke paas shayad paise na ho.  
   **English answer:** Rahul may/might not have money.  

20. **Hindi prompt:** हमें घर जाना होगा।  
   **Romanized:** Hame ghar jana hoga.  
   **English answer:** We will have to go home.  

21. **Hindi prompt:** हमें समझौता करना होगा।  
   **Romanized:** Hame samjhauta karna hoga.  
   **English answer:** We will have to compromise.  

22. **Hindi prompt:** मुझे खेलना है।  
   **Romanized:** Mujhe khelna hai.  
   **English answer:** I have to play.  

23. **Hindi prompt:** हमें नहीं खेलना है।  
   **Romanized:** Hame nahi khelna hai.  
   **English answer:** We have not to play. / We don't have to play.  

24. **Hindi prompt:** क्या मुझे जाना है?  
   **Romanized:** Kya mujhe jana hai?  
   **English answer:** Have I to go? / Do I have to go?  

25. **Hindi prompt:** मेरा टाइम अच्छा कट रहा है।  
   **Romanized:** Mera time accha kat raha hai.  
   **English answer:** I am having a good time. / I am going through a good time.  

26. **Hindi prompt:** लगता है उसके पास पैन है।  
   **Romanized:** Lagta hai uske paas pen hai.  
   **English answer:** Seems as, he has a pen. / He seems to have a pen.  

27. **Hindi prompt:** लगता है तुम्हारे पास दिमाग नहीं है।  
   **Romanized:** Lagta hai tumhare paas dimag nahi hai.  
   **English answer:** It seems that you don't have brain. / You seem to have no brain.  

28. **Hindi prompt:** आपसे मिले हुए मुझे 2 साल हो गए हैं।  
   **Romanized:** Aapse mile hue mujhe do saal ho gaye hai.  
   **English answer:** It has been 2 years to me having met you.  

29. **Hindi prompt:** राहुल को देखे हुए कई दिन हो चुके हैं।  
   **Romanized:** Rahul ko dekhe hue kai din ho chuke hai.  
   **English answer:** It has been many days having seen Rahul.  

30. **Hindi prompt:** साथ खेले हुए काफी समय हो गया।  
   **Romanized:** Sath khele hue kafi samay ho gaya.  
   **English answer:** It has been a long having played together.  

31. **Hindi prompt:** पैसा होना अच्छी बात है पर घमंड नहीं होना चाहिए।  
   **Romanized:** Paisa hona achi baat hai par ghamand nahi hona chahiye.  
   **English answer:** It is good to have money but there should not be arrogance.  

32. **Hindi prompt:** हो सकता है उसके पास किताब हो।  
   **Romanized:** Ho sakta hai uske paas kitab ho.  
   **English answer:** He may/might/could have a book.  

33. **Hindi prompt:** हो सकता है राहुल के पास मोबाइल हो।  
   **Romanized:** Ho sakta hai Rahul ke paas mobile ho.  
   **English answer:** Rahul may/might/could have a mobile.  

34. **Hindi prompt:** तुम्हारे पास कितना पैसा है?  
   **Romanized:** Tumhare paas kitna paisa hai?  
   **English answer:** How much money do you have?  

35. **Hindi prompt:** आसमान में कितने तारे हैं?  
   **Romanized:** Aasman mein kitne taare hai?  
   **English answer:** How many stars are there in the sky? / How many stars does the sky have?  

36. **Hindi prompt:** गिलास में कितना पानी था?  
   **Romanized:** Glass me kitna paani tha?  
   **English answer:** How much water was there in the glass? / How much water did the glass have?  

37. **Hindi prompt:** अविरत बर्गर खा रहा है।  
   **Romanized:** Avirat burger kha raha hai.  
   **English answer:** Avirat is eating burger. / Avirat is having burger. / Avirat is taking burger.  

38. **Hindi prompt:** हमेशा के लिए रख लीजिए।  
   **Romanized:** Hamesha ke liye rakh lijiye  
   **English answer:** Keep it forever. / Have it for keeps.  

39. **Hindi prompt:** उसने खाना खा लिया था।  
   **Romanized:** Usne khana kha liya tha.  
   **English answer:** He had eaten the food. / He had taken the food. / He had had the food.  

40. **Hindi prompt:** इसके बावजूद,मैं तुम्हें चाहता हूँ।  
   **Romanized:** Iske bawajood, mai tumhe chahta hoon.  
   **English answer:** Having said that, I love you.  

41. **Hindi prompt:** मुझे जाना पड़ रहा है।  
   **Romanized:** Mujhe jana pad raha hai.  
   **English answer:** I am having to go. / I have to go.  

42. **Hindi prompt:** राहुल को सोचना पड़ रहा है।  
   **Romanized:** Rahul ko sochna pad raha hai.  
   **English answer:** Rahul is having to think. / Rahul has to think.  

43. **Hindi prompt:** मेरे पैर में दर्द है।  
   **Romanized:** Mere pair mein dard hai.  
   **English answer:** I have a pain in my leg. / My leg is paining. / I am having a pain in my leg.  

44. **Hindi prompt:** मुझे फिजूल में आप से सवाल पूछने पढ़ रहे हैं।  
   **Romanized:** Mujhe fizul main aap se sawal puchne padh rahe hai.  
   **English answer:** I am having to ask you questions for no reason. / I have to ask you questions for no reason.  

45. **Hindi prompt:** मेरे पास कार होनी चाहिए थी।  
   **Romanized:** Mere paas car honi chahiye thi.  
   **English answer:** I should have had a car.  

46. **Hindi prompt:** उसके पास कुछ होना चाहिए था।  
   **Romanized:** Uske pas kuch hona chahiye tha.  
   **English answer:** He should have had something.  

47. **Hindi prompt:** वो निकल गया होगा।  
   **Romanized:** Wo nikal gaya hoga.  
   **English answer:** He would have left.  

48. **Hindi prompt:** आपने उसे कॉल किया होगा।  
   **Romanized:** Aapne use call kiya hoga.  
   **English answer:** You would have called him.  

49. **Hindi prompt:** आप रख लीजिए ये पैन।  
   **Romanized:** Aap rakh lijiye ye pen.  
   **English answer:** You keep this pen. / You have this pen.  

50. **Hindi prompt:** 2019 तक मेरे पास कार हो सकती है।  
   **Romanized:** 2019 tak mere paas car ho sakti hai.  
   **English answer:** I may have a car by 2019. / I might have a car by 2019. / I could have a car by 2019. / I can have a car by 2019.  

## Source-text and verification notes

- All 50 Hindi prompts and their printed Romanized lines were OCRed from row crops and visually checked against the scans; all 50 English answers were visually reviewed and paired by number. The prompt and answer sequences are complete and unique.
- Lesson 26 spans PDF pages 356–359 (printed pages 355–358). Hindi/Romanized prompts 1–21 are on PDF page 356, 22–48 on page 357, and 49–50 on page 358. The English answer key starts on page 358 after prompt 50 and continues through page 359; answers 1–50 were checked and paired by number.
- All 50 Hindi prompts and their printed Romanized lines were OCRed from row crops and visually checked against the scanned pages; the English answer key was visually reviewed on pages 358–359. The prompt and answer sequences are complete and unique; no unreadable sections were found.
- Printed page footer numbers are one lower than PDF page numbers.
- Printed Romanized forms are retained, including the singular `hai` with plural Hindi at items 28, 29, and 35; `pas` at 46; and the missing final period at 38. Item 40 has no space after the comma in Hindi (`बावजूद,मैं`) but a space in the printed Romanization (`bawajood, mai`); both are kept as printed.
- Item 44’s scan prints `पूछने पढ़ रहे हैं` / `puchne padh rahe hai`, an apparent source typo; it is preserved rather than silently rewritten. At item 49, the printed Hindi says `पैन` while the Romanized line says `pen`; both printed forms are retained.
- English answer wording and all printed alternatives are retained as printed, including source grammar and punctuation.

**Unreadable text:** none identified.

