# Lesson 38 — Singular to Plural

Source: PDF pages 475–477 (printed pages 474–476).

**Change the following singular nouns to Plural.**

1. **City**
2. **Fly**
3. **Baby**
4. **Lady**
5. **Story**
6. **Dish**
7. **Wish**
8. **Brush**
9. **Match**
10. **Catch**
11. **Watch**
12. **Box**
13. **Fox**
14. **Tax**
15. **Class**
16. **Pass**
17. **Kiss**
18. **Mango**
19. **Tomato**
20. **Potato**
21. **Hero**
22. **Photo**
23. **Logo**
24. **Piano**
25. **Kilo**
26. **Housewife**
27. **Life**
28. **Knife**
29. **Tooth**
30. **Foot**
31. **Man**
32. **Woman**
33. **Pencil**
34. **Book**
35. **Mirror**
36. **Toy**

## Answers

1. `City + ies = Cities`
2. `Fly + ies = Flies`
3. `Baby + ies = Babies`
4. `Lady + ies = Ladies`
5. `Story + ies = Stories`
6. `Dish + es = Dishes`
7. `Wish + es = Wishes`
8. `Brush + es = Brushes`
9. `Match + es = Matches`
10. `Catch + es = Catches`
11. `Watch + es = Watches`
12. `Box + es = Boxes`
13. `Fox + es = Foxes`
14. `Tax + es = Taxes`
15. `Class + es = Classes`
16. `Pass + es = Passes`
17. `Kiss + es = Kisses`
18. `Mango + es = mangoes`
19. `Tomato + es = Tomatoes`
20. `Potato + es = Potatoes`
21. `Hero + es = Heroes`
22. `Photo + s = Photos`
23. `Logo + s = Logos`
24. `Piano + s = Pianos`
25. `Kilo + s = Kilos`
26. `Housewife + ves = Housewives`
27. `Life + ves = Lives`
28. `Knife + ves = Knives`
29. `Tooth + ee = Teeth`
30. `Foot + ee = Feet`
31. `Man  + e =Men`
32. `Woman + e = Women`
33. `Pencil + s = Pencils`
34. `Book + s = Books`
35. `Mirror + s = Mirrors`
36. `Toy + s = Toys`

### Source flags

- Answer 18 is printed with lowercase `mangoes`; preserved.
- Answer 31 is printed as `Man  + e =Men`; spacing preserved.
- Answer 32 is printed as `Woman + e = Women`; formula preserved.
