# Lesson 29 — Use of Ever & Never

**PDF pages:** 380–401 (printed pages 379–400)

## Please translate the following sentences into English:

1. **Hindi prompt:** क्या वो कभी आपसे मिलता है?  
   **Romanized:** (Kya vo kabhi aapse milta hai?)  
   **English answer:** Does he ever meet you?  

2. **Hindi prompt:** मुझे याद नहीं कि मैंने उसे यहाँ देहरादून में कभी देखा है।  
   **Romanized:** (Mujhe yaad nahi ki maine use yahaan Dehradun me kabhi dekha hai.)  
   **English answer:** I can’t remember if I have ever seen him here in Dehradun.  

3. **Hindi prompt:** क्या वो कभी आपके घर आते हैं?  
   **Romanized:** (Kya wo kabhi aapke ghar aate hain?)  
   **English answer:** Do they ever visit your home? / Do they ever come to your home?  

4. **Hindi prompt:** क्या आप कभी दिल्ली में रहे हो?  
   **Romanized:** (Kya aap kabhi Delhi me rahe ho?)  
   **English answer:** Have you ever lived to Delhi? / Have you ever been to Delhi?  

5. **Hindi prompt:** क्या राकेश कभी 100 मे से 100 नंबर लायेगा?  
   **Romanized:** (Kya Rakesh kabhi 100 me se 100 number layega?)  
   **English answer:** Will Rakesh ever score 100 out of 100?  

6. **Hindi prompt:** क्या आप कभी दिल्ली गये हो?  
   **Romanized:** (Kya aap kabhi Delhi gaye ho?)  
   **English answer:** Have you ever gone to Delhi? /Have you ever been to Delhi?  

7. **Hindi prompt:** मुझे कभी कॉल मत करना।  
   **Romanized:** (Mujhe kabhi call mat karna)  
   **English answer:** Don’t ever call me. / Never call me.  

8. **Hindi prompt:** क्या आप इस नदी को कभी तैर कर पार कर सकते हो?  
   **Romanized:** (Kya aap is nadee Ko kabhi tair kar paar kar sakte ho?)  
   **English answer:** Can you ever swim across this river?  

9. **Hindi prompt:** मुझसे बात कभी मत करना।  
   **Romanized:** (Mujhse baat kabhi mat karna.)  
   **English answer:** Don’t ever talk to me. / Never talk to me.  

10. **Hindi prompt:** उसे परेशान कभी मत करना, वरना वो गुस्सा हो जायेगा.  
   **Romanized:** (Use paereshan kabhi mat karna, varna vo gussa ho jayega.)  
   **English answer:** Don’t ever disturb him, or else he will get angry.  

11. **Hindi prompt:** वहाँ कभी मत जाना।  
   **Romanized:** (Wahaan kabhi mat jana.)  
   **English answer:** Don’t ever go there. / Never go there.  

12. **Hindi prompt:** मैंने उसे कभी रोते हुए नहीं देखा है।  
   **Romanized:** (Maine use kabhi rote hue nahi dekha hai.)  
   **English answer:** I have never seen him crying.  

13. **Hindi prompt:** क्या तुमने कभी गाना गाया?  
   **Romanized:** (Kya Tumne kabhi gana gaya?)  
   **English answer:** Did you ever sing a song.  

14. **Hindi prompt:** मुझे कभी मत छोड़ना।  
   **Romanized:** (Mujhe kabhi mat chodna.)  
   **English answer:** Never leave me.  

15. **Hindi prompt:** कभी भी खुद को अकेला मत समझना।  
   **Romanized:** (Kabhi bhi khud ko akela mat samajhna.)  
   **English answer:** Never feel yourself alone.  

16. **Hindi prompt:** कभी भी मेरी ज़रूरत हो, तो बताना।  
   **Romanized:** (Kabhi bhi meri zaroorat ho, to batana.)  
   **English answer:** If you ever need me, tell me.  

17. **Hindi prompt:** क्या तुमने कभी किसी से प्यार किया?  
   **Romanized:** (Kya tumne kabhi kisi se pyar kiya?)  
   **English answer:** Did you ever love someone?  

18. **Hindi prompt:** कभी भी समय को बर्बाद मत करो।  
   **Romanized:** (Kabhi bhi samay ko barbad mar karo.)  
   **English answer:** Don’t ever waste your time.  

19. **Hindi prompt:** कभी भी किसी को धोखा मत दो।  
   **Romanized:** (kabhi bhi kisi ko dhokha mat do.)  
   **English answer:** Don’t ever cheat anyone. / Never cheat anyone.  

20. **Hindi prompt:** मुझसे कभी भी झूठ मत बोलना।  
   **Romanized:** (Mujhse kabhi bhi jhoot mat bolna.)  
   **English answer:** Don’t ever lie to me. / Never tell a lie to me  

21. **Hindi prompt:** वहाँ कभी मत खेलना।  
   **Romanized:** (Wahaan kabhi mat khelna.)  
   **English answer:** Never play there.  

22. **Hindi prompt:** हमें कभी कॉल मत करना।  
   **Romanized:** (Hame kabhi call mat karna)  
   **English answer:** Never call us.  

23. **Hindi prompt:** क्या आपने कभी मल्टीप्लेक्स मे मूवी नहीं देखी है?  
   **Romanized:** (Kya aapne kabhi multiplex me movie nahi dekhi hai?)  
   **English answer:** Have you never seen a movie in a multiplex?  

24. **Hindi prompt:** मैं मसूरी कभी नहीं गया।.  
   **Romanized:** (Mai mussoorie kabhi nahi gaya.)  
   **English answer:** I never visited mussoorie.  

25. **Hindi prompt:** वो इस नदी को तैर कर कभी पार नहीं कर सकता।  
   **Romanized:** (Wo is nadee lo tair kar kabhi paar nahi kar sakta.)  
   **English answer:** He can never swim across this river.  

26. **Hindi prompt:** क्या आपने कभी कार नहीं चलाई है?  
   **Romanized:** (Kya aapane kabhi car nahi chalayi hai?)  
   **English answer:** Have you never driven a car?  

27. **Hindi prompt:** वो कभी भी स्कूल नहीं गया, इसलिए वो फेल हो गया।  
   **Romanized:** (Wo kabhi bhi school nahi gaya, isliye wo fail ho gaya.)  
   **English answer:** He never went to school; that’s why he failed the exam.  

28. **Hindi prompt:** मैं कभी नहीं चाहूँगा कि तुम्हारे साथ बुरा हो।  
   **Romanized:** (Main kabhi nahi chahunga ki tumhare sath bura ho.)  
   **English answer:** I would never want anything wrong to happen with you.  

29. **Hindi prompt:** आपको गरीबों को कभी नीचा नहीं समझना चाहिए।  
   **Romanized:** (Aapko gareebo ko kabhi neecha nahi samajhna chahiye.)  
   **English answer:** You should never look down on the poor.  

30. **Hindi prompt:** मुझे कभी नहीं लगता कि वो 2 बॉल पर 8 रन बना सकता है।  
   **Romanized:** (Mujhe kabhi nahi lagta ki vo 2 ball par 8 run bana sakta hai.)  
   **English answer:** I never feel that, he can make 8 runs in 2 balls.  

31. **Hindi prompt:** अभी नहीं तो कभी नहीं!  
   **Romanized:** (Abhi nahi to kabhi kabhi!)  
   **English answer:** Now or never!  

32. **Hindi prompt:** मैंने आज तक कभी किसी को एक रूपया नहीं दिया।  
   **Romanized:** (Maine aaj tak kabhi kisi ko ek rupaya nahi diya.)  
   **English answer:** I’ve never given even a single penny to anyone.  

33. **Hindi prompt:** ये कभी मत कहना कि मैं ये नहीं कर सकता।  
   **Romanized:** (Ye kabhi mat kehna ki main ye nahi kar sakta.)  
   **English answer:** Never say that you can’t do it.  

34. **Hindi prompt:** कभी भी किसी के पीठ पीछे बुराई मत करो।  
   **Romanized:** (kabhi bhi kisi ke peeth peeche burai mat karo.)  
   **English answer:** Never say anything wrong about anyone at the back.  

35. **Hindi prompt:** हम कभी मिल नहीं सकते।  
   **Romanized:** (Hum kabhi mil nahi sakte.)  
   **English answer:** We can never meet.  

36. **Hindi prompt:** मैं हमेशा आपका साथ दूँगा।  
   **Romanized:** (Main humesha apka sath doonga.)  
   **English answer:** I will always support you. / I will support you forever.  

37. **Hindi prompt:** हमने अपना गाँव हमेशा के लिए छोड़ दिया।  
   **Romanized:** (Humne aapna gaon humesha ke lie chod diya.)  
   **English answer:** We left our village forever.  

38. **Hindi prompt:** वक्त और हालात हमेशा एक जैसे नहीं होते।  
   **Romanized:** (waqt aur halaat humesha ek jaise nahi hote.)  
   **English answer:** Time and circumstances are not always the same. / Time and circumstances are not the same forever.  

39. **Hindi prompt:** मैं हमेशा आपका दोस्त रहूँगा।  
   **Romanized:** (Main humesha aapka dost rahoonga.)  
   **English answer:** I will always be your friend. / I will be your friend forever.  

40. **Hindi prompt:** तुम हमेशा के लिए मेरे हो ।  
   **Romanized:** (Tum humesha ke liye mere ho.)  
   **English answer:** You are mine forever.  

41. **Hindi prompt:** ये दोस्ती हमेशा कायम रहेगी।  
   **Romanized:** (Ye dosti humesha kayam rahegi.)  
   **English answer:** This friendship will forever be intact.  

42. **Hindi prompt:** ये किस्सा हमेशा के लिए खत्म कर दो।  
   **Romanized:** (Ye kissa humesha ke liye khatam kardo.)  
   **English answer:** Finish this anecdote forever.  

43. **Hindi prompt:** क्या तुम हमेशा ऐसे ही मुझे गिफ्ट देते रहोगे?  
   **Romanized:** (Kya tum humesha Ese hi mujhe gift dete rahoge.)  
   **English answer:** Will you forever keep gifting me like this?  

44. **Hindi prompt:** अगर मेरी जॉब लग गयी तो लोगो का मुँह हमेशा के लिए बंद हो जायेगा।  
   **Romanized:** (Agar meri job lag gayi to, logo ka muh humesha ke liye band ho jayega.)  
   **English answer:** If I get a job, then the people will become quiet forever.  

45. **Hindi prompt:** मैं हमेशा के लिए देहरादून छोड़ने वाला हूँ।  
   **Romanized:** (Main humesha ke liye Dehradun chodne wala hun.)  
   **English answer:** I'm about to leave Dehradun forever.  

46. **Hindi prompt:** एक बार सीवर लाईन बन जाए, तो हमेशा के लिए राहत मिल जायेगी।  
   **Romanized:** (Ek bar sewer line ban jaye, humesha ke liye rahat mil jaegi.)  
   **English answer:** Once the sewer line is built, we will get relief forever.  

47. **Hindi prompt:** फिक्र मत करो, मैं हमेशा तुम्हारे साथ हूँ।  
   **Romanized:** (Fikar mat karo, mai humesha tumhare sath hun.)  
   **English answer:** Do not worry, I am with you forever.  

48. **Hindi prompt:** समय हमेशा चलता रहता है, किसी का इंतजार नहीं करता।  
   **Romanized:** (Samay humesha chalta rehta hai, kisi ka intzaar nahi karta.)  
   **English answer:** Time goes on forever, does not wait for anyone.  

49. **Hindi prompt:** मैं हमेशा आपकी आज्ञा का पालन करता रहूँगा।  
   **Romanized:** (Mai humesha aapki aagya ka palan karta rahunga.)  
   **English answer:** I will obey your order forever.  

50. **Hindi prompt:** क्या तुम ये घर हमेशा के लिए छोड़ सकते हो?  
   **Romanized:** (Kya tum ye ghar humesha ke liye chod sakte ho?)  
   **English answer:** Can you leave this house forever?  

51. **Hindi prompt:** क्या कभी आपने बस में सफर किया है?  
   **Romanized:** (Kya kabhi aapne bus mein safar kiya hai?)  
   **English answer:** Have you ever traveled in a bus?  

52. **Hindi prompt:** आपको पहले कभी भी मैंने यहाँ नहीं देखा।  
   **Romanized:** (Apko pahale kabhi bhee mene yahaan nahi dekha.)  
   **English answer:** I have never seen you here before.  

53. **Hindi prompt:** मैं कभी भी देहरादून से दिल्ली अकेले नहीं गया।  
   **Romanized:** (Main kabhi bhee Dehradun se Delhi akele nahi gaya.)  
   **English answer:** I never went from Dehradun to Delhi alone.  

54. **Hindi prompt:** क्या आपको कभी किसी ने चॉकलेट गिफ़्ट करी है?  
   **Romanized:** (Kya aapko kabhi kisi ne chocolate gift kari hai?)  
   **English answer:** Has anyone ever gifted you a chocolate?  

55. **Hindi prompt:** मेरी मम्मी ने मुझे कभी भी झूठ बोलना नहीं सिखाया है।  
   **Romanized:** (Meri Mummy ne mujhe kabhi bhee jooth bolna nahi sikhaya hai.)  
   **English answer:** My mom taught me never to lie.  

56. **Hindi prompt:** क्या हम कभी दोबारा मिलेंगे?  
   **Romanized:** (Kya hum kabhi dobaara milege?)  
   **English answer:** Will we ever meet again?  

57. **Hindi prompt:** मैं आपसे दोबारा कभी नहीं मिलूँगा।  
   **Romanized:** (Main aapse dobaara kabhi nahi miloonga.)  
   **English answer:** I will never see you again.  

58. **Hindi prompt:** आज तक मैंने कभी अपना गाँव नहीं देखा।  
   **Romanized:** (Aaj tak mene kabhi apna gaw nahi dekhaa.)  
   **English answer:** Till date I have never seen my village.  

59. **Hindi prompt:** कभी आप भी हमारे घर में ज़रूर आईए।  
   **Romanized:** (Kabhi aap bhee hamaare ghar jaroor aaiye.)  
   **English answer:** You must have come to our house sometime.  

60. **Hindi prompt:** आपने कभी भी मेरे बारे में नहीं सोचा।  
   **Romanized:** (Aapne kabhi bhee mere bare mein nahi socha.)  
   **English answer:** You never thought of me.  

61. **Hindi prompt:** मुझे तुम कभी भी पसंद नहीं थे।  
   **Romanized:** (Mujhe tum kabhi bhee pasand nahi the.)  
   **English answer:** I never liked you.  

62. **Hindi prompt:** तुम्हारी ये अजीब बातें कभी ख़त्म नहीं होती हैं।  
   **Romanized:** (Tumhari ye ajeeb baate kabhi khatm nahi hoti hai.)  
   **English answer:** These strange things of yours never end.  

63. **Hindi prompt:** मेरे पापा से मुझे कभी भी डाँट नहीं पड़ती है।  
   **Romanized:** (Mere papa se mujhe Kabhi daant nahi padti hain.)  
   **English answer:** I never get scolded by my father.  

64. **Hindi prompt:** मुझे पता है, आप अपने काम से कभी ऊबेंगे नहीं।  
   **Romanized:** (Mujhe pata hai, aap apne kaam se kabhi oobenge nahin.)  
   **English answer:** I know you will never get bored with your work.  

65. **Hindi prompt:** मैंथ्स में मैंने ऐसे नम्बर पहले कभी नहीं देखे।  
   **Romanized:** (Maths main mene aise number pahale kabhi nahi dekhe.)  
   **English answer:** I have never seen such numbers in Maths before?  

66. **Hindi prompt:** मैंने कभी भी चोरी नहीं की है।  
   **Romanized:** (Meine kabhi bhee chori nahi ki hai.)  
   **English answer:** I have never been involved in a theft.  

67. **Hindi prompt:** छोटी-छोटी बातों का कभी भी बुरा नहीं मानना चाहिये।  
   **Romanized:** (Choti choti baato ka kabhi bhee bura nahin maanna chahiye.)  
   **English answer:** One should never feel bad about small things.  

68. **Hindi prompt:** मैंने कभी भी पहले इतना सुंदर चित्र नहीं देखा।  
   **Romanized:** (Maine pahale kabhi bhee itana sunder chitar nahin dekha.)  
   **English answer:** I have never seen a picture so beautiful before.  

69. **Hindi prompt:** आशा कभी आपको छोड़ कर नहीं जाती है, आप इसे छोड़ते हैं।  
   **Romanized:** (Aasha kabhi aapako chhod kar nahin jaati hai, aap ise chhodate hain.)  
   **English answer:** Hope never leaves you, you leave it.  

70. **Hindi prompt:** मुझे कभी किसी के घर खाली हाथ जाना अच्छा नहीं लगता है।  
   **Romanized:** (Mujhe kabhi kisi ke ghar khali haath jaana acha nahin lagta hai.)  
   **English answer:** I never like to go to someone's house empty handed.  

71. **Hindi prompt:** तुमने कभी कार चलाने की कोशिश की भी है?  
   **Romanized:** (Tumne kabhi car chalaane ki koshish ki bhee hai?)  
   **English answer:** Have you ever tried to drive a car?  

72. **Hindi prompt:** सुमित आप कभी नहीं सुधरने वाले हो।  
   **Romanized:** (Sumit aap kabhi nahin sudharne wale ho.)  
   **English answer:** Sumit you are never going to improve.  

73. **Hindi prompt:** मुझे नहीं पता, आपकी बातें कभी अच्छी होती भी है, या नहीं।  
   **Romanized:** (Mujhe nahin pata, aapki baate kabhi achi hoti bhi hai ya nahin.)  
   **English answer:** I don't know whether your words are ever good or not.  

74. **Hindi prompt:** मैं यह कभी आशा नहीं करूँगा, आप किसी का भी दिल दुखाओगे।  
   **Romanized:** (Main yah kabhi aasha nahin karoonga, aap kisi ka bhee dil dukhaoge.)  
   **English answer:** I would never hope that you will hurt anyone.  

75. **Hindi prompt:** कभी भी पैसा ख़र्च करने से पहले कमाना सीख जाओ।  
   **Romanized:** (Kabhi bhee paisa kharch karne se pahale kamaana seekh jao.)  
   **English answer:** Learn to earn before ever spending money.  

76. **Hindi prompt:** कभी मैं सोचते- सोचते ही सो जाता हूँ।  
   **Romanized:** (Kabhi main sochate sochate hee so jaata hoon.)  
   **English answer:** Sometimes I fall asleep just thinking.  

77. **Hindi prompt:** मैंने कभी भी नहीं सोचा था, आप इतना बदल जाओगे।  
   **Romanized:** (Maine kabhi bhee nahin socha thaa, aap itana badal jaaoge.)  
   **English answer:** I never thought you would change so much.  

78. **Hindi prompt:** सच बोलने वाला इंसान कभी भी झूठ से नहीं डरता है।  
   **Romanized:** (Sach bolane wala insaan kabhi bhee jooth se nahin darta hai.)  
   **English answer:** A person who tells the truth is never afraid of a lie.  

79. **Hindi prompt:** वो जो लड़का है, वो कभी भी कहीं भी घूमने निकल जाता हैं।  
   **Romanized:** (Vo jo ladka hai, vo kabhi bhee kahi bhee ghoomane nikal jaata hain.)  
   **English answer:** The boy that he is, he goes out for a walk anywhere anytime.  

80. **Hindi prompt:** मैंने कभी भी किसी की नकल करने की कोशिश नहीं करी।  
   **Romanized:** (Maine kabhi bhee kisi ki nakal karne ki koshish nahin kari.)  
   **English answer:** I never tried to imitate anyone.  

81. **Hindi prompt:** क्या तुम भी कभी इस रास्ते से स्कूल गये हो?  
   **Romanized:** (Kya tum bhee kabhi ess rashte se school gaye ho?)  
   **English answer:** Have you ever gone to school by this route?  

82. **Hindi prompt:** मैं पहले कभी भी इस रास्ते पर नहीं गया हूँ।  
   **Romanized:** (Main pahale kabhi bhee ess rashte par nahin gaya hoon.)  
   **English answer:** I have never gone this route before.  

83. **Hindi prompt:** मैं क्या करूँ, जब मैंने ये काम पहले कभी किया ही नहीं।  
   **Romanized:** (Main kya karu, jab maine ye kaam pahale kabhi kiya hee nahin.)  
   **English answer:** What should I do when I have never done this work before?  

84. **Hindi prompt:** मैं पहले कभी इलाहबाद नहीं गया।  
   **Romanized:** (Main pahale kabhi Allahabad nahin gaya.)  
   **English answer:** I have never been to Allahabad before.  

85. **Hindi prompt:** इतना सुंदर सूर्यास्त मैंने पहले कभी नहीं देखा है।  
   **Romanized:** (Itana sundar sooryaast maine pahale kabhi nahin dekha hai.)  
   **English answer:** I have never seen such a beautiful sunset before.  

86. **Hindi prompt:** इतनी बड़ी मछली मैंने पहले कभी नहीं देखी।  
   **Romanized:** (Itani badi machali maine pahale kabhi nahin dekhi.)  
   **English answer:** I have never seen such a big fish before.  

87. **Hindi prompt:** आप गर्मी की छुट्टी में कभी नानी के घर गए हो ?  
   **Romanized:** (Aap garmi ki chutti mein kabhi naani ke gahr gaye ho?)  
   **English answer:** Have you ever visited your grandmother's house during summer vacation?  

88. **Hindi prompt:** मैंने कभी भी अपनी जिंदगी में पहले ऐसा दृश्य नहीं देखा।  
   **Romanized:** (Maine kabhi bhee apni zindagi mein pahale aisa drishya nahin dekha.)  
   **English answer:** I have never seen such a scene before in my life.  

89. **Hindi prompt:** मैंने कभी नहीं सोचा था, आज के दिन सचिन 100 रन मारेगा।  
   **Romanized:** (Maine kabhi nahin socha tha, aaj ke din sachin 100 run maarega.)  
   **English answer:** I Never thought that Sachin would hit 100 runs on this day.  

90. **Hindi prompt:** मेरी पेंटिंग्स को पहले कभी किसी ने नहीं खरीदा।  
   **Romanized:** (Meri painting ko pahale kabhi kisee ne nahin khareeda.)  
   **English answer:** No one has ever bought my paintings before.  

91. **Hindi prompt:** अगर आप अच्छा खाना खाओगे तो कभी बीमार नहीं होंगे।  
   **Romanized:** (Agar aap acha khana khaoge to kabhi bhimaar nahin honge.)  
   **English answer:** If you eat good food you will never get sick.  

92. **Hindi prompt:** आपने कभी भी मेरे पक्ष में कोई बात नहीं की।  
   **Romanized:** (Aapne kabhi bhee mere paksh mein koi baat nahin kee.)  
   **English answer:** You never spoke in my favor.  

93. **Hindi prompt:** मेहनत करने वाले की कभी हार नहीं होती है।  
   **Romanized:** (Mehnat karne wale ki kabhi haar nahin hoti hai.)  
   **English answer:** The one who works hard never loses. (Mehnatkarne wale kikabhihaarnahinhotihai.)  

94. **Hindi prompt:** कभी जीतने के लिए हारना भी पड़ता है।  
   **Romanized:** (kabhi jeetane ke liye haarna bhee padta hai.)  
   **English answer:** Sometimes you have to lose to win.  

95. **Hindi prompt:** मैंने गौतम बारे में पहले कभी नहीं सोचा।  
   **Romanized:** (Maine Gautam ke baare mein pahale kabhi nahe socha.)  
   **English answer:** I never thought of Gautam before.  

96. **Hindi prompt:** मैं कभी भी नहीं चाहूँगा की आप ये बाज़ी जीतें।  
   **Romanized:** (Main kabhi bhee nahin chahoonga ki aap ye bazee jeeten.)  
   **English answer:** I would never want you to win this bet.  

97. **Hindi prompt:** राजा नें कभी भी किसी की बात ध्यान से नहीं सुनी।  
   **Romanized:** (Raja nai kabhi bhi kisi ki baat dhyan se nahi suni.)  
   **English answer:** The king never listened carefully to anyone.  

98. **Hindi prompt:** मैंने कभी नहीं सोचा था कि आप ऑटो वाले से इतनी बहस करोगे।  
   **Romanized:** (Maine kabhi nahin socha tha ki aap auto wale se itani bahas karoge.)  
   **English answer:** I never thought that you would argue so much with the auto wala.  

99. **Hindi prompt:** उसने अपने हक़ के लिए कभी भी बहस नहीं करी।  
   **Romanized:** (Usne aapne haq kai liye kabhi bhi behes nahin kari.)  
   **English answer:** He never argued for his rights.  

100. **Hindi prompt:** मैंने कभी नहीं सोचा था, आप इस तरह से बदल जाओगे।  
   **Romanized:** (Maine kabhi nahin socha tha, aap ess tarah se badal jaoge.)  
   **English answer:** I never thought you would turn like this.  

101. **Hindi prompt:** मुझे याद नहीं कि मैंने उसे यहाँ देहरादून में कभी देखा है।  
   **Romanized:** (Mujhe yaad nahi ki maine use yahaan Dehradun me kabhi dekha hai.)  
   **English answer:** I don't remember ever seeing him here in Dehradun  

102. **Hindi prompt:** क्या आप कभी दिल्ली के अलावा कहीं रहे हो?  
   **Romanized:** (Kya aap kabhi Delhi kai alawa kahin rahe ho?)  
   **English answer:** Have you ever lived anywhere other than Delhi? ,  

103. **Hindi prompt:** मुझे अपनी जवानी के दिन याद करके कभी हँसी नहीं आती है।  
   **Romanized:** (Mujhe apne jawani kai din yaad karke kabhi hasi nahi aati.)  
   **English answer:** I never laugh remembering the days of my youth.  

104. **Hindi prompt:** मुझे अच्छे से याद है, मैंने आपको कभी भी कहीं नहीं देखा।  
   **Romanized:** (Mujhe ache se yaad hai, maine aapko kabhi bhi kahin nahin dekha.)  
   **English answer:** I remember well, I have never seen you anywhere.  

105. **Hindi prompt:** मेरी मम्मी मुझे कभी भी तकलीफ़ में नहीं देख सकती।  
   **Romanized:** (Meri mummy mujhe kabhi bhee takleef mein nahin dekh sakti.)  
   **English answer:** My mother can never see me in trouble.  

106. **Hindi prompt:** मैंने उसको कभी भी इतना डरा हुआ नहीं देखा।  
   **Romanized:** (Maine usko kabhi bhee itana dara hua nahi dekha.)  
   **English answer:** I have never seen him so scared.  

107. **Hindi prompt:** वो आखिरी शाम इतनी हसीन थी कि वो लड़का जब तक ज़िंदा रहेगा उसे कभी नहीं भूलेगा।  
   **Romanized:** (Vo aakhri shaam itani haseen thee ki vo ladka jab tak zinda rahega use kabhi nahin bhoolega.)  
   **English answer:** That last evening was so beautiful that the boy would never forget him as long as he lived.  

108. **Hindi prompt:** मैंने कभी नहीं सोचा था कि मैं अपनी टीम से इस तरह से बाहर हो जाऊँगा।  
   **Romanized:** (Maine kabhi nahin socha tha ki, mein apni team se ess tareeke se bhar ho jaaounga.)  
   **English answer:** I never thought I'd be left out of my team like this.  

109. **Hindi prompt:** मैं इस काम में आपका साथ कभी नहीं देने वाला हूँ।  
   **Romanized:** (Main ess kaam mein aapka saath kabhi nahin dene waala hoon.)  
   **English answer:** I am never going to accompany you in this work.  

110. **Hindi prompt:** वह अपने पिता के महल को घेरे हुए सुंदर बगीचों से आगे कभी नहीं गया था।  
   **Romanized:** (Vah apne pita ke mahal ko ghere hue sundar bageechon se aage kabhi nahin gaya tha.)  
   **English answer:** He had never gone beyond the beautiful gardens that surrounded his father's palace.  

111. **Hindi prompt:** उन्होंने पुस्तक की बहुत प्रशंसा की, क्योंकि उन्होंने ऐसा कुछ कभी नहीं देखा था।  
   **Romanized:** (Unhone Pustak ki bahut prashansa ki, kyonki unhone aisa kuch kabhi nahin dekha tha.)  
   **English answer:** He praised the book very much, because he had never seen anything like it.  

112. **Hindi prompt:** क्या आप कभी 5 स्टार होटल में रुके हो?  
   **Romanized:** (Kya aap kabhi 5 star hotal mein ruke ho?)  
   **English answer:** Have you ever stayed in a 5 star hotel?  

113. **Hindi prompt:** मैंने शालू के मुँह से पहले कभी भी आपका नाम नहीं सुना था।  
   **Romanized:** (Maine Shalu ke muh se pahale kabhi bhee aapka naam nahin suna tha.)  
   **English answer:** I had never heard your name before Shalu's mouth.  

114. **Hindi prompt:** मुझे पता है, आपने कभी भी माता-पिता से इस बात पर विचार नहीं किया होगा।  
   **Romanized:** (Mujhe pata hai, aapne kabhi bhee maata pitaa se ess baat par vichar nahin kiya hoga.)  
   **English answer:** I know, you would have never considered this to the parents.  

115. **Hindi prompt:** हमने तुमको कभी भी पराया नहीं समझा।  
   **Romanized:** (Humne tumko kabhi bhee paraaya nahin samjha.)  
   **English answer:** We have never considered you a stranger.  

116. **Hindi prompt:** बिना पूछे कभी भी किसी की चीज़े छूना अच्छी आदत नहीं है।  
   **Romanized:** (Bina poochhe kabhi bhee kisi kee cheeze choona achi aadat nahin hai.)  
   **English answer:** It is never a good habit to touch someone's things without asking.  

117. **Hindi prompt:** प्रियंका कभी भी जल्दी से हार मानने वाली लड़कियों में से नहीं है।  
   **Romanized:** (Priyanka kabhi bhee jaldi se haar maanne wali ladkiyo mein se nahin hai.)  
   **English answer:** Priyanka is never the one to give up quickly.  

118. **Hindi prompt:** मैंने कभी भी इतनी तेज़ कार नहीं चलाई है।  
   **Romanized:** (Maine kabhi bhee itani tez car nahin chalayee hai.)  
   **English answer:** I have never driven a car so fast.  

119. **Hindi prompt:** छोटी- छोटी गलतियाँ कभी भी बड़ी हार का कारण बन जाती है।  
   **Romanized:** (Choti- Choti galatiyaan kabhi bhee badi haar ka kaaran ban jaati hai.)  
   **English answer:** Small mistakes sometimes become the cause of big defeat.  

120. **Hindi prompt:** इस बात पर मैंने कभी गौर नहीं किया कि, वे अब बहुत अच्छे दोस्त बन गए।  
   **Romanized:** (Is baat maine kabhi gaur nahin kiya ki, ve ab bahut ache dost ban gaye.)  
   **English answer:** I never noticed that they have become very good friends now.  

121. **Hindi prompt:** उसने इस विचार को स्वीकार कर लिया था कि वह इस पल को कभी नहीं भूल पाएगी।  
   **Romanized:** (Usne is vichaar ko sveekaar kar liya tha ki vah is pal ko kabhee nahin bhool paayegi.)  
   **English answer:** She had accepted the idea that she would never forget this moment.  

122. **Hindi prompt:** आपको कभी भी मेरी सच्चाई पर संदेह नहीं करना चाहिए था।  
   **Romanized:** (Apko kabhi bhee meri sachhai par sandeh nahin karna chaahiye tha.)  
   **English answer:** You should never have doubted my truthfulness.  

123. **Hindi prompt:** शायद मैं आपको कभी भी भूल नहीं पाऊँगा।  
   **Romanized:** (Shayad main apko kabhi bhee bhool nahin paunga.)  
   **English answer:** Maybe I'll never forget you.  

124. **Hindi prompt:** क्या आपने कभी किसी से लिफ़्ट माँगी है।  
   **Romanized:** (Kya aapne kabhi kisi se lift mangi hai.)  
   **English answer:** Have you ever asked someone for a lift?  

125. **Hindi prompt:** अजीब है, यहाँ पहले कभी मुझे अकेलापन नहीं लगा था।  
   **Romanized:** (Ajeeb hai, yahaan pahale kabhi mujhe akelapan nahin laga tha.)  
   **English answer:** Strange, I've never felt lonely here before.  

126. **Hindi prompt:** मैं अपने जीवन में इतना बेशर्म कभी नहीं था।  
   **Romanized:** (Main apne jeevan mein itna besharam kabhi nahi tha.)  
   **English answer:** I have never been so shameless in my life.  

127. **Hindi prompt:** मैं आज तक हवाईजहाज़ में कभी नहीं बैठी।  
   **Romanized:** (Main aaj tak havaejahaaz main kabhi nahi baithee.)  
   **English answer:** I have never boarded a plane till today.  

128. **Hindi prompt:** मैं आपसे मिलने कभी नहीं आऊँगा।  
   **Romanized:** (Main aapse milane kabhi nahi aaunga.)  
   **English answer:** I will never come to see you.  

129. **Hindi prompt:** आपने कभी सोचा था, कि मैं आपसे मिलने आ सकता हूँ।  
   **Romanized:** (Aapne kabhi socha tha, ki main apse milane aa sakta hoon.)  
   **English answer:** Have you ever thought that I can come to see you?  

130. **Hindi prompt:** आपको क्या लगा, कि मुझे कभी सच का पता नहीं चलेगा।  
   **Romanized:** (Aapko kya laga, ki mujhe kabhi sach ka pata nahi chalega.)  
   **English answer:** What do you think, that I will never know the truth.  

131. **Hindi prompt:** उसने कभी अनुमान नहीं लगाया होगा, कि इन पहाड़ों में इतना भव्य घर मौजूद है।  
   **Romanized:** (Usne kabhi anumaan nahin lagaaya hoga ki in pahaadon mein itana bhavy ghar maujood hai.)  
   **English answer:** He would never have guessed, that such a grand house exists in these mountains.  

132. **Hindi prompt:** मैंने कभी नहीं सोचा था, तुम मुझसे इतना प्यार करते हो।  
   **Romanized:** (Maine kabhi nahi socha tha, ki tum mujhse itna pyaar karte ho.)  
   **English answer:** I never thought, you love me so much.  

133. **Hindi prompt:** कुछ ऐसा था जिसे उसके माता-पिता कभी नहीं समझ पाए, शायद यही वजह थी कि वे दुनिया से दूर चले गए। ।  
   **Romanized:** (kuchh aisa tha jise uske mata-pita kabhi nahi samajh paaye, shaayad yahi vajah thee ki ve duniya se door chale gaye.)  
   **English answer:** There was something his parents could never understand, which was probably the reason why they left the world.  

134. **Hindi prompt:** मैंने आपको पहले कभी रोते नहीं देखा था।  
   **Romanized:** (Maine aapko pahale kabhi rote nahi dekha tha.)  
   **English answer:** I had never seen you cry before.  

135. **Hindi prompt:** वास्तव में, उनके पास एक मासूमियत थी, जो उसने कभी नहीं देखी थी।  
   **Romanized:** (Vaastav mein, unake paas ek maasoomiyat thee jo usne kabhi nahi dekhi thee.)  
   **English answer:** Indeed, he had an innocence which he had never seen.  

136. **Hindi prompt:** वहाँ थोड़ी देर के लिए मैंने सोचा कि तुम फिर कभी नहीं आओगे।  
   **Romanized:** (Vahaan thodi der ke lie maine socha ki tum phir kabhi nahin aaoge.)  
   **English answer:** There for a while I thought you would never come again.  

137. **Hindi prompt:** तुम्हारी ग़लती के लिए राहुल तुमको कभी भी माफ़ नहीं करेगा। ,  
   **Romanized:** (Tumhari galti ke liye Rahul tumko kabhi bhee maaf nahi karega.)  
   **English answer:** Rahul will never forgive you for your mistake.  

138. **Hindi prompt:** मुझे बहुत आश्चर्य है कि, उन्हें कभी मेरा मेल नहीं मिला।  
   **Romanized:** (Mujhe bahut aashchary hai ki, unhe kabhi mera mail nahi mila.)  
   **English answer:** I am very surprised that they never got my mail.  

139. **Hindi prompt:** उसने शायद कभी किसी को ऐसा करते नहीं सुना!  
   **Romanized:** (Usne shaayad kabhi kisi ko aisa karate nahin suna!)  
   **English answer:** He probably never heard anyone do this!  

140. **Hindi prompt:** आपने कभी सोचा था, कि 2011 वर्ल्ड कप भारत जीतेगा?  
   **Romanized:** (Aapne kabhi socha tha ki 2011 World Cup India jeetega?)  
   **English answer:** Have you ever thought that India will win the 2011 World Cup?  

141. **Hindi prompt:** क्या आपने कभी पतंगे उड़ाई हैं?  
   **Romanized:** (Kya aapne kabhi patange udaee hain?)  
   **English answer:** Have you ever flown kites?  

142. **Hindi prompt:** मुझे नहीं पता था कि, मैं पकड़ा जाऊँगा वरना मैं कभी भी चोरी नहीं करता।  
   **Romanized:** (Mujhe nahi pata tha ki, main pakada jaoonga varna main kabhi bhee chori nahi karta.)  
   **English answer:** I didn't know that I would be caught or else I would never steal.  

143. **Hindi prompt:** अगर मुझे पता होता तो मैं इतनी सुनसान जगह पर कभी नहीं आता।  
   **Romanized:** (Agar mujhe pata hota to main itani soonsaan jagah par kabhi nahi aata.)  
   **English answer:** If I had known, I would never have come to such a deserted place.  

144. **Hindi prompt:** मैं अपने बच्चों को कभी भी रोने नहीं देता हूँ।.  
   **Romanized:** (Main apne bachho ko kabhi nahi rone deta hoon.)  
   **English answer:** I never let my children cry.  

145. **Hindi prompt:** क्या मुझे उस आदमी पर भरोसा करना चाहिये था जिससे मैं कभी नहीं मिला।  
   **Romanized:** (Kya mujhe us aadmi par bharosha karna chahiye tha, jisse main kabhi nahi mila.)  
   **English answer:** Should I trust the man I've never met?  

146. **Hindi prompt:** आपने कभी रात के समय में सफ़र किया है।  
   **Romanized:** (Aapne kabhi raat ke samay mein safar kiya hai.)  
   **English answer:** Have you ever traveled during night time?  

147. **Hindi prompt:** आपने कभी सोचा था कि आप अपने स्कूल में टॉप करोगे।  
   **Romanized:** (Aapne kabhi socha tha ki aap apne school mein top karoge.)  
   **English answer:** Have you ever thought that you would top your school?  

148. **Hindi prompt:** कभी भी किसी गरीब का मज़ाक नहीं उड़ाना चाहिए, क्या पता कल वो अमीर बन जाये।  
   **Romanized:** (Kabhi bhee kisi gareeb ki majaak nahi udanee chahiye, kya pata kal vo ameer ban jaaye.)  
   **English answer:** Never make fun of a poor person, he might become rich in the future.  

149. **Hindi prompt:** उनका दावा है कि उन्होंने कभी किसी को गंभीर रूप से चोट नहीं पहुँचाई।  
   **Romanized:** (Unka dawa hai ki unhone kabhi kisi ko gambheer roop se chot nahi pahunchaee.)  
   **English answer:** He claims that he never seriously hurt anyone.  

150. **Hindi prompt:** हमारे देश में भ्रष्टाचार कभी समाप्त नहीं होगा।  
   **Romanized:** (Hamare desh mein bhrashtachaar kabhi samaapt nahin hoga.)  
   **English answer:** Corruption will never end in our country.  

151. **Hindi prompt:** मैंने कभी नहीं सोचा था कि हम इतने जल्दी पहुँच जाएंगे।  
   **Romanized:** (Maine kabhi nahi socha tha ki hum itane jaldi pahuch jaayenge.)  
   **English answer:** I never thought we would reach so soon.  

152. **Hindi prompt:** 75% नंबर लाना कभी मेरे लिए बड़ी बात नहीं थी।  
   **Romanized:** (75% Number lana kabhi mere liye badi baat nahi thee.)  
   **English answer:** Getting 75% marks was never a big deal for me.  

153. **Hindi prompt:** मैं कभी नहीं चाहता हूँ कि आप मेरे घर आकर मेरी बेइज़्जती करो।  
   **Romanized:** (Main kabhi nahin chaata hoon ki aap mere ghar aakar meri beizjatee karo.)  
   **English answer:** I never want you to come to my house and insult me.  

154. **Hindi prompt:** आपके साथ तो मैं पैदल कभी नहीं चलने वाला।  
   **Romanized:** (Apke sath to main paidal kabhi nahi chalne wala.)  
   **English answer:** I will never walk with you.  

155. **Hindi prompt:** मैंने 5000 की नौकरी आज तक कभी नहीं करी है।  
   **Romanized:** (Maine 5000 ki naukari aaj tak kabhi nahi kari hai.)  
   **English answer:** I have never done 5000 jobs till date.  

156. **Hindi prompt:** हम अपने स्कूल में कभी भी हिंदी में बात नहीं करते है।  
   **Romanized:** (Hum apne school mein kabhi bhee hindi mein baat nahi karte hai.)  
   **English answer:** We never talk in Hindi in our school.  

157. **Hindi prompt:** हमने सारे गलत काम किये पर कभी किसी का दिल नहीं दुखाया।  
   **Romanized:** (Humne sare galat kaam kiye par kabhi kisi ka dil nahi dukhaya.)  
   **English answer:** We did all the wrong things but never hurt anyone's heart.  

158. **Hindi prompt:** मैं कभी भी सुबह उठ के चाय नहीं पीता हूँ।  
   **Romanized:** (Mai kabhi bhee subah uth ke chaay nahi peeta hoon.)  
   **English answer:** I never wake up in the morning and drink tea.  

159. **Hindi prompt:** मैं रात को कभी जल्दी नहीं सोता हूँ।  
   **Romanized:** (Main raat ko kabhi jaldi nahi sota hoon.)  
   **English answer:** I never sleep early at night.  

160. **Hindi prompt:** मैं कभी मसूरी नहीं गया और मैं वहाँ से किसी को नहीं जानता।  
   **Romanized:** (Main kabhi Musoorie nahi gaya aur main vahaan se kisi ko nahin jaanata.)  
   **English answer:** I have never been to Mussorie and I do not know anyone from there.  

161. **Hindi prompt:** मैं पहले कभी भी नाव में नहीं बैठा हूँ।  
   **Romanized:** (Main pahale kabhi bhee naav main nahi baitha hoon.)  
   **English answer:** I have never sat in a boat before.  

162. **Hindi prompt:** मैं कभी किसी निहत्थे पर हाथ नहीं उठाया है।  
   **Romanized:** (Maine kabhi kisi nihathe par hath nahi uthaaya hai.)  
   **English answer:** I have never raised my hand on an unarmed man.  

163. **Hindi prompt:** मैं कभी इंडियन आर्मी का हिस्सा नहीं बन पाऊँगा।  
   **Romanized:** (Main kabhi Indian Army ka hissa nahi ban paunga.)  
   **English answer:** I will never be able to be a part of the Indian Army.  

164. **Hindi prompt:** मैंने कभी नहीं सोचा था कि मैं ऑल ओवर इंडिया फर्स्ट रैंक प्राप्त करूँगा।  
   **Romanized:** (Maine kabhi nahi socha tha ki main all over India First rank praapt karoonga.)  
   **English answer:** I never thought that I will get all over India first rank.  

165. **Hindi prompt:** मैंने अपनी जिंदगी में कभी कुछ पाया नहीं पर खोया बहुत कुछ है।  
   **Romanized:** (Maine apni zindagi mein kabhi kuch paaya nahi par khoyaa bahut kuch hai.)  
   **English answer:** I have never gained anything in my life but I have lost a lot.  

166. **Hindi prompt:** मैं कभी सिगरेट नहीं पीता पर लाइटर हमेशा रखता हूँ धमाका करने के लिये।  
   **Romanized:** (Main kabhi cigarrete nahin peeta par laitar hamesha rakhta hoon dhamaaka karne ke liye.)  
   **English answer:** I never smoke but always carry a lighter to explode.  

167. **Hindi prompt:** ड्रिंक करके कभी भी गाड़ी नहीं चलानी चाहिए।  
   **Romanized:** (Drink karke kabhi bhee gadi nahi chalaani chahiye.)  
   **English answer:** Never drive a car after drinking.  

168. **Hindi prompt:** आज तक तुमने कभी अपना काम खुद भी किया है ?  
   **Romanized:** (Aaj tak tumne kabhi apna kaam khud bhi kiya hai?)  
   **English answer:** Have you ever done your own work till date?  

169. **Hindi prompt:** मुझे मालूम नहीं था, हमारी मुलाकात कभी ऐसे भी होगी।  
   **Romanized:** (Mujhe maloom nahi tha, hamari mulakaat kabhi aise bhee hogi.)  
   **English answer:** I did not know that we would ever meet like this.  

170. **Hindi prompt:** तुमने कभी सोचा था सलोनी आपको इतना महँगा गिफ़्ट देगी।  
   **Romanized:** (Tumne kabhi socha tha Saloni aapko itana mehnga gift degi.)  
   **English answer:** Have you ever thought that Saloni would give you such an expensive gift?  

171. **Hindi prompt:** मैंने इतने सारे पैसे अपनी लाइफ़ में कभी नहीं देखें।  
   **Romanized:** (Maine itane saare paise apni life mein kabhi nahi dekhe.)  
   **English answer:** I have never seen so much money in my life.  

172. **Hindi prompt:** मैंने आपको पहले कभी भी इतने गंभीर सोच में बैठे नहीं देखा।  
   **Romanized:** (Maine apko pahale kabhi bhee itane gambheer soch mein baithe nahi dekha.)  
   **English answer:** Never before have I seen you sit with such serious thoughts.  

173. **Hindi prompt:** हमने हाथ हिलाया लेकिन वह अलविदा कहने के लिए कभी नहीं रुका।  
   **Romanized:** (Hamane haath hilaaya lekin vah alvida kahne ke lie kabhi nahi ruka.)  
   **English answer:** We shook hands but he never stopped to say goodbye.  

174. **Hindi prompt:** राहुल क्या आपने कभी सैंडविच खाया है?  
   **Romanized:** (Rahul kya aapne kabhi sandwich khaya hai.)  
   **English answer:** Rahul Have you ever had a sandwich?  

175. **Hindi prompt:** क्या तुम्हारे मामा ने कभी तुमको मारा है।  
   **Romanized:** (Kya tumhare mama ne kabhi tumko maara hai.)  
   **English answer:** Has your maternal uncle ever beaten you?  

176. **Hindi prompt:** अगर तुम्हें जाना पड़ा तो मैं तुम्हें कभी नहीं रोकूँगा।  
   **Romanized:** (Aagar tumhe jaana pada to main tumhe kabhi nahi rokoonga.)  
   **English answer:** If you had to go, I would never stop you.  

177. **Hindi prompt:** मैंने आपको इतना रोते हुए पहले कभी नहीं देखा।  
   **Romanized:** (Maine aapko itana rote hua pahale kabhi nahi dekha.)  
   **English answer:** I have never seen you cry so much before.  

178. **Hindi prompt:** मुझे नहीं लगता कि वह कभी मुझसे डरती भी थी।  
   **Romanized:** (Mujhe nahi lagta ki vah kabhi mujhse darti bhee thee.)  
   **English answer:** I don't think she was ever afraid of me.  

179. **Hindi prompt:** आप सबसे प्यारे व्यक्ति हैं जिनसे मैं कभी मिला हूँ।  
   **Romanized:** (Aap sabse pyaare vyakti hain jinase main kabhi mila hoon.)  
   **English answer:** You are the sweetest person I have ever met.  

180. **Hindi prompt:** क्या आपने कभी गलती नहीं की?  
   **Romanized:** (Kya aapne kabhi galti nahin kee?)  
   **English answer:** Have you never made a mistake?  

181. **Hindi prompt:** क्या मैंने कभी तुमसे झूठ बोला है?  
   **Romanized:** (Kya maine kabhi tumse jhooth bola hai?)  
   **English answer:** Have I ever lied to you?  

182. **Hindi prompt:** क्या आपको लगता है कि मैं आपको कभी नुकसान पहुँचाऊँगा?  
   **Romanized:** (Kya aapko lagta hai ki main aapko kabhi nuksaan pahunchaoonga?)  
   **English answer:** Do you think I will ever harm you?  

183. **Hindi prompt:** क्या आप कभी नहीं चाहते कि आपके पास कोई ऐसा व्यक्ति हो जिससे आप अपनी परेशानी साझा कर सकें?  
   **Romanized:** (Kya aap kabhi nahi chaahate ki aapke paas koi aisa vyakti ho jisase aap apani pareshaani saajha kar saken?)  
   **English answer:** Don't you ever wish you had someone with whom you could share your troubles?  

184. **Hindi prompt:** अगर मैं उनसे कभी नहीं मिलूंगा, तो मैं उन्हें कभी नहीं जान पाऊँगा, है ना?  
   **Romanized:** (Agar main unse kabhi nahi miloonga, to main unhen kabhi nahi jaan paoonga, hai na?)  
   **English answer:** If I will never meet him, I will never know him, right?  

185. **Hindi prompt:** मुझे नहीं पता कि क्या मैं कभी किसी आदमी से प्यार कर सकती हूँ।  
   **Romanized:** (Mujhe nahi pata ki kya main kabhi kisi aadmi se pyaar kar sakati hoon.)  
   **English answer:** I don't know if I can ever love a man.  

186. **Hindi prompt:** उनके परिवार में किसी ने भी उनकी बेगुनाही पर कभी सवाल नहीं उठाया।  
   **Romanized:** (Unke parivaar mein kisi ne bhee unke begunahi par svaal nahi uthaaya.)  
   **English answer:** No one in his family ever questioned his innocence.  

187. **Hindi prompt:** क्या आपके मन में कभी यह सवाल आया कि मैंने इस बारे में क्या सोचा?  
   **Romanized:** (kya aapke man mein kabhi yah savaal aaya ki maine is baare mein kya socha?)  
   **English answer:** Have you ever wondered what I thought about this?  

188. **Hindi prompt:** मुझे याद नहीं है कि मैं कभी भी कमज़ोर महसूस कर रहा हूँ।  
   **Romanized:** (Mujhe yaad nahi hai ki main kabhi bhee kamzor mahasoos kar raha hoon.)  
   **English answer:** I can't remember ever feeling weak.  

189. **Hindi prompt:** संभावना कम थी कि वह कभी वापस आएगी।  
   **Romanized:** (Sambhaavana kam thee ki vah kabhi vaapas aaegi.)  
   **English answer:** There was little chance she would ever return.  

190. **Hindi prompt:** क्या तुमने कभी बाइबल नहीं पढ़ी?  
   **Romanized:** (Kya tumane kabhi baibal nahi padhee?)  
   **English answer:** Have you never read the Bible?  

191. **Hindi prompt:** अपने आप को कभी भी जोखिम में न डालें।  
   **Romanized:** (Apane aap ko kabhi bhee jokhim mein na daalen.)  
   **English answer:** Never put yourself at risk.  

192. **Hindi prompt:** क्या वह कभी उन बातों से आगे निकल पाएगी जो माँ ने उसे सिखाई थीं?  
   **Romanized:** (Kya vah kabhi un baaton se aage nikal paegi jo maa ne use sikhayee theen?)  
   **English answer:** Will she ever be able to get past the things that her mother taught her?  

193. **Hindi prompt:** उसने कहा कि मैं सबसे खूबसूरत महिला थी जिसे उसने कभी देखा था।  
   **Romanized:** (Usne kaha ki main sabase khoobsoorat mahila thee jise usne kabhi dekha tha.)  
   **English answer:** He said that I was the most beautiful woman he had ever seen.  

194. **Hindi prompt:** क्या उसे कभी अपने घर को छोड़ के वापस जाने का पछतावा हुआ?  
   **Romanized:** (Kya use kabhi apne ghar ko chod ke vaapas jaane ka pachhataava hua?)  
   **English answer:** Did he ever regret leaving his home and going back?  

195. **Hindi prompt:** क्या आपने कभी इनमें से किसी एक की सवारी की है?  
   **Romanized:** (Kya aapne kabhi inme se kisi ek ki savaari ki hai?)  
   **English answer:** Have you ever ridden one of these?  

196. **Hindi prompt:** क्या पंकज ने कभी आपको फोन किया?  
   **Romanized:** (Kya Pankaj ne kabhi apako phone kiya?)  
   **English answer:** Did Pankaj ever call you?  

197. **Hindi prompt:** क्या आपके साथ कभी ऐसा हुआ है?  
   **Romanized:** (Kya aapake saath kabhi aisa hua hai?)  
   **English answer:** Has this ever happened to you?  

198. **Hindi prompt:** सुमित "क्या तुम कभी गलत हो सकते हो?  
   **Romanized:** (Sumit kya tum kabhi galat ho sakte ho?)  
   **English answer:** Sumit "Can you ever be wrong?  

199. **Hindi prompt:** क्या मुझे कभी इसकी आदत हो जाएगी?  
   **Romanized:** (Kya mujhe kabhi iski aadat ho jaegee?)  
   **English answer:** Will I ever get used to it?  

200. **Hindi prompt:** क्या आप कभी इस मुद्दे पर आने वाले थे?  
   **Romanized:** (Kya aap kabhi is mudde par aane vaale the?)  
   **English answer:** Were you ever going to come across this issue?  

201. **Hindi prompt:** क्या आपको कभी ग्रामीण इलाकों की याद आती है?  
   **Romanized:** (Kya aapko kabhi graameen ilaakon kee yaad aati hai?)  
   **English answer:** Do you ever miss the rural areas?  

202. **Hindi prompt:** आपको मैंने इस तरह नाचते हुए कभी नहीं देखा।  
   **Romanized:** (Aapko maine ess tarah naachate hue kabhi nahin dekha.)  
   **English answer:** I have never seen you dance like this.  

203. **Hindi prompt:** क्या यह सबसे खूबसूरत जगह नहीं है जिसे आपने कभी देखा है?  
   **Romanized:** (Kya yah sabse khoobasoorat jagah nahin hai jise aapne kabhi dekha hai?)  
   **English answer:** Isn't this the most beautiful place you've ever seen?  

204. **Hindi prompt:** वह वो सब कुछ करना चाहती थी जो वह कभी चाहती थी।  
   **Romanized:** (Vah vo sab kuch karna chaahti thee jo vah kabhi chaahti thee.)  
   **English answer:** She wanted to do everything she ever wanted.  

205. **Hindi prompt:** नेहा ने कभी मौली के दूसरे माता-पिता का जिक्र नहीं किया।  
   **Romanized:** (Neha ne kabhi maulee ke doosare mata-pita ka jikr nahi kiya.)  
   **English answer:** Neha never mentioned Molly's other parents.  

206. **Hindi prompt:** परिवार में किसी ने कभी भी मेरे ऊपर चर्चा नहीं की।  
   **Romanized:** (Parivaar mein kisi ne kabhee bhee mere upar charcha nahi kee.)  
   **English answer:** No one in the family ever discussed me.  

207. **Hindi prompt:** आखिरकार, इतिहास में कोई भी कभी भी अतीत को उस तरह से देखने में सक्षम नहीं हुआ है जैसा हम देखते हैं।  
   **Romanized:** (Aakhirkaar, itihaas mein koi bhee kabhi bhee ateet ko us tarah se dekhane mein saksham nahin hua hai jaisa ham dekhate hain.)  
   **English answer:** After all, no one in history has ever been able to see the past the way we do.  

208. **Hindi prompt:** क्या आपने कभी किसी को बताया है?  
   **Romanized:** (Kya aapne kabhi kisi ko bataaya hai?)  
   **English answer:** Have you ever told anyone?  

209. **Hindi prompt:** चाहे जो मर्ज़ी कह लो मैं उससे बात करना बंद कभी नहीं करूँगा।  
   **Romanized:** (Chahe jo marzi kehlo main usse baat karna kabhi bhi band nahin karunga.)  
   **English answer:** I will never stop talking to him whatever he wants.  

210. **Hindi prompt:** तुमने कभी भी अपने दोस्त को बचाने के लिए झूठ बोला?  
   **Romanized:** (Tumne kabhi bhi apne dost ko bachane kai liye jhoot bola?)  
   **English answer:** Have you ever lied to save your friend?  

211. **Hindi prompt:** मैं किसी की नज़रो में अच्छा बनने के लिए झूठ कभी नहीं बोलूँगा।  
   **Romanized:** (Main kisi ki nazro mai acha banne kai liye jhoot kabhi nahi bolunga.)  
   **English answer:** I will never lie to be good in the eyes of anyone.  

212. **Hindi prompt:** मैने आज तक कभी सिगरेट को हाथ नहीं लगाया।  
   **Romanized:** (Maine aaj tak kabhi cigarette ko kabhi hath nahi lagaya.)  
   **English answer:** I have never touched a cigarette till today.  

213. **Hindi prompt:** मैं कितना भी स्ट्रेस में रहूँ सिगरेट को कभी नही छूऊँगा।  
   **Romanized:** (Mai kitna bhi stress main rahu cigarette ko kabhi nahi chuoonga.)  
   **English answer:** No matter how stressed I am, I will never touch a cigarette.  

214. **Hindi prompt:** क्या तुमने कभी किसी की फिलिंग की कदर की है?  
   **Romanized:** (Kya tumne kabhi kisi ki feeling ki kadar ki hai?)  
   **English answer:** Have you ever appreciated someone's filling?  

215. **Hindi prompt:** क्या आप कभी किसी हिंदी फ़िल्म के हीरो से मिले हो?  
   **Romanized:** (Kya aap kabhi kisi hindi film ke hero se mile ho?)  
   **English answer:** Have you ever met the hero of any Hindi film?  

216. **Hindi prompt:** मैने किसी के बारे में खुद से पहले कभी नही सोचा।  
   **Romanized:** (Maine kisi kai bare main khud se pehle kabhi nahi socha.)  
   **English answer:** I have never thought of anyone before myself.  

217. **Hindi prompt:** मैने कभी इतनी सुंदर तस्वीर कभी नहीं देखी।  
   **Romanized:** (Maine itni sundar tasveer kabhi nahi dekhi.)  
   **English answer:** I have never seen such a beautiful picture.  

218. **Hindi prompt:** क्या तुम्हारा कभी मन नहीं किया की मुझे कॉल करने का?  
   **Romanized:** (Kya tumhara kabhi man nahi kiya mujhe call karne ka?)  
   **English answer:** Have you never felt like calling me?  

219. **Hindi prompt:** मेरा इतने सालो में तुमसे बात करने का मन कभी नहीं किया।  
   **Romanized:** (Mera itne saalon main tumse baat karne ka man kabhi nahi kiya.)  
   **English answer:** I have never felt like talking to you in all these years.  

220. **Hindi prompt:** मैने मंकी कैप कभी नहीं पहनी।  
   **Romanized:** (Maine monkey cap kabhi nahi pehni.)  
   **English answer:** I have never worn a monkey cap.  

221. **Hindi prompt:** क्या तुमने कभी नितिन को अपने दिल की बात बताई?  
   **Romanized:** (Kya tumne kabhi Nitin ko apne dil ki baat bataee?)  
   **English answer:** Have you ever told your heart to Nitin?  

222. **Hindi prompt:** मैं गाँव में पैदा हुआ था यह मम्मी ने कभी नहीं बताया।  
   **Romanized:** (Main gaon main paida huwa tha yah mummy nai kabhi nahi batayaa.)  
   **English answer:** My mother never told me that I was born in the village.  

223. **Hindi prompt:** क्या तुमने कभी कॉल सेंटर मे जॉब की है?  
   **Romanized:** (Kya tumne kbhi call centre mai job ki hai?)  
   **English answer:** Have you ever worked in a call center?  

224. **Hindi prompt:** मैंने उसको कभी भी चोट पहुँचाने की कोशिश नहीं की।  
   **Romanized:** (Maine usko kabhi bhee chot pahunchaane ki koshish nahin kee.)  
   **English answer:** I never tried to hurt him.  

225. **Hindi prompt:** मैने रात को हॉल में कभी मूवी नहीं देखी।  
   **Romanized:** (Maine raat ko hall mai kabhi movie nahi dekhi.)  
   **English answer:** I have never seen a movie in the hall at night.  

226. **Hindi prompt:** मैं रात को 8 बजे के बाद घर से बाहर कभी नहीं निकलता हूँ।  
   **Romanized:** (Main raat ko 8 baje ke baad ghar se baahar kabhee nahi nikalta hoon.)  
   **English answer:** I never leave the house after 8 o'clock in the night.  

227. **Hindi prompt:** क्या आपने कभी सोचा था, कि मैं एक दिन बहुत बड़ा इंसान बनूँगा।  
   **Romanized:** (Kya aapne kabhi socha tha, ki main ek din bahut bada insaan banuga.)  
   **English answer:** Have you ever thought that one day I will become a very big person?  

228. **Hindi prompt:** अगर आप कठोर है तो कोई भी आपको कभी चोट नहीं पहुँचा सकता।  
   **Romanized:** (Agar aap kathor hai to koi bhee aapko kabhi chot nahi pahucha sakta.)  
   **English answer:** If you are tough no one can ever hurt you.  

229. **Hindi prompt:** मैंने आप दोनों को कभी भी साथ में जाते नहीं देखा हैं।  
   **Romanized:** (Maine aap dono ko kabhi bhee sath mein jaate nahi dekha hai.)  
   **English answer:** I have never seen you two go together.  

230. **Hindi prompt:** क्या हम कभी निर्दोष थे?  
   **Romanized:** (Kya ham kabhi nirdosh the?)  
   **English answer:** Were we ever innocent?  

231. **Hindi prompt:** क्या वो कभी आपसे मिलता है?  
   **Romanized:** (Kya vo kabhi aapse milta hai?)  
   **English answer:** Does he ever meet you?  

232. **Hindi prompt:** क्या वो कभी आपके घर आते हैं?  
   **Romanized:** (Kya wo kabhi aapke ghar aate hain?)  
   **English answer:** Do they ever come to your house?  

233. **Hindi prompt:** क्या तुमने कभी उसे पढ़ा?  
   **Romanized:** (Kya tumane kabhi use padha?)  
   **English answer:** Have you ever read it?  

234. **Hindi prompt:** क्या तुम कभी केरल गए हो?  
   **Romanized:** (Kya tum kabhi Kerala gaye ho?)  
   **English answer:** Have you ever been to Kerala? / Have you ever visited Kerala?  

235. **Hindi prompt:** आज के बाद कभी अपनी शक्ल मत दिखाना।  
   **Romanized:** (Aaj ke baad kabhi apni shakal mat dikhana.)  
   **English answer:** After today never show your face again.  

## Source-text and verification notes

- All 235 Hindi and printed Romanized prompts on PDF pages 380–394 were OCRed from row crops and visually checked against the scans. All 235 printed English answers on pages 394–401 were visually verified and paired by item number. Prompt and answer sequences are complete and unique.
- Lesson 29 spans PDF pages 380–401 (printed pages 379–400). It contains 235 Hindi/Romanized prompts on PDF pages 380–394 and their same-number English answers on PDF pages 394–401. PDF page 394 has prompts 222–235, then the Answers heading and answers 1–6; PDF page 395 continues answers 7–43. The prompt and answer sequences are each complete and unique from 1 through 235.
- All 235 Hindi and printed Romanized prompts were OCRed from row crops and visually checked against the scans. All 235 printed English answers were visually verified and paired by item number. No unreadable sections.
- Nonstandard or inconsistent printed Romanization is retained rather than normalized. Examples include `mar` for `mat` (18), `lo` for `ko` (25), repeated `kabhi kabhi` (31), `gaw` for गाँव (58), `hotal` (112), `Musoorie` (160), `naav main` (161), `cigarrete` and `laitar` (166), `Aagar` (176), `kbhi` (223), and `banuga` (227). Item 43’s Hindi scan is a question while Romanization ends with a period; item 174’s Hindi is a question while Romanization also ends with a period. Source-specific capitalization, spacing, misspellings and incomplete parenthetical punctuation are preserved where printed.
- Printed Hindi/Romanized mismatches and grammatical quirks are preserved: item 95 Hindi omits `के` while Romanized includes `ke`; item 97 prints `राजा नें`; item 105’s printed Romanized line lacks a closing parenthesis; items 118–119 retain unusual spacing; item 129 Romanized prints `apse` for Hindi `आपसे`; item 156 prints `करते है`; item 187 is printed in lowercase; and item 204 and several other examples preserve the source’s awkward wording. The correction at 187 only fixes an OCR-added capital I in `kabhI`.
- English answer wording, punctuation, alternatives, capitalization and printed oddities are retained as they appear in the answer key. Footer page numbers in scan images are one lower than PDF page labels.

**Unreadable text:** none identified.

