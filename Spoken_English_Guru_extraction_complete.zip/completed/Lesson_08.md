# Lesson 8 — Simple Sentences (No action by the Subject)

**PDF pages:** 59–67 (printed pages 58–66)

## Bilingual prompts and printed English answers

### 1. इस अलमारी में चार किताबें हैं।
**Romanized:** (Is almirah me chaar kitaben hain.)
**English answer:** This almirah has four books. / There are four books in this almirah.
**Explanation:** You can also say “cupboard” instead of “almirah”.

### 2. इस अलमारी में चार किताबें नहीं हैं।
**Romanized:** (Is almirah me chaar kitaben nahi hain.)
**English answer:** This almirah doesn’t have four books. / There aren’t four books in this almirah.

### 3. उसके पास कुछ है।
**Romanized:** (Uske paas kuchh hai.)
**English answer:** He has something.

### 4. उसके पास कुछ नहीं है।
**Romanized:** (Uske paas kuchh nahi hai.)
**English answer:** He does not have anything.

### 5. क्या उसके पास कुछ है?
**Romanized:** (Kya uske paas kuchh hai?)
**English answer:** Does he have something?

### 6. क्या उसके पास कुछ नहीं है?
**Romanized:** (Kya uske paas kuchh nahi hai?)
**English answer:** Does he not have something? / Does he have nothing?

### 7. उसके पास क्या है?
**Romanized:** (Uske pass kya hai?)
**English answer:** What does he have?

### 8. उसके पास कितने पैन हैं?
**Romanized:** (Uske pass kitne pen hain?)
**English answer:** How many pens does he have?

### 9. उसके पास क्या क्या है?
**Romanized:** (Uske pass kya kya hai?)
**English answer:** What all does he have?

### 10. उसके पास मेरा पैन क्यों है?
**Romanized:** (Uske pass mera pen kyon hai?)
**English answer:** Why does he have my pen?

### 11. तुम्हारे पास क्या है?
**Romanized:** (Tumhare pass kya hai?)
**English answer:** What do you have?

### 12. तुम्हारे पास क्या था?
**Romanized:** (Tumhare pass kya tha?)
**English answer:** What did you have?

### 13. उसके तीन भाई बहन हैं।
**Romanized:** (Uske teen bhai bahan hain.)
**English answer:** He has three siblings.

### 14. उसके तीन भाई बहन नहीं हैं।
**Romanized:** (Uske teen bhai bahan nahi hain.)
**English answer:** He does not have three siblings.

### 15. क्या उसके तीन भाई बहन नहीं हैं?
**Romanized:** (Kya uske teen bhai bahan nahi hain?)
**English answer:** Does he not have three siblings?

### 16. उसके तीन भाई बहन क्यों नहीं हैं?
**Romanized:** (Kya uske teen bhai bahan kyon nahi hain?)
**English answer:** Why does he not have three siblings?

### 17. मेरे तीन भाई बहन हैं।
**Romanized:** (Mere teen bhai bahan hain.)
**English answer:** I have three siblings.

### 18. मेरे तीन भाई बहन नहीं हैं।
**Romanized:** (Mere teen bhai bahan nahi hain.)
**English answer:** I do not have three siblings.

### 19. मेरा पैन किसके पास है?
**Romanized:** (Mera pen kiske paas hai?)
**English answer:** Who has my pen?

### 20. पैन किस किस के पास हैं?
**Romanized:** (Pen kis kis ke paas hain?)
**English answer:** Who all have pens?

### 21. इस क्लास में किस किस के तीन भाई बहन हैं?
**Romanized:** (Is class me kis kis ke 3 bhai bahan h?)
**English answer:** Who all in this class have three siblings?

### 22. ये मेरे बच्चे हैं।
**Romanized:** (Ye mere bachche hain.)
**English answer:** These are my children.

### 23. वो मेरे बच्चे हैं।
**Romanized:** (Vo mere bachche hain.)
**English answer:** Those are my children.

### 24. ये बच्चे मेरे हैं।
**Romanized:** (Ye bachche mere hai.)
**English answer:** These children are mine.

### 25. ये मेरा पैन है।
**Romanized:** (Ye mera pen hai.)
**English answer:** This is my pen.

### 26. ये पैन मेरा है।
**Romanized:** (Ye pen mera hai.)
**English answer:** This pen is mine.

### 27. ये मेरी बिल्ली है।
**Romanized:** (Ye meri billi hai.)
**English answer:** This is my cat.

### 28. ये बिल्ली मेरी है।
**Romanized:** (Ye billi meri hai.)
**English answer:** This cat is mine.

### 29. ये राम की किताब है।
**Romanized:** (Ye Ram ki kitab hai.)
**English answer:** This is Ram’s book.

### 30. ये किताब राम की है।
**Romanized:** (Ye kitab Ram ki hai.)
**English answer:** This book is Ram’s. / This book belongs to Ram.

### 31. ये कहानी किसी और की है।
**Romanized:** (Ye kahani kisi aur ki hai.)
**English answer:** This story is someone else’s. / This story belongs to someone else.

### 32. बच्चे किसके साथ हैं?
**Romanized:** (Bachche kiske saath hai?)
**English answer:** With whom are the children?

### 33. मम्मी के पास पैसे नहीं है।
**Romanized:** (Mummi ke pass paise nahi hai.)
**English answer:** Mom doesn’t have money.

### 34. वो किसके पापा हैं?
**Romanized:** (Vo kiske papa hain?)
**English answer:** Whose father is he?

### 35. वो किस लड़की के पापा हैं?
**Romanized:** (Vo kis ladki ke papa hain?)
**English answer:** Which girl’s father is he? / He is the father of which girl?

### 36. तुम किस शहर से हो?
**Romanized:** (Tum kis shahar se ho?)
**English answer:** From which city are you? / Which city are you from?

### 37. आप कहाँ से हैं?
**Romanized:** (Aap kahaan se hain?)
**English answer:** From where are you? / Where are you from?

### 38. तुम किस शहर में हो?
**Romanized:** (Tum kis shahar mein ho?)
**English answer:** In which city are you? / Which city are you in?

### 39. एक दिन, मेरे पास एक मर्सीडीज़ कार होगी।
**Romanized:** (Ek din, mere paas ek Mercedes hogi.)
**English answer:** One day, I will have a Mercedes car.

### 40. तुम कब तक ऑफिस में थे?
**Romanized:** (Tum kab tak office mein the?)
**English answer:** Until when were you in the office? / Until when were you there in the office?
**Explanation:** You can also use “Till what time” instead of “Until when” in this sentence.

### 41. वो कब से ऑफिस में है?
**Romanized:** (Vo kab se office mein hai?)
**English answer:** Since when is he there in the office? / Since when is he there in the office?
**Explanation:** You can also use “For how long” instead of “Since when” in this sentence.

### 42. रवि घर पर सोया हुआ है।
**Romanized:** (Ravi ghar par soya hua hai.)
**English answer:** Ravi is asleep at home.

### 43. रवि इस वक्त उठा हुआ है।
**Romanized:** (Ravi is waqt utha hua hai.)
**English answer:** Ravi is awake at this time.

### 44. रवि इस वक्त बैठा हुआ है।
**Romanized:** (Ravi is waqt baitha hua hai.)
**English answer:** Ravi is sitting at this time.

### 45. मैं क्लास में बैठा हूँ।
**Romanized:** (Main class mein baitha hoon.)
**English answer:** I am sitting in the class.

### 46. रवि इस वक्त खड़ा है।
**Romanized:** (Ravi is waqt khada hai.)
**English answer:** Ravi is standing at this time.

### 47. पैन मुड़ा हुआ है।
**Romanized:** (Pen muda hua hai.)
**English answer:** The pen is bent.

### 48. ये बात मेरी किताब में लिखी हुई है।
**Romanized:** (Ye baat meri kitab me likhi hui hai.)
**English answer:** This thing is written in my book.

### 49. ये बात इस किताब में छपी हुई है।
**Romanized:** (Ye baat is kitab me chhapi hui hai.)
**English answer:** This thing is printed in this book.

### 50. रोड पर एक आदमी मरा हुआ है।
**Romanized:** (Road par ek aadmi mara hua hai.)
**English answer:** A man is dead on the road. / There is a man dead on the road.

### 51. मेरे पास कुछ फटे हुए कपड़े हैं।
**Romanized:** (Mere paas kuchh phate hue kapde hain.)
**English answer:** I have some torn clothes.

### 52. मेरे पास कुछ पुराने कपड़े हैं।
**Romanized:** (Mere paas kuchh purane kapde hain.)
**English answer:** I have some worn-out clothes.

### 53. एक बच्चा क्लास में छिपा हुआ है।
**Romanized:** (Ek bachcha class me chhipa hua hai.)
**English answer:** A child is hidden in the class. / There is a child hidden in the class.

### 54. उस टेबल पर क्या है?
**Romanized:** (Us table par kya hai?)
**English answer:** What is on that table? / What is there on that table?

### 55. मैं इस फोटो में नहीं हूँ।
**Romanized:** (Main is photo mein nahi hoon.)
**English answer:** I am not in this photograph. / I am not there in this photograph.

### 56. क्या तुम्हारे पास है?
**Romanized:** (Kya tumhare paas hai?)
**English answer:** Do you have?

### 57. क्या तुम्हारे पास मोबाइल है?
**Romanized:** (kya tumhare paas mobile hai?)
**English answer:** Do you have a mobile?

### 58. तुम्हारे पास क्या है?
**Romanized:** (Tumhare paas kya hai?)
**English answer:** What do you have?

### 59. गाड़ी में कितना पेट्रोल है?
**Romanized:** (Gadi me kitna petrol hai?)
**English answer:** How much petrol does the car have? / How much petrol is there in the car?

### 60. तुम्हारे पास कितना पैसा है?
**Romanized:** (Tumhare pass kitna paisa hai?)
**English answer:** How much money do you have? / How much money is there with you?

### 61. तुम्हारी जेब में कितना पैसा है?
**Romanized:** (Tumhari jeb me kitna paisa hai?)
**English answer:** How much money do you have in your pocket? / How much money is there in your pocket?

### 62. ये तुम्हारा नहीं है।
**Romanized:** (Ye tumhara nahi hai.)
**English answer:** This is not yours.

### 63. ये हमारा है।
**Romanized:** (Ye hamara hai.)
**English answer:** This is ours.

### 64. हम तुम्हारे हैं।
**Romanized:** (Hum tumhare hain.)
**English answer:** We are yours.

### 65. तुम अच्छे हो।
**Romanized:** (Tum achchhe ho.)
**English answer:** You are good.

### 66. पापा राहुल के साथ थे।
**Romanized:** (Papa Rahul ke saath the.)
**English answer:** Papa was with Rahul. / Papa was there with Rahul.

### 67. बच्चा मेरे आगे था।
**Romanized:** (Bachcha mere aage tha.)
**English answer:** The kid was ahead of me.

### 68. ये उसका दोस्त नहीं है।
**Romanized:** (Ye uska dost nahi hai.)
**English answer:** This is not his friend.

### 69. ये लड़का कहाँ पर था?
**Romanized:** (Ye ladka kahan par tha?)
**English answer:** Where was this boy?

### 70. मैं राम की वजह से यहाँ हूँ।
**Romanized:** (Main Ram ki vajah se yahan hoon.)
**English answer:** I am here because of Ram.

### 71. उसके पास पैन था।
**Romanized:** (Uske pass pen tha.)
**English answer:** He had a pen.

### 72. राहुल किसका भाई है?
**Romanized:** (Rahul kiska bhai hai?)
**English answer:** Whose brother is Rahul?

### 73. वो घर किसका है?
**Romanized:** (Vo ghar kiska hai?)
**English answer:** Whose is that house/home?

### 74. मैं तुमसे लम्बा हूँ।
**Romanized:** (Main tumse lamba hoon.)
**English answer:** I am taller than you.

### 75. मैं कौन हूँ?
**Romanized:** (Main kaun hoon?)
**English answer:** Who am I?

### 76. क्या है वो?
**Romanized:** (Kya hai vo?)
**English answer:** What is that?

### 77. मेरे पीछे कौन खड़ा था?
**Romanized:** (Mere peechhe kaun khada tha?)
**English answer:** Who was standing behind me?

### 78. उसके भाई कितने बड़े हैं?
**Romanized:** (Uske bhai kitne bade hain?)
**English answer:** How old are his brothers?

### 79. तुम मेरे सबसे छोटे भाई हो।
**Romanized:** (Tum mere sabse chhote bhai ho.)
**English answer:** You are my youngest brother.

### 80. ये तुम्हारे लिए मेरा प्यार है।
**Romanized:** (Ye tumhare liye mera pyaar hai.)
**English answer:** This is my love for you.

### 81. क्या है उसका नाम?
**Romanized:** (Kya hai uska naam?)
**English answer:** What is his name?

### 82. वो थकी हुई थी।
**Romanized:** (Vo thakee hui thi.)
**English answer:** She was tired.

### 83. हम बैठे हुए थे।
**Romanized:** (Hum baithe hue the.)
**English answer:** We were sitting.

### 84. तुम खड़े क्यों हो?
**Romanized:** (Tum khade kyun ho?)
**English answer:** Why are you standing?

### 85. तुम दिल्ली के आस पास हो।
**Romanized:** (Tum Delhi ke aas paas ho.)
**English answer:** You are nearabout Delhi. / You are hereabouts Delhi.

### 86. मेरे पैर में क्या है?
**Romanized:** (Mere pair mein kya hai?)
**English answer:** What is there in my leg?

### 87. उसके पास कुछ नहीं है।
**Romanized:** (Uske paas kuch nahi hai.)
**English answer:** He doesn’t have anything. / He has nothing.

### 88. राम पेड़ के पीछे छिपा हुआ था।
**Romanized:** (Ram ped ke peeche chipa hua tha.)
**English answer:** Ram was hidden behind the tree.

### 89. मैं हर पल तुम्हारे साथ था।
**Romanized:** (Main har pal tumhare sath tha.)
**English answer:** I was there with you every moment.

### 90. किस शहर में हो तुम इस वक्त?
**Romanized:** (kis shahar me ho tum is vakt?)
**English answer:** In which city are you right now? / Which city are you in right now?

### 91. मैं सिर्फ तुम्हारे लिए जिंदा हूँ।
**Romanized:** (Mai sirf tumhare liye zinda hoon.)
**English answer:** I am alive only for you.

### 92. राम कहीं खोया हुआ था।
**Romanized:** (Ram kahi khoya hua tha.)
**English answer:** Ram was lost somewhere.

### 93. मैं तुम्हारे सपनों में खोया हुआ हूँ।
**Romanized:** (Main tumhare sapno me khoya hua hoon.)
**English answer:** I am lost in your dreams.

### 94. मोबाइल टेबल पर रखा हुआ है।
**Romanized:** (Mobile table par rakha hua hai.)
**English answer:** The mobile is kept on the table.

### 95. मैं डरा हुआ था।
**Romanized:** (Mai dara hua tha.)
**English answer:** I was scared. / I was horrified. / I was terrified. / I was petrified.

### 96. कितने बच्चे इस समय यहाँ हैं?
**Romanized:** (Kitne bachche is samay yahan hai?)
**English answer:** How many children are here at this time?

### 97. राम 2 बजे जगा हुआ था।
**Romanized:** (Ram 2 baje jaga hua tha.)
**English answer:** Ram was awake at 2.

### 98. राम 2 बजे से जगा हुआ था।
**Romanized:** (Ram 2 baje se jaga hua tha.)
**English answer:** Ram had been awake since 2.

### 99. उसके पापा पिये हुए थे।
**Romanized:** (Uske papa piye hue the.)
**English answer:** His father was drunk.

### 100. तुम मेरे करीबी दोस्त हो।
**Romanized:** (Tum mere kareebi dost ho.)
**English answer:** You are my close friend.

### 101. ये लिखा हुआ था।
**Romanized:** (Ye likha hua tha.)
**English answer:** It was written.

### 102. ये भगवत गीता में लिखा हुआ है।
**Romanized:** (Ye Bhagwat Geeta me likha hua hai.)
**English answer:** It is written in the Bhagavad Geeta.

### 103. भिखारी के कपड़े फटे हुए थे।
**Romanized:** (Bhikhari ke kapde phate hue the.)
**English answer:** The beggar’s clothes were torn.

### 104. क्या तुम्हारे पास कुछ था?
**Romanized:** (Kya tumhare pass kuch tha?)
**English answer:** Did you have something?

### 105. हमारे पास कुछ है।
**Romanized:** (Hamare paas kuch hai.)
**English answer:** We have something.

### 106. मैं किसके लिए वहाँ था?
**Romanized:** (Main kiske liye vaha tha?)
**English answer:** For whom was I there? / Whom was I there for?

### 107. वो तुम्हारे लिए रूका हुआ है।
**Romanized:** (Vo tumhare liye ruka hua hai.)
**English answer:** He is waiting for you.

### 108. तुम घर के अंदर थे।
**Romanized:** (Tum ghar ke andar the.)
**English answer:** You were inside the house.

### 109. राम मेरे बगल में खड़ा है।
**Romanized:** (Ram mere bagal main khada hai.)
**English answer:** Ram is standing beside / next to / adjacent me.

### 110. शिव की पूजा यहाँ प्रसिद्ध है।
**Romanized:** (Shiv kee pooja yahan prasiddh hai.)
**English answer:** The worship of Lord Shiva is famous here.

### 111. हमारी ख्वाहिशें इतनी क्यों हैं?
**Romanized:** (Hamari khvahishein itni kyon hai?)
**English answer:** Why are our desires these many?

### 112. तुम ऐसे क्यों हो?
**Romanized:** (Tum aise kyon ho?)
**English answer:** Why are you so?

### 113. पैसे किसके पास हैं?
**Romanized:** (Paise kiske paas hai?)
**English answer:** Who has money?

### 114. क्या तुम्हारे पास दिमाग नहीं है?
**Romanized:** (kya tumhare pass dimaag nahi hai?)
**English answer:** Do you not have brain? / Do you not have mind?

### 115. ये टूटा हुआ दिल मेरा है।
**Romanized:** (Ye toota hua dil mera hai.)
**English answer:** This broken heart is mine.

### 116. उसके कितने लड़के हैं?
**Romanized:** (Uske kitne ladke hai?)
**English answer:** How many sons does he have?

### 117. आप मुझसे ज़्यादा बुरे हैं।
**Romanized:** (Aap mujhse zyada bure hain.)
**English answer:** You are worse than I.

### 118. क्या राम मुझसे ज़्यादा अच्छा है?
**Romanized:** (kya Ram mujhse zyada acha hai?)
**English answer:** Is Ram better than me?

### 119. मुझे तुमसे प्यार है।
**Romanized:** (Mujhe tumse pyaar hai.)
**English answer:** I am in love with you. / I love you.

### 120. इतने सारे पैसे तुम्हारे पास कैसे हैं?
**Romanized:** (Itne sare paise tumhare paas kaise hai?)
**English answer:** How do you have this much money?

### 121. रिश्ते खूबसूरत होते हैं।
**Romanized:** (Rishte khoobsurat hote hai.)
**English answer:** Relations are beautiful.

### 122. ये कोई और है।
**Romanized:** (Ye koi aur hai.)
**English answer:** This is someone else.

### 123. ये कुछ और है।
**Romanized:** (Ye kuch aur hai.)
**English answer:** This is something else.

### 124. तुम्हारा पैन कौन सा वाला है?
**Romanized:** (Tumhara pen kaun sa vala hai?)
**English answer:** Which one is your pen?

### 125. ये पैन किसका है?
**Romanized:** (Ye kiska pen hai?)
**English answer:** Whose is this pen?

### 126. तुम्हारे पीछे कौन है?
**Romanized:** (Tumhare peechhe kaun hai?)
**English answer:** Who is behind you?

### 127. पैसे किसके पास नहीं हैं?
**Romanized:** (Paise kiske pass nahi hain?)
**English answer:** Who doesn’t have money?

### 128. तुम किस बात के लिए दुखी हो?
**Romanized:** (Tum kis baat ke liye dukhi ho?)
**English answer:** What are you sad for?

### 129. राम कब तक इस जगह में था?
**Romanized:** (Ram kab tak is jagah mein tha?)
**English answer:** Until (Till what time) when was Ram here in this place?

### 130. मैं तुम्हारे सामने खड़ा था।
**Romanized:** (Main tumhare saamne khada tha.)
**English answer:** I was standing in front of you. / I was standing before you.

### 131. मैं ठीक तुम्हारे सामने खड़ा था।
**Romanized:** (Main theek tumhare saamane khada tha.)
**English answer:** I was standing just in front of you. / I was standing just before you.

### 132. किस लड़की के पापा वहाँ खड़े थे?
**Romanized:** (kis ladki ke papa vahan khade the?)
**English answer:** Which girl’s father was standing there?

### 133. मैं गिटार के लिए पागल हूँ।
**Romanized:** (Main guitaar ke liye pagal hoon.)
**English answer:** I am crazy for guitar. / I am obsessed for guitar.

### 134. वहाँ कितने लोग हैं?
**Romanized:** (Vahan kitne log hai?)
**English answer:** How many people are there?

### 135. पैन कहाँ रखा हुआ है? /
**Romanized:** (Pen kahan rakha hua hai?)
**English answer:** Where is the pen kept?

### 136. समय क्या हुआ है?
**Romanized:** (Samay kya hua hai?)
**English answer:** What is the time?

### 137. तुम दोनों सबसे अच्छे हो।
**Romanized:** (Tum dono sabse ache ho.)
**English answer:** You both are the best. / Both of you are the best.

### 138. हम सब तुम्हारे साथ हैं।
**Romanized:** (Hum sab tumhare saath hain.)
**English answer:** We all are with you.

### 139. मैं तुम्हारा कौन हूँ?
**Romanized:** (Main tumhara kaun hoon?)
**English answer:** Who am I to you?

---
**Verification:** All 139 Hindi prompts were OCR-read from individual rows and checked against the page images. Printed Romanized text and all 139 English answer-key entries were paired by item number; all answer alternatives and three explanatory notes were preserved. No unreadable text.

