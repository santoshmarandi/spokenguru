# Lesson 35 — Special Cases

**PDF pages:** 451–454 (printed pages 450–453)

These sentences are taken from the lesson “Special Cases” of the “Spoken English Guru” English Speaking Course Book. Let’s translate them into English.

## Prompts and answers

1. **आज तुम्हारा चेहरा अच्छा लग रहा है।**
   Romanized: Aaj tumhaara chehra acha lag raha hai.  
   **Answer:** Your face is looking good today.

2. **तुम्हें देखने के बाद मुझे अच्छा लगा।**
   Romanized: Tumhe dekhne ke baad mujhe acha laga.  
   **Answer:** Having seen you, I felt good.

3. **राम और सीता एक दूसरे के लिए ही बने हैं।**
   Romanized: Ram aur Seeta ek dusre ke liye hi bane hai.  
   **Answer:** Ram & Seeta are meant/made for each other.

4. **क्या तुम अंग्रेज़ी बोलना जानते हो?**
   Romanized: Kya tum angrezi bolna jaante ho?  
   **Answer:** Do you know how to speak in English?

5. **मैं दिन भर खेलता रहता था।**
   Romanized: Main din bhar khelta rehta tha.  
   **Answer:** I used to play throughout the day.

6. **यह पैन भारत में बना है।**
   Romanized: Yah pen Bharat mai bana hai.  
   **Answer:** This pen is made in India.

7. **तुम जब उसकी हालत देखोगे तो अपने आँसू रोक नहीं पाओगे।**
   Romanized: Tum jab uski haalat dekhoge to apne aansu rok nahi paoge.  
   **Answer:** When you will see his plight/condition, you wouldn’t be able to hold your emotions.

8. **चाहे वो जो करे, मैं साथ दूँगा।**
   Romanized: Chahe vo jo kare, mai sath doonga.  
   **Answer:** No matter what, I’ll stand by him.

9. **राम के पास पैसे नहीं हैं, अब राम क्या करे?**
   Romanized: Ram ke paas paise nahi hain, ab Ram kya kare?  
   **Answer:** Ram doesn’t have money, what does he do now?

10. **तुम्हारी आवाज़ अच्छी लगी।**
   Romanized: Tumhaari aawaz achi lagi.  
   **Answer:** Your voice sounded pretty.

11. **यह चश्मा चाईना में बना है।**
   Romanized: Yah chasma China mai bana hai.  
   **Answer:** These spectacles are made in China.

12. **खाना खाने के बाद मुझे जाना था।**
   Romanized: Khana khane ke baad mujhe jaana tha.  
   **Answer:** I had to go after having food. / Having had food, I had to go.

13. **पैसा खर्च करने के लिए ही होता है।**
   Romanized: Paisa kharch karne ke liye hi hota hai.  
   **Answer:** Money is to spend.

14. **क्या तुम लिखना जानते थे?**
   Romanized: Kya tum likhna jaante the?  
   **Answer:** Did you know how to write?

15. **मैं रात भर पढ़ता रहा।**
   Romanized: Main raat bhar padhta raha.  
   **Answer:** I kept on reading whole night.

16. **हम कहाँ सोयें?**
   Romanized: Hum kahan soye?  
   **Answer:** Where do we sleep?

17. **मैं आँसू नहीं रोक पाया।**
   Romanized: Main aansoo nahi rok paya.  
   **Answer:** I couldn’t hold tears.

18. **यह मोबाइल ऑस्ट्रेलिया में बना है।**
   Romanized: Yah mobile Australia mai bana hai.  
   **Answer:** This mobile is made in Australia.

19. **मैं कार चलाना नहीं जानता।**
   Romanized: Main car chalana nahi jaanta.  
   **Answer:** I don’t know how to drive the car.

20. **तुम्हारी आवाज़ से लगता है तुम्हें खाँसी है।**
   Romanized: Tumhari aawaz se lagta h tumhe khansi h.  
   **Answer:** Your voice suggests that you are suffering from cough.

21. **वो नाराज़ हो गया।**
   Romanized: Vo naraaz ho gya.  
   **Answer:** He got angry/annoyed.

22. **मैं किसे पूछूँ ?**
   Romanized: Main kisse poochun?  
   **Answer:** Whom do I ask?

23. **मैं परेशान हो गया।**
   Romanized: Main pareshan ho gaya.  
   **Answer:** I got annoyed.

24. **सीता कम्प्यूटर चलाना नहीं जानती थी।**
   Romanized: Seeta computer chalana nahi jaanti thi.  
   **Answer:** Seeta didn’t know how to operate a computer.

25. **मम्मी एकाद साल में ठीक हो जायेगी।**
   Romanized: Mummy ekaad saal mai thik ho jayegi.  
   **Answer:** Mom will be fine in a year or so.

26. **मैं वो नहीं जिसने तुम्हारे भाई को डाँटा।**
   Romanized: Main vo nahi jisne tumhare bhaee ko daanta.  
   **Answer:** I am not the one who scolded your brother.

27. **तुम वो इन्सान हो जिसे मैं चाहती हूँ।**
   Romanized: Tum vo insan ho jise main chahti hoon.  
   **Answer:** You are the person who I love.

28. **क्या मैं वहाँ जाऊँ ?**
   Romanized: Kya main vahan jaaun?  
   **Answer:** Do I go there?

29. **वो खाना बनाना नहीं जानता।**
   Romanized: Vo khaana banana nahi janta.  
   **Answer:** He doesn’t know how to prepare the food.

30. **दिल को कैसे मनाऊँ ?**
   Romanized: Dil ko kaise manaun?  
   **Answer:** How do I convince my heart?

31. **ये बात अच्छी लगती है।**
   Romanized: Yah baat achi lagti hai.  
   **Answer:** This sounds good.

32. **बच्चे को ठंड लग गयी थी।**
   Romanized: Bache ko thand lag gayi thi.  
   **Answer:** Child had got cold.

33. **तुम्हारा ये कहना कि मैं पागल हूँ, मुझे अच्छा नहीं लगा।**
   Romanized: Tumhaara yai kehna ki main pagal hun, mujhe acha nahi laga.  
   **Answer:** Yours saying that I was mad, I didn’t like.

34. **तुम्हारा मुझे डाँटना ठीक नहीं था।**
   Romanized: Tumhara mujhe daantna thik nahi tha.  
   **Answer:** Yours scolding me was not fair.

35. **राम का मुझे डाँटना ठीक नहीं था।**
   Romanized: Ram ka mujhe daantna thik nahi tha.  
   **Answer:** Ram’s scolding me was not fair.

36. **पापा का मुझे पीटना ठीक नहीं था।**
   Romanized: Papa ka mujhe peetna thik nahi tha.  
   **Answer:** Dad’s beating me was not fair.

37. **यह संगीत अच्छा लग रहा है।**
   Romanized: Yah sangeet acha lag raha hai.  
   **Answer:** This music is sounding good.

38. **लगता है तुम्हें मैं अच्छा नहीं लगा।**
   Romanized: Lagta hai tumhe main acha nahi laga.  
   **Answer:** Seems as you didn’t like me.

39. **लगता है तुम पागल हो।**
   Romanized: Lagta hai tum pagal ho.  
   **Answer:** Seems as you are mad.

40. **रोटी मम्मी ने बनायी थी।**
   Romanized: Roti mummy nai banayi thi.  
   **Answer:** Roti was made by Mom.

41. **मैं तुम्हें देखता रहूँगा।**
   Romanized: Main tumhe dekhta rahunga.  
   **Answer:** I will keep on watching you.

42. **वो खाना पकाना क्‍यों नहीं जानती?**
   Romanized: Vo khana pakana kyun nahi jaanti.  
   **Answer:** Why does she not know how to cook the food?

43. **मैं घर पहुँचने वाला हूँ।**
   Romanized: Main ghar pahuchne wala hun  
   **Answer:** I am about to reach home.

44. **ट्रेन आने वाली थी।**
   Romanized: Train aane wali thi.  
   **Answer:** Train was about to arrive.

45. **मैं ये काम करने योग्य हूँ।**
   Romanized: Main ye kaam karne yogya hoon.  
   **Answer:** I am able to do this work. / I can do this work.

46. **ये राम ने बनाया है।**
   Romanized: Ye Ram nai banaya hai.  
   **Answer:** This is made by Ram.

47. **क्या तुम खेलना जानते हो ?**
   Romanized: Kya tum khelna jaante ho?  
   **Answer:** Do you know how to play?

48. **खिड़कियाँ लकड़ी की बनी हैं।**
   Romanized: Khidkiyan lakdi kee bani hain.  
   **Answer:** Windows are made of wood,

49. **मैं इसी काम के लिए बना हूँ।**
   Romanized: Main isi kaam ke liye bana hun.  
   **Answer:** I am meant only for this.

50. **ये दरवाजा लोहे का है।**
   Romanized: Yah darwaza lohe ka hai.  
   **Answer:** This door is made of Iron.

51. **तुम्हारी बातों से लगता है कि तुम ज़्यादा सोचते हो।**
   Romanized: Tumhari baton se lagta hai ki tum zyada sochte ho.  
   **Answer:** Your talks suggest, you think a lot.

52. **ये मोबाईल सैमसंग का है।**
   Romanized: Ye mobile Samsung ka hai.  
   **Answer:** This mobile is made by Samsung. / It’s a Samsung mobile.

53. **मैं खुद को नहीं रोक सकता ।**
   Romanized: Main khud ko nahi rok sakta.  
   **Answer:** I can’t hold myself.

54. **मैं काबिल इन्सान हूँ।**
   Romanized: Main kabil insaan hun.  
   **Answer:** I am an able man.

55. **सीता वही लड़की तो है जो उस दिन आयी थी।**
   Romanized: Seeta vahi ladki to hai jo us din aayi thi.  
   **Answer:** Seeta is the very/same girl who had come the other day.

56. **हम एकाद दिन में आ सकते हैं ।**
   Romanized: Hum ekaad din mai aa sakte hain.  
   **Answer:** We can come in a day or so.

57. **राम वो लड़का है जिसने तुम्हारी मदद की थी।**
   Romanized: Ram vo ladka hai jisne tumhaari madad kee thi.  
   **Answer:** Ram is the boy who had helped you.

58. **हमें सर्दी लग गयी थी।**
   Romanized: Hume sardi lag gayi thi.  
   **Answer:** We had got cold.

59. **मैं सिर्फ तुम्हारे लिए ही बना हूँ।**
   Romanized: Main sirf tumhaare liye hi bana hun.  
   **Answer:** I am meant only for you.

60. **मैं पंजाबी लिखना जानता हूँ।**
   Romanized: Main Punjabi likhna jaanta hun.  
   **Answer:** I know how to write Punjabi.

## Source notes

All 60 Hindi prompts, printed Romanized lines, and numbered English answers were checked against the scans on PDF pages 451–454. The printed Romanized forms “kai” (items 2, 12, 13, 49), “or” (item 3), and “dantaa” (item 26) were corrected to “ke,” “aur,” and “daanta,” respectively, to match the Hindi and intended transliteration. The printed answer to item 20 reads “You voice”; the obvious typo was corrected to “Your voice.” Other unusual English wording in the printed answer key is preserved. No unreadable text was found.
