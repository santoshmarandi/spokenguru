# Lesson 34 — Synonyms

**PDF pages:** 439–450 (printed pages 438–449)

Write the Synonyms of the following words:

## Answers

1. **Abhor** (Hindi: घृणा करना)  
   **Answer:** Abominate, hate

2. **Absurd** (Hindi: बेतुका)  
   **Answer:** Bizarre, fanciful

3. **Acclaim** (Hindi: जय-जयकार करना)  
   **Answer:** Applaud, Cheer

4. **Abase** (Hindi: अपमानित करना)  
   **Answer:** Degrade, Demean

5. **Abet** (Hindi: उकसाना)  
   **Answer:** Promote, Assist

6. **Assiduous** (Hindi: परिश्रमी)  
   **Answer:** Diligent, Laborious

7. **Abstruse** (Hindi: अव्यक्त)  
   **Answer:** Hidden, Recondite

8. **Acme** (Hindi: परिपूर्णता)  
   **Answer:** Apex, Peak

9. **Accommodate** (Hindi: समायोजित)  
   **Answer:** Entertain, Harmonies

10. **Abridge** (Hindi: संक्षिप्तीकरण, काट-छाँट)  
   **Answer:** Compress, Truncate

11. **Abundant** (Hindi: प्रचुर)  
   **Answer:** Ample, Bountiful,

12. **Abstain** (Hindi: बचना)  
   **Answer:** Avoid, Shun

13. **Alms** (Hindi: भिक्षा)  
   **Answer:** Gratuity, Money

14. **Admiration** (Hindi: प्रशंसा)  
   **Answer:** Praise, Approval

15. **Ameliorate** (Hindi: सुधारना)  
   **Answer:** Improve, Amend

16. **Adherent** (Hindi: समर्थक)  
   **Answer:** Follower, Supporter,

17. **Astonish** (Hindi: चकित)  
   **Answer:** Amaze, Surprise,

18. **Antithesis** (Hindi: विलोम)  
   **Answer:** Reverse, obverse

19. **Adversity** (Hindi: विपत्ति)  
   **Answer:** Calamity, Misfortune,

20. **Apprehend** (Hindi: पकड़ना)  
   **Answer:** Seize, Arrest

21. **Appraise** (Hindi: आंकना)  
   **Answer:** Evaluate, Estimate,

22. **Affliction** (Hindi: यातना)  
   **Answer:** Distress, Ordeal

23. **Assistance** (Hindi: सहायता)  
   **Answer:** Help, Collaboration

24. **Ally** (Hindi: मित्र)  
   **Answer:** Colleague, Accomplice,

25. **Aphorism** (Hindi: कहावत)  
   **Answer:** Adage, Axiom

26. **Audacious** (Hindi: साहसी)  
   **Answer:** Bold, Daring

27. **Bad** (Hindi: खराब)  
   **Answer:** Evil, icked

28. **Brittle** (Hindi: नाजुक)  
   **Answer:** Frail, Feeble

29. **Brave** (Hindi: बहादुर)  
   **Answer:** Bold, Dauntless

30. **Browbeat** (Hindi: धमकाना)  
   **Answer:** Frighten, Threaten

31. **Bigoted** (Hindi: कट्टर)  
   **Answer:** Prejudiced, Biased

32. **Bizarre** (Hindi: विचित्र)  
   **Answer:** Fantastic, Unusual

33. **Bait** (Hindi: चारा)  
   **Answer:** Decoy, Trap

34. **Banish** (Hindi: निर्वासित, देश-निकाला देना)  
   **Answer:** Ostracise, Exile

35. **Beg** (Hindi: निवेदन करना)  
   **Answer:** Solicit, Implore

36. **Blame** (Hindi: दोष)  
   **Answer:** Reproach, Censure

37. **Blessing** (Hindi: आशीर्वाद)  
   **Answer:** Benediction, protection

38. **Bedlam** (Hindi: हंगामा)  
   **Answer:** Chaos, Confusion

39. **Backlash** (Hindi: प्रतिक्रिया)  
   **Answer:** Repercussion, Reaction

40. **Behaviour** (Hindi: व्यवहार)  
   **Answer:** Conduct, Manner

41. **Care** (Hindi: ध्यान)  
   **Answer:** Look after, Solicitude

42. **Conceit** (Hindi: गुमान)  
   **Answer:** Arrogance, Pride

43. **Cajole** (Hindi: बहलाना)  
   **Answer:** Flatter, Persuade

44. **Condone** (Hindi: माफ करना)  
   **Answer:** Pardon, Excuse

45. **Cross** (Hindi: पार करना)  
   **Answer:** Short, Annoyed

46. **Cruelty** (Hindi: क्रूरता)  
   **Answer:** Ferocity, Brutality

47. **Constant** (Hindi: लगातार)  
   **Answer:** Continuous, Eternal

48. **Conversant** (Hindi: परिचित)  
   **Answer:** Acquainted, Well versed

49. **Concise** (Hindi: संक्षिप्त)  
   **Answer:** Brief, Compact

50. **Crafty** (Hindi: चालाक)  
   **Answer:** Artful, Cunning

51. **Condign** (Hindi: लायक़)  
   **Answer:** Suitable, Deserved

52. **Choleric** (Hindi: चिड़चिड़ा)  
   **Answer:** Petulant, Bad-tempered

53. **Charlatan** (Hindi: मायावी)  
   **Answer:** Mountebank, Impostor

54. **Calm** (Hindi: शांत)  
   **Answer:** Composed, Peaceful

55. **Confess** (Hindi: कबूल)  
   **Answer:** Admit, Acknowledge

56. **Cursory** (Hindi: सतही,चलता हुआ)  
   **Answer:** Offhand, Hasty

57. **Cynical** (Hindi: निंदक)  
   **Answer:** Pessimistic, Sardonic

58. **Discourse** (Hindi: प्रवचन)  
   **Answer:** Exhortation, Dissertation

59. **Dissipate** (Hindi: नष्ट करना)  
   **Answer:** Scatter, disappear

60. **Divine** (Hindi: दिव्य)  
   **Answer:** Godlike, Heaven

61. **Damage** (Hindi: क्षति)  
   **Answer:** Harm, Loss

62. **Dangerous** (Hindi: खतरनाक)  
   **Answer:** Precarious, Perilous

63. **Diffident** (Hindi: संकोची)  
   **Answer:** Bashful, shrink

64. **Didactic** (Hindi: शिक्षाप्रद)  
   **Answer:** Preachy, Instructive

65. **Definitive** (Hindi: अंतिम)  
   **Answer:** Decisive, Final

66. **Decay** (Hindi: नाश)  
   **Answer:** Decline, Corrode

67. **Desultory** (Hindi: असंबद्ध)  
   **Answer:** Rambling, Aimless,

68. **Denounce** (Hindi: आरोप लगा देना)  
   **Answer:** Accuse, Blame

69. **Destitute** (Hindi: निराश्रित)  
   **Answer:** Orphan, Forsaken

70. **Effete** (Hindi: अशक्त)  
   **Answer:** Old, Exhausted

71. **Entice** (Hindi: बहकाना)  
   **Answer:** Allure, Persuade

72. **Exculpate** (Hindi: सफ़ाई देना)  
   **Answer:** Acquit, Absolve

73. **Exigency** (Hindi: ज़रूरत)  
   **Answer:** Distress, Emergency

74. **Exquisite** (Hindi: अति सुंदर)  
   **Answer:** Exclusive, Elegant

75. **Emulate** (Hindi: अनुकरण, अनुसरण करना)  
   **Answer:** Copy, Imitate

76. **Extravagant** (Hindi: फ़िजूल ख़र्च)  
   **Answer:** Wasteful, immoderate

77. **Exterminate** (Hindi: विनाश)  
   **Answer:** Eliminate, Eradicate

78. **Extricate** (Hindi: हल करना,सुलझाना)  
   **Answer:** Detach, Disentangle

79. **Emancipate** (Hindi: स्वतंत्र करना)  
   **Answer:** Liberate, Free

80. **Exacerbate** (Hindi: ख़राब करना)  
   **Answer:** Intensify, Aggravate

81. **Fate** (Hindi: नसीब)  
   **Answer:** Destiny, providence

82. **Fight** (Hindi: लड़ाई)  
   **Answer:** Battle, Combat

83. **Fatuous** (Hindi: बुद्धिहीन)  
   **Answer:** Silly, stupid

84. **Forbid** (Hindi: रोकना, मना करना)  
   **Answer:** Preclude, Prohibit

85. **Furbish** (Hindi: चमक लाना)  
   **Answer:** Renovate, Polish

86. **Fictitious** (Hindi: काल्पनिक)  
   **Answer:** False, Fabricated

87. **Fatal** (Hindi: घातक)  
   **Answer:** Mortal, Deadly

88. **Fortitude** (Hindi: धैर्य)  
   **Answer:** Valour, Determination

89. **Flippant** (Hindi: क्षुद्र)  
   **Answer:** Impudent, Frivolous

90. **Ferocious** (Hindi: क्रूर)  
   **Answer:** Uncivilized, Savage

91. **Flamboyant** (Hindi: चमकीला)  
   **Answer:** Ornate, Ostentatious

92. **Fortuitous** (Hindi: आकस्मिक)  
   **Answer:** Fortunate, Accidental

93. **Fecund** (Hindi: उपजाऊ)  
   **Answer:** Fruitful, Fertile

94. **Fury** (Hindi: रोष)  
   **Answer:** Wrath, Rage

95. **Forerunner** (Hindi: पूर्वज)  
   **Answer:** Precursor, Herald

96. **Fallible** (Hindi: अविश्वसनीय)  
   **Answer:** Imperfect, Faulty

97. **Gratification** (Hindi: संतुष्टि)  
   **Answer:** Enjoyment, fulfillment

98. **Guile** (Hindi: छल)  
   **Answer:** Cunning, Fraud

99. **Garrulous** (Hindi: बातूनी)  
   **Answer:** Chatty, Talkative

100. **Hamper** (Hindi: बाधा)  
   **Answer:** Prevent, Block

101. **Humane** (Hindi: दयालु)  
   **Answer:** Compassionate, Generous

102. **Humility** (Hindi: विनम्रता)  
   **Answer:** Modesty, Humbleness

103. **Haughty** (Hindi: घमंडी)  
   **Answer:** Egoist, Arrogant

104. **Inanimate** (Hindi: अचेतन,निर्जीव)  
   **Answer:** Dormant, Extinct

105. **Insidious** (Hindi: कपटी)  
   **Answer:** Deceitful, Dangerous

106. **Impertinent** (Hindi: अभेद्य)  
   **Answer:** Impudent, Arrogant

107. **Intimate** (Hindi: निजी, करीबी)  
   **Answer:** Close, Confidential

108. **Inexorable** (Hindi: निष्ठुर)  
   **Answer:** Inescapable, Merciless

109. **Impotent** (Hindi: शक्तिहीन)  
   **Answer:** Inadequate, Incapable

110. **Immaterial** (Hindi: महत्वहीन)  
   **Answer:** Useless, Irrelevant

111. **Ingenuous** (Hindi: सरल)  
   **Answer:** Innocent, Sincere

112. **Indignant** (Hindi: क्रोधित)  
   **Answer:** Angry, Furious

113. **Joy** (Hindi: हर्ष)  
   **Answer:** Pleasure, Delight

114. **Jolly** (Hindi: विनोदी, विनोदशील)  
   **Answer:** Merry, Jovial

115. **Jubilant** (Hindi: उल्लासित, आनंद करनेवाला)  
   **Answer:** Elated, Triumphant

116. **Knave** (Hindi: धूर्त, दुष्ट)  
   **Answer:** Fraud, Rogue

117. **Loyal** (Hindi: निष्ठावान)  
   **Answer:** Honest, Trustworthy

118. **Lethargy** (Hindi: सुस्ती)  
   **Answer:** Laziness, Idleness

119. **Liberal** (Hindi: उदार)  
   **Answer:** Generous, Kind

120. **Lament** (Hindi: विलाप)  
   **Answer:** Mourn, Sorrow,

121. **Lively** (Hindi: जीवंत)  
   **Answer:** Agile, Brisk

122. **Likeness** (Hindi: समानता)  
   **Answer:** Similarity, Resemblance

123. **Mighty** (Hindi: शक्तिमान)  
   **Answer:** Strong, Powerful

124. **Magnificent** (Hindi: शानदार)  
   **Answer:** Glorious, Grand

125. **Meagre** (Hindi: अल्प, तुच्छ)  
   **Answer (source key #126):** Scanty, Small

126. **Malice** (Hindi: द्वेष, गुस्सा)  
   **Answer (source key #125):** Bitterness, Spite

127. **Melancholy** (Hindi: उदासी)  
   **Answer:** Dejection, Gloom

128. **Morbid** (Hindi: रोगी)  
   **Answer:** Horrid, Gruesome

129. **Misery** (Hindi: कष्ट)  
   **Answer:** Sorrow, Distress

130. **Notable** (Hindi: प्रसिद्ध)  
   **Answer:** Remarkable, Memorable

131. **Notorious** (Hindi: कुख्यात)  
   **Answer:** Flagrant, Dishonorable

132. **Obtrude** (Hindi: निकालना)  
   **Answer:** Impose, Interfere

133. **Obscene** (Hindi: गंदा)  
   **Answer:** Bawdy, Awful

134. **Obliterate** (Hindi: काटना)  
   **Answer:** Demolish, Destroy

135. **Prerogative** (Hindi: परमाधिकार)  
   **Answer:** Right, Privilege

136. **Poignant** (Hindi: मार्मिक)  
   **Answer:** Heart-rending, Touching

137. **Prodigal** (Hindi: खर्चीला)  
   **Answer:** Spendthrift, Extravagant

138. **Pensive** (Hindi: चिंताग्रस्त, उदासीन)  
   **Answer:** Reflective, Thoughtful

139. **Prate** (Hindi: खोल देना)  
   **Answer:** Babble, Chatter

140. **Pious** (Hindi: पवित्र)  
   **Answer:** Holy, Religious

141. **Pathetic** (Hindi: दयनीय)  
   **Answer:** Moving, Touching

142. **Picturesque** (Hindi: सुरम्य, अनोखा)  
   **Answer:** Scenic, Charming

143. **Possess** (Hindi: अधिकारी)  
   **Answer:** Acquire, Seize

144. **Philanthropist** (Hindi: जनहितैषी, परोपकारक)  
   **Answer:** Kind, Charitable

145. **Portray** (Hindi: चित्रित)  
   **Answer:** Sketch, Draw

146. **Pillage** (Hindi: डकैती, लूट का माल)  
   **Answer:** Steal, Rob

147. **Precocious** (Hindi: असामयिक)  
   **Answer:** Bright, Intelligent

148. **Patronise** (Hindi: सहायता देना)  
   **Answer:** Condescend, Snub

149. **Prohibit** (Hindi: निषेध)  
   **Answer:** Prevent, Forbid

150. **Quick** (Hindi: शीघ्र)  
   **Answer:** Swift, Fast

151. **Quaint** (Hindi: विचित्र)  
   **Answer:** Queer, Singular

152. **Quip** (Hindi: ताना)  
   **Answer:** Repartee, Retort

153. **Quarantined** (Hindi: पृथक करना)  
   **Answer:** Restrained, Isolated

154. **Quest** (Hindi: खोज)  
   **Answer:** Crusade, Pursuit

155. **Reiterate** (Hindi: बार बार दोहराना)  
   **Answer:** Iterate, Repeat

156. **Refined** (Hindi: परिशोधित, परिष्कृत)  
   **Answer:** Sophisticated, Elegant

157. **Radiant** (Hindi: दीप्तिमान,उज्ज्वल)  
   **Answer:** Glittering, Bright

158. **Rebellion** (Hindi: विद्रोह)  
   **Answer:** Fight, Mutiny

159. **Rigid** (Hindi: कठोर)  
   **Answer:** Strict, Stiff

160. **Rash** (Hindi: जल्दबाज)  
   **Answer:** Impulsive, Impetuous

161. **Renowned** (Hindi: प्रसिद्ध)  
   **Answer:** Famed, Reputed

162. **Rash** (Hindi: जल्दबाज)  
   **Answer:** Impulsive, Foolhardy

163. **Rural** (Hindi: ग्रामीण)  
   **Answer:** Simple, Rustic

164. **Ridiculous** (Hindi: हास्यास्पद, भद्दा)  
   **Answer:** Ludicrous, Ridiculous

165. **Rejoice** (Hindi: खुश हो जाओ)  
   **Answer:** Celebrate, Delight

166. **Remorse** (Hindi: पश्चाताप, पछतावा)  
   **Answer:** Grief, Regret

167. **Resistance** (Hindi: प्रतिरोध)  
   **Answer:** Opposition, Hindrance

168. **Radical** (Hindi: उग्र)  
   **Answer:** Rebellious, Thorough

169. **Refute** (Hindi: खंडन)  
   **Answer:** Disprove, Deny

170. **Ruin** (Hindi: बर्बाद)  
   **Answer:** Devastation, Destruction

171. **Substantiate** (Hindi: सिद्ध करना)  
   **Answer:** Authenticate, Verify

172. **Scrutinise** (Hindi: ताकना)  
   **Answer:** Examine, Inspect

173. **Statute** (Hindi: क़ानून)  
   **Answer:** Ordinance, Law

174. **Sordid** (Hindi: घिनौना)  
   **Answer:** Nasty, Dirty

175. **Spurious** (Hindi: जाली)  
   **Answer:** Artificial, Fake

176. **Sacred** (Hindi: धार्मिक)  
   **Answer:** Satisfy, Indulge

177. **Stipulation** (Hindi: शर्त)  
   **Answer:** Clause, Condition

178. **Shrewd** (Hindi: चालाक)  
   **Answer:** Calculative, Astute

179. **Static** (Hindi: स्थिर)  
   **Answer:** Stable, Still

180. **Spry** (Hindi: फुर्तीला)  
   **Answer:** Agile, Brisk

181. **Succinct** (Hindi: संक्षिप्त)  
   **Answer:** Concise, Abbreviated

182. **Solitary** (Hindi: अकेला)  
   **Answer:** Isolated, Lonely

183. **Subterfuge** (Hindi: छल)  
   **Answer:** Deception, Sham

184. **Scanty** (Hindi: अल्प)  
   **Answer:** Slender, Limited

185. **Sane** (Hindi: समझदार)  
   **Answer:** Sensible, Balanced

186. **Specimen** (Hindi: नमूना)  
   **Answer:** Dummy, Sample

187. **Sensual** (Hindi: कामुक)  
   **Answer:** Carnal, Fleshy

188. **Servile** (Hindi: चापलूस)  
   **Answer:** Docile, Slavish

189. **Sacred** (Hindi: धार्मिक)  
   **Answer:** Consecrated, Holy

190. **Scold** (Hindi: डांटना)  
   **Answer:** Blame, Criticise

191. **Superficial** (Hindi: सतही)  
   **Answer:** Outward, Shallow

192. **Sterile** (Hindi: बाँझ)  
   **Answer:** Unproductive, Barren

193. **Tyro** (Hindi: नौसिखिए)  
   **Answer:** Amateur, Neophyte

194. **Temperate** (Hindi: शीतोष्ण)  
   **Answer:** Moderate, Mild

195. **Tentative** (Hindi: दुविधा में पड़ा हुआ)  
   **Answer:** Hesitant, Provisional

196. **Tenet** (Hindi: सिद्धांत)  
   **Answer:** Dogma, Belief

197. **Tyrant** (Hindi: तानाशाह)  
   **Answer:** Oppressor, Autocrat

198. **Temporal** (Hindi: लौकिक, सामयिक)  
   **Answer:** Earthly, Worldly

199. **Thrive** (Hindi: फलना-फूलना, कामयाब होना)  
   **Answer:** Flourish, Grow

200. **Therapeutic** (Hindi: चिकित्सीय)  
   **Answer:** Restorative, Remedial

201. **Utopian** (Hindi: काल्पनिक)  
   **Answer:** Visionary, Perfect

202. **Urchin** (Hindi: नटखट लड़का)  
   **Answer:** Foundling, Orphan

203. **Unique** (Hindi: अद्वितीय, अनोखा)  
   **Answer:** Different, Exclusive,

204. **Urbane** (Hindi: शिष्ट)  
   **Answer:** Suave, Polished

205. **Ulterior** (Hindi: गुप्त)  
   **Answer:** Remote, Secondary

206. **Urge** (Hindi: अनुरोध, बताना)  
   **Answer:** Impulse, Drive

207. **Vilify** (Hindi: गाली देना)  
   **Answer:** Defame, Malign

208. **Vehemence** (Hindi: उत्साह, जोश)  
   **Answer:** Force, Fervour

209. **Vigilance** (Hindi: जागरूकता)  
   **Answer:** Attentiveness, Alertness

210. **Vivacious** (Hindi: गरमागरम)  
   **Answer:** Bubbling, Animated

211. **Vindictive** (Hindi: प्रतिशोधी)  
   **Answer:** Spiteful, Resentful

212. **Winsome** (Hindi: आनंदमय)  
   **Answer:** Lovely, Delightful

213. **Veracity** (Hindi: सच्चाई)  
   **Answer:** Comely, Appealing

214. **Weary** (Hindi: थका, हारा)  
   **Answer:** Tired, Exhausted

215. **Waive** (Hindi: माफ़, छोड़ देना)  
   **Answer:** Relinquish, Renounce,

216. **Wistful** (Hindi: उदास)  
   **Answer:** Plaintive, Longing

217. **Wile** (Hindi: छलबल, कपट)  
   **Answer:** Ruse, Artifice

218. **Yield** (Hindi: प्राप्ति)  
   **Answer:** Harvest, Submit

219. **Zenith** (Hindi: शीर्षबिंदु)  
   **Answer:** Summit, Peak

220. **Zeal** (Hindi: उत्साह)  
   **Answer:** Passion, Fervour

## Source notes

The printed answer-key entries 125 and 126 are evidently transposed. To pair the words correctly, prompt 125 (Meagre) is paired with source answer 126 (“Scanty, Small”), and prompt 126 (Malice) with source answer 125 (“Bitterness, Spite”); the original answer-key numbers are shown inline.

Prompt 176 is printed as “Sacred,” but its numbered source answer is “Satisfy, Indulge”; this apparent source mismatch is retained because no alternative answer is provided. Prompt 213 (“Veracity”) is likewise paired with the printed answer 213 (“Comely, Appealing”) and flagged rather than replaced with an inferred answer.

Answer 27 is visibly printed as “Evil, icked” in the scan and is retained exactly as printed. No unreadable text was found.
