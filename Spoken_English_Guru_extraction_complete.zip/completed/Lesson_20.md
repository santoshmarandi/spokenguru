# Lesson 20 — Conjunctions

**PDF pages:** 280–293 (printed pages 279–292)

## Please translate the following sentences into English

1. **Hindi prompt:** उसके आते ही सब हँसने लगे।  
   **Romanized:** Uske aate hi sab hasne lage.  
   **English answer:** As soon as he came, all started laughing. / As soon as he came, all began to laugh. / The moment he came, all started laughing. / The moment he came, all began to laugh.

2. **Hindi prompt:** चाहे वो बैठे या न बैठे, मैं तो बैठूंगा।  
   **Romanized:** Chahe wo baithe ya na baithe, main to baithunga.  
   **English answer:** Whether he sits or not, I will.

3. **Hindi prompt:** चाहे वो आये या न आये, मैं तो दिल्ली निकल जाऊँगा।  
   **Romanized:** Chahe woh aaye ya na aaye, main to Delhi nikal jaunga.  
   **English answer:** Whether he comes or not, I will leave for Delhi.

4. **Hindi prompt:** न वो आया, न मैं गया।  
   **Romanized:** Na vo aaya, na main gaya.  
   **English answer:** Neither he came, nor I went.

5. **Hindi prompt:** न मैंने देखा, न किसी और को देखने दिया।  
   **Romanized:** Na mene dekha, na kisi or ko dekhne diya.  
   **English answer:** Neither I saw, nor let anyone else see.

6. **Hindi prompt:** क्या वो जानता था कि मैं कौन हूँ?  
   **Romanized:** Kya wo janta tha ki main kaun hoon?  
   **English answer:** Did he know who I was?

7. **Hindi prompt:** क्या वो जानता है कि मैं कौन हूँ?  
   **Romanized:** Kya wo janta hai ki main kaun hoon?  
   **English answer:** Does he know who I am?

8. **Hindi prompt:** मैं तुम्हें यही तो बता रहा हूँ।  
   **Romanized:** Main tumhe yahee to bata raha hoon.  
   **English answer:** That’s what I am telling you.

9. **Hindi prompt:** मैं यही तो कर रहा हूँ।  
   **Romanized:** Main yahee to kar raha hoon.  
   **English answer:** That’s what I am doing.

10. **Hindi prompt:** मैं तुम्हें यही तो समझा रहा हूँ।  
   **Romanized:** Main tumhe yahee to samjha raha hoon.  
   **English answer:** That’s what I am making you understand.

11. **Hindi prompt:** मैं वहीं तो जा रहा हूँ।  
   **Romanized:** Main vaheen to ja raha hoon.  
   **English answer:** That’s where I am going.

12. **Hindi prompt:** मैं वहीं तो खेल रहा हूँ।  
   **Romanized:** Main vaheen to khel raha hoon.  
   **English answer:** That’s where I am playing.

13. **Hindi prompt:** वो अंग्रेज़ी ही नहीं पंजाबी भी जानता है।  
   **Romanized:** Wo angrezi hi nahi Punjabi bhi janta hai.  
   **English answer:** He not only knows English but also Punjabi.

14. **Hindi prompt:** वो मेरा भाई ही नहीं आपका बॉस भी है।  
   **Romanized:** Vo mera bhai hi nahi aapka boss bhi hai.  
   **English answer:** He is not only my brother but also your boss.

15. **Hindi prompt:** वो मेरा ही नहीं तेरा भी दोस्त है।  
   **Romanized:** Vo mera hi nahi tera bhi dost hai.  
   **English answer:** He is not only my friend but also yours.

16. **Hindi prompt:** भले ही ट्रेन 2 घंटे लेट आये, हमें आज जाना है।  
   **Romanized:** Bhale hi train 2 ghante late aaye, hame aaj jana hai.  
   **English answer:** Even if the train comes late by 2 hrs, we have to go today.

17. **Hindi prompt:** भले ही वो कोई भी हो, मैं अपने सिद्धान्तों से समझौता नहीं करता।  
   **Romanized:** Bhale hi vo koi bhi ho, main apne siddhanton se samjhauta nahi karta.  
   **English answer:** Even if he is anyone, I don’t compromise with my principles.

18. **Hindi prompt:** उसने एक शब्द तक नहीं बोला।  
   **Romanized:** Usne ek shabd tak nahi bola.  
   **English answer:** He didn’t speak even a word.

19. **Hindi prompt:** मैंने तुम्हारा नाम सुना तक नहीं था।  
   **Romanized:** Maine tumhara naam suna tak nahi tha.  
   **English answer:** I had not even heard your name.

20. **Hindi prompt:** मैंने अभी तक कुछ नहीं खाया है।  
   **Romanized:** Maine abhi tak kuch nahi khaya hai.  
   **English answer:** I have not eaten (had) anything yet. / I have not eaten (had) anything as yet. / I have not eaten (had) anything till now. / I have not eaten (had) anything by now. / I have not eaten (had) anything so far.

21. **Hindi prompt:** फिर भी मैंने उसका नाम लिया।  
   **Romanized:** Fir bhi mene uska naam liya.  
   **English answer:** Then also, I took his name. / Even then, I took his name.

22. **Hindi prompt:** फिर भी मैं जाऊँगा ही।  
   **Romanized:** Fir bhi main jaunga hi.  
   **English answer:** Then also, I will definitely go. / Even then, I will definitely go.

23. **Hindi prompt:** ये पेन नहीं बल्कि पेंसिल है।  
   **Romanized:** Ye pen nahi balki pencil hai.  
   **English answer:** This is not a pen, but a pencil.

24. **Hindi prompt:** तुम मेरे जितने चालाक नहीं हो।  
   **Romanized:** Tum mere jitne chalak nahi ho.  
   **English answer:** You are not as clever as I am.

25. **Hindi prompt:** क्या तुम मेरे जितना अच्छा गा सकते हो?  
   **Romanized:** Kya tum mere jitna achchha ga sakte ho?  
   **English answer:** Can you sing as well as I can?

26. **Hindi prompt:** मेरे घर आ जाना जैसे ही पापा आ जायें।  
   **Romanized:** Mere ghar aa jaana jaise hee papa aa jayege.  
   **English answer:** Come to my home as soon as papa comes./ Come to my home the moment papa comes.

27. **Hindi prompt:** जहाँ तक मुझे पता है, उसकी शादी हो चुकी है।  
   **Romanized:** Jahaan tak mujhe pata hai, uski shaadi ho chuki hai.  
   **English answer:** As far as I know, he has got married.

28. **Hindi prompt:** जहाँ तक मैं जानता हूँ, उसके दो बच्चे हैं।  
   **Romanized:** Jahaan tak main janta hoon, uske do bachche hain.  
   **English answer:** As far as I know, he has got two children.

29. **Hindi prompt:** हालाँकि मैं बीमार था, तब भी मैंने काम किया।  
   **Romanized:** Halaanki main bimaar tha, tab bhi mene kaam kiya.  
   **English answer:** Although I was unwell, yet I worked.

30. **Hindi prompt:** उसे भी फल पसन्द नहीं थे।  
   **Romanized:** Use bhi phal pasand nahi the.  
   **English answer:** He didn’t like the fruits either. / Even, he didn’t like the fruits.

31. **Hindi prompt:** उसे अभी भी बुखार है।  
   **Romanized:** Use abhi bhi bukhar hai.  
   **English answer:** He is still suffering from a fever. / He has still got fever.

32. **Hindi prompt:** वो अपने दोस्तों के साथ खेलते हुए टीवी देख रहा था।  
   **Romanized:** Wo apne dosto ke saath khelte hue TV dekh raha tha.  
   **English answer:** He was watching TV while playing with his friends.

33. **Hindi prompt:** या तो मैं गलत हूँ या फिर तुम।  
   **Romanized:** Ya to main galat hoon ya phir tum.  
   **English answer:** Either I am wrong or you are.

34. **Hindi prompt:** या तो मेरा गलत है या तुम्हारा?  
   **Romanized:** Ya to mera galat hai ya tumhara?  
   **English answer:** Either mine is wrong or yours is. / Either mine or yours is wrong.

35. **Hindi prompt:** तुम मेरे दोस्त नहीं हो इसलिए मैंने कॉल नहीं की।  
   **Romanized:** Tum mere dost nahi ho isliye maine call nahi ki.  
   **English answer:** You are not my friend that’s why I didn’t call you.

36. **Hindi prompt:** जब तक तुम नहीं आते, मैं कहीं नहीं जाऊँगा।  
   **Romanized:** Jab tak tum nahi aate, main kahi nahi jaunga.  
   **English answer:** Until you come, I will not go anywhere. / Till you don’t come, I will not go anywhere.

37. **Hindi prompt:** जब तक तुम यहाँ हो, मैं भी कहीं नहीं जाऊँगा।  
   **Romanized:** Jab tak tum yaha ho, main bhi kahi nahi jaunga.  
   **English answer:** As long as you are here, even I will not go anywhere.

38. **Hindi prompt:** जब तक तुम मेरी इज्जत करोगे, मैं भी करूँगा।  
   **Romanized:** Jab tak tum meri izzat karoge, main bhi karunga.  
   **English answer:** As long as you respect me, I will too.

39. **Hindi prompt:** ऐसी कहानियाँ बहुत बोरिंग होती हैं।  
   **Romanized:** Aesi kahaniya bahut boring hoti hai.  
   **English answer:** Such stories are extremely boring.

40. **Hindi prompt:** क्या वो आज भी मुझे याद करता है?  
   **Romanized:** Kya wo aaj bhi mujhe yaad karta hai?  
   **English answer:** Does he still miss me?

41. **Hindi prompt:** ऐसा ख्याल तक मुझे नहीं आता।  
   **Romanized:** Aisa khayal tak mujhe nahi aata.  
   **English answer:** I can’t even think so. / I can’t even imagine so.

42. **Hindi prompt:** जिसने तुम्हें जाने दिया वो मेरा बड़ा भाई था।  
   **Romanized:** Jisne tumhe jane diya vo mera bada bhai tha.  
   **English answer:** The one, who let you go, was my elder brother. / That who let you go, was my elder brother.

43. **Hindi prompt:** मैंने तुम्हें पूछा तक नहीं कि तुम कैसे हो।  
   **Romanized:** Maine tumhe pucha tak nahi ki tum kaise ho.  
   **English answer:** I didn’t even ask you how you were.

44. **Hindi prompt:** हम वहीं पर तो खड़े होकर पढ़ रहे थे।  
   **Romanized:** Hum wahi par to khade hokar padh rahe the.  
   **English answer:** That’s where we were standing and studying.

45. **Hindi prompt:** उसने मुझे सिखाया था कि लड़ते कैसे हैं।  
   **Romanized:** Usne mujhe sikhaya tha ki ladte kaise hai.  
   **English answer:** He had taught me how to fight.

46. **Hindi prompt:** मैं आपसे पूछ रहा हूँ कि ये करना कैसे है।  
   **Romanized:** Main aapse pooch raha hoon ki ye karna kaise hai.  
   **English answer:** I am asking you how to do it.

47. **Hindi prompt:** मैं आपसे पूछ रहा हूँ कि जाना कहाँ है।  
   **Romanized:** Main aapse pooch raha hoon ki jana kahaan hai.  
   **English answer:** I am asking you where to go.

48. **Hindi prompt:** सबको इज्जत दो, ऐसा न हो तुम्हें भी कोई इज्जत न दें।  
   **Romanized:** Sabko izzat do aisa na ho tumhe bhi koi izzat na de.  
   **English answer:** Respect all, lest nobody should respect you.

49. **Hindi prompt:** अब चलते हैं, वरना हमें देर हो जायेगी।  
   **Romanized:** Ab chalte hai warna hame der ho jayegi.  
   **English answer:** Let’s go now, or else we’ll be late.

50. **Hindi prompt:** राज नहीं जानता कि वो दिल्ली जायेगा या नहीं।  
   **Romanized:** Raj nahi janta ki vo delhi jayega ya nahi.  
   **English answer:** Raj doesn’t know whether he will go to Delhi or not.

51. **Hindi prompt:** वो मुझसे बात करने लगा मानो मुझे पहले से जानता हो।  
   **Romanized:** Wo mujhse baat karne laga maano mujhe pahle se janta ho.  
   **English answer:** He started talking to me as if he knew me beforehand. / He started talking to me as though he knew me beforehand.

52. **Hindi prompt:** जब तक बच्चे नहीं पूछेंगे, उन्हें कैसे पता चलेगा?  
   **Romanized:** Jab tak bacche nahi poochenge, unhe kaise pata chalega?  
   **English answer:** Unless the children ask, how would they get to know?

53. **Hindi prompt:** वो तुम्हें आने देगा बशर्ते तुम उसे कुछ पैसे दो।  
   **Romanized:** Wo tumhe aane dega basharte tum use kuch paise do.  
   **English answer:** He will let you come provided you give him some money.

54. **Hindi prompt:** जिसे मैंने पिया वो पानी नहीं कुछ और था।  
   **Romanized:** Jise maine piya wo paani nahi kuch aur tha.  
   **English answer:** That (What) I drank wasn’t water but something else.

55. **Hindi prompt:** उसने भी नहीं चाहा।  
   **Romanized:** Usne bhi nahi chaha.  
   **English answer:** Even he didn’t want to. / He didn’t want either.

56. **Hindi prompt:** हालाँकि मुझे खेलने नहीं दिया जा रहा, फिर भी मैं शांत हूँ।  
   **Romanized:** Halanki mujhe khelne nahi diya ja raha, phir bhi main shaant hoon.  
   **English answer:** Though I am not being let play, still I am quiet.

57. **Hindi prompt:** मैं उसे भिजवा सकता हूँ, पर तब जब तुम घर आ जाओ।  
   **Romanized:** Main use bhijwa sakta hoon, par tab jab tum ghar aa jao.  
   **English answer:** I can make him go, provided you come home.

58. **Hindi prompt:** मैंने न कभी किया न करने की सोच सकता हूँ।  
   **Romanized:** Maine na kabhi kiya na karne ki soch sakta hoon.  
   **English answer:** Neither I did nor can I ever think to do.

59. **Hindi prompt:** हमें पढ़ने तक नहीं दिया गया था।  
   **Romanized:** Hame padhne tak nahi diya gaya tha.  
   **English answer:** We were not even let study.

60. **Hindi prompt:** जिसे तुम याद कर रहे हो, उसे तुम कभी याद नहीं आते।  
   **Romanized:** Jise tum yaad kar rahe ho, use tum kabhi yaad nahi aate.  
   **English answer:** The one you are missing never misses you.

61. **Hindi prompt:** वो भी हमें देखता रहा।  
   **Romanized:** Wo bhi hame dekhta raha.  
   **English answer:** Even he kept looking at us. / He also kept looking at us.

62. **Hindi prompt:** या तो अपनी हार पर रोना होगा हमें, या फिर लड़ते हुए जान देनी होगी।  
   **Romanized:** Ya to apni haar par rona hoga hame,ya phir ladte hue jaan deni hogi.  
   **English answer:** Either we will have to cry over our defeat or sacrifice our lives fighting.

63. **Hindi prompt:** वो पढ़ने के लिए नहीं आया ताकि उसे डांट न पड़े।  
   **Romanized:** Wo padhne ke lie nahi aaya taaki use daant na pade.  
   **English answer:** He didn’t come to study so that he couldn’t get scolded.

64. **Hindi prompt:** मैं कह नहीं सकता कि वो कब तक आयेगा।  
   **Romanized:** Main kah nahi sakta ki vo kab tak aayega.  
   **English answer:** I can’t say when he would come by.

65. **Hindi prompt:** न उसने देखा होगा न किसी और ने।  
   **Romanized:** Na usne dekha hoga na kisi aur ne.  
   **English answer:** Neither he would have seen nor anybody else.

66. **Hindi prompt:** मैं कह नहीं सकता कि वो आयेगा।  
   **Romanized:** Main keh nahi sakta ki vo aayega.  
   **English answer:** I can’t say if he will come.

67. **Hindi prompt:** जहाँ तक मेरी ज़िन्दगी का सवाल है, मैंने इसे मानव कल्याण पर लगा दिया है।  
   **Romanized:** Jaha tak meri zindagi ka sawal hai, maine ise manav kalyaan par laga diya hai.  
   **English answer:** As far as my life is concerned, I have devoted it to human welfare.

68. **Hindi prompt:** न वो समझा जो मुझे कहना था न ही उसने सुनने की कोशिश तक की।  
   **Romanized:** Na Wo samjha jo mujhe kehna tha na hi usne sunne ki koshish tak ki.  
   **English answer:** Neither he understood what I had to say nor he even tried to listen.

69. **Hindi prompt:** या तो वो तुम्हें जाने देगा या वो बहाने बनायेगा।  
   **Romanized:** Ya to wo tumhe jaane dega ya wo bahane banayega.  
   **English answer:** Either he will let you go or he will make excuses.

70. **Hindi prompt:** शिक्षा मेरे लिए व्यवसाय नहीं है बल्कि आप तक पहुँचने का एक प्रयास है।  
   **Romanized:** Shiksha mere liye vyavsaay nahi hai balki aap sab tak pahunchne ka ek prayas hai.  
   **English answer:** Education is not a business for me but an endeavor to reach you.

71. **Hindi prompt:** मैं भी खुश नहीं हूँ।  
   **Romanized:** Main bhi khush nahi hoon.  
   **English answer:** Even, I am not happy. / I am not happy either.

72. **Hindi prompt:** हम उतने सभ्य हैं जितना हमें होना चाहिए।  
   **Romanized:** Ham utne sabhay hai jitna hame hona chahiye.  
   **English answer:** We are as civilized as we should be.

73. **Hindi prompt:** जहाँ तक मेरा सवाल है, मुझे यकीन है मैं सबका दिल जीत लूँगा।  
   **Romanized:** Jaha tak mera sawal hai, mujhe yakeen hai main sabka dil jeet loonga.  
   **English answer:** As far as I am concerned; I am sure I will win everyone’s heart.

74. **Hindi prompt:** यह प्यार नहीं, आकर्षण है।  
   **Romanized:** Yah pyar nahi, aakarshan hai.  
   **English answer:** It’s not love but infatuation.

75. **Hindi prompt:** क्या उनमें से कोई इतना हैंडसम था जितना वो है।  
   **Romanized:** Kya unme se koi itna handsome tha jitna wo hai.  
   **English answer:** Was any of them as handsome as he is?

76. **Hindi prompt:** क्या उसके पास मेरे जितनी गाड़ियाँ थी?  
   **Romanized:** Kya uske pass mere jitni gadiya thi?  
   **English answer:** Did he have as many cars as I had?

77. **Hindi prompt:** चूँकि मैंने उसे फोन नहीं किया, इसलिए उसने अगले पूरे दिन मुझसे बात नहीं की।  
   **Romanized:** Chunki maine use phone nahi kiya, isliye usne agle poore din mujhse baat nahi ki.  
   **English answer:** Since I didn’t call him, he didn’t talk to me for the next whole day.

78. **Hindi prompt:** उसे पता नहीं था कि वो जायेगा।  
   **Romanized:** Use pata nahi tha ki wo jayega.  
   **English answer:** He had no idea if he would go.

79. **Hindi prompt:** इसी तरह मैं बड़ा हुआ।  
   **Romanized:** Isi tarah main bada hua.  
   **English answer:** That’s how I grew up.

80. **Hindi prompt:** मेरी मम्मी ऐसी नहीं है कि तुम्हारे बहानों को मान जाए।  
   **Romanized:** Meri mummy aesi nahi hai ki tumhare bahano ko maan jaye.  
   **English answer:** My mom is not such a lady who will buy your excuses.

81. **Hindi prompt:** मैंने ये किताब खोली ही थी कि मुझे याद आ गया, जब मैं बच्चा था मुझे ये किताब पसंद थी।  
   **Romanized:** Maine ye kitab kholi hi thi ki mujhe yaad aa gaya, jab main bachcha tha mujhe ye kitaab pasand thi.  
   **English answer:** No sooner had I opened this book than I remembered; when I was a kid, I loved it.

82. **Hindi prompt:** मैं अभी भी तुम्हें प्यार करता हूँ।  
   **Romanized:** Main abhi bhi tumhe pyar karta hoon.  
   **English answer:** I still love you.

83. **Hindi prompt:** उनमें से किसी के पास भी मेरे जितनी पेन्सिलें नहीं थी।  
   **Romanized:** Unme se kisi ke pass bhi mere jitni pencile nahi thi.  
   **English answer:** None of them had as many pencils as I had.

84. **Hindi prompt:** क्या तुम्हारा सुझाव मेरे जितना अच्छा है?  
   **Romanized:** Kya tumhara sujhaav mere jitna achchha hai?  
   **English answer:** Is your suggestion as good as that of mine?

85. **Hindi prompt:** मैंने वहीं तो उस अजनबी को देखा था।  
   **Romanized:** Maine vahi to us ajnabi ko dekha tha.  
   **English answer:** That’s where I had seen that stranger.

86. **Hindi prompt:** उसने मुझे फोन नहीं किया क्योंकि वो मुझसे नाराज़ है।  
   **Romanized:** Usne mujhe phone nahi kiya kyonki wo mujhse naraaz hai.  
   **English answer:** He didn’t call me because he is angry with me.

87. **Hindi prompt:** वो मेरे जितना लम्बा नहीं था।  
   **Romanized:** Wo mere jitna lamba nahi tha.  
   **English answer:** He was not as tall as I was.

88. **Hindi prompt:** उसके हालात अभी भी उसके काबू से बाहर हैं।  
   **Romanized:** Uske haalat abhi bhi uske kaboo se baahar hai.  
   **English answer:** His circumstances are still out of his control.

89. **Hindi prompt:** वो लड़की ऐसा गिफ्ट पसन्द नहीं करेगी।  
   **Romanized:** Wo ladki aisa gift pasand nahi karegi.  
   **English answer:** That girl will not like such a gift.

90. **Hindi prompt:** उनमें से कुछ मेरे भाई जितने तेज़ हैं।  
   **Romanized:** Unme se kuch mere bhai jitne tez hai.  
   **English answer:** A few of them are as intelligent as my brother is.

91. **Hindi prompt:** उसी वक्त मैंने भी ग्रेजुएशन पूरी की।  
   **Romanized:** Usi wakt maine bhi graduation Poori ki.  
   **English answer:** That’s when even I completed graduation.

92. **Hindi prompt:** जैसे ही तुम वहाँ पहुँचो, मुझे कॉल करना।  
   **Romanized:** Jaise hi tum waha pahuncho, mujhe call karna.  
   **English answer:** As soon as you reach there, call me up. / The moment you reach there, call me up.

93. **Hindi prompt:** जहाँ तक मुझे पता है वो स्वभाव का अच्छा है।  
   **Romanized:** Jaha tak mujhe pata hai vo saobhav ka achha hai.  
   **English answer:** As far as I know, he is nice by nature.

94. **Hindi prompt:** न केवल मेरी बल्कि उसकी ज़िन्दगी भी इस एक गलत फैसले के कारण बर्बाद हो गई है।  
   **Romanized:** Na kewal meri balki uski zindagi bhi is ek galat faisle ke karan barbaad ho gai hai.  
   **English answer:** Not only my life but also his has been ruined due to this one wrong decision.

95. **Hindi prompt:** मैं न उसे कॉल कर पाया न उसे आखिरी वक्त पे देख पाया।  
   **Romanized:** Main na use call kar paya na use aakhri wakt pe dekh paya.  
   **English answer:** I could neither call him nor see him at the last time.

96. **Hindi prompt:** इस साल कई हिट फिल्में हैं जैसे सन्जू, पदमावत आदि।  
   **Romanized:** Is saal kai hit flim hai jaise Sanju, Padmavat aadi.  
   **English answer:** There are so many big hits this year such as Sanju, Padmavat, etc.

97. **Hindi prompt:** मैं कह नहीं सकता, वो तुम्हें ऐसी किसी बात के लिए फोन करेगा।  
   **Romanized:** Main kah nahi sakta, wo tumhe aisi kisi baat ke liye phone karega.  
   **English answer:** I can’t say if he would call you for any such thing.

98. **Hindi prompt:** मैं उसे कॉल करने के अलावा कुछ भी कर सकता था।  
   **Romanized:** Main use call karne ke alawa kuch bhi kar sakta tha.  
   **English answer:** I could do anything but call him.

99. **Hindi prompt:** चाहे वह खाये या ना खाये, कम से कम मैं तो नहीं खाने वाला।  
   **Romanized:** Chahe wah khaye ya na khaye, kam se kam main to nahi khane vala.  
   **English answer:** Whether he eats or not, at least I am not going to eat.

100. **Hindi prompt:** जितना तुम उसे प्यार करते हो, मैं भी करता हूँ।  
   **Romanized:** Jitna tum use pyaar karte ho, main bhi karta hoon.  
   **English answer:** I love her as much as you do.

101. **Hindi prompt:** मैंने भी उसे रुलाया।  
   **Romanized:** Maine bhi use rolaya.  
   **English answer:** Even I made him weep.

102. **Hindi prompt:** यही तो मुझे हमेशा नापसंद था और नियति देखिए आज मेरे पास ये करने के सिवाय कोई चारा ही नहीं है।  
   **Romanized:** Yahi to mujhe hamesha naapasand tha aur niyati dekhie aaj mere pass ye karne ke sivaay koi chara hi nahi hai.  
   **English answer:** That’s what I always disliked and see destiny, I have no choice but to do it.

103. **Hindi prompt:** वो अभी भी बुरे दौर से गुज़र रहा है।  
   **Romanized:** Wo abhi bhi bure dor se guzar raha hai.  
   **English answer:** He is still going through a bad phase.

104. **Hindi prompt:** जो तुम कहो, मैं अंत तक करता रहूँगा।  
   **Romanized:** Jo tum kaho, main ant tak karta rahoonga.  
   **English answer:** Whatever you say, I will keep doing till the end.

105. **Hindi prompt:** जब तक वो मिलने नहीं आता मैं नहीं जाने वाला।  
   **Romanized:** Jab tak vo milne nahi aata main nahi jane vala.  
   **English answer:** Until he comes to meet, I am not gonna go. (Gonna = Going to)

106. **Hindi prompt:** हम इस तरह रोड पार करते हैं।  
   **Romanized:** Ham is tarah road paar karte hai.  
   **English answer:** That’s how we cross the road.

107. **Hindi prompt:** जैसा तुम चाहो।  
   **Romanized:** Jaisa tum chaho  
   **English answer:** As you wish.

108. **Hindi prompt:** जैसा तुम पसंद करो।  
   **Romanized:** Jaisa tum pasand karo.  
   **English answer:** As you choose.

109. **Hindi prompt:** मैं पढ़ने लगा ज्यों ही पापा आये।  
   **Romanized:** Main padhne laga jyoo hi papa aaye.  
   **English answer:** I started studying the moment Dad dropped in.

110. **Hindi prompt:** तुम मेरे कोई नहीं हो जबकि वो मेरा सब कुछ है।  
   **Romanized:** Tum mere koi nahi ho jabki vo mera sab kuch hai.  
   **English answer:** You are no one to me, whereas he is everything.

111. **Hindi prompt:** वो मेरे लिए रुका जब तक मैं नहीं आया।  
   **Romanized:** Wo mere liye ruka jab tak main nahi aaya.  
   **English answer:** He waited for me until I came. / He waited for me till I didn’t come.

112. **Hindi prompt:** जैसा आपने मुझे बताया था मैंने किया।  
   **Romanized:** Jaisa aapne mujhe bataya tha maine kiya.  
   **English answer:** I have done as instructed by you.

113. **Hindi prompt:** उसने पढ़ते हुए मुझे कॉल किया।  
   **Romanized:** Usne padhte hue mujhe call kiya.  
   **English answer:** He called me while studying.

114. **Hindi prompt:** मैंने तुम्हें कॉल की ही थी कि तुम मेरे घर पहुँच गये।  
   **Romanized:** Maine tumhe call ki hi thi ki tum mere ghar pahunch gaye.  
   **English answer:** No sooner had I called you than you reached my home.

115. **Hindi prompt:** हमने अभी तक ताजमहल नहीं देखा है।  
   **Romanized:** Hamne abhi tak TajMahal nahi dekha hai.  
   **English answer:** We have not seen the Taj yet.

116. **Hindi prompt:** तुमने अभी तक कितना पैसा इकट्ठा कर लिया है?  
   **Romanized:** Tumne abhi tak kitna paisa ikhatta kar liya hai?  
   **English answer:** How much money have you collected so far?

117. **Hindi prompt:** इस तरह का आदमी घमंडी होता है।  
   **Romanized:** Is tarah ka aadmi ghamandi hota hai.  
   **English answer:** Such a man is arrogant.

118. **Hindi prompt:** उसने इस तरह मेरा स्वागत किया कि एक पल को मुझे लगा कि मैं हीरो हूँ।  
   **Romanized:** Usne is tarah mera swaagat kiya ki ek pal ko mujhe laga ki main hero hoon.  
   **English answer:** He welcomed me in such a way that for a moment I felt as if I was a hero.

119. **Hindi prompt:** मुझे भी ऐसा व्यवहार कभी पसंद नहीं आया।  
   **Romanized:** Mujhe bhi aisa vyavhaar kabhi pasand nahi aaya.  
   **English answer:** Even I never liked such a behavior.

120. **Hindi prompt:** मैं इस साल ज़्यादा मेहनत करूँगा क्योंकि मैं दोबारा फेल नहीं होना चाहता।  
   **Romanized:** Main is saal zyada mehnat karunga kyunki main dobara fail nahi hona chahta.  
   **English answer:** I will work harder this year because I don’t want to fail again.

121. **Hindi prompt:** मुझे टीवी की ज़रूरत नहीं थी पर तुमने दिला दी.  
   **Romanized:** Mujhe TV ki zarurat nahi thi par tumne dila di.  
   **English answer:** I didn’t need a TV but you provided me.

122. **Hindi prompt:** मेरे पास कुछ नहीं है फिर भी मैं हिम्मत नहीं हारता।  
   **Romanized:** Mere pass kuch nahi hai phir bhi main himmat nahi harta.  
   **English answer:** I have nothing; still, I don’t lose hope.

123. **Hindi prompt:** कोई तो दोषी है, तुम या मैं?  
   **Romanized:** Koi to doshi hai, tum ya main?  
   **English answer:** Someone is to blame; either you or me?

124. **Hindi prompt:** जब तक वो मेरे पैसे वापस नहीं करता मैं उसे नहीं छोड़ने वाला।  
   **Romanized:** Jab tak Wo mere paise vapas nahi karta main use nahi chhodne vala.  
   **English answer:** Until he returns my money, I am not going to spare him.

125. **Hindi prompt:** वो उतनी दूर तक नहीं जा सका।  
   **Romanized:** Wo utni dur tak nahi ja saka.  
   **English answer:** He couldn’t go that far.

126. **Hindi prompt:** वो सच नहीं एक दिखावा था।  
   **Romanized:** Wo sach nahi ek dikhawa tha.  
   **English answer:** That was not a truth but a sham.

127. **Hindi prompt:** जिसके साथ तुमने फोटो खिंचवाई, वो कौन है?  
   **Romanized:** Jiske saath tumne photo khichvai, vo kon hai?  
   **English answer:** The one, you had a picture with; who is he? / That you had a picture with, who is he?

128. **Hindi prompt:** उसी को तो मैंने भेजा।  
   **Romanized:** usi ko to maine bheja.  
   **English answer:** That’s whom I sent.

129. **Hindi prompt:** इसी बात पर तो हमारे बीच झगड़ा हुआ।  
   **Romanized:** Isi baat par to hamare beech jhagda hua.  
   **English answer:** That’s what we had a dispute on. / That’s the matter we had a dispute on.

130. **Hindi prompt:** न खुद करते हो, न हमें करने देते हो।  
   **Romanized:** Na khud karte ho, na hame karne dete ho.  
   **English answer:** Neither you do yourself, nor let us do.

131. **Hindi prompt:** ऐसी लापरवाही अभी तक किसी और ने नहीं की है।  
   **Romanized:** Aisi laparwahi abhi tak kisi aur ne nahi ki hai.  
   **English answer:** No one else has done such negligence as yet.

132. **Hindi prompt:** उसके पास अभी भी बहुत पैसा है।  
   **Romanized:** Uske pass abhi bhi bahut paisa hai.  
   **English answer:** He still has lots of money. / He still has a lot of money.

133. **Hindi prompt:** न बारिश हुई, न कोई आया।  
   **Romanized:** Na barish huai, na koi aaya.  
   **English answer:** Neither it rained, nor anyone came.

134. **Hindi prompt:** तुम उसे यहाँ लाये ताकि हमें पिटवा सको।  
   **Romanized:** Tum use yahaa laaye taaki hamen pitva sako.  
   **English answer:** You got him here to beat us.

135. **Hindi prompt:** जिसके साथ हम चल रहे हैं, वो भूत नहीं हो सकता।  
   **Romanized:** Jiske saath ham chal rahe hai, wo bhoot nahi ho sakta.  
   **English answer:** The one we are walking with, can’t be a ghost.

136. **Hindi prompt:** जिसका दिल टूटा होता है दर्द वही महसूस करता है।  
   **Romanized:** Jiska dil tuta hota h dard vahi mehsoos karta h.  
   **English answer:** The one whose heart is broken feels the pain.

137. **Hindi prompt:** उसका भी कोई नहीं था।  
   **Romanized:** Uska bhi koi nahi tha.  
   **English answer:** Nobody was his either.

138. **Hindi prompt:** राम ने ये करवाया ताकि कोई उसे दोष न दे।  
   **Romanized:** Ram ne ye karwaya taaki koi use dosh na de.  
   **English answer:** Ram got it done so that nobody blamed him.

139. **Hindi prompt:** जब भी उनसे पूछा गया, वो चुप हो जाते थे।  
   **Romanized:** Jab bhi unse pucha gaya, wo chup ho jate the.  
   **English answer:** Whenever they were asked, they would keep quiet.

140. **Hindi prompt:** मैं भी किसी से नहीं डरता था।  
   **Romanized:** Main bhi kisi se nahi darta tha.  
   **English answer:** Even I wasn’t scared of anyone.

141. **Hindi prompt:** मेरे पास उसके जितनी किताबें क्यों नहीं थी?  
   **Romanized:** Mere pass uske jitni kitabe kyu nahi thi?  
   **English answer:** Why did I not have as many books as he had?

142. **Hindi prompt:** हमारे घर में भले ही कम्प्यूटर न हो, पर हमने चलाना सीख लिया है।  
   **Romanized:** Hamare ghar mein bhale hi computer na ho, par hamne chalana seekh liya hai.  
   **English answer:** Even if we don’t have a computer at home, still we have learned to operate it.

143. **Hindi prompt:** हमसे कोई नहीं मिलता था शायद इसलिए कि हम सब से अलग थे।  
   **Romanized:** Hamse koi nahi milta tha shayad isliye ki ham sab se alag the.  
   **English answer:** Nobody would meet us, probably because we were different than others.

144. **Hindi prompt:** उन्हें ही नहीं, उनके परिवार वालों को भी कोर्ट में पेश किया जाना है।  
   **Romanized:** Unhe hi nahi, unke parivaar valo Ko bhi court mein pesh kiya jana hai.  
   **English answer:** Not only they but also their family members have to be produced in the court.

145. **Hindi prompt:** हमने अभी तक किसी को नहीं बुलाया है।  
   **Romanized:** Hamne abhi tak kisi ko nahi bulaya hai.  
   **English answer:** We have not called anyone yet.

146. **Hindi prompt:** भले ही उसने मुझे जाने दिया पर मैं उसका साथ देने की सोच भी नहीं सकता।  
   **Romanized:** Bhle hi usne mujhe jaane diya par main uska saath dene ki soch bhi nahi sakta.  
   **English answer:** Even if he let me go, but I can’t even think of supporting him.

147. **Hindi prompt:** हालाँकि उसकी तबीयत खराब है फिर भी मैं उसकी हिम्मत की दाद देता हूँ कि वो सुबह से काम कर रहा है।  
   **Romanized:** Halanki uski tabiyat kharab hai phir bhi main uski himmat ki daad deta hoon ki vo subah se kam kar raha hai.  
   **English answer:** Although he is unwell, yet I salute his courage that he has been working since morning.

148. **Hindi prompt:** उसने ये किया ताकि लोग उसकी तारीफ करें।  
   **Romanized:** Usne ye kiya taaki log uski tarif Kare.  
   **English answer:** He did it so that people appreciate him.

149. **Hindi prompt:** अपने दोस्तों का साथ दो ऐसा न हो कि ज़रूरत पड़ने पर वो तुम्हारा साथ न दें।  
   **Romanized:** Apne dosto ka saath do aisa na ho ki zaroorat padne par vo tumhara saath na de.  
   **English answer:** Help your friends lest they shouldn’t help you in need.

150. **Hindi prompt:** क्या ये वही लड़का है जिसे तुम उस दिन पूछ रहे थे?  
   **Romanized:** Kya ye wahi ladka hai jise tum us din puch rahe the?  
   **English answer:** Is this the same boy whom you were asking the other day?

151. **Hindi prompt:** उसके बारे में भले ही तुम कुछ भी कहो पर उसे मुझ से बेहतर कोई नहीं जानता।  
   **Romanized:** Uske baare mein bhale hi tum kuch bhi kaho par usse mujh se behtar koi nahi janta.  
   **English answer:** Although you say anything about him, yet nobody knows him better than I do.

152. **Hindi prompt:** वो न कुछ सोच पाया न अपनी बात कह पाया।  
   **Romanized:** Wo na kuch soch paya na apni baat kah paya.  
   **English answer:** He could neither think anything nor say what he wanted to.

153. **Hindi prompt:** ऐसी चीजें मैं भी नहीं खाता।  
   **Romanized:** Aisi chije main bhee nahi khata.  
   **English answer:** I don’t eat such things either. / Even, I don’t eat such things.

154. **Hindi prompt:** या तो वो तुम्हें जाने देगा या फिर ये कहकर रोकेगा कि उसे तुम्हारी ज़रूरत है।  
   **Romanized:** Ya to wo tumhe jane dega ya phir yeh kahkar rokega ki use tumhari zaroorat hai.  
   **English answer:** Either he will let you go or he will stop you saying he needs you.

155. **Hindi prompt:** रिश्ते उन्हें कहते हैं जो हमें एक दूसरे से प्यार करना सिखाते हैं।  
   **Romanized:** Rishte unhe kehte hai jo hame ek doosre se pyar karna sikhate hai.  
   **English answer:** They are relations that teach us to love each other.

156. **Hindi prompt:** उसे भी इस बारे में नहीं बताया गया।  
   **Romanized:** Use bhi is baare me nahi bataya gaya.  
   **English answer:** Even he was not told about this.

157. **Hindi prompt:** क्या तुम कार चलाना जानते हो?  
   **Romanized:** Kya tum car chalana jante ho?  
   **English answer:** Do you know how to drive the car?

158. **Hindi prompt:** क्या तुम अभी भी ऐसा सोचते हो?  
   **Romanized:** Kya tum abhi bhi aisa sochte ho?  
   **English answer:** Do you still think so?

159. **Hindi prompt:** मैंने ये किताब खोली ही थी कि मुझे अपना बचपन याद आ गया।  
   **Romanized:** Maine ye kitab kholi hi thi ki mujhe apna bachpan yaad aa gaya.  
   **English answer:** No sooner had I opened the book than I remembered my childhood.

160. **Hindi prompt:** सही पता लिखो कहीं ऐसा न हो कि कूरियर कहीं और चला जाए।  
   **Romanized:** Sahi pata likho kaheen aisa na ho ki courier kahin or chala jaye.  
   **English answer:** Write the correct address lest the courier should go somewhere else.

161. **Hindi prompt:** सही पता लिखो ताकि कूरियर कहीं और न चला जाए।  
   **Romanized:** Sahi pata likho taaki courier kahin or na chala jaye.  
   **English answer:** Write the correct address so that the courier doesn't go anywhere else.

162. **Hindi prompt:** सही पता लिखो नहीं तो कूरियर कहीं और जा सकता है।  
   **Romanized:** Sahi pata likho nahi to courier kahin or ja sakta hai.  
   **English answer:** Write the correct address otherwise the courier may go somewhere else.

## Source-text and verification notes

- All 162 Hindi prompts and printed Romanized lines on PDF pages 280–289 were OCRed and visually checked against the page scans; obvious OCR spacing, split-word, and punctuation artifacts were corrected. No unreadable prompt sections.
- The answer key begins on PDF page 289 after prompts 161 and 162 and continues through page 293. All 162 English answers were visually reviewed and paired with the same-number prompt; the answer sequence is unique and continuous from 1 to 162.
- The source Romanized line for item 37 contains a duplicated opening parenthesis; the Romanized words are preserved and the punctuation wrapper normalized. Other source wording, grammar, and slash-separated answer alternatives are retained.

**Unreadable text:** none identified.

