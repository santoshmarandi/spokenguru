# Lesson 13 — Can/Could + Be, Have & Been

**PDF pages:** 139–145 (printed pages 138–144)

**Instruction:** Translate the following sentences into English.

## Bilingual prompts and printed English answers

### 1. विद्यार्थी स्कूल से घर आ सकते हैं।
**Romanized:** (Vidyarthi school se ghar aa sakte hain.)
**English answer:** Students can come home from school.

### 2. कुछ भी हो सकता था।
**Romanized:** (Kuchh bhi ho sakta tha.)
**English answer:** Anything could have happened.

### 3. तुम कभी किसी को प्यार नहीं कर सकते।
**Romanized:** (Tum kabhi kisi ko pyar nahi kar sakte.)
**English answer:** You can never love anyone.

### 4. तुम समय पर क्यों नहीं आ सके?
**Romanized:** (Tum samay par kyon nahi aa sake?)
**English answer:** Why could you not come on time?

### 5. तुम नल खोल सकते थे पर तुमने नहीं खोला।
**Romanized:** (Tum nal khol sakte the pr tumne ni khola.)
**English answer:** You could have turned on the tap but you didn’t.

### 6. मैं जा नहीं पाया।
**Romanized:** (Main ja nahi paya.)
**English answer:** I could not go.

### 7. क्या तुम कल रात सो पाये?
**Romanized:** (Kya tum kal raat so paye?)
**English answer:** Could you sleep last night?

### 8. क्या तुम जा पाये?
**Romanized:** (Kya tum ja paye?)
**English answer:** Could you go?

### 9. हम कभी नहीं भुला सके।
**Romanized:** (Ham kabhi nahi bhula sake.)
**English answer:** I could never forget.

### 10. मैं आ सकता था पर नहीं आया।
**Romanized:** (Main aa sakta tha par nahi aaya.)
**English answer:** I could have come but I didn’t.

### 11. मैं घूमने कभी नहीं जा सकता।
**Romanized:** (Main ghumne kabhi nahi ja sakta.)
**English answer:** I can/could never go for a walk.

### 12. कुछ भी हो सकता है, मैं कह नहीं सकता।
**Romanized:** (Kuch bhi ho skta h, main kah nhi skta)
**English answer:** Anything can happen. I can’t say.

### 13. वह मुझसे दूर कभी नहीं जा सकता।
**Romanized:** (Wah mujhse dur kabhi nahi ja sakta.)
**English answer:** He can/could never go away from me.

### 14. राम मिठाई खा सकता था।
**Romanized:** (Ram mithai kha sakta tha.)
**English answer:** Ram could have eaten the sweets.

### 15. मैं कभी गाना नहीं गा सका।
**Romanized:** (Main kabhi gaana nahi ga saka.)
**English answer:** I could never sing songs.

### 16. तुम मुझसे मिलने आ सकते हो।
**Romanized:** (Tum mujhse milne aa sakte ho.)
**English answer:** You can/could come to meet me.

### 17. श्वेता अपने दिल की बात कभी नहीं कह सकी।
**Romanized:** (Shweta apne dil ki bat kabhi nahi keh saki.)
**English answer:** Shweta could never speak out her feelings.

### 18. अंगूर खट्टे हो सकते थे।
**Romanized:** (Angoor khatte ho sakte the.)
**English answer:** Grapes could have been sour.

### 19. हम तुम्हें कभी बर्दाश्त नहीं कर सकते।
**Romanized:** (Ham tumhe kbhi bardasht nhi kr sakte.)
**English answer:** We can/could never tolerate you.

### 20. राम किसी तरह वहाँ पहुँच सकता था।
**Romanized:** (Ram kisi tarah waha pahunch sakta tha.)
**English answer:** Ram could have somehow reached there.

### 21. लोग तुम्हारे बारे में सोच सकते थे।
**Romanized:** (Log tumhare bare mein soch sakte the.)
**English answer:** People could have thought about you.

### 22. तुम इम्तिहान पास नहीं कर सकते।
**Romanized:** (Tum imtihan paas nahi kar sakte.)
**English answer:** You can’t pass the examination.

### 23. तुम खा सकते हो; चाहे ये या चाहे वो।
**Romanized:** (Tum kha sakte ho; chahe ye ya chahe wo.)
**English answer:** You can eat; either this or that.

### 24. तुम मेरे घर आ सकते थे पर तुम नहीं आये।
**Romanized:** (Tum mere ghar aa sakte the par tum nahi aaye.)
**English answer:** You could have come my home but you didn’t.

### 25. मैं जीतना चाहता था पर कभी जीत नहीं पाया।
**Romanized:** (Main jeetna chahata tha par kabhi jeet nahi paya.)
**English answer:** I wanted to win but I could never.

### 26. तुमने हमेशा मुझे सम्मान दिया, मैं भूल नहीं सकता।
**Romanized:** (Tumne hamesha mujhe samman diya, main bhul nahi sakta.)
**English answer:** You always respected me, I can’t forget.

### 27. मैं तुमसे मिलने कभी नहीं आ सकता।
**Romanized:** (Main tumse milne kabhi nahi aa sakta.)
**English answer:** I can never come to meet you.

### 28. मैं तुमसे कभी नहीं कह सका।
**Romanized:** (Main tumse kabhi nahi kah saka.)
**English answer:** I could never say to you.

### 29. क्या तुम वहाँ जा पाए? शायद कभी नहीं।
**Romanized:** (Kya tum waha ja pae? shayad kbhi nhi.)
**English answer:** Could you ever go there? Never! I guess.

### 30. क्या तुम मेरे लिए नहीं रुक सकते?
**Romanized:** (Kya tum mere liye nahi ruk sakte?)
**English answer:** Can’t you wait for me?

### 31. क्या वो पा सकी जो वो चाहती थी?
**Romanized:** (Kya wo pa saki jo vo chahati thi?)
**English answer:** Could she achieve what she wanted?

### 32. मैं सरकार के फैसले के विरुद्ध विद्रोह नहीं कर सका।
**Romanized:** (Main sarkar ke faisle ke viruddh vidrooh nahi kar saka.)
**English answer:** I couldn’t protest against Government decision.

### 33. क्या तुम उस लड़के से मिल सकते हो?
**Romanized:** (Kya tum us ladke se mil sakte ho?)
**English answer:** Can you meet that boy?

### 34. तुम प्यार की तुलना किसी चीज से नहीं कर सकते।
**Romanized:** (Tum pyar ki tulna kisi chiz se nahi kar sakte.)
**English answer:** You can’t compare love with anything.

### 35. क्या आप मेरे लिए थोड़ा समय निकाल सकते हैं?
**Romanized:** (Kya aap mere liye thoda samay nikal sakte hain?)
**English answer:** Could you please spare some time for me?

### 36. क्या मैं मिस्टर बत्रा से बात कर सकता हूँ?
**Romanized:** (Kya main Mr. Batra se bat kr skta hu?)
**English answer:** Could I speak with Mr. Batra?

### 37. मोबाईल मुझे मेरी पढ़ाई से भटका नहीं सका।
**Romanized:** (Mobile mujhe meri padhai se bhatka nahi saka.)
**English answer:** Mobile could not divert me from my studies.

### 38. देरी हो सकती थी।
**Romanized:** (Deri ho sakti thi.)
**English answer:** It could be delayed.

### 39. इसे कैसे सुधारा जा सकता है?
**Romanized:** (Ise kaise sudhara ja sakta hai?)
**English answer:** How can it be corrected?

### 40. बारिश हो सकती थी पर हुई नहीं।
**Romanized:** (Barish ho sakti thi par hui nahi.)
**English answer:** It could have rained but didn’t.

### 41. आज ओले पड़ सकते थे पर नहीं पड़े।
**Romanized:** (Aaj ole pad sakte the par nahi pade.)
**English answer:** It could have hailed today but didn’t.

### 42. क्या मैं कुछ कह सकता हूँ?
**Romanized:** (Kya main kuchh kah sakta hun?)
**English answer:** Can I say something?

### 43. क्या मैं आपको कुछ देर बाद कॉल कर सकता हूँ?
**Romanized:** (Kya main aapko kuch der baad call kr sakta hu?)
**English answer:** Can I call you after sometime?

### 44. काश तुम सच्चाई देख पाते।
**Romanized:** (Kash tum Sachai dekh paate.)
**English answer:** I wish you could see the reality.

### 45. आप क्रेडिट कार्ड से भुगतान कर सकते हो।
**Romanized:** (Aap credit card se bhugtan kar sakte ho.)
**English answer:** You can make the payment by credit card.

### 46. तुम मुश्किल में पड़ सकते हो।
**Romanized:** (Tum mushkil mein pad sakte ho.)
**English answer:** You could be in trouble.

### 47. मैं गलत हो सकती हूँ।
**Romanized:** (Main galat ho sakti hun.)
**English answer:** I could be wrong.

### 48. मैं अंग्रेज़ी नहीं बोल सकती।
**Romanized:** (Main angreji nahi bol sakti.)
**English answer:** I can’t speak English.

### 49. क्या मैं अंग्रेज़ी बोल सकती हूँ?
**Romanized:** (Kya main angreji bol sakti hun?)
**English answer:** Can I speak English?

### 50. मैं अंग्रेज़ी कैसे सीख सकती हूँ?
**Romanized:** (Main angreji kaise sikh sakti hun?)
**English answer:** How can I learn English?

### 51. मैं कहाँ अंग्रेज़ी सीख सकती हूँ?
**Romanized:** (Main kahaan angreji seekh sakti hun?)
**English answer:** Where can I learn English?

### 52. क्या तुम अंग्रेज़ी नहीं बोल सकते?
**Romanized:** (Kya tum angreji nahi bol sakte?)
**English answer:** Can’t you speak English?

### 53. वो आज आपसे मिल सकता है।
**Romanized:** (Wo aaj apse mil sakta hai.)
**English answer:** He could meet you today.

### 54. वो आपसे कल मिल सकता था।
**Romanized:** (Wo apse kal mil sakta tha.)
**English answer:** He could meet you yesterday.

### 55. कल वो आपसे मिल सकता है।
**Romanized:** (Kal wo apse mil sakta hai.)
**English answer:** He could meet you tomorrow.

### 56. वो घर नहीं आ पाया।
**Romanized:** (Wo ghar nahi aa paya.)
**English answer:** He couldn’t come home.

### 57. वो इतना महँगा फ़ोन कैसे खरीद पाया?
**Romanized:** (Wo itna mehanga phone kaise kharid paya?)
**English answer:** How could he buy such an expensive phone?

### 58. मैं समय पर कार्यालय नहीं पहुँच सका क्योंकि बारिश हो रही थी।
**Romanized:** (Main samay par karyalay nahi pahunch saka kyunki baarish ho rahi thi.)
**English answer:** I couldn’t reach the office on time because it was raining.

### 59. काश मैं एक बार आपसे मिल पाता।
**Romanized:** (Kaash main ek baar apse mil paata.)
**English answer:** I wish I could meet you once.

### 60. काश वो समझ पाता जो मेरा मतलब था।
**Romanized:** (Kaash wo samajh pata jo mera matlab tha.)
**English answer:** I wish he could understand what I meant.

### 61. मैं यहाँ कैसे आ पाता अगर आपने मेरी मदद नहीं की होती तो।
**Romanized:** (Main yahan kaise aa pata agar aapne meri madad nahin ki hoti to.)
**English answer:** How could I come here if you didn’t help me.

### 62. वो इस वक़्त घर पर हो सकती थी, पर वो नहीं थी।
**Romanized:** (Wo is waqt ghar par ho sakti thi, par wo nhi thi.)
**English answer:** She could be at home right now; but she wasn’t.

### 63. ये बहुत जोखिम भरा हो सकता था, किसी तरह से मैंने मैनेज किया।
**Romanized:** (Yah bahut jokhim bhara ho sakta tha; kisi tarah se maine manage kiya.)
**English answer:** It could be so risky; but somehow, I managed.

### 64. ये बहुत जोखिम भरा हो सकता है, इसे मत करो।
**Romanized:** (Yah bahut jokhim bhara ho sakta hai ise mat karo.)
**English answer:** It could be so risky; don’t do it.

### 65. मैं अगले साल एक अच्छी जॉब में हो सकता हूँ।
**Romanized:** (Main agale saal ek acchi job main ho sakta hoon.)
**English answer:** I could be in a good job next year.

### 66. मुझे घर वापस भेजा जा सकता था, लेकिन उसने मुझे दूसरा चांस दे दिया।
**Romanized:** (Mujhe ghar vaapas bheja ja sakta tha; lekin usne mujhe doosra chance de diya.)
**English answer:** I could be sent back home; but he gave me another chance.

### 67. मुझे घर वापस भेजा जा सकता था,अगर मैं प्रदर्शन नहीं करता तो।
**Romanized:** (Mujhe ghar vaapas bheja ja sakta tha; agar main pradarshan nahi karta to.)
**English answer:** I could be sent back home; if I don’t perform.

### 68. यह आसानी से किया जा सकता है।
**Romanized:** (Yah asani se kiya ja sakta hai.)
**English answer:** It could be easily done.

### 69. यह आसानी से किया जा सकता था, लेकिन मैं ऐसा नहीं कर सका।
**Romanized:** (Yah asani se kiya ja sakta tha, lekin main aisa nahi kar saka.)
**English answer:** It could be easily done, but I couldn’t do so.

### 70. वह कल आपको बुला सकता था।
**Romanized:** (Vah kal aapko bula sakta tha.)
**English answer:** He could have called you yesterday.

### 71. मैं उनके साथ खेल सकता था, लेकिन उन्होंने मुझे मौका नहीं दिया।
**Romanized:** (Main unke saath khel sakta tha, lekin unhone mujhe mauka nahin diya.)
**English answer:** I could have played with them, but he didn't give me a chance.

### 72. वह डॉक्टर बन सकती थी।
**Romanized:** (Vah doctor ban sakti thi.)
**English answer:** She could have become a doctor.

### 73. अगर उसे अच्छी नौकरी मिल जाए तो अगले कुछ सालों में उसके पास एक अच्छा घर हो सकता है।
**Romanized:** (Agar use acchi naukari mil jaye to agale kuchh saalon mein uske paas ek accha ghar ho sakta hai.)
**English answer:** He could have a good house in the next few years if he gets a good job

### 74. अगर उनके पास अच्छी नौकरी होती तो आज उनके पास एक अच्छा घर होता।
**Romanized:** (Agar unke pass acchi naukri hoti to aaj unke paas ek acha ghar hota.)
**English answer:** He would have had a good house today if he had a good job.

### 75. अगर उसके पास अच्छी नौकरी होती तो उसके पास एक अच्छा घर हो सकता था।
**Romanized:** (Agar uske pass acchi naukri hoti to unke pas ek accha ghar ho sakta tha.)
**English answer:** He could have had a good house if he had a good job.

### 76. उसके पास ज़्यादा हो सकता था पर उसने कभी परवाह नहीं की।
**Romanized:** (Uske pass zyada ho sakta tha par usne kabhi parwah nahi ki.)
**English answer:** She could have had more but she never cared.

### 77. अगर मैं उसका समर्थन नहीं करता, तो उसके पास इतना बड़ा अवसर नहीं हो सकता था।
**Romanized:** (Agar main uska samarthan nahi karta, to uske paas itna bada awsar nahi ho sakta tha.)
**English answer:** He couldn’t have had such a great opportunity if I hadn’t supported him.

### 78. उसे प्रताड़ित किया जा सकता था, लेकिन पुलिस ने बहुत अच्छा व्यवहार किया।
**Romanized:** (Use pratadit kiya ja sakta tha, lekin police ne bahut acha vyavhaar kiya.)
**English answer:** He could have been tortured, but the police behaved very well.

### 79. मुझसे पूछा जा सकता था कि हम सोमवार को कहाँ थे।
**Romanized:** (Mujhse poocha ja sakta tha ki ham somwar ko kahaan the.)
**English answer:** I could have been asked about where we were on Monday.

### 80. यह जानकारी जनता के बीच साझा की जा सकती थी लेकिन भगवान का शुक्र है कि ऐसा कुछ नहीं हुआ।
**Romanized:** (Yah jaankari janta ke beech saajha ki ja sakti thi, lekin bhagvan ka shukr hai ki aisa kuch nahin hua.)
**English answer:** This information could have been shared among the public but thank God, nothing happened as such.

### 81. आज आपको स्कूल जाना पड़ सकता है।
**Romanized:** (Aaj apko school jana pad sakta hai.)
**English answer:** You could have to go to school today.

### 82. आपको कल स्कूल जाना पड़ सकता था।
**Romanized:** (Apko kal school jaana pad sakta tha.)
**English answer:** You could have to go to school yesterday. / You could have had to go to school yesterday.

### 83. जब भी वह आपको बुलाएगी आपको यहाँ फिर से आना पड़ सकता है।
**Romanized:** (Jab bhi wah apko bulayegi apko yahaan phir se aana pad sakta hai.)
**English answer:** You could have to come here again whenever she calls you.

## Source-text notes

- **Item 28:** The printed answer says 'I could never say to you.'; its unusual wording is retained.
- **Item 65:** The printed answer says 'I could be in a good job next year.'; retained as printed.
- **Item 81:** The printed answer says 'You could have to go to school today.'; retained as printed.
- **Item 83:** The printed answer says 'You could have to come here again whenever she calls you.'; retained as printed.

**Editorial corrections:** Hindi OCR on items 5, 13, 29, 57, 73 and 80 was corrected against the page images; item 31 Romanization was normalized for an obvious duplicated letter. The printed English answer typo “did’t” at item 71 was corrected to “didn’t”; other answer-key wording and alternatives are preserved, including the irregular wording noted above.

**Unreadable text:** none identified.

