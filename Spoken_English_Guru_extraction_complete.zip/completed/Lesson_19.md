# Lesson 19 — Position Sense

**PDF pages:** 274–279 (printed pages 273–278)

## Please translate the following sentences into English

1. **Hindi prompt:** तुम मेरे दाँयी ओर हो।  
   **Romanized:** Tum mere danyee aur ho.  
   **English answer:** You are right to me.

2. **Hindi prompt:** क्या राम तुम्हारे सामने था?  
   **Romanized:** Kya Ram tumhare samne tha?  
   **English answer:** Was Ram in front of you?

3. **Hindi prompt:** मैं उसके आगे खड़ा था।  
   **Romanized:** Main uske aage khada tha.  
   **English answer:** I was standing ahead of him.

4. **Hindi prompt:** राम के आगे कितने लोग हैं?  
   **Romanized:** Ram ke aage kitne log hain?  
   **English answer:** How many people are there ahead of Ram?

5. **Hindi prompt:** बच्चों के ठीक सामने अध्यापक खड़े हैं।  
   **Romanized:** Bachcho ke theek samne adhyapak khade hai.  
   **English answer:** The teacher is standing just in front of the students.

6. **Hindi prompt:** तुम्हारे बाँयी ओर कौन है?  
   **Romanized:** Tumhare bayee aur kaun hai?  
   **English answer:** Who is to the left of you? / Who is left to you?

7. **Hindi prompt:** मेरे बगल में दाँयी ओर सीता बैठी है।  
   **Romanized:** Mere bagal mein dayee aur Seeta baithee hai.  
   **English answer:** Seeta is sitting immediate right to me.

8. **Hindi prompt:** सीता के बगल में बाँयी ओर एक लड़का है।  
   **Romanized:** Seeta ke bagal mein byee aur ek ladka hai.  
   **English answer:** A boy is immediate left to Seeta. / A boy is to the immediate left of Seeta.

9. **Hindi prompt:** मैं तुम्हारे पीछे था।  
   **Romanized:** Main tumhare peeche tha.  
   **English answer:** I was behind you.

10. **Hindi prompt:** उसके पीछे कितने लोग खड़े हैं?  
   **Romanized:** Uske peeche kitne log khade hai?  
   **English answer:** How many people are standing behind him?

11. **Hindi prompt:** राम एक कोने में बैठा है।  
   **Romanized:** Ram ek kone mein baitha hai.  
   **English answer:** Ram is sitting in a corner.

12. **Hindi prompt:** मेरे बाँयी ओर कोई लड़का नहीं था।  
   **Romanized:** Mere bayee aur koi ladka nahi tha.  
   **English answer:** There was no boy to the left of me. / There was no boy left to me.

13. **Hindi prompt:** राहुल मेरे ठीक सामने था क्या?  
   **Romanized:** Rahul mere theek samne tha kya?  
   **English answer:** Was Rahul exactly in front of me?

14. **Hindi prompt:** मेरे घर के सामने तुम्हारा घर है।  
   **Romanized:** Mere ghar ke samne tumhara ghar hai.  
   **English answer:** Your house is in front of my house / mine.

15. **Hindi prompt:** मेरा घर तुम्हारे घर से ठीक आगे वाला है।  
   **Romanized:** Mera ghar tumhare ghar se theek aage vala hai.  
   **English answer:** My house is just ahead of yours.

16. **Hindi prompt:** मेरा घर तुम्हारे घर से ठीक पीछे वाला है।  
   **Romanized:** Mera ghar tumhare ghar se theek peeche vala hai.  
   **English answer:** My house is just before yours.

17. **Hindi prompt:** रोहित के दाँयी ओर कितने लोग हैं?  
   **Romanized:** Rohit ke dayee aur kitne log hai?  
   **English answer:** How many people are there to the right of Rohit? / How many people are there right to Rohit?

18. **Hindi prompt:** सीता के बाँयी ओर कितने लड़के हैं?  
   **Romanized:** Seeta ke bayee aur kitne ladke hai?  
   **English answer:** How many boys are there to the left of Seeta? / How many boys are there left to Seeta?

19. **Hindi prompt:** मेरे दाँयी ओर कोई नहीं है।  
   **Romanized:** Mere dayee aur koi nahi hai.  
   **English answer:** There is no one to the right of me. / There is no one right to me.

20. **Hindi prompt:** क्या तुम्हारे दाँयी ओर कोई है?  
   **Romanized:** Kya tumhare dayee aur koi hai?  
   **English answer:** Is there someone to the right of you? / Is there someone right to you?

21. **Hindi prompt:** क्या तुम्हारे बाँयी ओर कोई नहीं है?  
   **Romanized:** Kya tumhare bayee aur koi nahi hai?  
   **English answer:** Is there no one to the left of you? / Is there no one left to you?

22. **Hindi prompt:** क्या तुम्हारे आगे कोई है?  
   **Romanized:** Kya tumhare aage koi hai?  
   **English answer:** Is there someone ahead of you?

23. **Hindi prompt:** क्या तुम्हारे पीछे कोई नहीं है?  
   **Romanized:** Kya tumhare peeche koi nahi hai?  
   **English answer:** Is there no one behind you?

24. **Hindi prompt:** क्या तुम्हारे सामने कोई है?  
   **Romanized:** Kya tumhare samne koi hai?  
   **English answer:** Is there someone in front of you?

25. **Hindi prompt:** क्या तुम्हारे बगल में कोई है?  
   **Romanized:** Kya tumhare bagal mein koi hai?  
   **English answer:** Is there someone next to / adjacent / beside you?

26. **Hindi prompt:** हम बाँयी ओर खड़े थे।  
   **Romanized:** Hum bayee aur khade the.  
   **English answer:** We were standing on the left.

27. **Hindi prompt:** हम दाँयी ओर खड़े थे।  
   **Romanized:** Hum dayee aur khade the.  
   **English answer:** We were standing on the right.

28. **Hindi prompt:** सीता क्लास में अकेली थी।  
   **Romanized:** Seeta class mein akeli thi.  
   **English answer:** Seeta was alone in the class.

29. **Hindi prompt:** राम वहाँ पर नहीं था।  
   **Romanized:** Ram wahaan par nahi tha.  
   **English answer:** Ram wasn’t there.

30. **Hindi prompt:** दिल्ली भारत के उत्तर में है।  
   **Romanized:** Delhi Bharat ke uttar mein hai.  
   **English answer:** Delhi is to the north of India. / Delhi is in the northern India.

31. **Hindi prompt:** केरल भारत के दक्षिण में है।  
   **Romanized:** Keral Bharat ke dakshin mein hai.  
   **English answer:** Kerala is to the South of India. / Kerala is in the southern India.

32. **Hindi prompt:** बंगाल भारत के पूरब में है।  
   **Romanized:** Bangal Bharat ke poorab mein hai.  
   **English answer:** Bengal is to the East of India. / Bengal is in the Eastern India.

33. **Hindi prompt:** उसके सामने कौन था?  
   **Romanized:** Uske samne kaun tha?  
   **English answer:** Who was in front of him/her?

34. **Hindi prompt:** मेरे आगे लाइन में तीन लोग खड़े थे।  
   **Romanized:** Mere aage line mein teen log khade the.  
   **English answer:** There were three people standing ahead of me in the queue.

35. **Hindi prompt:** राम के आगे 2 आदमी थे।  
   **Romanized:** Ram ke aage 2 aadmi the.  
   **English answer:** There were 2 men ahead of Ram.

36. **Hindi prompt:** मेरे पीछे लाइन में कितने थे?  
   **Romanized:** Mere peeche line mein kitne the?  
   **English answer:** How many were there behind me in the queue.

37. **Hindi prompt:** मेरे जूते कमरे के एक कोने में पड़े थे।  
   **Romanized:** Mere joote kamre ke ek kone mein pade the.  
   **English answer:** My shoes were lying in a corner of the room.

38. **Hindi prompt:** तुम्हारे जूते के सामने वाले जूते मेरे हैं।  
   **Romanized:** Tumhare joote ke samne vale joote mere hai.  
   **English answer:** The shoes beside yours are mine.

39. **Hindi prompt:** वो तुम्हारे किस तरफ है?  
   **Romanized:** Vo tumhare kis taraf hai?  
   **English answer:** Which side is he from you?

40. **Hindi prompt:** वो मेरे दाँयी ओर है |.  
   **Romanized:** Vo mere dayee aur hai.  
   **English answer:** He is to the right of me. / He is right to me.

41. **Hindi prompt:** दाँयी ओर तो ठीक है पर वो कया बगल में है?  
   **Romanized:** Dayee aur to theek hai par vo kya bagal mein hai?  
   **English answer:** Right side is fine but is he adjacent?

42. **Hindi prompt:** हमारे बीच 2 लड़कियाँ हैं।  
   **Romanized:** Hamare beech 2 ladkiyan hai.  
   **English answer:** There are 2 girls between us.

43. **Hindi prompt:** सीता और गीता के बीच कितने हैं?  
   **Romanized:** Seeta aur Geeta ke beech kitne hai?  
   **English answer:** How many are there between Seeta & Geeta?

44. **Hindi prompt:** रोहन के बगल में कौन है?  
   **Romanized:** Rohan ke bagal mein kaun hai?  
   **English answer:** Who is beside Rohan?

45. **Hindi prompt:** सीता के बगल में कोई नहीं है।  
   **Romanized:** Seeta ke bagal mein koi nahi hai.  
   **English answer:** Nobody is beside Seeta.

46. **Hindi prompt:** राम आगे है और मैं पीछे।  
   **Romanized:** Ram aage hai aur main peeche.  
   **English answer:** Ram is ahead of me. / I am behind Ram.

47. **Hindi prompt:** तुम दाँयी ओर थे।  
   **Romanized:** Tum dayee aur the.  
   **English answer:** You were on the right.

48. **Hindi prompt:** तुम्हारे पीछे कौन है? कोई नहीं।  
   **Romanized:** Tumhare peeche kaun hai? Koi nahi.  
   **English answer:** Who is behind you? None.

49. **Hindi prompt:** मैं किस दिशा में हूँ?  
   **Romanized:** Main kis disha mein hoon?  
   **English answer:** Which direction am I in?

50. **Hindi prompt:** तुम इस वक्त उत्तर की ओर जा रहे हो।  
   **Romanized:** Tum is vakt uttar kee aur ja rahe ho.  
   **English answer:** You are going towards north at the moment.

51. **Hindi prompt:** मयंक सोनम के बगल में बैठा है।  
   **Romanized:** Mayank Sonam ke bagal me baitha hai.  
   **English answer:** Mayank is sitting next to/ adjacent/ beside sonam.

52. **Hindi prompt:** स्वाति अज़हर के बगल में खड़ी है।  
   **Romanized:** Swati Azhar ke bagal me khadi hai.  
   **English answer:** Swati is standing next to/ adjacent/ beside Azhar.

53. **Hindi prompt:** सोनी सोनम के आगे बैठी है।  
   **Romanized:** Soni Sonam ke aage baithi hai.  
   **English answer:** Soni is sitting ahead of Sonam.

54. **Hindi prompt:** सीमा अंजलि के पीछे बैठी है।  
   **Romanized:** Seema Anjali ke peeche baithi hai.  
   **English answer:** Seema is sitting behind Anjali.

55. **Hindi prompt:** टीचर स्टूडेंट के सामने खड़े है।  
   **Romanized:** Teacher student ke saamne khade hai.  
   **English answer:** Teacher is standing in front of the student.

56. **Hindi prompt:** आरोही अविरत के दाईं ओर है।  
   **Romanized:** Arohi Avirat ke dayi or hai.  
   **English answer:** Arohi is to the right of (right to) Avirat.

57. **Hindi prompt:** अज़हर के आगे कौन बैठा है?  
   **Romanized:** Azhar ke aage kaun baitha hai?  
   **English answer:** Who is sitting ahead of Azhar?

58. **Hindi prompt:** सोनी के बगल में इमरान क्यों बैठा है?  
   **Romanized:** Soni ke bagal me Imran kyu baitha hai?  
   **English answer:** Why is Imran sitting beside/next to/adjacent Soni?

59. **Hindi prompt:** सोनम स्वाति के बाईं ओर है।  
   **Romanized:** Sonam Swati ke baai or hai.  
   **English answer:** Sonam is left to / to the left of Swati.

60. **Hindi prompt:** आन्या इमरान के बगल में दाईं ओर है।  
   **Romanized:** Aanya Imran ke bagal me daai or hai.  
   **English answer:** Aanya is immediate right to Imran.

61. **Hindi prompt:** सोनी इमरान के बगल में बाईं ओर बैठी है।  
   **Romanized:** Soni Imran ke bagal me baayin or baithi hai.  
   **English answer:** Soni is sitting immediate left to Imran.

62. **Hindi prompt:** इमरान स्वाति के ठीक आगे बैठा है।  
   **Romanized:** Imran Swati ke thik aage baitha hai.  
   **English answer:** Imran is sitting immediate ahead of Swati.

63. **Hindi prompt:** मैं आपको गली के कोने पर मिलूँगा।  
   **Romanized:** Mai aapko gali ke kone par milunga.  
   **English answer:** I will meet you at the corner of the street.

64. **Hindi prompt:** आप अमन के दाईं ओर बैठे हो।  
   **Romanized:** Aap Aman ke daeen or baithe ho.  
   **English answer:** You are sitting right to Aman. / You are sitting to the right of Aman.

65. **Hindi prompt:** आप अमन के बाईं ओर बैठे हो।  
   **Romanized:** Aap Aman ke baeen or baithe ho.  
   **English answer:** You are sitting left to Aman. / You are sitting to the left of Aman.

66. **Hindi prompt:** आप अमन के आगे बैठे हो।  
   **Romanized:** Aap Aman ke aage baithe ho.  
   **English answer:** You are sitting ahead of Aman.

67. **Hindi prompt:** आप अमन के पीछे बैठे हो।  
   **Romanized:** Aap Aman ke peechhe baithe ho.  
   **English answer:** You are sitting behind Aman.

68. **Hindi prompt:** आप अमन के बगल में बैठे हो।  
   **Romanized:** Aap Aman ke bagal me baithe ho.  
   **English answer:** You are sitting next to/adjacent/beside Aman.

69. **Hindi prompt:** वो मेरे सामने खड़ा था।  
   **Romanized:** Vo mere saamne khada tha.  
   **Printed gloss:** Face to Face  
   **English answer:** He was standing in front of me.

70. **Hindi prompt:** मैं लाइन में उसके आगे खड़ा था।  
   **Romanized:** Main line me uske aage khada tha.  
   **English answer:** I was standing ahead of him in the queue.

71. **Hindi prompt:** तुम्हारे बाईँ ओर कौन है?  
   **Romanized:** Tumhare baeen aur kaun hai?  
   **English answer:** Who is to the left of you? / Who is left to you?

72. **Hindi prompt:** तुम्हारे जूते के सामने वाले जूते मेरे हैं।  
   **Romanized:** Tumhare joote ke samne vale joote mere hai.  
   **English answer:** The shoes beside yours are mine.

73. **Hindi prompt:** संजना के बगल में कोई नहीं है।  
   **Romanized:** Sanjana ke bagal mein koi nahi hai.  
   **English answer:** There is no one beside Sanjana.

74. **Hindi prompt:** मैं किस दिशा में हूँ?  
   **Romanized:** Main kis disha mein hoon?  
   **English answer:** In which direction am I? / Which direction am I in?

75. **Hindi prompt:** मैं उत्तर की ओर जा रहा हूँ।  
   **Romanized:** Main uttar kee or ja rahe hu.  
   **English answer:** I am going towards the north.

76. **Hindi prompt:** आप दाईं ओर थे।  
   **Romanized:** Aap daeen or the.  
   **English answer:** You were on the right side.

77. **Hindi prompt:** आप बाईं ओर थे।  
   **Romanized:** Aap baeen or the.  
   **English answer:** You were on the left side.

78. **Hindi prompt:** बाईं ओर चलो।  
   **Romanized:** Baeen or chalo.  
   **English answer:** Walk on the left side. / Keep the left.

79. **Hindi prompt:** दिल्ली भारत के उत्तर में है।  
   **Romanized:** Delhi Bharat ke uttar mein hai.  
   **English answer:** Delhi is to the north of India. / Delhi is in the northern India.

80. **Hindi prompt:** केरल भारत के दक्षिण में है।  
   **Romanized:** Keral Bharat ke dakshin mein hai.  
   **English answer:** Kerala is to the South of India. / Kerala is in the southern India.

81. **Hindi prompt:** बंगाल भारत के पूरब में है।  
   **Romanized:** Bangal Bharat ke poorab mein hai.  
   **English answer:** Bengal is to the East of India. / Bengal is in the Eastern India.

82. **Hindi prompt:** कृपया दाईं ओर खिसकिए।  
   **Romanized:** Kripya daeen or khisakiye.  
   **English answer:** Please move to the right.

83. **Hindi prompt:** कृपया बाईं ओर खिसकिए।  
   **Romanized:** Kripya baeen or khisakiye.  
   **English answer:** Please move to the left.

## Source-text and verification notes

- The 83 Hindi prompts and printed Romanized lines on PDF pages 274–277 were OCRed and visually checked against the page images. Clear OCR artifacts in items 63 and 69 were corrected; no unreadable sections.
- The English answer key begins after prompt 83 on PDF page 277 and runs through page 279. All 83 answers form a unique continuous 1–83 sequence and are paired to the same-number prompts.
- Item 69 includes the extra printed gloss “Face to Face” before its Romanized sentence; both are retained. The Romanized wording in item 75 (“ja rahe hu”) is preserved as printed, despite its mismatch with the Hindi prompt.
- Other source answer wording and grammar are retained rather than rewritten.

**Unreadable text:** none identified.

