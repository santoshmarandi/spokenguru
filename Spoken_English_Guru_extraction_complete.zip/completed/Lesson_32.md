# Lesson 32 — Question Tags

**PDF pages:** 417–419 (printed pages 416–418)

## Translate the following “Question Tag” sentences into English

1. **Hindi:** पंकज अच्छा है, है ना?  
   **Romanized:** (Pankaj acha hai, hai naa?)  
   **English:** Pankaj is good, isn’t he?  

2. **Hindi:** पिंकी अच्छी लड़की है, है ना ?  
   **Romanized:** (Pinky achi ladki hai, hai naa?)  
   **English:** Pinki is a sweet girl, isn’t she?  

3. **Hindi:** तुम पागल हो, नहीं क्या  
   **Romanized:** (Tum pagal ho, nahi kya?)  
   **English:** You are mad, aren’t you?  

4. **Hindi:** मैं बुरा हूँ, है ना ?  
   **Romanized:** (Main bura hoon, hai naa?)  
   **English:** I am bad, am I not?  

5. **Hindi:** वो खुश था, नहीं  
   **Romanized:** (Vo khush thaa, nahin?)  
   **English:** He was happy, wasn’t he?  

6. **Hindi:** हम दुखी थे, है ना?  
   **Romanized:** (Hum dukhi the, hai naa?)  
   **English:** We were sad, weren’t we?  

7. **Hindi:** मेरे पास पैसे हैं, नहीं ?  
   **Romanized:** (Mere paas paise hain, nahin?)  
   **English:** I have money, haven’t I?  

8. **Hindi:** पापा के पास कुछ है, है ना ?  
   **Romanized:** (Papa ke paas kuch hai, hai na?)  
   **English:** Father has something, hasn’t he?  

9. **Hindi:** उसके पास किताब थी, नहीं क्या ?  
   **Romanized:** (Uske paas kitab thi, nahin kya?)  
   **English:** He had a book, hadn’t he?  

10. **Hindi:** तुम स्कूल जाते हो, है ना?  
   **Romanized:** (Tum school jaate ho, hai na?)  
   **English:** You go to school, don’t you?  

11. **Hindi:** राम स्कूल जाता है, है ना?  
   **Romanized:** (Ram school jaata hai, hai na?)  
   **English:** Ram goes to school, doesn’t he?  

12. **Hindi:** वो खेल रही है, है ना ?  
   **Romanized:** (Vo khel rahi hai, hai na?)  
   **English:** She is playing, isn’t she?  

13. **Hindi:** तुमने ताजमहल देखा है, है कि नहीं ?  
   **Romanized:** (Tumane Taj Mahal dekha hai, hai ki nahin?)  
   **English:** You have seen the Taj, haven’t you?  

14. **Hindi:** वो स्कूल जायेगा, है ना?  
   **Romanized:** (Vo school jaayega, hai na?)  
   **English:** He will go to school, won’t he?  

15. **Hindi:** तुम वहाँ गये, है कि नहीं ?  
   **Romanized:** (Tum vahaan gaye, hai ki nahin?)  
   **English:** You went there, didn’t you?  

16. **Hindi:** मैं आया था, है कि नहीं ?  
   **Romanized:** (Main aaya tha, hai ki nahin?)  
   **English:** I had come, hadn’t I?  

17. **Hindi:** बस चली गयी होगी, है ना ?  
   **Romanized:** (Bus chali gayi hogi, hai na?)  
   **English:** Bus will have gone, won’t it ?  

18. **Hindi:** वो सो रहा होगा, है ना?  
   **Romanized:** (Vo so raha hoga, hai naa?)  
   **English:** He will be sleeping, won’t he?  

19. **Hindi:** तुम अकेले जा सकते हो, है कि नहीं ?  
   **Romanized:** (Tum akele jaa sakte ho, hai ki nahin?)  
   **English:** You can go alone, can’t you?  

20. **Hindi:** मुझे जाना चाहिए, क्या कहते हो ?  
   **Romanized:** (Mujhe jaana chahiye, kya kehte ho?)  
   **English:** I should go, shouldn’t I?  

21. **Hindi:** ये प्यार है, है ना ?  
   **Romanized:** (Ye pyaar hai, hai naa?)  
   **English:** It is love, isn’t it?  

22. **Hindi:** राम अच्छा नहीं है, है क्या ?  
   **Romanized:** (Raam acha nahin hai, hai kya?)  
   **English:** Ram is not good, is he?  

23. **Hindi:** तुम पागल नहीं हो, हो क्या ?  
   **Romanized:** (Tum pagal nahin ho, ho kya?)  
   **English:** You are not mad, are you?  

24. **Hindi:** मैं पागल नहीं हूँ, हूँ क्या ?  
   **Romanized:** (Main pagal nahin hoon, hoon kya?)  
   **English:** I am not mad, am I?  

25. **Hindi:** वो खुश नहीं था, था क्या ?  
   **Romanized:** (Vo khush nahin tha, tha kya?)  
   **English:** He was not happy, was he?  

26. **Hindi:** हम दुखी नहीं थे, थे क्या ?  
   **Romanized:** (Hum dukhi nahin the, the kya?)  
   **English:** We were not sad, were we?  

27. **Hindi:** मेरे पास पैसे नहीं हैं, हैं क्या ?  
   **Romanized:** (Mere paas paise nahin hai, hai kya?)  
   **English:** I don’t have money, do I?  

28. **Hindi:** राम के पास कुछ नहीं है, है क्या ?  
   **Romanized:** (Ram ke paas kuch nahin hai, hai kya?)  
   **English:** Ram doesn’t have anything, does he?  

29. **Hindi:** उसके पास किताब नहीं थी, थी क्या ?  
   **Romanized:** (Uske paas kitab nahin thi, thi kya?)  
   **English:** He didn’t have a book, did he?  

30. **Hindi:** तुम स्कूल नहीं जाते हो ना ?  
   **Romanized:** (Tum school nahin jate ho na?)  
   **English:** You don’t go to school, do you?  

31. **Hindi:** राम स्कूल नहीं जाता, है ना?  
   **Romanized:** (Ram school nahin jata, hai na?)  
   **English:** Ram doesn’t go to school, does he?  

32. **Hindi:** वो नहीं खेल रही है, है ना?  
   **Romanized:** (Vo nahin khel rahi, hai naa?)  
   **English:** She is not playing, is she?  

33. **Hindi:** तुमने ताजमहल नहीं देखा, है ना ?  
   **Romanized:** (Tumne tajmahal nahin dekha, hai naa?)  
   **English:** You haven’t seen the Taj, have you?  

34. **Hindi:** वो स्कूल नहीं जायेगा, है ना ?  
   **Romanized:** (Vo school nahi jayega, hai naa?)  
   **English:** He will not go to school, will he?  

35. **Hindi:** तुम वहाँ नहीं गये, है ना?  
   **Romanized:** (Tum wahaan nahin gaye, hai naa?)  
   **English:** You didn’t go there, did you?  

36. **Hindi:** मैं नहीं आया था, आया था क्या ?  
   **Romanized:** (Main nahin aaya tha, aaya thaa kya?)  
   **English:** I hadn’t come, had I?  

37. **Hindi:** बस नहीं गयी होगी, है ना ?  
   **Romanized:** (Bus nahin gayi hogi, hai na?)  
   **English:** Bus will not have gone, will it?  

38. **Hindi:** वो सो नहीं रहा होगा, है ना ?  
   **Romanized:** (Vo so nahin rahaa hoga, hai naa?)  
   **English:** He will not be sleeping, will he?  

39. **Hindi:** तुम नहीं जा सकते, है ना?  
   **Romanized:** (Tum nahi jaa sakte, hai naa?  
   **English:** You can’t go, can you?  

40. **Hindi:** मुझे जाना नहीं चाहिए, क्या कहते हो?  
   **Romanized:** (Mujhe jaana nahin chahiye, kya kehate ho?)  
   **English:** I shouldn’t go, should I?  

41. **Hindi:** ये प्यार नहीं है, है क्या ?  
   **Romanized:** (Ye pyaar nahin hai, hai kya?)  
   **English:** It is not love, is it?  

## Source-text and verification notes

- All 41 Hindi prompts and their printed Romanized lines appear on PDF pages 417–418; the 41-item English answer key spans pages 418–419. The prompt and answer sequences were verified from 1 through 41 and paired by number.
- The Hindi was extracted from individual scan rows and compared with the page images; two independent scan audits found all characters readable. Four clear OCR artifacts were corrected: a spurious comma in item 17, merged words in item 21, an extra full stop in item 26, and a stray apostrophe in item 27.
- Printed bilingual quirks are retained rather than silently rewritten: item 3 has no terminal punctuation in the Hindi; item 39’s Romanized line lacks a closing parenthesis; the printed spelling “jata” in item 31 is retained even though item 11 uses “jaata”. Other Romanized differences are also preserved, including Pinky (item 2) versus Hindi पिंकी, singular hai in item 27, and omitted hai in item 32.
- The English answer key is preserved as printed, including “I am bad, am I not?” and its other source word choices. No unreadable sections.

**Unreadable text:** none identified.

