# Lesson 21 — Use of LET

**PDF pages:** 294–303 (printed pages 293–302)

## Please translate the following sentences into English

1. **Hindi prompt:** वो मुझे फ्रूट्स खाने देता है।  
   **Romanized:** Vo mujhe fruits khane deta hai.  
   **English answer:** He lets me eat the fruits.

2. **Hindi prompt:** वो मुझे खेलने देता है।  
   **Romanized:** Vo mujhe khelne deta hai.  
   **English answer:** He lets me play.

3. **Hindi prompt:** वो मुझे फुटबाल खेलने देता है।  
   **Romanized:** Vo mujhe football khelne deta hai.  
   **English answer:** He lets me play football.

4. **Hindi prompt:** वो मुझे खेलने नहीं देता है।  
   **Romanized:** Vo mujhe khelne nahi deta hai.  
   **English answer:** He does not let me play.

5. **Hindi prompt:** क्या वो मुझे खेलने नहीं देता है?  
   **Romanized:** Kya vo mujhe khelne nahi deta hai?  
   **English answer:** Does he not let me play?

6. **Hindi prompt:** वो मुझे खेलने क्यों नहीं देता है?  
   **Romanized:** Vo mujhe khelne kyon nahi deta hai?  
   **English answer:** Why does he not let me play?

7. **Hindi prompt:** वो मुझे कब खेलने देता है?  
   **Romanized:** Vo mujhe kab khelne deta hai?  
   **English answer:** When does he let me play?

8. **Hindi prompt:** वो मुझे कहाँ खेलने देता है?  
   **Romanized:** Vo mujhe kahaan khelne deta hai?  
   **English answer:** Where does he let me play?

9. **Hindi prompt:** वो मुझे खेलने देता है।  
   **Romanized:** Vo mujhe khelne deta hai.  
   **English answer:** He lets me play.

10. **Hindi prompt:** मुझे उसके द्वारा खेलने दिया जाता है।  
   **Romanized:** Mujhe uske dwara khelne diya jata hai.  
   **English answer:** I am let play by him.

11. **Hindi prompt:** मुझे खेलने दिया जाता है।  
   **Romanized:** Mujhe khelne diya jata hai.  
   **English answer:** I am let play.

12. **Hindi prompt:** मुझे रवि के द्वारा खेलने दिया जाता है।  
   **Romanized:** Mujhe Ravi ke dwara khelne diya jata hai.  
   **English answer:** I am let play by Ravi.

13. **Hindi prompt:** वो मुझे खेलने दे रहा है।  
   **Romanized:** Vo mujhe khelne de raha hai.  
   **English answer:** He is letting me play.

14. **Hindi prompt:** मुझे खेलने दिया जा रहा है।  
   **Romanized:** Mujhe khelne diya ja raha hai.  
   **English answer:** I am being let play.

15. **Hindi prompt:** मुझे रवि के द्वारा खेलने दिया जा रहा है।  
   **Romanized:** Mujhe Ravi ke dwara khelne diya ja raha hai.  
   **English answer:** I am being let play by Ravi.

16. **Hindi prompt:** मैं उसे घर आने दूँगा।  
   **Romanized:** Main use ghar aane doonga.  
   **English answer:** I will let him come home.

17. **Hindi prompt:** मैं उसे घर नहीं आने दूँगा।  
   **Romanized:** Main use ghar nahi aane doonga.  
   **English answer:** I will not let him come home.

18. **Hindi prompt:** मैं क्यों आऊँ?  
   **Romanized:** Main kyon aaoon?  
   **English answer:** Why do I come? / Why shall I come?

19. **Hindi prompt:** मैं उसे घर क्यों आने दूँ?  
   **Romanized:** Main use ghar kyon aane doon?  
   **English answer:** Why do I let him come home? / Why shall I let him come home?

20. **Hindi prompt:** मुझे घर आने दिया गया।  
   **Romanized:** Mujhe ghar aane diya gaya.  
   **English answer:** I was let come home.

21. **Hindi prompt:** हमें बोलने नहीं दिया गया।  
   **Romanized:** Hame bolne nahi diya gaya.  
   **English answer:** We were not let speak.

22. **Hindi prompt:** बच्चे मुझे पढ़ने नहीं देते।  
   **Romanized:** Bachche mujhe padhne nahi dete.  
   **English answer:** Children don’t let me study.

23. **Hindi prompt:** उसे जाने क्यों नहीं दिया तुमने?  
   **Romanized:** Use jaane kyo nahi diya tumne?  
   **English answer:** Why did you not let him go?

24. **Hindi prompt:** मैडम ने क्लास में सिर्फ मुझे बैठने दिया।  
   **Romanized:** Madam ne class me sirf mujhe baithne diya.  
   **English answer:** Madam let only me sit in the class.

25. **Hindi prompt:** सरकार ने हमें बिल्डिंग नहीं बनाने दी।  
   **Romanized:** Sarkaar ne hame building nahi banane di.  
   **English answer:** The government didn’t let us construct a building.

26. **Hindi prompt:** माँ ने बच्चे को पिटने नहीं दिया।  
   **Romanized:** Maa ne bachche ko pitne nahi diya.  
   **English answer:** The mother didn’t let the child be beaten.

27. **Hindi prompt:** क्या तुम मुझे जाने दोगे अगर मैं तुम्हें ₹10 दूँ तो?  
   **Romanized:** Kya tum mujhe jaane doge agar main tumhe ₹10 doon to?  
   **English answer:** Will you let me go if I give you Rs 10?

28. **Hindi prompt:** मैं तुम्हें गाने सुनने दूँगा पर पहले पैसे दो।  
   **Romanized:** Main tumhe gane sunne doonga par pahle paise do.  
   **English answer:** I will let you listen to the songs but first, you give me money.

29. **Hindi prompt:** मेरा अकेलापन मुझे जीने नहीं देगा।  
   **Romanized:** Mera akelapan mujhe jeene nahi dega.  
   **English answer:** My loneliness will not let me live.

30. **Hindi prompt:** वो मुझे फोन करने दे सकता था।  
   **Romanized:** Vo mujhe phone karne de sakta tha.  
   **English answer:** He could let me call.

31. **Hindi prompt:** तुम मुझे शायद न जाने दो।  
   **Romanized:** Tum mujhe shayad na jane do.  
   **English answer:** You might not let me go.

32. **Hindi prompt:** मुझे शायद जाने दिया जाये।  
   **Romanized:** Mujhe shayad jaane diya jaaye.  
   **English answer:** I might be let go.

33. **Hindi prompt:** राम मुझे सोने नहीं देता।  
   **Romanized:** Ram mujhe sone nahi deta.  
   **English answer:** Ram doesn’t let me sleep.

34. **Hindi prompt:** तुम मुझे सोने देते हो।  
   **Romanized:** Tum mujhe sone dete ho.  
   **English answer:** You let me sleep.

35. **Hindi prompt:** क्या राम तुम्हें जाने देता है?  
   **Romanized:** Kya Ram tumhe jane deta hai?  
   **English answer:** Does Ram let you go?

36. **Hindi prompt:** मैं पढ़ने नहीं दूँगा।  
   **Romanized:** Main padhne nahi doonga.  
   **English answer:** I will not let study.

37. **Hindi prompt:** मैं तुम्हें पढ़ने नहीं दूँगा।  
   **Romanized:** Main tumhe padhne nahi doonga.  
   **English answer:** I will not let you study.

38. **Hindi prompt:** मैं किसी को भी पढ़ने नहीं दूँगा।  
   **Romanized:** Main kisi ko bhi padhne nahi doonga.  
   **English answer:** I will not let anyone study.

39. **Hindi prompt:** मैं हर किसी को पढ़ने दूँगा।  
   **Romanized:** Main har kisi ko padhne doonga.  
   **English answer:** I will let everyone study.

40. **Hindi prompt:** राम श्याम को आने देगा।  
   **Romanized:** Ram Shyam ko aane dega.  
   **English answer:** Ram will let Shyam come.

41. **Hindi prompt:** उसने मुझे कुछ नहीं करने दिया।  
   **Romanized:** Usne mujhe kuch nahi karne diya.  
   **English answer:** He didn’t let me do anything.

42. **Hindi prompt:** तुमने मुझे खाने नहीं दिया।  
   **Romanized:** Tumne mujhe khaane nahi diya.  
   **English answer:** You didn’t let me eat.

43. **Hindi prompt:** मम्मी मुझे टी.वी. देखने देती है।  
   **Romanized:** Mummy mujhe TV dekhne deti hai.  
   **English answer:** Mummy lets me watch the TV.

44. **Hindi prompt:** मम्मी मुझे टी.वी. नहीं देखने देती।  
   **Romanized:** Mummy mujhe TV nahi dekhne deti.  
   **English answer:** Mummy doesn’t let me watch the TV.

45. **Hindi prompt:** पापा सोचने नहीं देते और फिर डाँटते हैं।  
   **Romanized:** Papa sochne nahi dete aur phir daantte hai.  
   **English answer:** Dad doesn’t me let think and then scolds.

46. **Hindi prompt:** वो हमें घर में नहीं घुसने देगा।  
   **Romanized:** Vo hame ghar mein nahi ghusne dega.  
   **English answer:** He’ll not let us enter the house.

47. **Hindi prompt:** पापा हमें पेड़ पर नहीं चढ़ने देते।  
   **Romanized:** Papa hame ped par nahi chadhne dete.  
   **English answer:** Dad doesn’t let us climb upon the tree.

48. **Hindi prompt:** बच्चे मम्मी पापा को सोने नहीं देंगे।  
   **Romanized:** Bachche mummy papa ko sone nahi denge.  
   **English answer:** Children will not let mom and dad sleep.

49. **Hindi prompt:** मैं तुम्हें पैन से लिखने नहीं दे सकता।  
   **Romanized:** Main tumhein pen se likhne nahi de sakta.  
   **English answer:** I can’t let you write with a pen.

50. **Hindi prompt:** मैं तुम्हें आम तोड़ने दूँगा।  
   **Romanized:** Main tumhe aam todne doonga.  
   **English answer:** I’ll let you pluck the mangoes.

51. **Hindi prompt:** उस लड़के ने मुझे वहाँ खेलने नहीं दिया।  
   **Romanized:** Us ladke ne mujhe vaha khelne nahi diya.  
   **English answer:** That boy didn’t let me play there.

52. **Hindi prompt:** इस आदमी ने राम को यहाँ बैठने नहीं दिया।  
   **Romanized:** Is aadmi ne Ram ko yaha baithne nahi diya.  
   **English answer:** This man didn’t let Ram sit here.

53. **Hindi prompt:** मैं तुम्हें ये नहीं करने दूँगा।  
   **Romanized:** Main tumhe ye nahi karne doonga.  
   **English answer:** I will not let you do this.

54. **Hindi prompt:** वो अक्सर मुझे जाने देता है।  
   **Romanized:** Vo aksar mujhe jane deta hai.  
   **English answer:** He often lets me go.

55. **Hindi prompt:** हम कभी-कभी उसे खेलने देते थे।  
   **Romanized:** Hum kabhi-kabhi use khelne dete the.  
   **English answer:** We used to sometimes let him play.

56. **Hindi prompt:** पापा मुझे स्कूल जाने नहीं देते।  
   **Romanized:** Papa mujhe school jane nahi dete.  
   **English answer:** Dad doesn’t let me go to school.

57. **Hindi prompt:** मैं तुम्हारे दुख को बढ़ने नहीं दूँगा।  
   **Romanized:** Main tumhare dukh ko badhne nahi doonga.  
   **English answer:** I’ll not let your pain increase.

58. **Hindi prompt:** उसने मुझे कार नहीं चलाने दी।  
   **Romanized:** Usne mujhe car nahi chalane di.  
   **English answer:** He didn’t let me drive the car.

59. **Hindi prompt:** उसने मुझे बाइक नहीं चलाने दी।  
   **Romanized:** Usne mujhe bike nahi chalane di.  
   **English answer:** He didn’t let me ride the bike.

60. **Hindi prompt:** उसने मुझे मोबाइल नहीं खरीदने दिया।  
   **Romanized:** Usne mujhe mobile nahi khareedne diya.  
   **English answer:** He didn’t let me purchase the mobile.

61. **Hindi prompt:** उसने मुझे कम्प्यूटर नहीं चलाने दिया।  
   **Romanized:** Usne mujhe computer nahi chalane diya.  
   **English answer:** He didn’t let me operate the computer.

62. **Hindi prompt:** उसने मुझे पानी नहीं पीने दिया।  
   **Romanized:** Usne mujhe pani nahi peene diya.  
   **English answer:** He didn’t let me drink water.

63. **Hindi prompt:** उसने मुझे खाना नहीं खाने दिया।  
   **Romanized:** Usne mujhe khana nahi khane diya.  
   **English answer:** He didn’t let me eat the food.

64. **Hindi prompt:** क्या तुमने उसे बैठने दिया?  
   **Romanized:** Kya tumne use baithne diya?  
   **English answer:** Did you let him sit?

65. **Hindi prompt:** क्या उसने मुझे फोन करने दिया?  
   **Romanized:** kya usne mujhe phone karne diya?  
   **English answer:** Did he let me call/phone/ring?

66. **Hindi prompt:** तुमने उसे जाने क्यों दिया?  
   **Romanized:** Tumne use jane kyo diya?  
   **English answer:** Why did you let him go?

67. **Hindi prompt:** तुमने उसे खेलने क्यों दिया?  
   **Romanized:** Tumne use khelne kyo diya?  
   **English answer:** Why did you let him play?

68. **Hindi prompt:** उसकी मम्मी ने उसे घर से निकलने नहीं दिया।  
   **Romanized:** Uski Mummy ne use ghar se nikalne nahi diya.  
   **English answer:** His mother didn’t let him go out of home.

69. **Hindi prompt:** वो गरीब था इसलिए लोगों ने उसे जीने नहीं दिया।  
   **Romanized:** Vo gareeb tha isliye logo ne use jeene nahi diya.  
   **English answer:** He was poor that’s why people didn’t let him live.

70. **Hindi prompt:** क्या तुम मुझे चैन से जीने दे सकते हो?  
   **Romanized:** kya tum mujhe chain se jeene de sakte ho?  
   **English answer:** Can you let me live peacefully?

71. **Hindi prompt:** वो राम को लड़ने देगी।  
   **Romanized:** Vo Ram ko ladne degi.  
   **English answer:** She will let Ram fight.

72. **Hindi prompt:** वो पक्का मुझे जाने देगा।  
   **Romanized:** Vo pakka mujhe jane dega.  
   **English answer:** He must let me go. / He’ll definitely let me go.

73. **Hindi prompt:** भगवान आज बारिश होने देंगे।  
   **Romanized:** Bhagvaan aaj barish hone denge.  
   **English answer:** God will let it rain today.

74. **Hindi prompt:** कोई मुझे पढ़ने नहीं देता।  
   **Romanized:** koi mujhe padhne nahi deta.  
   **English answer:** Nobody lets me study.

75. **Hindi prompt:** मैं तुम्हें बाजार जाने दे रहा हूँ।  
   **Romanized:** Main tumhein bazaar jane de raha hoon.  
   **English answer:** I am letting you go to market.

76. **Hindi prompt:** हम सब उसे जीने नहीं देते।  
   **Romanized:** Hum sab use jeene nahi dete.  
   **English answer:** We all don’t let him live.

77. **Hindi prompt:** मुझे बर्गर क्यों नहीं खाने देते तुम?  
   **Romanized:** Mujhe Burger kyo nahi khane dete tum?  
   **English answer:** Why don’t you let me eat Burger?

78. **Hindi prompt:** वो मेरा दोस्त है इसलिए मैं उसे गलत नहीं करने देता।  
   **Romanized:** Vo mera dost hai isliye main use galat nahi karne deta.  
   **English answer:** He is my friend, that’s why I don’t let him do wrong.

79. **Hindi prompt:** पापा मुझे 18 साल से पहले कार नहीं चलाने देंगे।  
   **Romanized:** Papa mujhe 18 saal se pehle car nahi chalane denge.  
   **English answer:** Dad will not let me drive the car before 18.

80. **Hindi prompt:** तुम हमें जाने दो।  
   **Romanized:** Tum hamein jane do.  
   **English answer:** You let us go.

81. **Hindi prompt:** मैं तुम्हें जाने क्यों दूँ?  
   **Romanized:** Main tumhein jane kyo doon?  
   **English answer:** Why do I let you go?

82. **Hindi prompt:** उसने मुझे कभी रोने नहीं दिया।  
   **Romanized:** Usne mujhe kabhi rone nahi diya.  
   **English answer:** He never let me cry.

83. **Hindi prompt:** तुमने मुझे कभी हँसने नहीं दिया।  
   **Romanized:** Tumne mujhe kabhi hansne nahi diya.  
   **English answer:** You never let me laugh.

84. **Hindi prompt:** तुम न सोते हो न मुझे सोने देते हो।  
   **Romanized:** Tum na sote ho na mujhe sone dete ho.  
   **English answer:** You neither sleep nor let me sleep.

85. **Hindi prompt:** या तो मुझे जाने दो या फिर तुम जाओ।  
   **Romanized:** Ya to mujhe jane do ya phir tum jao.  
   **English answer:** Either you let me go or you go yourself.

86. **Hindi prompt:** मैंने उस दिन उसे फोन नहीं करने दिया।  
   **Romanized:** Maine us din use phone nahi karne diya.  
   **English answer:** I didn’t let him call/phone that day.

87. **Hindi prompt:** मैंने भी आने नहीं दिया।  
   **Romanized:** Maine bhi aane nahi diya.  
   **English answer:** Even I didn’t let come.

88. **Hindi prompt:** तुमने मुझे सोचने तक नहीं दिया।  
   **Romanized:** Tumne mujhe sochne tak nahi diya.  
   **English answer:** You didn’t even let me think.

89. **Hindi prompt:** वो मुझे भी सोने नहीं देता।  
   **Romanized:** Vo mujhe bhi sone nahi deta.  
   **English answer:** He doesn’t let me sleep either.

90. **Hindi prompt:** मैं न तुम्हें खेलने दूँगा न टी.वी. देखने दूँगा।  
   **Romanized:** Main na tumhein khelne doonga na TV dekhne doonga.  
   **English answer:** I’ll neither let you play nor watch TV.

91. **Hindi prompt:** हम तुम्हें एक सेकंड भी सोचने नहीं देंगे।  
   **Romanized:** Hum tumhe 1 second bhi sochne ni denge.  
   **English answer:** We’ll not let you think even for a second.

92. **Hindi prompt:** मैं तुम्हें मिठाई खाने दूँगा पर तब जब तुम मुझे भी दो।  
   **Romanized:** Main tumhein mithai khane doonga par tab jab tum mujhe bhi do.  
   **English answer:** I’ll let you eat sweets provided you give me too.

93. **Hindi prompt:** वो राम को जीने नहीं देता और तुम उसे मरने नहीं देते।  
   **Romanized:** Vo Ram ko jeene nahi deta aur tum use marne nahi dete.  
   **English answer:** He doesn’t let Ram live & you don’t let him die.

94. **Hindi prompt:** मैं तुम्हें एक्सरसाइज नहीं करने दूँगा।  
   **Romanized:** Main tumhein exercise nahi karne doonga.  
   **English answer:** I’ll not let you exercise.

95. **Hindi prompt:** मम्मी और पापा हमें खेलने देंगे।  
   **Romanized:** Mummy aur Papa hamein khelne denge.  
   **English answer:** Mom and dad will let us play.

96. **Hindi prompt:** क्या आप मेरे भाई को जाने दोगे?  
   **Romanized:** Kya aap mere bhai ko jane doge?  
   **English answer:** Will you let my brother go?

97. **Hindi prompt:** राहुल ने मुझे कोई भी काम कभी अकेले नहीं करने दिया।  
   **Romanized:** Rahul ne mujhe koi bhi kaam kabhi akele nahi karne diya.  
   **English answer:** Rahul never let me do any work alone.

98. **Hindi prompt:** वो हम बच्चों को मोबाइल नहीं छेड़ने देते हैं।  
   **Romanized:** Vo hum bachchon ko mobile nahi chedne dete hai.  
   **English answer:** He doesn’t let we kids touch his mobile.

99. **Hindi prompt:** बॉस मुझे सोचने तक नहीं देते।  
   **Romanized:** Boss mujhe sochne tak nahi dete.  
   **English answer:** Boss doesn’t even let me think.

100. **Hindi prompt:** मैं आपको सोचने क्यों दूँ?  
   **Romanized:** Main aapko sochne kyo doon?  
   **English answer:** Why do I let you think? / Why shall I let you think?

101. **Hindi prompt:** राम उसे क्यों जाने दे?  
   **Romanized:** Ram use kyo jane de?  
   **English answer:** Why does Ram let him go? / Why shall Ram let him go?

102. **Hindi prompt:** मम्मी मुझे ज़रूर पढ़ने देगी।  
   **Romanized:** Mummy mujhe zaroor padhne degi.  
   **English answer:** Mom will surely let me study.

103. **Hindi prompt:** यहाँ लोग मुझे चैन से जीने नहीं देते।  
   **Romanized:** Yaha log mujhe chain se jeene nahi dete.  
   **English answer:** People here don’t let me live peacefully.

104. **Hindi prompt:** बच्चे मुझे पढ़ने नहीं देते।  
   **Romanized:** Bachche mujhe padhne nahi dete.  
   **English answer:** The kids don’t let me study.

105. **Hindi prompt:** क्या उसने तुम्हें आने दिया?  
   **Romanized:** kya usne tumhein aane diya?  
   **English answer:** Did he let you come?

106. **Hindi prompt:** हमें क्यों नहीं बोलने दिया तुमने?  
   **Romanized:** Hamein kyo nahi bolne diya tumne?  
   **English answer:** Why did you not let us speak?

107. **Hindi prompt:** राम ने सीता को जहर क्यों खाने दिया?  
   **Romanized:** Ram ne Seeta ko zahar kyo khaane diya?  
   **English answer:** Why did Ram let Seeta eat poison?

108. **Hindi prompt:** सरकार हमें अपनी बात नहीं कहने देती।  
   **Romanized:** Sarkaar hame apni baat nahi kahne deti.  
   **English answer:** The government doesn’t let us say what we want.

109. **Hindi prompt:** मैं तुम्हें उस बच्चे को नहीं पीटने दूँगा।  
   **Romanized:** Main tumhe us bachche ko ni peetne dunga.  
   **English answer:** I will not let you beat that child.

110. **Hindi prompt:** राम तुम्हें कभी जीतने नहीं देगा।  
   **Romanized:** Ram tumhein kabhi jeetne nahi dega.  
   **English answer:** Ram will never let you win.

111. **Hindi prompt:** सीता का भाई मुझे अपने घर में नहीं घुसने देता।  
   **Romanized:** Seeta ka bhai mujhe apne ghar mein nahi ghusne deta.  
   **English answer:** Seeta’s brother doesn’t let me enter his home.

112. **Hindi prompt:** क्या तुम मुझे मिलने दोगे?  
   **Romanized:** Kya tum mujhe milne doge?  
   **English answer:** Will you let me meet?

113. **Hindi prompt:** लोग उसे मुझसे मिलने नहीं देते।  
   **Romanized:** log use mujhse milne nahi dete.  
   **English answer:** People don’t let him meet me.

114. **Hindi prompt:** मेरे पापा मुझे आने नहीं देते।  
   **Romanized:** Mere papa mujhe aane nahi dete.  
   **English answer:** My father doesn’t let me come.

115. **Hindi prompt:** सीता गीता को वहाँ जाने क्यों नहीं देती?  
   **Romanized:** Seeta Geeta ko vaha jane kyo nahi deti?  
   **English answer:** Why does Seeta not let Geeta go there?

116. **Hindi prompt:** मैं उसे जाने देता हूँ।  
   **Romanized:** Main use jane deta hu.  
   **English answer:** I let him go.

117. **Hindi prompt:** वो मुझे खेलने नहीं देता।  
   **Romanized:** Wo mujhe khelne nahi deta.  
   **English answer:** He does not let me play.

118. **Hindi prompt:** हमने राहुल को अन्दर आने दिया।  
   **Romanized:** Humne Rahul ko andar aane diya.  
   **English answer:** We let Rahul come in.

119. **Hindi prompt:** रवि उसे मिलने नहीं दे रहा है।  
   **Romanized:** Ravi use milne nahi de raha hai.  
   **English answer:** Ravi is not letting him meet.

120. **Hindi prompt:** पापा आपको नहीं जाने देंगे।  
   **Romanized:** Papa aapko nahi jane denge.  
   **English answer:** Papa will not let you go.

121. **Hindi prompt:** मैंने उसे जाने दिया।  
   **Romanized:** Maine use jaane diya.  
   **English answer:** I let him/her go.

122. **Hindi prompt:** आपको उसे बोलने देना चाहिए।  
   **Romanized:** Aapko use bolne dena chahiye.  
   **English answer:** You should let him speak.

123. **Hindi prompt:** वो मुझे बर्गर कभी खाने नहीं देगा।  
   **Romanized:** Wo mujhe burger kabhi khane nahi dega.  
   **English answer:** She will never let me eat burger.

124. **Hindi prompt:** आप मुझे सोचने तक नहीं देते।  
   **Romanized:** Aap mujhe sochne tak nahi dete.  
   **English answer:** You do not even let me think.

125. **Hindi prompt:** क्या आप कृपया मुझे 2 मिनट चैन की साँस लेने देंगे।  
   **Romanized:** Kya aap kripya mujhe 2 minute chain ki saans lene denge.  
   **English answer:** Would you please let me take a sign/breathe/heave of relief for 2 minutes.

126. **Hindi prompt:** मुझे पता लगाने दो कि वो कौन हैं।  
   **Romanized:** Mujhe pata lagane do ki vo kaun hain.  
   **English answer:** Let me find out who they are.

127. **Hindi prompt:** मुझे देखने दो, वो कहाँ है।  
   **Romanized:** Mujhe dekhne do, vo kahaan hai.  
   **English answer:** Let me see where he is.

128. **Hindi prompt:** मैं आपको जाने नहीं दूँगा।  
   **Romanized:** Main aapko jaane nahi doonga.  
   **English answer:** I’ll not let you go.

129. **Hindi prompt:** मेरे पिताजी ने 18 साल की उम्र से पहले मुझे कार नहीं चलाने दी।  
   **Romanized:** Mere pitaji ne 18 saal ki umr se pehle mujhe car nahi chalane di.  
   **English answer:** My dad didn’t let me drive the car before I turned 18.

130. **Hindi prompt:** मैं उसे अपने साथ खेलने देता था।  
   **Romanized:** Mai use apne saath khelne deta tha.  
   **English answer:** I used to let him play with me.

131. **Hindi prompt:** उसे पहले हालात को समझ लेने दो।  
   **Romanized:** Use pehle haalaat ko samajh lene do.  
   **English answer:** Let him understand the situation first.

132. **Hindi prompt:** उसे जाने दो।  
   **Romanized:** Use jaane do.  
   **English answer:** Let him go.

133. **Hindi prompt:** उसे मत जाने दो।  
   **Romanized:** Use mat jaane do.  
   **English answer:** Don’t let him go. / Let him not go.

134. **Hindi prompt:** आप बहुत थके हुए हैं, इसलिए मैं आपको आज के लिए आराम करने दूँगा।  
   **Romanized:** Aap bahut thake hue hain, isliye main aapko aaj ke liye aaraam karne doonga.  
   **English answer:** You are extremely tired, so I’ll let you take rest for today.

135. **Hindi prompt:** आप मुझे नहीं करने देते, जो मैं चाहता हूँ।  
   **Romanized:** Aap mujhe ni krne dete, jo mai chahta hu.  
   **English answer:** You don’t let me do what I want.

136. **Hindi prompt:** मैं किसी को भी अपने दोस्त का दिल नहीं दुखाने दूँगा।  
   **Romanized:** Mai kisi ko bhi apne dost ka dil nahi dukhane doonga.  
   **English answer:** I won’t let anyone hurt my friend.

137. **Hindi prompt:** वह आपको पार्टी में क्यों नहीं आने देती?  
   **Romanized:** Vo aapko party me kyu nahi aane deti?  
   **English answer:** Why does she not let you attend the party?

138. **Hindi prompt:** उसने अपनी बेटी को मोबाइल पर खेलने दिया।  
   **Romanized:** Usne apni beti ko mobile par khelne diya.  
   **English answer:** She let her daughter play on mobile.

139. **Hindi prompt:** वो मुझे किसी के साथ काम नहीं करने दे रहा है।  
   **Romanized:** Vo mujhe kisi ke sath kaam nahi karne de raha h.  
   **English answer:** He is not letting me work with anyone.

140. **Hindi prompt:** तुम्हें उसे अपने मोबाइल का उपयोग करने देना चाहिए; वो अब बच्चा नहीं है।  
   **Romanized:** Tumhe use apne mobile ka upyog karne dena chahiye; vo ab bachcha nahi hai.  
   **English answer:** You should let him use your mobile; he is no longer a kid.

141. **Hindi prompt:** मैं आपको अपने से कभी दूर नहीं जाने दूँगा।  
   **Romanized:** Mai aapko apne se kabhi door nahi jaane dunga.  
   **English answer:** I’ll never let you go away from me.

142. **Hindi prompt:** क्या आप कृपया मुझे अंदर आने देंगे?  
   **Romanized:** Kya aap kripya mujhe andar aane denge?  
   **English answer:** Would you please let me come in?

143. **Hindi prompt:** क्या आप मुझे एक गिलास पानी देंगे?  
   **Romanized:** Kya aap mujhe ek glass paani denge?  
   **English answer:** Would you please give me a glass of water?

144. **Hindi prompt:** ये जैसा है, वैसा ही रहने दो।  
   **Romanized:** Ye jaisa hai, vaisa hi rehne do.  
   **English answer:** Let it be, as it is.

145. **Hindi prompt:** हर किसी को उससे सवाल पूछने दो।  
   **Romanized:** Har kisi ko usse sawal puchne do.  
   **English answer:** Let everyone ask questions to him.

146. **Hindi prompt:** आज मुझे अपने साथ घर आने दो।  
   **Romanized:** Aaj mujhe apne saath ghar aane do.  
   **English answer:** Let me come home with you today.

147. **Hindi prompt:** उसने मुझे कभी भी इस बारे में जानने नहीं दिया।  
   **Romanized:** Usne mujhe kabhi bhi is baare me jaanne nahi diya.  
   **English answer:** He never let me know about it.

148. **Hindi prompt:** वो कब कब आपको कम्प्यूटर पर बैठने देता है?  
   **Romanized:** Vo kab kab aapko computer par baithne deta hai?  
   **English answer:** How often does he let you sit on the computer?

## Source-text and verification notes

- All 148 Hindi prompts and printed Romanized lines on PDF pages 294–300 were OCRed and visually checked against the page scans; clear numeral, spelling, spacing, and punctuation artifacts were corrected. No unreadable prompt sections.
- Prompt 148 is printed on PDF page 300 above the Answers heading. The answer key starts below it and continues through page 303; all 148 English answers were visually checked and paired with their same-number prompts.
- Slash-separated answer alternatives and source wording were retained. The answer-key sequence is unique and continuous from 1 to 148.

**Unreadable text:** none identified.

