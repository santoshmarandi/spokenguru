# Lesson 9 — Use of THERE

**PDF pages:** 68–86 (printed pages 67–85)

## Bilingual prompts and printed English answers

### 1. एक नल था।
**Romanized:** (Ek nal tha.)
**English answer:** There was a tap.

### 2. क्या तुम्हारा भाई वहाँ था?
**Romanized:** (Kya tumhara bhai wahaan tha?)
**English answer:** Was your brother there?

### 3. कोई है क्या?
**Romanized:** (Koi hai kya?)
**English answer:** Is there someone?

### 4. क्या आपके दिल में प्यार नहीं है?
**Romanized:** (Kya aapke dil mein pyaar nahi hai?)
**English answer:** Isn’t there love in your heart?

### 5. तुम वहाँ क्यों छिपे हुए हो?
**Romanized:** (Tum wahaan kyon chipe hue ho?)
**English answer:** Why are you hidden there?

### 6. जंगल में एक राजा रहता था।
**Romanized:** (Jungle mein ek raja rehta tha.)
**English answer:** There lived a king in the Jungle.

### 7. वहाँ कुछ नहीं था।
**Romanized:** (Wahaan kuch nahi tha.)
**English answer:** Nothing was there. / There was nothing.

### 8. एक राजा वहाँ गया।
**Romanized:** (Ek raja wahaan gaya.)
**English answer:** There went a king. / A king went there.

### 9. वहाँ क्या है?
**Romanized:** (Wahaan kya hai?)
**English answer:** What is there?

### 10. उस शहर में एक पार्क था।
**Romanized:** (Us shahar mein ek park tha.)
**English answer:** There was a park in that city.

### 11. क्या तुम वहाँ नहीं थे?
**Romanized:** (Kya tum vahaan nahi the?)
**English answer:** Were you not there?

### 12. क्लास में 3 लड़कियाँ बैठी थी।
**Romanized:** (Class mein 3 ladkiyaan baithee thee.)
**English answer:** There were 3 girls sitting in the class.

### 13. मेरे पापा वहाँ रहते थे।
**Romanized:** (Mere papa wahaan rehte the.)
**English answer:** There lived my dad. / My dad lived there.

### 14. टेबल पर पैन था।
**Romanized:** (Table par pen tha.)
**English answer:** There was a pen on the table.

### 15. तकिये के नीचे एक पत्र है।
**Romanized:** (Takiye ke neeche ek patr hai.)
**English answer:** There is a letter beneath/underneath the pillow.

### 16. वहाँ कोई नहीं होगा।
**Romanized:** (Vahan koi nahihoga.)
**English answer:** There will be no one.

### 17. तुम्हारे भाई के साथ एक आदमी खड़ा है।
**Romanized:** (Tumhare bhai ke saath ek aadmee khada hai.)
**English answer:** There is a man standing with your brother.

### 18. इस तरह के कई फूल हैं।
**Romanized:** (Is tarah ke kai phool hai.)
**English answer:** There are so many such flowers.

### 19. वहाँ देखने को कुछ नहीं है।
**Romanized:** (Vahan dekhne ko kuch nahi hai.)
**English answer:** There is nothing to see.

### 20. क्या क्लास में कोई नहीं है?
**Romanized:** (Kya class mein koi nahi hai?)
**English answer:** Isn’t there anyone in class?

### 21. खेलने के लिए लड़के नहीं है।
**Romanized:** (Khelne ke liye ladke nahi hai.)
**English answer:** There are no boys to play.

### 22. उसके बटुए में पैसे नहीं है।
**Romanized:** (Uske batue mein paise nahi hai.)
**English answer:** There is no money in his wallet.

### 23. इस कंपनी में आगे बढ़ने के कई अवसर हैं।
**Romanized:** (Is company me aage badne ke kai avsar hain.)
**English answer:** There are numerous opportunities in this company to grow.

### 24. जाने की ज़रूरत नहीं है।
**Romanized:** (Jaane ki jaroorat nahi hai.)
**English answer:** There is no need to go.

### 25. बर्गर खाने की कोई ज़रूरत नहीं।
**Romanized:** (Burger khane ki koi jaroorat nahi.)
**English answer:** There is no need to eat burger.

### 26. एक सांप था।
**Romanized:** (Ek saanp tha.)
**English answer:** There was a snake.

### 27. एक पेड़ है, जिसका रंग लाल है।
**Romanized:** (Ek ped hai, jiska rang laal hai.)
**English answer:** There is a tree, which is of red colour. / There is a tree of red colour.

### 28. क्या तुम्हारे पास वहाँ कुछ था?
**Romanized:** (Kya tumhare pass vahaan kuchh tha?)
**English answer:** Did you have something there?

### 29. उस कुएँ में पानी नहीं था।
**Romanized:** (Us kuye mein pani nahi tha.)
**English answer:** There was no water in that well.

### 30. जब कभी मैं परेशानी में था, तुम मेरे साथ थे।
**Romanized:** (Jab kabhi main pareshanee mein tha, tum mere saath the.)
**English answer:** Whenever I was in trouble, you were there with me.

### 31. मैंने जो कुछ किया, वहीं पर किया।
**Romanized:** (Maine jo kuch kiya, vahi par kiya.)
**English answer:** Whatever I did, I did there.

### 32. उसकी जिंदगी में खुशी नहीं है।
**Romanized:** (Uski zindagi mein khushi nahi hai.)
**English answer:** There is no joy in his life.

### 33. क्या वहाँ कुछ चल रहा है?
**Romanized:** (Kya vahan kuch chal raha hai?)
**English answer:** Is something going on there?

### 34. प्यार जैसी कोई चीज नहीं होती।
**Romanized:** (Pyaar jaisi koi cheez nahi hoti.)
**English answer:** There is nothing as such love.

### 35. ऐसा कोई शब्द नहीं होता।
**Romanized:** (Aisa koi shabd nahi hota.)
**English answer:** There is no word as such.

### 36. ऐसी कोई कहानी नहीं है।
**Romanized:** (Aisi koi kahani nahi hai.)
**English answer:** There is no such story.

### 37. ऐसा कोई गांव नहीं है।
**Romanized:** (Aisa koi gaanv nahi hai.)
**English answer:** There is no such village.

### 38. ऐसा कोई देश नहीं है, जहाँ सिर्फ जानवर रहते हो।
**Romanized:** (Aisa koi desh nahi hai, jahan sirf janvar rahte ho.)
**English answer:** There is no country as such, where there are only animals.

### 39. ऐसा कोई मोबाइल नहीं है, जिसे मैं ठीक नहीं कर सकता।
**Romanized:** (Aisa koi mobile nahi hai, jise main theek nahi kar sakta.)
**English answer:** There is no such a mobile, which I can’t repair.

### 40. क्या वहाँ कोई नहीं है?
**Romanized:** (Kya vahan koi nahi hai?)
**English answer:** Isn’t there anyone?

### 41. ऐसा कोई आदमी नहीं होता जिसे चोट नहीं लगती।
**Romanized:** (Aisa koi aadmi nhi hota jise chot ni lgti.)
**English answer:** There is no such a man, who doesn’t get hurt.

### 42. वहाँ कितने लोग हैं?
**Romanized:** (Wahaan kitne log hain?)
**English answer:** How many people are there?

### 43. वहाँ कितने लोग थे?
**Romanized:** (Wahaan kitne log the?)
**English answer:** How many people were there?

### 44. वहाँ क्या है?
**Romanized:** (Wahaan kya hai?)
**English answer:** What is there?

### 45. तुम वहाँ किसके साथ थे?
**Romanized:** (Tum vahan kiske saath the?)
**English answer:** With whom were you there?

### 46. उस गांव में बिजली नहीं है।
**Romanized:** (Us gaon mein bijlee nahi hai.)
**English answer:** There is no electricity in that village.

### 47. क्या तुम्हारे दिमाग में कुछ है?
**Romanized:** (Kya tumhare dimaag mein kuch hai?)
**English answer:** Is there something in your mind?

### 48. क्या इस जीवन में केवल दुख है?
**Romanized:** (Kya is jeevan mein kewal dukh hai?)
**English answer:** Is there only pain in this life?

### 49. वहाँ कौन सब लोग हैं?
**Romanized:** (Wahaan kaun sab log hai?)
**English answer:** Who all people are there?

### 50. क्या तुम्हारे पापा वहाँ नहीं थे?
**Romanized:** (Kya tumhare papa wahaan nahi the?)
**English answer:** Was your dad not there?

### 51. वहाँ कौन- कौन रहता है।
**Romanized:** (Wahaan kon-kon rehta hai.)
**English answer:** Who all live there?

### 52. मैंने वहाँ किसी को भी नहीं देखा।
**Romanized:** (Mene wahaan kisi ko bhi nahi dekha.)
**English answer:** I didn't see anyone there.

### 53. मैंने आपको वहाँ जाने के लिए पहले ही मना किया था।
**Romanized:** (Maine aapko wahaan jaane ke liye pahle hi mana kiya tha.)
**English answer:** I already told you to go there.

### 54. मेरे पापा अब वहाँ नहीं रहते है।
**Romanized:** (Mere papa ab wahaan nahi rehte hai.)
**English answer:** My father no longer lives there.

### 55. मैं आज तक वहाँ कभी गया ही नहीं।
**Romanized:** (Main aaj tak wahaan kabhi nahi gaya.)
**English answer:** I have never been there till date.

### 56. तुम वहाँ क्यों गए?
**Romanized:** (Tum wahaan kyon gaye?)
**English answer:** Why did you go there?

### 57. हमने वहाँ एक दिन गेम खेला था।
**Romanized:** (Hamne wahaan ek din game khela tha.)
**English answer:** We played a game there one day.

### 58. मैंने वहाँ चोरी नहीं की।
**Romanized:** (Maine wahaan chori nahi ki.)
**English answer:** I didn't steal there.

### 59. तुम्हारी मम्मी वहाँ तो नहीं है।
**Romanized:** (Tumhari mummy wahaan to nahi hai.)
**English answer:** Your mother is not there.

### 60. तुम वहाँ कब से रह रही हो?
**Romanized:** (Tum wahaan kab se rah rahi ho.)
**English answer:** How long have you been living there?

### 61. क्या मैंने तुमको कभी कहा कि वहाँ जाओ?
**Romanized:** (Kya maine tumko kabhi kaha ki wahan jao?)
**English answer:** Did I ever asked you to go there?

### 62. आपने कभी वहाँ की आइसक्रीम खायी है।
**Romanized:** (Aapne kabhi wahaan ki icecream khai hai.)
**English answer:** Have you ever eaten ice cream there?

### 63. मैं वहाँ घूमने आज तक नहीं गया हूँ।
**Romanized:** (Main wahaan ghoomne aaj tak nahi gaya hoon.)
**English answer:** I have not gone there for a walk till date.

### 64. तुम रोज़- रोज़ वहाँ क्यों चले जाते हो?
**Romanized:** (Tum roz-roz wahaan kyon chale jaate ho?)
**English answer:** Why do you go there everyday?

### 65. मैंने वहाँ कोई मारपीट नहीं की है।
**Romanized:** (Maine wahaan koi maar peet nahi ki hai.)
**English answer:** I haven't had any violence there.

### 66. तुमने वहाँ किस-किस को देखा था।
**Romanized:** (Tumne wahaan kis-kis ko dekha tha.)
**English answer:** Whom did you see there?

### 67. मैंने तुम्हें वहाँ किस लिए भेजा था।
**Romanized:** (Maine tumhe wahaan kis liye bheja tha.)
**English answer:** Why did I send you there?

### 68. शादी में वहाँ कितने लोग आये थे।
**Romanized:** (Shaadi mein wahaan kitne log aaye the.)
**English answer:** How many people had come there for the wedding?

### 69. वहाँ जितने भी लोग आए थे, सब आपको जानते थे।
**Romanized:** (Wahaan jitne bhi log aaye the, sab aapko jante the.)
**English answer:** All the people who came there knew you.

### 70. वहाँ आज बहुत ही ज़्यादा ठंड है।
**Romanized:** (Wahaan aaj bahut hee zyaada thand hai.)
**English answer:** It is very cold there today.

### 71. वहाँ आज पुलिस आयी थी।
**Romanized:** (Wahaan aaj police aayi thi.)
**English answer:** There the police came today.

### 72. वहाँ देखो कितना सुंदर नजारा है।
**Romanized:** (Wahaan dekho kitna sundar nazara hai.)
**English answer:** Look what a beautiful view there.

### 73. वहाँ देखो, क्या हो रहा है।
**Romanized:** (Wahaan dekho kya ho raha hai.)
**English answer:** Look there, what's going on.

### 74. वहाँ आज घूमने कौन- कौन जा रहा है।
**Romanized:** (Wahaan aaj ghumne kaun kaun ja raha hai.)
**English answer:** Who is going to visit there today?

### 75. वहाँ घूमने से अच्छा है, मैं घर में पढ़ाई करूँ।
**Romanized:** (Wahaan ghumne se acha hai, main ghar mein padhai karoon.)
**English answer:** It is better to study at home than to travel there.

### 76. वहाँ घूमने का बिल्कुल भी मन नहीं है।
**Romanized:** (Wahaan ghumne ka bilkul bhi man nahi hai.)
**English answer:** There is no desire to roam there at all.

### 77. तुमने पानी की बोतल को वहाँ क्यों रखा है?
**Romanized:** (Tumne pani ki bottle ko wahan kyon rakha hai?)
**English answer:** Why have you kept the water bottle there.

### 78. वहाँ पर एक नयी दुकान खोली गयी है।
**Romanized:** (Wahaan par ek nayi dukan kholi gayi hai.)
**English answer:** A new shop has been opened there.

### 79. मैं वहाँ लाइन में खड़ा नहीं होना चाहता हूँ।
**Romanized:** (Main wahaan line mein khada nahi hona chahta hu.)
**English answer:** I don't want to stand in line there.

### 80. मैंने वहाँ आज तक कभी भी इतनी भीड़ नहीं देखी।
**Romanized:** (Maine whaan aaj tak kabhi bhee itni bheed nahi dekhi.)
**English answer:** I have never seen such a crowd there till today.

### 81. वहाँ बैठ के चुपचाप से टीवी देखो।
**Romanized:** (Wahaan baith ke chup chap se T.V dekho.)
**English answer:** Sit there and watch TV silently.

### 82. वहाँ से देहरादून कितनी दूर है?
**Romanized:** (Wahaan se Dehradun kitni door hai?)
**English answer:** How far is Dehradun from there?

### 83. वहाँ से आने में इतनी देर क्यों लगी आपको?
**Romanized:** (Wahaan se aane mein itni der kyu lagi aapko.)
**English answer:** Why did it take you so long to come from there?

### 84. वहाँ से मत जाओ, रोड खराब है।
**Romanized:** (Wahaan se mat jaao, road kharaab hai.)
**English answer:** Don't go from there, the road is bad.

### 85. वहाँ से कोई भी शॉर्टकट रास्ता नहीं है।
**Romanized:** (Wahaan se koi bhi shortcut rasta nahi hai.)
**English answer:** There is no shortcut way out there.

### 86. मेरा वहाँ जाने का बिल्कुल भी मन नहीं है।
**Romanized:** (Mera wahaan jaane ka bilkul bhi man nahi hai.)
**English answer:** I don't feel like going there at all.

### 87. वहाँ किसकी लड़ाई हो रही है?
**Romanized:** (Wahaan kiski ladai ho rahi hai.)
**English answer:** Whose fight is going on there?

### 88. वहाँ जाकर कोई भी फ़ायदा नहीं है।
**Romanized:** (Wahaan jaakar koi bhee faayda nahi hai.)
**English answer:** There is no use going there.

### 89. मुझे वहाँ जाने से कोई नहीं रोक सकता।
**Romanized:** (Mujhe wahaan jaane se koi nahi rok sakta.)
**English answer:** No one can stop me from going there.

### 90. वहाँ जाकर कोई भी शरारत मत करना।
**Romanized:** (Wahaan jaakar koi bhi shararat mat karna.)
**English answer:** Don't do any mischief after going there.

### 91. वहाँ से रास्ता बंद है।
**Romanized:** (Wahaan se raasta band hai.)
**English answer:** From there the road is closed.

### 92. हमें वहाँ फालतू में क्यों भेजा जाता है?
**Romanized:** (Hamein wahaan faltu mein kyon bheja jata hai?)
**English answer:** Why are we sent there unnecessarily?

### 93. हमने आज वहाँ पापा को देखा।
**Romanized:** (Hamne aaj wahaan papa ko dekha.)
**English answer:** We saw Papa there today.

### 94. मुझे वहाँ कोई भी तो नहीं मिला।
**Romanized:** (Mujhe wahaan koi bhi to nahi mila.)
**English answer:** I didn't find anyone there.

### 95. अब मैं वहाँ कभी भी नहीं जाने वाला।
**Romanized:** (Ab main wahaan kabhi bhi nahi jaane wala.)
**English answer:** I will never go there again.

### 96. हम सब कल वहाँ घूमने जाएँगे।
**Romanized:** (Hum sab kal wahaan ghumne jayenge.)
**English answer:** All of us will go there for a walk tomorrow.

### 97. वहाँ देखो तुमने फिर से गन्दा कर दिया है।
**Romanized:** (Wahaan dekho tumne phir se ganda kar diya.)
**English answer:** Look there you messed up again

### 98. वहाँ देखो कितनी सारी भीड़ जमा हो रखी है।
**Romanized:** (Wahaan dekho kitni saari bheed jamaa ho rakhi hai.)
**English answer:** Look how many crowds have gathered there.

### 99. हमने तो आपको वहाँ कभी नहीं देखा।
**Romanized:** (Humne to aapko wahaan kabhi nahi dekha.)
**English answer:** We have never seen you there.

### 100. वहाँ से तुम गलत रास्ते पर चले गये हो।
**Romanized:** (Wahaan se tum galat raste par chale gaye ho.)
**English answer:** From there you have gone down the wrong path.

### 101. वहाँ आज बहुत ज़्यादा जाम लगा हुआ है।
**Romanized:** (Wahaan aaj bahut jaayda jaam laga hua hai.)
**English answer:** There is a lot of traffic jam there today.

### 102. रेनु को जल्दी वहाँ से घर लेकर आओ।
**Romanized:** (Renu ko jaldi wahaan se gahr lakar aao.)
**English answer:** Quickly bring Renu home from there.

### 103. वहाँ से मेरे घर 5 किमी की दूरी पर है।
**Romanized:** (Wahaan se mera ghar 5 km ki doori par hai.)
**English answer:** My house is 5 km away from there.

### 104. वहाँ और कौन- कौन था?
**Romanized:** (Wahaan aur kon kon tha.)
**English answer:** Who else was there?

### 105. वहाँ अब कोई भी नहीं रहता है।
**Romanized:** (Wahaan ab koi bhee nahi rehta hai.)
**English answer:** No one lives there anymore.

### 106. वहाँ रात को रुकने में बहुत मज़ा आता है।
**Romanized:** (Wahaan raat ko rukne me bahut maza aata h.)
**English answer:** It's a lot of fun to stay there for the night.

### 107. वहाँ की शादी का खाना बहुत ही अच्छा था।
**Romanized:** (Wahaa ki shadi ka khana bahut hi accha tha.)
**English answer:** The food over there at the wedding was very tasty.

### 108. परेशान मत हो, वहाँ तुमको कोई न कोई मिल ही जाएगा।
**Romanized:** (Pareshan mat ho, wahaan tumko koi na koi mil hi jayega.)
**English answer:** Don't be upset, you will definitely find someone there.

### 109. वहाँ जाने की ज़रूरत नहीं है।
**Romanized:** (Wahaan jaane kee zaroorat nahi hai.)
**English answer:** No need to go there.

### 110. वहाँ से तुमको कोई भी बस मिल जायेगी।
**Romanized:** (Wahaan se tumko koi bhi bus mil jayegi.)
**English answer:** From there you will get any bus.

### 111. मुझे नहीं पता, मैं वहाँ क्यों जा रहा हूँ।
**Romanized:** (Mujhe nahi pata, main wahaan kaun ja raha hu.)
**English answer:** I don't know why I am going there.

### 112. तुमने पानी की बोतल वहाँ क्यों रखी?
**Romanized:** (Tumane pani ko botal wahaan kyon rakhi?)
**English answer:** Why did you keep the water bottle there?.

### 113. वहाँ जाने से पहले एक बार सोच तो लेते।
**Romanized:** (Wahaan jaane se pehle ek baar soch to lete.)
**English answer:** You should have at least thought once before you went there.

### 114. तुम वहाँ रोज़- रोज़ क्यों जाते हो?
**Romanized:** (Tum wahaan roz-roz kyu jaate ho.)
**English answer:** Why do you go there everyday?

### 115. वहाँ का मौसम बहुत ही सुहावना होता है।
**Romanized:** (Wahaan ka mosam bahut hi suhavna hota h.)
**English answer:** The weather there is very pleasant.

### 116. वहाँ मैं एक बार ज़रूर जाना चाहता हूँ।
**Romanized:** (Wahaan mein ek baar zaroor jaana chaahta hu.)
**English answer:** I definitely want to go there once.

### 117. वहाँ जाकर राफ्टिंग ज़रूर करना।
**Romanized:** (Wahaan jakar Rafting Zaroor Karna.)
**English answer:** Go there and do rafting for sure.

### 118. वहाँ के ATM में आज पैसे नहीं है।
**Romanized:** (Wahaan ke ATM mein aaj paise nahi hai.)
**English answer:** There is no money in the ATM today.

### 119. हम वहाँ जाकर खूब मस्ती करने वाले है।
**Romanized:** (Hum wahaan jakar khoob masti karne wale h.)
**English answer:** We are going to go there and have a lot of fun.

### 120. वहाँ तुम्हारी मर्ज़ी बिल्कुल नहीं चलने वाली।
**Romanized:** (Wahaa tumhari marzi bilkul nahi chalne wali.)
**English answer:** Your will is not going to work there at all.

### 121. तुम्हारे पापा वहाँ किस जगह रहते हैं?
**Romanized:** (Tumhare papa wahaan kis jagah rehte hain?)
**English answer:** Where does your father live there?

### 122. वहाँ लिफ़्ट में कोई फंस गया है।
**Romanized:** (Wahaan lift mein koi fans gaya hai.)
**English answer:** There is someone stuck in the lift.

### 123. वहाँ कोई भी प्रिंट की मशीन नहीं है।
**Romanized:** (Wahaan koi bhi Print ki machine nahi hai.)
**English answer:** There is no print machine there.

### 124. लॉकडाउन की वजह से वहाँ की सारी दुकानें बंद हैं।
**Romanized:** (Lockdown ki wajah se wahaan ki sari dukane band hai.)
**English answer:** Due to the lockdown, all the shops there are closed.

### 125. वहाँ जाने के लिए हजारों रुपये किराया तो लगता ही है।
**Romanized:** (Wahaan jaane ke liye to hazaaron rupya kiraya to lagta hee hai.)
**English answer:** Thousands of rupees are charged for going there.

### 126. वहाँ के ट्रैफिक में फंसने से तो अच्छा है इधर से चलो।
**Romanized:** (Wahaan ke Traffic mein fasane se to acha hai ki idhar se chalo.)
**English answer:** It is better to walk from here than to get stuck in the traffic there.

### 127. वहाँ जाकर कोई भी ऐसा काम मत करना जिससे माता-पिता का सर झुके।
**Romanized:** (Wahaan jaakar koi bhi esa kaam mat karna jisse mata pita ka sir jhuke.)
**English answer:** Don’t do any such thing over there, which could let your parents down.

### 128. वहाँ जाने से अच्छा तो मेरे घर आ जाओ।
**Romanized:** (Wahaan jaane se acha to mere ghar aa jao.)
**English answer:** It’s better to go there than to come to my house.

### 129. वहाँ जाकर तुम दिन भर क्या-क्या काम करते हो।
**Romanized:** (Wahaan jakar tum din bhar kya-kya kaam karte ho.)
**English answer:** After going there, what all do you do the whole day?

### 130. वहाँ जितनी भी जमीन दिख रही है सब मेरी है।
**Romanized:** (Wahaan jitni bhi zameen dikh rahi hai, sab meri hai.)
**English answer:** All the land that is visible there is mine.

### 131. अगर तुम वहाँ जाओगे तो पंकज से मिलकर ज़रूर आना।
**Romanized:** (Agar tum wahaan jaaoge to Pankaj se milkar zaroor aana.)
**English answer:** If you will go there then definitely come to meet Pankaj.

### 132. आजकल वहाँ पर कोरोना के केस आने लग गए हैं।
**Romanized:** (Aajkal wahaan par corona ke case aane lag gaye hai.)
**English answer:** Nowadays cases of corona have started coming there.

### 133. कोरोना के कारण वहाँ की सारी गाड़ियां बंद हैं।
**Romanized:** (Corona ke kaaran wahan ki sari gadiya band hai.)
**English answer:** Due to Corona, all the vehicles there are closed.

### 134. वहाँ जाकर मुझे अपने भाई की बहुत याद आती है।
**Romanized:** (Wahaan jakar mujhe apne bhai ki bahut yaad aati hai.)
**English answer:** After going there, I miss my brother very much.

### 135. जहाँ हम बचपन में क्रिकेट खेला करते थे आज वहाँ पर बड़े-बड़े घर बन गए हैं।
**Romanized:** (Jahan ham bachpan mein cricket khela karte the aaj wahan par bade-bade ghar ban gaye hain.)
**English answer:** Where we played cricket in childhood; today, big houses have been built there.

### 136. वहाँ हम जब भी खेलते हैं, हमेशा हार जाते हैं।
**Romanized:** (Vahaan hum jab bhi khelte hain, hamesha har jate hai.)
**English answer:** There we always lose whenever we play.

### 137. कोरोना के कारण वहाँ के सभी स्कूले बंद किए जा चुके हैं।
**Romanized:** (Corona ke karan wahaan ke sabhi school band kiye ja chuke hai.)
**English answer:** All the schools there have been closed due to Corona.

### 138. इस समय वहाँ बहुत तेज़ गर्मी हो रही होगी।
**Romanized:** (Is samay wahaan bahut tez garmi ho rahi hogi.)
**English answer:** It must be getting very hot there at this time.

### 139. वहाँ मैं हर जगह घूम रखा हूँ।
**Romanized:** (Wahaan main har jagah ghoom rakha hoon.)
**English answer:** I have wandered everywhere over there.

### 140. वहाँ देखो, आपसे मिलने कौन आया है!
**Romanized:** (Wahaan dekho aap se milne kon aaya hai!)
**English answer:** Look over there, who has come to meet you!

### 141. वहाँ जाकर सबसे पहले दादी से मिलना।
**Romanized:** (Wahaan jakar sabse pahle dadi se milna.)
**English answer:** Going there and meeting grandmother first.

### 142. वहाँ पहुँचते ही मुझे कॉल ज़रूर करना।
**Romanized:** (Wahaan pahuchte hi mujhe call zaroor karna.)
**English answer:** Make sure to call me as soon as you reach there.

### 143. वहाँ जाकर तो मेरा दिमाग ही काम करना बंद कर देता है।
**Romanized:** (Wahaan jaakar to mera dimag hi kaam karna band kar deta hai.)
**English answer:** After going there, my brain stops working.

### 144. वहाँ तो तुम मुझसे बहुत अकड़ के बात कर रहे थे।
**Romanized:** (Wahaan to tum mujhse bahut akad ke baat kar rahe the.)
**English answer:** There you were talking to me very arrogantly.

### 145. वहाँ जाकर तुम क्या करोगे, जब तुम्हें कोई जानता ही नहीं।
**Romanized:** (Wahaan jakar tum kya karoge, jab tumhe koi jaanta hi nahi.)
**English answer:** What will you do after going there, when no one knows you?

### 146. मैंने शायद तुम्हें वहाँ देखा था।
**Romanized:** (Maine shayad tumhe wahaan dekha tha.)
**English answer:** I probably saw you there.

### 147. मैं वहाँ सिर्फ आपको ही देख रहा था, आप बहुत सुंदर लग रही थी।
**Romanized:** (Main wahaan sirf aapko hi dekh raha tha, aap bahut sundar lag rhi thi.)
**English answer:** I was there only looking at you, you looked so beautiful.

### 148. आपके पापा के साथ वहाँ और कौन रहता है?
**Romanized:** (Aapke papa ke sath wahan or kon rahta h.)
**English answer:** Who else lives there with your father?

### 149. तुम ही मुझे लेकर गये, वरना मैं वहाँ कभी नहीं जाता।
**Romanized:** (Tum hee mujhe gaye, warna main wahaan kabhi nahi jaata.)
**English answer:** You only took me there, otherwise I wouldn’t have gone there ever.

### 150. क्या वो सब अभी भी वहाँ रहते है।
**Romanized:** (Kya wo sab abhi bhi wahaan rahte hai.)
**English answer:** Do they all still live there?

### 151. सीधे घर आना रात को वहाँ मत रुकना।
**Romanized:** (Sidhe ghar aana raat ko wahaan mat rukna.)
**English answer:** Come home directly, don't stay there overnight.

### 152. वहाँ मत जाओ, आज वहाँ बहुत तेज़ बारिश हो रही है।
**Romanized:** (Wahaan mat jao, aaj wahaan bahut tez bearish ho rahi hai.)
**English answer:** Don't go there, it’s raining there heavily today.

### 153. आज वहाँ जाने के लिये बहुत देर हो गयी है, अब मैं कल जाऊँगा।
**Romanized:** (Aaj wahaan jaane ke liye bahut der ho gayi hai, ab main wahaan kal jaunga.)
**English answer:** It is too late to go there today, now I will go tomorrow.

### 154. वहाँ तुम्हें बहुत पैदल जाना होगा, क्या तुम चलोगे?
**Romanized:** (Wahan tumhe bahut paidal jaana hoga, kya tum chaloge?)
**English answer:** There you will have to walk a lot, will you walk?

### 155. वहाँ तुम अकेले कभी नहीं जाओगे।
**Romanized:** (Wahaan tum akele kabhi nahi jaaoge.)
**English answer:** There you will never go alone.

### 156. तुम अपने सारे दोस्तों को लेकर वहाँ क्यों गये?
**Romanized:** (Tum apne sare dosto ko lekar wahaan kyon gaye?)
**English answer:** Why did you go there with all your friends?

### 157. वहाँ से यहाँ लगभग कितने घंटे लगते है।
**Romanized:** (Wahaan se yahan lagbhag kitne ghante lagte hai.)
**English answer:** Approximately how many hours does it take to be here from there?

### 158. वहाँ जितना भी कूड़ा गिरा हुआ है, सब तुम्हें ही उठाना है।
**Romanized:** (Wahaan jitana bhee kooda gira hua hai, sab tumhe hi uthana hai.)
**English answer:** You have to pick up all the garbage that is scattered there.

### 159. वहाँ जाने से पहले क्या तुमने मुझे पूछा था?
**Romanized:** (Wahaan jaane se pehle kya tumne mujhe pucha tha?)
**English answer:** Did you ask me before going there?

### 160. वहाँ कितने लोग हैं?
**Romanized:** (Wahaan kitne log hai?)
**English answer:** How many people are there?

### 161. वहाँ जाने की बस मुझे कहाँ से मिलेगी?
**Romanized:** (Wahaan jaane ki bus mujhe kaha se milegi?)
**English answer:** Where will I get the bus to go there?

### 162. वहाँ जाने के लिये मेरे पास पैसे नहीं है।
**Romanized:** (Wahaan jaane ke liye mere paas paise nahi hai.)
**English answer:** I have no money to go there.

### 163. आते समय वहाँ से मेरे लिये एक गिफ़्ट लेकर ज़रूर आना।
**Romanized:** (Aaate samay wahaan se mere liye ek gift lekar zaroor aana.)
**English answer:** While coming, definitely bring a gift from there for me.

### 164. अब तक वहाँ मैच शुरू हो गया होगा।
**Romanized:** (Ab tak wahaan match shuru ho gaya hoga.)
**English answer:** By now the match would have started there.

### 165. वहाँ की दुकान पर राशन का सारा सामान मिलता है।
**Romanized:** (Wahaan ki dukaan par rashan ka saara saamaan milta hai.)
**English answer:** All the ration items are available at the shop there.

### 166. तुम्हें वहाँ गाड़ी ज़रूर रोकनी चाहिए थी।
**Romanized:** (Tumhe wahaan gaadi zaroor rokani chahiye thee.)
**English answer:** You must have stopped the car there.

### 167. वहाँ जाकर देखो, कुछ दिख रहा है?
**Romanized:** (Wahaan jaakar dekho, kuchh dikh raha hai?)
**English answer:** Go there and see, can you see something?

### 168. वहाँ जाने से पहले ज़रा सोच लो।
**Romanized:** (Wahaan jaane se pahle soch lo.)
**English answer:** Think a little bit before going there.

### 169. वहाँ जाने में बहुत खतरा है।
**Romanized:** (Wahaan jaane mein bahut khatra hai.)
**English answer:** There is great danger in going there.

### 170. आपके पापा वहाँ कितने दिनों से रह रहे हैं।
**Romanized:** (Aapke papa wahaa kitne dino se rah rahe h.)
**English answer:** How many days has your father been living there?

### 171. जहाँ भी देखो वहाँ भीड़ है।
**Romanized:** (Jahaan bhee dekho wahaan bheed hai.)
**English answer:** Wherever you look there is a crowd.

### 172. मैंने कभी नहीं सोचा था, कि मैं एक दिन वहाँ जाकर इतने पैसे कमा लूँगा।
**Romanized:** (Maine kabhi socha nahi tha, ki main ek din wahaan jakar kitne paise kama loonga.)
**English answer:** I had never thought that I would one day go there and earn so much money.

### 173. वहाँ जाने में जान का खतरा हो सकता है।
**Romanized:** (Wahaan jaane main jaan ka khatra ho sakta h.)
**English answer:** There may be danger to life in going there.

### 174. वहाँ जाने के लिये कुछ जेब खर्च तो चाहिए।
**Romanized:** (Wahaan jaane ke liye kuchh jeb kharch to chahiye.)
**English answer:** Some pocket money is needed to go there.

### 175. वहाँ जाने के लिये कोई भी रास्ता आज तक नहीं बना है।
**Romanized:** (Wahaan jaane ke liye koi bhi raasta aaj tak nahi bana hai.)
**English answer:** No road has been made till date to go there.

### 176. वहाँ मैं बस 5 मिनट में पहुँच जाऊँगा।
**Romanized:** (Wahaan main bas 5 minute main pahuch jaaonga.)
**English answer:** I will reach there in just 5 minutes.

### 177. वहाँ से पहुँचने के लिये 5 बसें बदलनी पड़ती है।
**Romanized:** (Wahaan se pahuchane ke liye 5 buse badalne lagti hai.)
**English answer:** One has to change 5 buses to reach there.

### 178. वहाँ से सारे गंदे बर्तन उठा के किचन में रखो।
**Romanized:** (Wahaan se sare gande bartan utha ke kitchen mein rakho.)
**English answer:** Pick up all the dirty utensils from there and keep them in the kitchen.

### 179. वहाँ की रोडों की हालत बहुत बेकार हो रखी है।
**Romanized:** (Wahaan kee rodo kee haalat bahut hee bekar ho rakhi hai.)
**English answer:** The condition of the roads there is very poor.

### 180. वहाँ के सभी जिले बहुत ही अच्छे है।
**Romanized:** (Wahaan ke sabhi jile bahut hi ache hai.)
**English answer:** All the districts there are very good.

### 181. क्या वहाँ कोई नहीं है?
**Romanized:** (Kya wahaan koi nahi hai?)
**English answer:** Isn't there anyone there?

### 182. वहाँ के गाँव के लोग बहुत ही अच्छे हैं।
**Romanized:** (Wahaan ke gaon ke log bahut hi ache hai.)
**English answer:** The people of the village there are very nice.

### 183. वहाँ के किसी-किसी घरों में बिजली की सुविधा अभी भी नहीं है।
**Romanized:** (Wahaan ke kisi- kisi gharon mein bijali ki suvidha abhi bhi nahi hai.)
**English answer:** There is still no electricity facility in any of the houses there.

### 184. वहाँ का जंगल रात को बहुत ही खतरनाक हो जाता है।
**Romanized:** (Wahaan ka jungle raat ko bahut hi khatarnak ho jata hai.)
**English answer:** There the forest becomes very dangerous at night.

### 185. वहाँ के जंगलों में लकड़ी काटना सख़्त मना है।
**Romanized:** (Wahaan ke jungalo mein lakadi kaatna sakht mana hai.)
**English answer:** It is strictly forbidden to cut wood in the forests there.

### 186. वहाँ की मिट्टी बहुत उपजाऊ है।
**Romanized:** (Wahaan ki mitti bahut upjau hai.)
**English answer:** The soil there is very fertile.

### 187. वहाँ हर परिवार में एक आदमी आर्मी में है।
**Romanized:** (Wahaan har parivar me ek admi Army me h.)
**English answer:** There is one man in every family in the army.

### 188. वहाँ का खाना मुझे बहुत पसंद है।
**Romanized:** (Wahaan ka khana mujhe bahut pasand hai.)
**English answer:** I love the food there.

### 189. वहाँ जाते-जाते मुझे भूल मत जाना।
**Romanized:** (Wahaan jaate jaate mujhe bhool mat jaana.)
**English answer:** Don't forget me while going there.

### 190. मैं वहाँ गलत रास्ते में चला गया था।
**Romanized:** (Main wahaan galat raste mein chala gaya tha.)
**English answer:** I had gone there in the wrong way.

### 191. वहाँ जाकर तुम बिगड़ मत जाना।
**Romanized:** (Wahaan jaakar tum bigad mat jaana.)
**English answer:** Going there, don't get spoilt/spoiled.

### 192. वहाँ जाकर अच्छे-अच्छे लोग भी बिगड़ जाते है।
**Romanized:** (Wahaan jaakar ache-ache log bhee bigad jaate hai.)
**English answer:** Even good people get spoilt/spoiled by going there.

### 193. मैं अपनी टीम को लेकर वहाँ ज़रूर जाऊँगा।
**Romanized:** (Main apni team ko lekar wahaan zaroor jaunga.)
**English answer:** I will definitely go there with my team.

### 194. मैं वहाँ जाकर अब कभी वापस नहीं आऊँगा।
**Romanized:** (Main wahaan jakar ab kabhi wapas nahi aaunga.)
**English answer:** I will go there and never come back.

### 195. बेटा, वहाँ जाने की ज़िद मत करो।
**Romanized:** (Beta wahaan jaane ki zid mat karo.)
**English answer:** Son, don't insist on going there.

### 196. वहाँ वही लोग जाते है, जो पेपर पास करते हैं।
**Romanized:** (Wahaan wahi log jaate hain jo paper pass karte hai)
**English answer:** Only those people go there, who pass the paper.

### 197. वहाँ के खाने का स्वाद एकदम बेकार है।
**Romanized:** (Wahaan ke khane ka swad ek dam bekar hai.)
**English answer:** The taste of the food there is absolutely useless.

### 198. वहाँ मुझे बिल्कुल भी नींद नहीं आती है।
**Romanized:** (Wahaan mujhe bilkul bhi neend nahi aati hai.)
**English answer:** There I do not sleep at all.

### 199. वहाँ की लाइफ स्टाइल मुझे बहुत पसंद है।
**Romanized:** (Wahaan ki life style mujhe bahut pasand hai.)
**English answer:** I love the lifestyle there.

### 200. वहाँ के लोग मुझे बिल्कुल भी पसंद नहीं आते है।
**Romanized:** (Wahaan ke log mujhe bilkul bhi pasand nahi aate hai.)
**English answer:** I do not like the people there at all.

### 201. वहाँ के रूम का ताला कितने बजे खोलोगे।
**Romanized:** (Wahaan ke room ka tala kitane baje khologe.)
**English answer:** At what time will you open the lock of the room there?

### 202. वहाँ के ऑफिस का टाइम कितने बजे से है?
**Romanized:** (Wahaan ke office ka time kitne baje se hai?)
**English answer:** What is the time of the office there?

### 203. जब भी तुम वहाँ से निकलोगे मुझे कॉल कर देना।
**Romanized:** (Jab bhi tum wahaan se nikle mujhe call kar dena.)
**English answer:** Give me a call whenever you leave from there.

### 204. वहाँ की शादी में मैंने बहुत डाँस किया।
**Romanized:** (Wahaan ki shaadi me mene bahut dance kiya.)
**English answer:** I danced a lot at the wedding there.

### 205. वहाँ आज मेला लगा हुआ है।
**Romanized:** (Wahaan aaj mela laga hua hai.)
**English answer:** There is a fair today.

### 206. क्या तुम्हारा भाई वहाँ था?
**Romanized:** (Kya tumhara bhai wahaan tha?)
**English answer:** Was your brother there?

### 207. वहाँ की दुकानों में आज फ्री राशन मिल रहा है।
**Romanized:** (Wahaan ki dukano mein aaj free raasan mil raha hai.)
**English answer:** Free ration is being available in the shops there today.

### 208. वहाँ आज भर्ती मेला लगा हुआ है।
**Romanized:** (Wahaan aaj bharti mela laga hua hai.)
**English answer:** A recruitment fair is being organized there today.

### 209. वहाँ आज बहुत दर्दनाक हादसा हो गया है।
**Romanized:** (Wahaan aaj bahut dardnak hadsa ho gaya hai.)
**English answer:** A very painful accident has happened there today.

### 210. वहाँ के भर्ती मेले में, मैं पहले भी गया हूँ।
**Romanized:** (Wahaan ki bharti mele mein main pahale bhee gaya hoon.)
**English answer:** I have been to the recruitment fair there before as well.

### 211. मेरे पापा वहाँ रहते थे।
**Romanized:** (Mere papa wahaan rehte the.)
**English answer:** My father used to live there.

### 212. वहाँ के कपड़ों की तो बात ही अलग है।
**Romanized:** (Wahaan ke kapdon ki to baat hi alag hai.)
**English answer:** The clothes from there are unique.

### 213. कल वहाँ डीजे रात 2:00 बजे तक बजा था।
**Romanized:** (Kal wahaan D.J raat 2 baje tak bajaa tha.)
**English answer:** Yesterday the DJ played there till 2:00 pm.

### 214. वहाँ के लोगों को बात करने की बिल्कुल तमीज़ नहीं है।
**Romanized:** (Wahaan ke logo ko baat karne ki bilkul tameez nahi hai.)
**English answer:** The people there have absolutely no manner to talk.

### 215. वहाँ का पानी मुझे बिल्कुल सूट नहीं करता है।
**Romanized:** (Wahaan ka pani mujhe bilkul suit nahi karta hai.)
**English answer:** The water there does not suit me at all.

### 216. वहाँ के लोग बहुत लंबी-लंबी गाड़ियों में घूमते हैं।
**Romanized:** (Wahaan ke log bahut lambi lambi gaadi mein ghoomta hai.)
**English answer:** The people there roam in very long vehicles.

### 217. ठंड में वहाँ बहुत ज़्यादा बर्फ़ गिरती है।
**Romanized:** (Thand mein wahaan bahut jaayda barf girti hain.)
**English answer:** A lot of snow falls there in winter.

### 218. वहाँ के लोगों को देखो दिन रात काम करते है।
**Romanized:** (Wahaan ke logo ko dekho din raat kaam karte hai.)
**English answer:** Look at the people there, they work day and night.

### 219. वहाँ समुद्र में बहुत बड़ी- बड़ी मछलियाँ होती हैं।
**Romanized:** (Wahaan samudar mein bahut badi-badi fish hoti hain.)
**English answer:** There are many big fish in the sea.

### 220. मुझे पता है, तुम वहाँ रोज़ क्यों जाते हो।
**Romanized:** (Mujhe pata hai, tum wahaan roz kyun jaate ho.)
**English answer:** I know why you go there everyday.

### 221. तुम्हारे वहाँ चाय की कोई भी अच्छी दुकान नहीं है।
**Romanized:** (Tumhare wahaan chai ki koi bhi achchhi dukan nahi hai.)
**English answer:** You don't have any good tea shops there.

### 222. वहाँ कोई भी मेरा अपना नहीं है।
**Romanized:** (Wahaan koi bhi mera apna nahi hai.)
**English answer:** No one there is my own.

### 223. मैं आज आपको वहाँ नहीं लेकर जा सकता।
**Romanized:** (Mai aaj aapko wahaan nahi lekar ja sakta.)
**English answer:** I can't take you there today.

### 224. मुझे आपके वहाँ कोई भी चीज़ें अच्छी नहीं लगी।
**Romanized:** (Mujhe aapke wahaan koi bhee cheeje achi nahi lagi.)
**English answer:** I don't like anything you have there.

### 225. वहाँ की दुकानों में कपड़े बहुत ही कम दामों में मिल जाते है।
**Romanized:** (Wahaan kee dookano mein kapde bahut hee kam damo mein mil jaate hai.)
**English answer:** Clothes are available at very low prices in the shops there.

### 226. वहाँ के सब लोग रात को 8 बजे ही सो जाते है।
**Romanized:** (Wahaan ke sab log raat ko 8 baje hi so jaate hai.)
**English answer:** Everyone there goes to sleep only at 8 o'clock in the night.

### 227. सर्दियों में वहाँ का पानी बहुत ही गर्म आता है।
**Romanized:** (Sardiyo mein wahaan ka pani bahut hi garam aata hai.)
**English answer:** In winter the water there comes very hot.

### 228. वहाँ जाने की तो मैंने कभी सोची भी नहीं थी।
**Romanized:** (Wahaan jaane ki to maine kabhi sochi bhi nahi thi.)
**English answer:** I had never even thought of going there.

### 229. वहाँ जाना है तो पहले होमवर्क कर लो।
**Romanized:** (Wahaan jana hai to pehle homework kar lo.)
**English answer:** If you want to go there, do your homework first.

### 230. वहाँ जाकर अपनी तबीयत का ख्याल रखना।
**Romanized:** (Wahaa jakar apni tabiyat ka khayal rakhna.)
**English answer:** Go there and take care of your health.

### 231. वहाँ जाने के लिए तुम्हारी जेब में पैसे हैं?
**Romanized:** (Wahaan jaane ke liye tumhari jeb mein paise h?)
**English answer:** Do you have money in your pocket to go there?

### 232. वहाँ जाकर तुम दिन दुनिया सब भूल जाते हो।
**Romanized:** (Wahaan jakar tum din-duniya sab bhool jaate ho.)
**English answer:** After going there, you forget the whole world.

### 233. वहाँ तुम्हारी कोई जान पहचान है?
**Romanized:** (Wahaan tumhari koi jaan pehchan hai?)
**English answer:** Do you have any acquaintances there?

### 234. वहाँ जाके तुम्हें कोई फायदा नहीं होने वाला।
**Romanized:** (Waha jake tumhe koi fayda nahi hone wala.)
**English answer:** To go there is of no use to you.

### 235. वहाँ की मिठाईयां बहुत फेमस है।
**Romanized:** (Wahaan ki mithaiyan bahut famous hai.)
**English answer:** The sweets there are very famous.

### 236. वहाँ के लोग तुम्हें चिढ़ाते क्यों है।
**Romanized:** (Wahaan ke log tumhe chidaate kyon hai.)
**English answer:** Why do the people there tease you?

### 237. राहुल का वहाँ आना जाना लगा रहता है।
**Romanized:** (Rahul ke wahaan aana jaana laga rehta hai.)
**English answer:** Rahul keeps coming and going there.

### 238. जब तक आप वहाँ हो अच्छे से पढ़ाई करो।
**Romanized:** (Jab tak aap wahaan ho ache se padhai karo.)
**English answer:** Till you are there, study well. / As long as you are there, study well.

### 239. तुम्हें वहाँ कूड़ा नहीं डालना चाहिए था।
**Romanized:** (Tumhen wahaan khuda nahi dalna chahiye tha.)
**English answer:** You shouldn't have thrown garbage there.

### 240. वहाँ ऊपर बंदर टंकी में चढ़ा है।
**Romanized:** (Wahaan Upar Bandar tanki mein chada hai.)
**English answer:** Up there the monkey has climbed into the tank.

### 241. मेरा वहाँ जाने का बहुत मन कर है।
**Romanized:** (Mera wahaan jaane ka bahut man kar raha hai.)
**English answer:** I am very keen to go there.

### 242. मैंने वहाँ जाकर तुम्हारे सामान में नहीं छेड़ा।
**Romanized:** (Maine wahaan jakar tumhare samne mein nahi cheda.)
**English answer:** I didn’t touch your belongings over there.

### 243. मैंने वहाँ कोई भी इंटरव्यू नहीं दिया।
**Romanized:** (Maine wahaan koi bhi interview nahi diya.)
**English answer:** I did not give any interview there.

### 244. वहाँ जाते जाते आज मुझे बहुत देर हो गई।
**Romanized:** (Wahaan jaate jaate mujhe bahut der ho gayi.)
**English answer:** Today I am very late on my way there.

### 245. जब तक मैं वहाँ पहुँचा तब तक गाड़ी निकल चुकी थी।
**Romanized:** (Jab tak main wahaan pahuncha tab tak gadi nikal chuki thi.)
**English answer:** By the time I reached there, the train had left.

### 246. मैंने वहाँ की हर एक जगह को घूम रखा है।
**Romanized:** (Maine wahaa ki hr jagah ko ghoom rakha h.)
**English answer:** I have visited every single place there.

### 247. मैं वहाँ पहले भी जा चुका हूँ।
**Romanized:** (Main wahaan pahale bhee jaa chuka hoon.)
**English answer:** I've been there earlier as well.

### 248. मैंने वहाँ जाने से पहले अपना कोरोना टैस्ट करा लिया था।
**Romanized:** (Maine wahaan jaane se pahle apna corona test kara liya tha.)
**English answer:** I got my corona test done before going there.

### 249. जब मैं वहाँ से आया तो मेरी जेब में पर्स नहीं था।
**Romanized:** (Jab main wahaan se aaya to meri jeb mein purse nahi tha.)
**English answer:** When I came from there, I did not have a purse in my pocket.

### 250. वहाँ रास्ते में मेरा पर्स कहीं गिर गया।
**Romanized:** (Wahaan raste mein mera purse kahi gir gaya.)
**English answer:** On the way there my purse fell somewhere.

### 251. जब मैं वहाँ पहुँचा तो बहुत तेज़ बारिश हो रही थी।
**Romanized:** (Jab main wahaan pahucha to bahut tez baarish ho rahi thi.)
**English answer:** When I reached there it was raining very heavily.

## Source-text notes

- **Item 111:** The printed Hindi says क्यों (kyon), but the printed Romanized line says kaun; both are preserved as printed.
- **Item 112:** The printed Hindi says पानी की बोतल, while the Romanized line reads pani ko botal; both are preserved as printed.
- **Item 149:** The printed Hindi includes लेकर (lekar), which is absent from the Romanized line; both are preserved as printed.
- **Item 172:** The printed Hindi says इतने पैसे (itne paise), while the Romanized line says kitne paise; both are preserved as printed.
- **Item 239:** The printed Hindi says कूड़ा (kooda), while the Romanized line says khuda; both are preserved as printed.
- **Item 241:** The printed Hindi reads मन कर है, while its Romanized line reads man kar raha hai; both are preserved as printed.
- **Item 242:** The printed Hindi says सामान (samaan), while the Romanized line says samne; both are preserved as printed.

**Editorial spelling cleanup:** Obvious OCR artifacts were corrected against the page images; a few common plural spellings were normalized where the printed form was plainly missing a nasal mark.

**Unreadable text:** none identified.

