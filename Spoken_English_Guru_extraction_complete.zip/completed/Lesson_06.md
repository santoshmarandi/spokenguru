# Lesson 6 — Three Degrees of Adverbs

**PDF pages:** 54–55 (printed pages 53–54)

## Adverbs and their three degrees

### 1. Gladly
**Answer:** Gladly – More gladly – Most gladly

### 2. Well
**Answer:** Well – Better – Best

### 3. Angrily
**Answer:** Angrily - More angrily - Most angrily

### 4. Brightly
**Answer:** Brightly - More brightly - Most brightly

### 5. Dimly
**Answer:** Dimly - More dimly- Most dimly

### 6. Freely
**Answer:** Freely - More freely - Most freely

### 7. Heavily
**Answer:** Heavily - More heavily - Most heavily

### 8. Loudly
**Answer:** Loudly - More loudly - Most loudly

### 9. Quietly
**Answer:** Quietly - More quietly - Most quietly

### 10. Sweetly
**Answer:** Sweetly - More sweetly - Most sweetly

### 11. Terribly
**Answer:** Terribly - More terribly - Most terribly

### 12. Badly
**Answer:** Badly - Worse - Worst

### 13. Far
**Answer:** Far - Farther - Farthest

### 14. Little
**Answer:** Little – Less - Least

### 15. Much/Many
**Answer:** Much/Many – More - Most

### 16. Well
**Answer:** Well – Better – Best

### 17. Forth
**Answer:** Forth – Further – Furthest

### 18. Ill
**Answer:** Ill – Worse – Worst

### 19. Nigh
**Answer:** Nigh – Nigher - Nighest and next

### 20. Late
**Answer:** Late – Later - Latest and last

### 21. Early
**Answer:** Early – Earlier - Earliest

### 22. Fast
**Answer:** Fast - Faster - Fastest

### 23. Hard
**Answer:** Hard – Harder - Hardest

### 24. High
**Answer:** High – Higher - Highest

### 25. Loud
**Answer:** Loud – Louder - Loudest

### 26. Near
**Answer:** Near – Nearer - Nearest

### 27. Soon
**Answer:** Soon – Sooner – Soonest

### 28. Slow
**Answer:** Slow – Slower – Slowest

### 29. Often
**Answer:** Often - More often - Most often

### 30. In
**Answer:** In – Inner – Innermost

### 31. Up
**Answer:** Up – Upper - Uppermost

---
**Verification:** All 31 prompts and 31 answer entries were checked against the two printed pages and paired by item number. No unreadable text; the lesson contains no Hindi text.

