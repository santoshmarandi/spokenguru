# Lesson 37 — Sentence Correction Exercise
Source: PDF pages 463–474 (printed pages 462–473).

**Correct the following sentences.**

## Original sentences and printed corrections
1. **Original:** Does he goes for a walk?  
   **Correct sentence (printed key):** Does he go for a walk?

2. **Original:** I doesn’t know what to do.  
   **Correct sentence (printed key):** I don’t know what to do.

3. **Original:** He is greatest.  
   **Correct sentence (printed key):** He is great. / He is the greatest.

4. **Original:** He don’t remember what I said.  
   **Correct sentence (printed key):** He doesn’t remember what I said.

5. **Original:** He has went to market.  
   **Correct sentence (printed key):** He has gone to market.

6. **Original:** He has been doing it since two years.  
   **Correct sentence (printed key):** He has been doing it for two years.

7. **Original:** All boys are naughty.  
   **Correct sentence (printed key):** All the boys are naughty.

8. **Original:** She must be standing on the door.  
   **Correct sentence (printed key):** She must be standing at the door.

9. **Original:** India is our country and we are it’s inhabitants.  
   **Correct sentence (printed key):** India is our country and we are her inhabitants.

10. **Original:** Hi, its me.  
   **Correct sentence (printed key):** Hi, it’s I.

11. **Original:** I have been working with you from yesterday.  
   **Correct sentence (printed key):** I have been working with you since yesterday.

12. **Original:** I have never seen such a wonderful people.  
   **Correct sentence (printed key):** I have never seen such wonderful people.

13. **Original:** He is one of the best friend of mine.  
   **Correct sentence (printed key):** He is one of the best friends of mine.

14. **Original:** Let he dance.  
   **Correct sentence (printed key):** Let him dance.

15. **Original:** I went market yesterday.  
   **Correct sentence (printed key):** I went to market yesterday.

16. **Original:** This is a womens park.  
   **Correct sentence (printed key):** This is a women’s park.

17. **Original:** He is going to the market.  
   **Correct sentence (printed key):** He is going to market.

18. **Original:** You, who is honest, shouldn’t do it.  
   **Correct sentence (printed key):** You, who are honest, shouldn’t do it.

19. **Original:** I, who is a good man, can never do it.  
   **Correct sentence (printed key):** I, who am a good man, can never do it.

20. **Original:** Neither the ball nor the bats was in good condition.  
   **Correct sentence (printed key):** Neither the ball nor the bats were in good condition.

21. **Original:** Neither the bats nor the ball were in good condition.  
   **Correct sentence (printed key):** Neither the bats nor the ball was in good condition.

22. **Original:** It take 2 minutes.  
   **Correct sentence (printed key):** It takes 2 minutes.

23. **Original:** The director and the producer is dead.  
   **Correct sentence (printed key):** The director and the producer are dead.

24. **Original:** The director and producer are dead.  
   **Correct sentence (printed key):** The director and producer is dead.

25. **Original:** Director and Producer is dead.  
   **Correct sentence (printed key):** Director and Producer are dead.

26. **Original:** Neither my brother nor I is happy.  
   **Correct sentence (printed key):** Neither my brother nor I am happy.

27. **Original:** Either she or I is telling a lie.  
   **Correct sentence (printed key):** Either she or I am telling a lie.

28. **Original:** Either I or she is telling a lie.  
   **Correct sentence (printed key):** Either I or she is telling a lie.

29. **Original:** Ajay as well as his brothers deserve the award.  
   **Correct sentence (printed key):** Ajay as well as his brothers deserves the award.

30. **Original:** I have seen the film and she has also.  
   **Correct sentence (printed key):** I have seen the film and so has she.

31. **Original:** The bus left before we reached.  
   **Correct sentence (printed key):** The bus had left before we reached.

32. **Original:** He is addicted to smoke.  
   **Correct sentence (printed key):** He is addicted to smoking.

33. **Original:** He never hesitates to sing.  
   **Correct sentence (printed key):** He never hesitates in singing.

34. **Original:** He has passion to read books.  
   **Correct sentence (printed key):** He has passion for reading books.

35. **Original:** Mr. Kumar is my English Teacher.  
   **Correct sentence (printed key):** Mr. Kumar is my teacher of English.

36. **Original:** His Exam starts from Monday.  
   **Correct sentence (printed key):** His Exam starts on Monday.

37. **Original:** I have learnt it word by word.  
   **Correct sentence (printed key):** I have learnt it word for word.

38. **Original:** It’s female compartment.  
   **Correct sentence (printed key):** It’s a ladies’ compartment.

39. **Original:** It’s color is black.  
   **Correct sentence (printed key):** Its color is black.

40. **Original:** Open your book in page number 8.  
   **Correct sentence (printed key):** Open your book at page number 8.

41. **Original:** Mr. Kumar is my Mathematics teacher.  
   **Correct sentence (printed key):** Mr. Kumar is my teacher of Mathematics.

42. **Original:** This is the house whose roof leaks.  
   **Correct sentence (printed key):** This is the house the roof of which leaks.

43. **Original:** This is the chair whose legs are broken.  
   **Correct sentence (printed key):** This is the chair the legs of which are broken.

44. **Original:** He died from Cancer.  
   **Correct sentence (printed key):** He died of Cancer.

45. **Original:** He died with Typhoid.  
   **Correct sentence (printed key):** He died of Typhoid.

46. **Original:** He is going to the school.  
   **Correct sentence (printed key):** He is going to school.

47. **Original:** I am coming from the hospital.  
   **Correct sentence (printed key):** I am coming from hospital.

48. **Original:** I am sitting at the home.  
   **Correct sentence (printed key):** I am sitting at home.

49. **Original:** I have lost my patience.  
   **Correct sentence (printed key):** I have lost patience.

50. **Original:** I say you.  
   **Correct sentence (printed key):** I say to you.

51. **Original:** Mr. Kumar is my Science teacher.  
   **Correct sentence (printed key):** Mr. Kumar is my teacher of science.

52. **Original:** I resigned from HCL and joined IBM.  
   **Correct sentence (printed key):** I resigned HCL and joined IBM.

53. **Original:** First in all, I told him about his mistakes.  
   **Correct sentence (printed key):** First of all, I told him about his mistakes.

54. **Original:** We need a house to live.  
   **Correct sentence (printed key):** We need a house to live in.

55. **Original:** Raju secured only passing marks in Maths.  
   **Correct sentence (printed key):** Raju secured only pass marks in Maths.

56. **Original:** No less than hundred soldiers were died in that blast.  
   **Correct sentence (printed key):** No fewer than hundred soldiers were died in that blast.

57. **Original:** One day, you will be of my age.  
   **Correct sentence (printed key):** One day you will be my age.

58. **Original:** You have got perfect furnitures.  
   **Correct sentence (printed key):** You have got perfect furniture.

59. **Original:** He is master of English.  
   **Correct sentence (printed key):** He is a master of English.

60. **Original:** My trouser is old.  
   **Correct sentence (printed key):** My trousers are old.

61. **Original:** My scissors are sharp.  
   **Correct sentence (printed key):** My scissors are sharp.

62. **Original:** Riches is transitory.  
   **Correct sentence (printed key):** Riches is transitory.

63. **Original:** Mr. Goyal is my Commerce teacher.  
   **Correct sentence (printed key):** Mr. Goyal is my teacher of Commerce.

64. **Original:** The sheep is grazing.  
   **Correct sentence (printed key):** The sheep are grazing.

65. **Original:** Mr. Kumar is my Hindi teacher.  
   **Correct sentence (printed key):** Mr. Kumar is my teacher of Hindi.

66. **Original:** My hair are black.  
   **Correct sentence (printed key):** My hair is black.

67. **Original:** I found two hair in vegetable.  
   **Correct sentence (printed key):** I found two hairs in vegetable.

68. **Original:** Rahul looks me.  
   **Correct sentence (printed key):** Rahul looks at me.

69. **Original:** Hindustan times is a newspaper.  
   **Correct sentence (printed key):** The Hindustan Times is a newspaper.

70. **Original:** He lives in UK.  
   **Correct sentence (printed key):** He lives in the UK.

71. **Original:** My house is made of the stone.  
   **Correct sentence (printed key):** My house is made of stone.

72. **Original:** He invited me for the lunch.  
   **Correct sentence (printed key):** He invited me to lunch.

73. **Original:** Ram’s and Mohan’s houses is under repair.  
   **Correct sentence (printed key):** Ram’s and Mohan’s houses are under repair.

74. **Original:** I appeared in B.Tech Exam in June this year.  
   **Correct sentence (printed key):** I appeared at B. Tech Exam in June this year.

75. **Original:** Sit in the door.  
   **Correct sentence (printed key):** Sit at the door.

76. **Original:** Somebody is knocking on the door.  
   **Correct sentence (printed key):** Somebody is knocking at the door.

77. **Original:** The thief escaped off the police.  
   **Correct sentence (printed key):** The thief escaped from the police.

78. **Original:** I have got an account in Allahabad bank.  
   **Correct sentence (printed key):** I have got an account with Allahabad bank.

79. **Original:** Open fifth page.  
   **Correct sentence (printed key):** Open at the fifth page.

80. **Original:** He is writing by a pen.  
   **Correct sentence (printed key):** He is writing with a pen.

81. **Original:** None of you was present in the class.  
   **Correct sentence (printed key):** None of you were present in the class.

82. **Original:** Each one of you are my friend.  
   **Correct sentence (printed key):** Each one of you is my friend.

83. **Original:** My friends enjoyed in the party.  
   **Correct sentence (printed key):** My friends enjoyed themselves in the party.

84. **Original:** You should avail the facilities.  
   **Correct sentence (printed key):** You should avail yourself the facilities.

85. **Original:** God helps all the rich & poor people.  
   **Correct sentence (printed key):** God helps all the rich & the poor.

86. **Original:** Many a students is working hard.  
   **Correct sentence (printed key):** Many a student is working hard.

87. **Original:** Call me anything else than a donkey.  
   **Correct sentence (printed key):** Call me anything else but a donkey.

88. **Original:** How clever man is he!  
   **Correct sentence (printed key):** How clever man he is!

89. **Original:** The teacher had hardly reached the class, then the students began to make a noise.  
   **Correct sentence (printed key):** The teacher had hardly reached the class, when the students began to make a noise.

90. **Original:** No sooner had I reached the room, then you started studying.  
   **Correct sentence (printed key):** No sooner had I reached the room, than you started studying.

91. **Original:** I love to walk in the park.  
   **Correct sentence (printed key):** I love walking in the park.

92. **Original:** He likes to music more than his life.  
   **Correct sentence (printed key):** He likes music more than his life.

93. **Original:** He loves to read the newspaper.  
   **Correct sentence (printed key):** He loves reading the newspaper.

94. **Original:** Unless you don’t go there, nothing will change.  
   **Correct sentence (printed key):** Unless you go there, nothing will change.

95. **Original:** Work hard lest you may fail the exam.  
   **Correct sentence (printed key):** Work hard lest you should fail the exam.

96. **Original:** The manager and the director is dead.  
   **Correct sentence (printed key):** The manager and the director are dead.

97. **Original:** He will come home in Christmas.  
   **Correct sentence (printed key):** He will come home at Christmas.

98. **Original:** You can cut the potato by a knife.  
   **Correct sentence (printed key):** You can cut the potato with a knife.

99. **Original:** Take the book from the table.  
   **Correct sentence (printed key):** Take the book off the table.

100. **Original:** I enjoy myself a lot during summer.  
   **Correct sentence (printed key):** I enjoy myself a lot during the summer.

101. **Original:** The singer and philosopher are dead.  
   **Correct sentence (printed key):** The singer and philosopher is dead.

102. **Original:** The singer and the philosopher is dead.  
   **Correct sentence (printed key):** The singer and the philosopher are dead.

103. **Original:** Neither Ali nor his friends was present in the party.  
   **Correct sentence (printed key):** Neither Ali nor his friends were present in the party.

104. **Original:** Many a girl love Rahul.  
   **Correct sentence (printed key):** Many a girl loves Rahul.

105. **Original:** I have purchase 12 dozen bananas.  
   **Correct sentence (printed key):** I have purchased 10 dozen bananas.

106. **Original:** He gave me an advice.  
   **Correct sentence (printed key):** He gave me a piece of advice.

107. **Original:** Did he advice you?  
   **Correct sentence (printed key):** Did he advise you?

108. **Original:** Each of the ladies perform her duty well.  
   **Correct sentence (printed key):** Each of the ladies performs her duty well.

109. **Original:** The crocodile is the largest of all other reptiles.  
   **Correct sentence (printed key):** The crocodile is the largest of all the reptiles.

110. **Original:** Preeti is the best of all other students in the class.  
   **Correct sentence (printed key):** Preeti is the best of all the students in the class.

111. **Original:** Swati is more smarter than Neha.  
   **Correct sentence (printed key):** Swati is smarter than Neha.

112. **Original:** I lain the book on the table.  
   **Correct sentence (printed key):** I laid the book on the table.

113. **Original:** He made me to go there.  
   **Correct sentence (printed key):** He made me go there.

114. **Original:** I discussed about the matter.  
   **Correct sentence (printed key):** I discussed the matter.

115. **Original:** I am so happy today.  
   **Correct sentence (printed key):** I am very happy today.

116. **Original:** He was so tired to walk any further.  
   **Correct sentence (printed key):** He was too tired to walk any further.

117. **Original:** He had told to me.  
   **Correct sentence (printed key):** He had told me.

118. **Original:** I am working ever since you went out.  
   **Correct sentence (printed key):** I have been working ever since you went out.

119. **Original:** He is not such person who can fight till the end.  
   **Correct sentence (printed key):** He is not such a person who can fight till the end.

120. **Original:** My parents got me written a letter.  
   **Correct sentence (printed key):** My parents got me write a letter./ My parents made me to write a letter./ My parents got a letter written by me.

121. **Original:** He keep on calling me fool.  
   **Correct sentence (printed key):** He keeps on calling me fool.

122. **Original:** He gets up early in morning.  
   **Correct sentence (printed key):** He gets up early in the morning.

123. **Original:** His awkward behavior suggest that he is not social.  
   **Correct sentence (printed key):** His awkward behavior suggests that he is not social.

124. **Original:** None of Ram & Shyam are my friend.  
   **Correct sentence (printed key):** None of Ram & Shyam is my friend.

125. **Original:** Hardly had he left the campus, then it started hailing.  
   **Correct sentence (printed key):** Hardly had he left the campus than it started hailing.

126. **Original:** Did you not tell him something?  
   **Correct sentence (printed key):** Did you not tell him anything?

127. **Original:** Rain has started.  
   **Correct sentence (printed key):** It has started raining.

128. **Original:** He made me wait three hours.  
   **Correct sentence (printed key):** He made me wait for three hours.

129. **Original:** He had told me that he will not go.  
   **Correct sentence (printed key):** He had told me that he would not go.

130. **Original:** The Earth is revolving around Sun.  
   **Correct sentence (printed key):** The Earth is revolving around the Sun.

131. **Original:** Despite of the problems, he did it.  
   **Correct sentence (printed key):** Despite the problems, he did it.

132. **Original:** He was surrounded by so many of his fans.  
   **Correct sentence (printed key):** He was surrounded with so many of his fans.

133. **Original:** The construction of this house need more people now.  
   **Correct sentence (printed key):** The construction of this house needs more people now.

134. **Original:** On the time of entry, they were shouting unneccessarily.  
   **Correct sentence (printed key):** At the time of entry, they were shouting unneccessarily.

135. **Original:** The boss has made compulsory for the employees come at sharp 10 am.  
   **Correct sentence (printed key):** The boss has made compulsory for the employees come at sharp 10 am.

136. **Original:** Smoking is injurious for health.  
   **Correct sentence (printed key):** Smoking is injurious to health.

137. **Original:** She refrains to meet him.  
   **Correct sentence (printed key):** She refrains from meeting him.

138. **Original:** Why do you dare go there?  
   **Correct sentence (printed key):** Why do you dare to go there?

139. **Original:** Anyone of the two girls can do this work.  
   **Correct sentence (printed key):** Either of the two girls can do this work.

140. **Original:** The construction of new house is going on since 2019.  
   **Correct sentence (printed key):** The construction of new house has been going on since 2019.

141. **Original:** A lot of pens and pencils was thrown into the dustbin.  
   **Correct sentence (printed key):** A lot of pens and pencils were thrown into the dustbin.

142. **Original:** This story is much interesting.  
   **Correct sentence (printed key):** This story is very interesting.

143. **Original:** He will have finish the work by evening.  
   **Correct sentence (printed key):** He will have finished the work by the evening

144. **Original:** If you will heat the ice, it will turn to water.  
   **Correct sentence (printed key):** If you heat ice, it will turn to water.

145. **Original:** She persisted me to visit Agra.  
   **Correct sentence (printed key):** She persisted me on visiting Agra.

146. **Original:** He is the best of the two players.  
   **Correct sentence (printed key):** He is better of the two players.

147. **Original:** He doesn’t know who I am?  
   **Correct sentence (printed key):** He doesn’t know who I am.

148. **Original:** He doesn’t know who am I?  
   **Correct sentence (printed key):** He doesn’t know who I am.

149. **Original:** Do you know who am I?  
   **Correct sentence (printed key):** Do you know who I am?

150. **Original:** If you worked every day, you would have finished it by now.  
   **Correct sentence (printed key):** If you had worked every day, you would have finished it by now.

151. **Original:** The building was white, unless he painted it blue.  
   **Correct sentence (printed key):** The building was white, until he painted it blue.

152. **Original:** You know him, do you?  
   **Correct sentence (printed key):** You know him, don’t you?

153. **Original:** You don’t know him, don’t you?  
   **Correct sentence (printed key):** You don’t know him, do you?

154. **Original:** He is more smarter than you.  
   **Correct sentence (printed key):** He is smarter than you.

155. **Original:** If I won a lottery, I will buy a new car.  
   **Correct sentence (printed key):** If I won a lottery, I would buy a new car.

156. **Original:** I knew who he is.  
   **Correct sentence (printed key):** I knew who he was.

157. **Original:** You, who is a good guy, shouldn’t tell a lie.  
   **Correct sentence (printed key):** You, who are a good guy, shouldn’t tell a lie.

158. **Original:** Have the pens returned by him?  
   **Correct sentence (printed key):** Have the pens been returned by him?

159. **Original:** Until he didn’t come, I waited.  
   **Correct sentence (printed key):** Until he came, I waited.

160. **Original:** I have a jeans.  
   **Correct sentence (printed key):** I have jeans. / I have a pair of jeans.

161. **Original:** My scissors is black.  
   **Correct sentence (printed key):** My scissors are black.

162. **Original:** I love these three fishes.  
   **Correct sentence (printed key):** I love these three fish.

163. **Original:** There were only three sheeps in the house.  
   **Correct sentence (printed key):** There were only three sheep in the house.

164. **Original:** He ordered for a burger.  
   **Correct sentence (printed key):** He ordered a burger.

165. **Original:** I have only three knifes.  
   **Correct sentence (printed key):** I have only three knives.

166. **Original:** How many housewifes are present here?  
   **Correct sentence (printed key):** How many housewives are present here?

167. **Original:** I have many photoes of my friend.  
   **Correct sentence (printed key):** I have many photos of my friend.

168. **Original:** He is younger than my brother.  
   **Correct sentence (printed key):** He is younger to my brother.

169. **Original:** The days passed happily today.  
   **Correct sentence (printed key):** The days passed off happily today.

170. **Original:** I am understanding you.  
   **Correct sentence (printed key):** I understand you.

171. **Original:** I have been knowing you for 5 years.  
   **Correct sentence (printed key):** I have known you for 5 years.

172. **Original:** He went to Temple, so am I.  
   **Correct sentence (printed key):** He went to Temple, so did I.

173. **Original:** The second innings is just over.  
   **Correct sentence (printed key):** The second inning is just over.

174. **Original:** The police investigated into the case.  
   **Correct sentence (printed key):** The police investigated the case.

175. **Original:** He is used to get up early.  
   **Correct sentence (printed key):** He is used to getting up early.

176. **Original:** He thought that he can win the game.  
   **Correct sentence (printed key):** He thought that he could win the game.

177. **Original:** Despite of repeated reminders, he is doing nothing.  
   **Correct sentence (printed key):** Despite repeated reminders, he is doing nothing.

178. **Original:** All of us will attend the party, wouldn't we?  
   **Correct sentence (printed key):** All of us would attend the party, wouldn't we?

179. **Original:** I am looking forward to see you soon.  
   **Correct sentence (printed key):** I am looking forward to seeing you soon.

180. **Original:** The patient died, before the doctor arrived.  
   **Correct sentence (printed key):** The patient had died, before the doctor arrived.

181. **Original:** I, along with my wife, are going for shoppping.  
   **Correct sentence (printed key):** I, along with my wife, am going for shoppping.

182. **Original:** He, along with his wife, are going for shoppping.  
   **Correct sentence (printed key):** He, along with his wife, is going for shoppping.

183. **Original:** Your friend is playing here since morning.  
   **Correct sentence (printed key):** Your friend has been playing here since morning.

184. **Original:** Your friend has been playing here from morning.  
   **Correct sentence (printed key):** Your friend has been playing here since morning.

185. **Original:** Rawats will also join us today.  
   **Correct sentence (printed key):** The Rawats will also join us today.

186. **Original:** Why are you appearing so happy today?  
   **Correct sentence (printed key):** Why do you appear so happy today?

187. **Original:** He is a learning person.  
   **Correct sentence (printed key):** He is a learned person.

188. **Original:** What he wants from me?  
   **Correct sentence (printed key):** What he does he want from me?

189. **Original:** I don’t know who is he?  
   **Correct sentence (printed key):** I don’t know who he is.

190. **Original:** They had no idea why was I doing all this?  
   **Correct sentence (printed key):** They had no idea why I was doing all this.

191. **Original:** It rained three hours before.  
   **Correct sentence (printed key):** It rained three hours ago.

192. **Original:** That hospital is very near my home.  
   **Correct sentence (printed key):** That hospital is very near to my home.

193. **Original:** She doesn’t like to be cheated.  
   **Correct sentence (printed key):** She doesn’t like to be cheated on.

194. **Original:** He cheated me.  
   **Correct sentence (printed key):** He cheated on me.

195. **Original:** I would rather die than compromising with my principles.  
   **Correct sentence (printed key):** I would rather die than compromise with my principles.

196. **Original:** This is the man, which met me yesterday.  
   **Correct sentence (printed key):** This is the man, who met me yesterday.

197. **Original:** He is a tall guy, isn't it?  
   **Correct sentence (printed key):** He is a tall guy, isn't he?

198. **Original:** My style is superior than yours.  
   **Correct sentence (printed key):** My style is superior to yours.

199. **Original:** He is a MSc in Physics.  
   **Correct sentence (printed key):** He is an MSc in Physics.

200. **Original:** Your shirt is inferior than my shirt in quality.  
   **Correct sentence (printed key):** Your shirt is inferior to my shirt in quality.


Source-key flags:
- The printed key itself contains source anomalies/awkward wording that is preserved: 56 “No fewer than hundred soldiers were died”; 84 “avail yourself the facilities”; 120 gives three printed alternatives; 124 uses “None of Ram & Shyam is my friend”; 135 omits “to” in “made compulsory for the employees come”; 145 “persisted me on visiting”; 146 “better of the two”; 162 “these three fish”; 168 “younger to my brother”; 169 “passed off happily today”; 181–182 retain “going for shoppping”; 188 “What he does he want from me?”; 192 “near to my home”; and 193–194 “cheated on”.
- The source key changes item 105 from the prompt’s “12 dozen” to “10 dozen”; this is preserved and flagged, not guessed.
- The source key’s item 3 intentionally prints two alternatives (“He is great. / He is the greatest.”), and item 120 prints three alternatives; all are retained.
- Scan-confirmed extraction corrections: reconstructed wrapped entries 89 and 120; removed running headers/footers only. No sentence wording was silently corrected beyond OCR/layout cleanup.
