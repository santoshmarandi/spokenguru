# Lesson 30 — Direct to Indirect Speech

**PDF pages:** 402–414 (printed pages 401–413)


## Exercise 1 — Change the following sentences into Indirect Speech


1. **Direct speech:** He said, “I am fine.”  
   **Indirect speech:** He said that he was fine.  

2. **Direct speech:** He said to me, “I am fine.”  
   **Indirect speech:** He told me that he was fine.  

3. **Direct speech:** He says, “I am fine.”  
   **Indirect speech:** He says that he is fine.  

4. **Direct speech:** He says to me, “I am fine.”  
   **Indirect speech:** He tells me that he is fine.  

5. **Direct speech:** He truly said, “No one can live without water.”  
   **Indirect speech:** He truly said that No one can live without water.” {Universal Truth}  

6. **Direct speech:** He said, “Hurrah! We have won the match.”  
   **Indirect speech:** He exclaimed with joy that they had won the match.  

7. **Direct speech:** He said to me, “I am your best friend.”  
   **Indirect speech:** He told me that he was my best friend.  

8. **Direct speech:** He said to me, “Does he go to school daily?”  
   **Indirect speech:** He asked me if he went to school daily.  

9. **Direct speech:** He said, “Honesty is the best policy.”  
   **Indirect speech:** He said that honesty is the best policy.” {Universal Truth}  

10. **Direct speech:** The doctor said, “Alas! Mr. Gupta is no more.”  
   **Indirect speech:** The doctor exclaimed with sorrow that Mr. Gupta was no more.  

11. **Direct speech:** Ravi said, “I am reading this book.”  
   **Indirect speech:** Ravi said that he was reading that book.  

12. **Direct speech:** I said to Mayank, “I will not come home tomorrow.”  
   **Indirect speech:** I told Mayank that I would not come home the next day.  

13. **Direct speech:** Dad said to Pankaj, “I will not give you pocket money.”  
   **Indirect speech:** Dad told Pankaj that he would not give him pocket money.  

14. **Direct speech:** My employee said to me, “I will not attend the office tomorrow.”  
   **Indirect speech:** My employee told me that he would not attend the office the next day.  

15. **Direct speech:** My friend said, “I have been to England thrice.”  
   **Indirect speech:** My friend said that he had been to England thrice.  

16. **Direct speech:** Ranjana said, “The child did not sleep properly last night,”  
   **Indirect speech:** Rajana said that the child had not slept properly the previous night.  

17. **Direct speech:** He said, "I will be in Mumbai tomorrow."  
   **Indirect speech:** He said that he would be in Mumbai the next/following day.  

18. **Direct speech:** He said to Sunaina, “Will you help me in the work?”  
   **Indirect speech:** He asked Sunaina if she would help him in the work.  

19. **Direct speech:** He said, "I'll be using the bike next Monday.”  
   **Indirect speech:** He said that he would be using the bike next Monday.  

20. **Direct speech:** Meena said to me, “Can you come with me to my home?”  
   **Indirect speech:** Meena asked me if I could come with her to her home.  

21. **Direct speech:** He said, "I can run faster than Ravi."  
   **Indirect speech:** He said that he could run faster than Ravi.  

22. **Direct speech:** His father said to me, “Do you know where Rahul is?”  
   **Indirect speech:** His father asked me whether I knew where Rahul was.  

23. **Direct speech:** He said to me, “Please keep the windows open.”  
   **Indirect speech:** He requested me to keep the windows open.  

24. **Direct speech:** She said to me, "How could you be so foolish!"  
   **Indirect speech:** She exclaimed with surprise/wonder how I could be so foolish.  

25. **Direct speech:** Pankaj said to me, “Why do you not go home?”  
   **Indirect speech:** Pankaj asked me why I did not go home.  

26. **Direct speech:** Pankaj said to me, “Why do you not come here?”  
   **Indirect speech:** Pankaj asked me why I did not come there.  

27. **Direct speech:** He said to Shweta, “Please speak the truth.”  
   **Indirect speech:** He requested Shweta to speak the truth.  

28. **Direct speech:** Neha said, "Alas! I have lost my mobile."  
   **Indirect speech:** Neha exclaimed with sorrow that she had lost her mobile.  

29. **Direct speech:** He asked me, “How is your father?”  
   **Indirect speech:** He asked me how my father was.  

30. **Direct speech:** He said, “Sorry for being rude to you!”  
   **Indirect speech:** He exclaimed with regret that he was rude to me.  

31. **Direct speech:** He said to her, “Get out of here at once.”  
   **Indirect speech:** He ordered her to get out of there at once.  

32. **Direct speech:** Doctor said to the patient, “Stop drinking.”  
   **Indirect speech:** Doctor advised the patient to stop drinking.  

33. **Direct speech:** The boss said to employees, “Work hard.”  
   **Indirect speech:** The boss ordered the employees to work hard.  

34. **Direct speech:** The doctor said to the patient, “Eat properly.”  
   **Indirect speech:** The doctor advised the patient to eat properly.  

35. **Direct speech:** He said to me, “May you live long!”  
   **Indirect speech:** He prayed that I might live long.  

36. **Direct speech:** The servant said to him, “Sir, please give me leave for two days.”  
   **Indirect speech:** The servant requested him to give him leave for two days.  

37. **Direct speech:** She said, “Would that Raveena were here!”  
   **Indirect speech:** She wished that Raveena had been there.  

38. **Direct speech:** He said, “Let us wait for them.”  
   **Indirect speech:** He said that we should wait for them.  

39. **Direct speech:** He said, “Raveena had a car.”  
   **Indirect speech:** He said that Raveena had a car.  

40. **Direct speech:** She said to her dad, “Good morning, dad!”  
   **Indirect speech:** She wished her dad good morning.  

41. **Direct speech:** Everyone said, “Bravo! Well done.”  
   **Indirect speech:** Everyone applauded them that they had done well.  

42. **Direct speech:** He said, “Who are you?”  
   **Indirect speech:** He asked who I was.  

43. **Direct speech:** She said to Mayank, “Good bye!”  
   **Indirect speech:** She bade Mayank good bye. (or) She bade good bye to Mayank.  

44. **Direct speech:** Ranjan said, “Ah, what nonsense I have done!”  
   **Indirect speech:** Ranjan exclaimed with regret that he had done nonsense.  

45. **Direct speech:** My friend said, “What a rapper Emiway is!”  
   **Indirect speech:** My friend exclaimed with wonder that Emiway was a great rapper.  

46. **Direct speech:** She said, “How beautiful the flower is!”  
   **Indirect speech:** She exclaimed with wonder that the flower was very beautiful.  

47. **Direct speech:** He said, “May you score 99 percentile in CAT!”  
   **Indirect speech:** He prayed that I might score 99 percentile in CAT.  

48. **Direct speech:** She said, “May God pardon me.”  
   **Indirect speech:** She prayed that God might pardon her.  

49. **Direct speech:** He said, “May you earn lots of money!”  
   **Indirect speech:** He prayed that I might earn lots of money.  

50. **Direct speech:** He said to his friend, “May you succeed in the test.”  
   **Indirect speech:** He wished that his friend might succeed in the examination.  

51. **Direct speech:** He said to me, “Please keep the door ajar.”  
   **Indirect speech:** He requested me to keep the door ajar.  

52. **Direct speech:** He said to Shweta, “Who are you to me?”  
   **Indirect speech:** He asked Shweta who she was to him.  

53. **Direct speech:** They said to me, “Long live.”  
   **Indirect speech:** They prayed that I might live long.  

54. **Direct speech:** He said, “Would that she were a teacher!”  
   **Indirect speech:** He wished that she had been a teacher.  

55. **Direct speech:** My father said, “What a disaster the earthquake is!”  
   **Indirect speech:** My father exclaimed with sorrow that the earthquake was a big disaster.  

56. **Direct speech:** My boss said to me, “Don’t come inside the room.”  
   **Indirect speech:** My boss ordered me not to come inside the room.  

57. **Direct speech:** I said, “When it gets dark, switch on the bulbs.”  
   **Indirect speech:** I told him to switch on the bulbs when it got dark.  

58. **Direct speech:** He said to Shweta, “May you pass the interview today!”  
   **Indirect speech:** He prayed that Shweta might pass the interview that day.  

59. **Direct speech:** He says to me, “I have never been to Delhi.”  
   **Indirect speech:** He tells me that he has never been to Delhi.  

60. **Direct speech:** He said, “Who are we?”  
   **Indirect speech:** He asked who they were.  

61. **Direct speech:** He said to me, “She left Delhi after I had left.”  
   **Indirect speech:** He told me that she had left Delhi after he had left.  

62. **Direct speech:** She said to him, “Don’t make me fool.”  
   **Indirect speech:** She told him not to make her fool.  

63. **Direct speech:** He said, "I may buy a pen.”  
   **Indirect speech:** He said that he might buy a pen.  

64. **Direct speech:** Ashok said to me, “I am your friend.”  
   **Indirect speech:** Ashok told me that he was my friend.  

65. **Direct speech:** He said, "Seema must work hard.”  
   **Indirect speech:** He said that Seema had to work hard.  

66. **Direct speech:** My boss said to me, “Don’t go there.”  
   **Indirect speech:** My boss ordered me not to go there.  

67. **Direct speech:** The teacher asked Arnavi, “What is your name? Where are you from?”  
   **Indirect speech:** The teacher asked Arnavi what her name was and where she was from.  

68. **Direct speech:** He said, "I should meet you in the evening.”  
   **Indirect speech:** He said that he should meet me in the evening.  

69. **Direct speech:** He said to me, “What are you doing?”  
   **Indirect speech:** He asked me what I was doing.  

70. **Direct speech:** He asked her, “I am going to market. Would you like to go along?”  
   **Indirect speech:** He told her that he was going to market and asked her if she’d like to go along.  

71. **Direct speech:** He said to me, “What is Shilpa doing?”  
   **Indirect speech:** He asked me what Shilpa was doing.  

72. **Direct speech:** Ayansh said to me, “Where are you going and why?”  
   **Indirect speech:** Ayansh asked me where I was going and why.  

73. **Direct speech:** He said to me, “What am I doing?”  
   **Indirect speech:** He asked me what he was doing.  

74. **Direct speech:** The teacher said, “Students, if you want to pass, work hard.”  
   **Indirect speech:** The teacher advised the students to work hard if they wanted to pass.  

75. **Direct speech:** He said to me, “Where do you live?”  
   **Indirect speech:** He asked me where I lived.  

76. **Direct speech:** She said to Arjun, “Will you go to school today?” Arjun said, “No.”  
   **Indirect speech:** She asked Arjun if he’d go to school that day. Arjun replied that he wouldn’t.  

77. **Direct speech:** He said to me, “How much money do you have?”  
   **Indirect speech:** He asked me how much money I had.  

78. **Direct speech:** He said to his teacher, “Sir, I couldn’t do my work as I was unwell.”  
   **Indirect speech:** He told his teacher respectfully that he couldn’t do his homework as he had been unwell.  

79. **Direct speech:** He said to Rahul, “When will you come?”  
   **Indirect speech:** He asked Rahul when he would come.  

80. **Direct speech:** He said to Seema, “Dear, why are you looking sad today?”  
   **Indirect speech:** He asked Seema lovingly why she was looking sad that day.  

81. **Direct speech:** He said to us, “Will you come for the meeting?”  
   **Indirect speech:** He asked us if/whether we would come for the meeting.  

82. **Direct speech:** He said to the peon, “Bring me a glass of water.”  
   **Indirect speech:** He ordered the peon to bring him a glass of water.  

83. **Direct speech:** The teacher said to Anjana, "Stand up right now."  
   **Indirect speech:** The teacher ordered/instructed Anjana to stand up right then.  

84. **Direct speech:** He said, “May you succeed in life!”  
   **Indirect speech:** He prayed that I might succeed in life.  

85. **Direct speech:** He said to his father, “Please bring me a glass of water.”  
   **Indirect speech:** He requested his father to bring him a glass of water.  

86. **Direct speech:** He said to his son, “Please bring me a glass of water.”  
   **Indirect speech:** He ordered his son to bring him a glass of water.  

87. **Direct speech:** Doctor said to the patient, "Change your food habits".  
   **Indirect speech:** Doctor suggested/advised the patient to change his food habits.  

88. **Direct speech:** The policeman said to the thief, “Why did you commit such a crime?”  
   **Indirect speech:** The policeman asked the thief why he had committed such a crime.  

89. **Direct speech:** He said, “How tragic the situation is!”  
   **Indirect speech:** He exclaimed with sorrow that the situation was so tragic.  

90. **Direct speech:** She said to him, “Who are you? What do you want from me?”  
   **Indirect speech:** She asked him, who he was and what he wanted from her.  

91. **Direct speech:** He said, “Oh! I missed the chance.”  
   **Indirect speech:** He exclaimed with sorrow that he had missed the chance.  

92. **Direct speech:** Arjun said to me, “Thank you so much for helping me out in such a difficult situation. I couldn’t have done it without your help.”  
   **Indirect speech:** Arjun thanked me for helping him out in such a difficult situation and said that he couldn’t have done it without my help.  

93. **Direct speech:** She said to her husband, "Please speak the truth.”  
   **Indirect speech:** She requested her husband to speak the truth.  

94. **Direct speech:** He said, “Yes, I’ve done it.”  
   **Indirect speech:** He admitted that he had done that.  

95. **Direct speech:** He said, “No, I’ve not done it.”  
   **Indirect speech:** He denied that he had done that.  

96. **Direct speech:** He said, “Have I done it?”  
   **Indirect speech:** He asked if he had done that.  

97. **Direct speech:** He said, “Have you done it?”  
   **Indirect speech:** He asked if I had done that.  

98. **Direct speech:** He said, “Who has done it?”  
   **Indirect speech:** He asked who had done that.  

99. **Direct speech:** She said to Bobby, "Please give me a glass of water."  
   **Indirect speech:** She requested Bobby to give her a glass of water.  

100. **Direct speech:** I said to the interviewer, “I assure you that I’ll perform the best.”  
   **Indirect speech:** I assured the interview to perform my best.  

101. **Direct speech:** Boss said, "Follow me".  
   **Indirect speech:** Boss ordered/instructed to follow him.  

102. **Direct speech:** Anjali said to her boss, "Please grant me leave for a day."  
   **Indirect speech:** Anjali requested her boss to grant her leave for a day.  

103. **Direct speech:** The doctor said to the patient, “I hope you are recovering.”  
   **Indirect speech:** The doctor hoped that the patient was recovering.  

104. **Direct speech:** She said to her friends, "Please do not tell a lie."  
   **Indirect speech:** She requested her friends not to tell a lie.  

105. **Direct speech:** He told me if I had been his friend, he would have helped me out for sure.  
   **Indirect speech:** He said to me, “If you were my friend, I would help you out for sure.”  

106. **Direct speech:** She asked me if I had been her friend, what I would have done for her.  
   **Indirect speech:** She asked me, “If you were my friend, what would you do for me?”  

107. **Direct speech:** The Principal said to us, "Don't make a noise."  
   **Indirect speech:** The Principal instructed/ordered us not to make a noise.  

108. **Direct speech:** Ayansh said, "Fantastic! We have won the match."  
   **Indirect speech:** Ayansh exclaimed with joy that they had won the match.  

109. **Direct speech:** My uncle said, "Well done! You have done a good job."  
   **Indirect speech:** My uncle exclaimed with applause that I had done a good job.  

110. **Direct speech:** She said, "Oh! I lost my pen."  
   **Indirect speech:** She exclaimed with sorrow that she had lost her pen.  

111. **Direct speech:** Arnavi said, "Sorry for being late!"  
   **Indirect speech:** Arnavi exclaimed with regret that she was late.  

112. **Direct speech:** He said, "I can’t believe this!"  
   **Indirect speech:** He exclaimed with wonder/surprise that he couldn’t believe that.  

113. **Direct speech:** Arnavi said, "He is unbelievably a great player."  
   **Indirect speech:** Arnavi exclaimed with wonder/surprise that he was unbelievably a great player.  

114. **Direct speech:** She said to me, "Wow! What a pleasant weather it is!"  
   **Indirect speech:** She exclaimed with joy that it was a very pleasant weather.  

115. **Direct speech:** He said, “Ranveer is so handsome!”  
   **Indirect speech:** He exclaimed with wonder that Ranveer was so handsome.  

116. **Direct speech:** He said to Meena, “I must consult a doctor.”  
   **Indirect speech:** He told Meena that he had to consult a doctor.  

117. **Direct speech:** He said, “You can’t talk about me.”  
   **Indirect speech:** He said that I couldn’t talk about him.  

118. **Direct speech:** He said, “How many people are here?”  
   **Indirect speech:** He asked how many people there were.  

119. **Direct speech:** He said to Shabnam, “May you live long!”  
   **Indirect speech:** He prayed that Shabnam might live long.  

120. **Direct speech:** She said, “Would that she were at home!”  
   **Indirect speech:** She wished that she had been at home.  

121. **Direct speech:** She said, “I wish she were at home!”  
   **Indirect speech:** She wished that she had been at home.  

122. **Direct speech:** He said, “Am I at home?”  
   **Indirect speech:** He asked if/whether he was at home.  

123. **Direct speech:** He said, “Ravi met me yesterday.”  
   **Indirect speech:** He said that Ravi had met him yesterday.  

124. **Direct speech:** She said to Mayank, “Whom will you meet today?”  
   **Indirect speech:** She asked Mayank whom he would meet that day.  

125. **Direct speech:** He said, “Oh no! I missed it.”  
   **Indirect speech:** He exclaimed with sorrow that he had missed it.  

126. **Direct speech:** He said, “Would that I were a girl!”  
   **Indirect speech:** He wished that he had been a girl.  

127. **Direct speech:** He said to Ravi, “I need to go home with you.”  
   **Indirect speech:** He told Ravi that he needed to go home with him.  

128. **Direct speech:** She said to me, "Would that you were here at that time!"  
   **Indirect speech:** She wished that I had been there at that time.  

129. **Direct speech:** Sachin said to me, "Good evening, Sir!"  
   **Indirect speech:** Sachin wished me good evening.  

130. **Direct speech:** Aman said, "Good bye, friends!"  
   **Indirect speech:** Aman bade his friends good bye.  

131. **Direct speech:** Arnavi said, "Unbelievable!"  
   **Indirect speech:** Arnavi exclaimed with wonder/surprise that it was unbelievable.  

132. **Direct speech:** He said, "Good morning, Mom!"  
   **Indirect speech:** He wished his Mom good morning.  

133. **Direct speech:** Arnavi said to her dad, "Good night!"  
   **Indirect speech:** Arnavi bade her dad good night.  

134. **Direct speech:** He said, "Would that I were a girl!"  
   **Indirect speech:** He wished that he had been a girl.  

135. **Direct speech:** Aman said, "I wish my friends were here!”  
   **Indirect speech:** Aman wished that his friends had been there.  

136. **Direct speech:** He said to Mayank, “May you succeed in life!”  
   **Indirect speech:** He prayed that Mayank might succeed in life.  

137. **Direct speech:** He said to the interviewer, “Could you please ask the relevant question?”  
   **Indirect speech:** He requested the interviewer if he could ask the relevant question.  

138. **Direct speech:** He said, “Kotdwara used to be a peaceful place once.”  
   **Indirect speech:** He said that Kotdwara used to be a peaceful place once.  

139. **Direct speech:** The spectators said, “Bravo! Well done, Ayansh.”  
   **Indirect speech:** The spectators applauded Ayansh saying that he had done well.  

140. **Direct speech:** The boss said, “It’s time to leave.”  
   **Indirect speech:** The boss said that it was time to leave.  

141. **Direct speech:** He said to the judge, “I never committed this crime.”  
   **Indirect speech:** He told the judge that he had never committed that crime.  

142. **Direct speech:** Rahul said, “I will never do it.”  
   **Indirect speech:** Rahul said that he would never do that.  

143. **Direct speech:** I said to my friend, “Good Morning, Let us go for a movie.”  
   **Indirect speech:** I wished my friend good morning and proposed him to go for a movie.  

144. **Direct speech:** A new student asked an old one, “Do you know who my dad is?”  
   **Indirect speech:** A new student asked an old one if he knew who his dad was.  

145. **Direct speech:** I said to him, “I can no longer tolerate your coming late every day.”  
   **Indirect speech:** I told him that I could no longer tolerate his coming late every day.  

146. **Direct speech:** I said to my father, “I will take you to Dehradun this week.”  
   **Indirect speech:** I told my father that I would take him to Dehradun that week.  

147. **Direct speech:** She said, “I go for a walk every morning.”  
   **Indirect speech:** She said that she went for a walk every morning.  

148. **Direct speech:** I said, “I don’t care about the job and left the office.”  
   **Indirect speech:** I said that I did not care about the job and left the office.  

149. **Direct speech:** I said to my brother, “Are you mad or what?”  
   **Indirect speech:** I told my brother if he was mad.  

150. **Direct speech:** I said, “How dare you?”  
   **Indirect speech:** I said how he dared.  

151. **Direct speech:** Naman said to me, “Can you do it for me?”  
   **Indirect speech:** Naman asked me if I could do that for him.  

152. **Direct speech:** I said to my wife, “Select one of these.”  
   **Indirect speech:** I told my wife to select one of those.  

153. **Direct speech:** He wrote in his report, “Fifty people have been died of Corona.”  
   **Indirect speech:** He reported that fifty people had been died of Corona.  

154. **Direct speech:** She said to me, “Please help me with my homework.”  
   **Indirect speech:** She requested me to help her with her homework.  

155. **Direct speech:** I said to him, “Where have you lost your mobile?”  
   **Indirect speech:** I asked him where he had lost his mobile.  

## Exercise 2 — Change the following sentences into Direct Speech


1. **Indirect speech:** He asked why I had not met Mr. Shukla.  
   **Direct speech:** He said, “Why didn’t you meet Mr. Shukla?”  

2. **Indirect speech:** He urged them to be quiet.  
   **Direct speech:** He said to them, “Be quiet.”  

3. **Indirect speech:** She asked me whether I had seen the film last night.  
   **Direct speech:** She asked me, “Did you see the film last night.  

4. **Indirect speech:** He exclaimed that it was a nice day.  
   **Direct speech:** He said to her, “What a nice day!”  

5. **Indirect speech:** Aman said that they had passed by a beautiful shop while coming back.  
   **Direct speech:** Aman said, “We passed by a beautiful shop while coming back.”  

6. **Indirect speech:** He asked him if he would have the car ready by the next day.  
   **Direct speech:** He said to him, “Will you have the car ready by tomorrow”?  

7. **Indirect speech:** I asked him why he was working in that company.  
   **Direct speech:** I said to him, “Why are you working in this company?”  

8. **Indirect speech:** He requested Rahul to repeat that.  
   **Direct speech:** He said to Rahul, “Could you please repeat it?”  

9. **Indirect speech:** The Captain commanded his team to wait there.  
   **Direct speech:** The Captain said to his team, “Wait here.”  

10. **Indirect speech:** Ravi told me that if he heard anything about that, he would let me know.  
   **Direct speech:** Ravi said to me, “If I hear anything about you, I’ll let you know.”  

11. **Indirect speech:** Ashish asked Aman whether he was going for the movie.  
   **Direct speech:** Ashish asked, “Are you going for the movie, Aman?”  

12. **Indirect speech:** Ranjana requested me if I could give her my book.  
   **Direct speech:** Ranjana said to me, “Can you please give me your book?”  

13. **Indirect speech:** The teacher congratulated Ayansh.  
   **Direct speech:** The teacher said to Ayansh, “Congratulations!”  

14. **Indirect speech:** I asked where he would be in the evening.  
   **Direct speech:** “Where will you be in the evening”, I said.  

15. **Indirect speech:** The mother warned her daughter to stay away from that kind of people.  
   **Direct speech:** The mother warned her daughter, “Stay away from this kind of people”.  

16. **Indirect speech:** He told Sohan that he had often told him not to go there.  
   **Direct speech:** He said to Sohan, “I have often told you not to go there.”  

17. **Indirect speech:** He told me that he expected me to attend the wedding.  
   **Direct speech:** He said to me, “I expect you to attend the wedding.”  

18. **Indirect speech:** She requested her friend to let her dance.  
   **Direct speech:** She said to her friend, “Let me dance.”  

19. **Indirect speech:** He ordered the students to open the books.  
   **Direct speech:** He said to the students, “Open your books.”  

20. **Indirect speech:** He ordered the students not to open the books.  
   **Direct speech:** He said to the students, “Don’t open your books.”  

21. **Indirect speech:** He exclaimed that it was a very beautiful day.  
   **Direct speech:** He said, “What a beautiful day.”  

22. **Indirect speech:** He said that he was too ill to walk.  
   **Direct speech:** He said, “I am too ill to walk.”  

23. **Indirect speech:** She asked the man where he was going.  
   **Direct speech:** She said to the man, “Where are you going?”  

24. **Indirect speech:** He wrote that he had met the PM a long back.  
   **Direct speech:** He wrote, “I met the PM a long back.”  

25. **Indirect speech:** Vineeta asked me why I had not attended the class.  
   **Direct speech:** Vineeta said to me, “Why did’t you attend the class?”  

26. **Indirect speech:** She said that the work was done.  
   **Direct speech:** She said, “The work is done.”  

27. **Indirect speech:** He informed me on the mobile that they were coming to our home.  
   **Direct speech:** He said to me on the mobile, “We are coming to your home.”  

28. **Indirect speech:** He told me that as my brother was unwell, I should have taken a leave.  
   **Direct speech:** He said, “As your friend is unwell, you should take a leave.”  

29. **Indirect speech:** My mother ordered me to wash my clothes right then.  
   **Direct speech:** My mother said to me, “Wash your clothes right now.”  

30. **Indirect speech:** Our teacher commanded us to always complete the homework on time.  
   **Direct speech:** Our teacher said, “Always complete your homework on time.”  

31. **Indirect speech:** Mom told me to open the window.  
   **Direct speech:** Mom said to me, “Open the window.”  

32. **Indirect speech:** He says that it will rain tomorrow.  
   **Direct speech:** He says, “It will rain tomorrow.”  

33. **Indirect speech:** He told his friends that all of them were his dear ones.  
   **Direct speech:** He said to his friends, “All of you are my dear ones.”  

34. **Indirect speech:** He said that the news had been splashed across TV screens the previous day.  
   **Direct speech:** He said, “The news has been splashed across TV screens yesterday.”  

35. **Indirect speech:** He said that Sapna didn’t try to understand what was going on.”  
   **Direct speech:** He said, "Sapna doesn’t try to understand what’s going on.”  

36. **Indirect speech:** She told her sister yesterday that she wanted to have a party that night.  
   **Direct speech:** She said to her sister yesterday, “I want to have a party tonight.”  

37. **Indirect speech:** Priyanka told me that she had been to Mumbai 2 years before/earlier.  
   **Direct speech:** Priyanka said to me, “I have been to Mumbai 2 years ago.”  

38. **Indirect speech:** He said that he would ask for my car next Monday.  
   **Direct speech:** He said, "I'll ask for your car next Monday.”  

39. **Indirect speech:** Many told him that he should leave his job then.  
   **Direct speech:** Many said to him, “You should leave the job now.”  

40. **Indirect speech:** Dad told Pankaj that he would not give him pocket money.  
   **Direct speech:** Dad said to Pankaj, “I will not give you pocket money.”  

41. **Indirect speech:** They told us that we must/had to do that ourselves.  
   **Direct speech:** They said to us, "You must do it yourselves.”  

42. **Indirect speech:** He said that Nepotism is a practice of giving unfair advantage to one’s family.  
   **Direct speech:** He said, "Nepotism is a practice of giving unfair advantage to one’s family.”  

43. **Indirect speech:** He asked me what I was doing with his friends.  
   **Direct speech:** He said to me, “What are you doing with my friends?”  

44. **Indirect speech:** Sanjay asked me where I lived.  
   **Direct speech:** Sanjay said to me, “Where do you live?”  

45. **Indirect speech:** He asked me how much money I did have (had).  
   **Direct speech:** He said to me, “How much money do you have?”  

46. **Indirect speech:** He asked me how much water he did have (had).  
   **Direct speech:** He said to me, “How much water does he have?”  

47. **Indirect speech:** She asked Rahul when they were supposed to come.  
   **Direct speech:** She said to Rahul, “When are they supposed to come?”  

48. **Indirect speech:** He asked us if/whether we would come for the meeting.  
   **Direct speech:** He asked us, “Will you come for the meeting?”  

49. **Indirect speech:** He asked if he could talk to Mr. Sharma.  
   **Direct speech:** He said, “Could I talk to Mr. Sharma?”  

50. **Indirect speech:** The teacher asked if he was the one, Ravi was talking about.  
   **Direct speech:** The teacher said, "Are you the one, Ravi is talking about?"  

51. **Indirect speech:** The teacher asked him if he had plucked the flower.  
   **Direct speech:** The teacher said to him, "Did he pluck the flower?"  

52. **Indirect speech:** He asked me if I knew who she was.  
   **Direct speech:** She said to me, “Do you know who I am?”  

53. **Indirect speech:** He prayed that I might score 99 percentile in the CAT exam.  
   **Direct speech:** He said, “May you score 99 percentile in the CAT exam!”  

54. **Indirect speech:** Anjali requested her boss to grant her leave for a day.  
   **Direct speech:** Anjali said to her boss, "Please grant me leave for a day."  

55. **Indirect speech:** The Principal instructed/ordered us not to make a noise.  
   **Direct speech:** The Principal said to us, "Don't make a noise."  

56. **Indirect speech:** He exclaimed with wonder/surprise that it was unbelievable.  
   **Direct speech:** He said, "Unbelievable!"  

57. **Indirect speech:** She exclaimed with joy that it was a very pleasant weather.  
   **Direct speech:** She said to me, "Wow! What a pleasant weather it is!"  

58. **Indirect speech:** Neha exclaimed with sorrow that she had lost her mobile.  
   **Direct speech:** Neha said, "Oh no! I lost my mobile."  

59. **Indirect speech:** Ravi exclaimed with regret that he had no idea about his situation.  
   **Direct speech:** Ravi said to Manish, "sorry! I had no idea about your situation."  

60. **Indirect speech:** Aman bade his friends good bye.  
   **Direct speech:** Aman said, "Good bye, friends!"  

61. **Indirect speech:** She wished that I had been there at that time.  
   **Direct speech:** She said to me, "Would that you were here at that time!"  

62. **Indirect speech:** He prayed that I might earn lots of money.  
   **Direct speech:** He said, “May you earn lots of recognition!”  

63. **Indirect speech:** He told me that it would be great if I allowed him to speak too.  
   **Direct speech:** He said to me, “It would be great if you allow me to speak too.”  

64. **Indirect speech:** I told him that nothing could be changed here.  
   **Direct speech:** I said to him, “Nothing can be changed here.”  

65. **Indirect speech:** The teacher said why I didn’t work hard for exams.  
   **Direct speech:** The teacher said, “Why don’t you work hard for exams?”  

66. **Indirect speech:** Sanju said that some relatives had come to his home.  
   **Direct speech:** Sanju said, “Some relatives came to my home.”  

67. **Indirect speech:** He shouted to let him do what he was doing.  
   **Direct speech:** He shouted, “Let me do what I am doing.”  

68. **Indirect speech:** She asked me if I was coming home with her.  
   **Direct speech:** She asked “Are you coming home with me?”  

69. **Indirect speech:** He said that he had passed the test.  
   **Direct speech:** He said, “I have passed the test.”  

70. **Indirect speech:** He asked me what my name was.  
   **Direct speech:** He said to me, “What is your name?”  

71. **Indirect speech:** He asked me what my father’s name was.  
   **Direct speech:** He said to me, “What is your father’s name?”  

72. **Indirect speech:** She asked me if I had finished my breakfast.  
   **Direct speech:** She said, “Have you finished your breakfast?”  

## Source-text and verification notes

- The source pages for Lesson 30 contain English text only; no Hindi text appears in this lesson.
- Exercise 1 has 155 prompts and 155 corresponding answers. Its prompts are on PDF pages 402–406 and its answers on pages 408–412. Exercise 2 has 72 prompts and 72 corresponding answers. Its prompts are on pages 406–408 and its answers on pages 412–414. The sequence boundaries were checked on shared pages 406, 408 and 412.
- Printed wording and irregularities are retained rather than silently rewritten. Examples include Exercise 1 prompts 105–106, which are already in indirect speech despite the exercise instruction; the duplicated Exercise 1 answers 120–121; and the printed wording “had been died” in answer 153.
- In Exercise 2 answers, entry 3 visibly ends without a closing quotation mark, and entry 6 places the question mark after the closing quotation mark. These source punctuation quirks are preserved. The PDF text layer encodes its curly opening/closing quotation marks as stray comma-like glyphs; these were restored to matching curly double quotation marks after visual comparison. Straight quotation marks remain where printed.
- All prompt and answer pages were visually checked. No unreadable sections.

**Unreadable text:** none identified.

