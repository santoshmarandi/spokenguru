# Lesson 33 — Antonyms

**PDF pages:** 420–438 (printed pages 419–437)

Write the opposite words (Antonyms) of the following words:

1. **Awake** — Hindi: जगा हुआ; Romanized: *Jagaa hua*  
   **Opposite:** **Asleep** — Hindi: सोया हुआ; Romanized: *Soya hua*

2. **Bitter** — Hindi: कड़वा; Romanized: *Kadva*  
   **Opposite:** **Sweet** — Hindi: मीठा; Romanized: *Meetha*

3. **Giant** — Hindi: विशाल; Romanized: *Vishaal*  
   **Opposite:** **Tiny** — Hindi: छोटा; Romanized: *Chota*

4. **Sane** — Hindi: समझदार; Romanized: *Samajhdaar*  
   **Opposite:** **Insane** — Hindi: पागल; Romanized: *Paagal*

5. **Lazy** — Hindi: आलसी; Romanized: *Aalsee*  
   **Opposite:** **Diligent** — Hindi: मेहनती; Romanized: *Mehanatee*

6. **Ancient** — Hindi: प्राचीन; Romanized: *Pracheen*  
   **Opposite:** **Modern** — Hindi: आधुनिक; Romanized: *Aadhunik*

7. **Forgive** — Hindi: क्षमा करना; Romanized: *shama karana*  
   **Opposite:** **Blame** — Hindi: दोष लगाना; Romanized: *Dosh lagana*

8. **Polite** — Hindi: विनम्र; Romanized: *Vinamra*  
   **Opposite:** **Rude** — Hindi: अशिष्ट; Romanized: *Ashisht*

9. **Alive** — Hindi: जीवित; Romanized: *Jeevit*  
   **Opposite:** **Dead** — Hindi: मृत; Romanized: *Mrit*

10. **Dawn** — Hindi: सवेरा; Romanized: *Savera*  
   **Opposite:** **Dusk** — Hindi: संध्या; Romanized: *Sandhya*

11. **Regular** — Hindi: नियमित; Romanized: *Niyamit*  
   **Opposite:** **Irregular** — Hindi: अनियमित; Romanized: *Aniyamit*

12. **Satisfied** — Hindi: संतुष्ट; Romanized: *Santusht*  
   **Opposite:** **Dissatisfied** — Hindi: असंतुष्ट; Romanized: *Asantusht*

13. **Heavy** — Hindi: भारी; Romanized: *Bhaaree*  
   **Opposite:** **Light** — Hindi: हल्का; Romanized: *Halka*

14. **Create** — Hindi: बनाना; Romanized: *Banana*  
   **Opposite:** **Destroy** — Hindi: नष्ट करना; Romanized: *Nasht Karna*

15. **Exhale** — Hindi: साँस छोड़ना; Romanized: *Saas chodna*  
   **Opposite:** **Inhale** — Hindi: साँस लेना; Romanized: *Saas lena*

16. **Exterior** — Hindi: बाहरी; Romanized: *Baharee*  
   **Opposite:** **Interior** — Hindi: आंतरिक; Romanized: *Aantrik*

17. **Major** — Hindi: बालिग; Romanized: *Baalig*  
   **Opposite:** **Minor** — Hindi: नाबालिग; Romanized: *Naabaalig*

18. **Relevant** — Hindi: प्रासंगिक; Romanized: *Praasangik*  
   **Opposite:** **Irrelevant** — Hindi: अप्रासंगिक; Romanized: *Apraasangik*

19. **Forward** — Hindi: आगे की ओर; Romanized: *Aage ki or*  
   **Opposite:** **Backward** — Hindi: पीछे की ओर; Romanized: *Pichhe ki or*

20. **Downwards** — Hindi: नीचे की ओर; Romanized: *Neeche ki or*  
   **Opposite:** **Upwards** — Hindi: ऊपर की ओर; Romanized: *Upar ki or*

21. **Heaven** — Hindi: स्वर्ग; Romanized: *Swarg*  
   **Opposite:** **Hell** — Hindi: नरक; Romanized: *Narak*

22. **Junior** — Hindi: कनिष्ठ; Romanized: *Kanishth*  
   **Opposite:** **Senior** — Hindi: वरिष्ठ; Romanized: *Varishth*

23. **Admit** — Hindi: स्वीकार करना; Romanized: *Sveekar karna*  
   **Opposite:** **Deny** — Hindi: मना करना; Romanized: *Manaa karna*

24. **Legal** — Hindi: कानूनी/वैध; Romanized: *Kanooni/Vaidh*  
   **Opposite:** **Illegal** — Hindi: गैरकानूनी/अवैध; Romanized: *Gairkanooni / Awaidh*

25. **Similar** — Hindi: समान; Romanized: *Samaan*  
   **Opposite:** **Different** — Hindi: भिन्न; Romanized: *Bhinn*

26. **Melt** — Hindi: पिघलाना; Romanized: *Pighlaana*  
   **Opposite:** **Freeze** — Hindi: जम जाना; Romanized: *Jam janaa*

27. **Good** — Hindi: अच्छा; Romanized: *Achchha*  
   **Opposite:** **Bad** — Hindi: बुरा; Romanized: *Bura*

28. **Best** — Hindi: सबसे अच्छा; Romanized: *Sabse Acha*  
   **Opposite:** **Worst** — Hindi: सबसे ख़राब; Romanized: *Sabse kharab*

29. **Noisy** — Hindi: शोर; Romanized: *Shor*  
   **Opposite:** **Quiet** — Hindi: शांत; Romanized: *Shaant*

30. **Old** — Hindi: पुराना; Romanized: *Puraana*  
   **Opposite:** **New** — Hindi: नया; Romanized: *Naya*

31. **Old** — Hindi: वृद्ध; Romanized: *Vriddh*  
   **Opposite:** **Young** — Hindi: युवा; Romanized: *Yuva*

32. **Accept** — Hindi: स्वीकार करना; Romanized: *Sveekar karna*  
   **Opposite:** **Refuse** — Hindi: इनकार करना; Romanized: *Inkar karna*

33. **Pass** — Hindi: सफल; Romanized: *Safal*  
   **Opposite:** **Fail** — Hindi: विफल; Romanized: *Vifal*

34. **Patient** — Hindi: धैर्यवान; Romanized: *Dhairyavan*  
   **Opposite:** **Impatient** — Hindi: अधीर; Romanized: *Adheer*

35. **Plural** — Hindi: बहुवचन; Romanized: *Bahuvachan*  
   **Opposite:** **Singular** — Hindi: एकवचन; Romanized: *Ekvachan*

36. **Possible** — Hindi: संभव; Romanized: *Sambhav*  
   **Opposite:** **Impossible** — Hindi: असंभव; Romanized: *Asambhav*

37. **Private** — Hindi: निजी; Romanized: *Nijee*  
   **Opposite:** **Public** — Hindi: सार्वजनिक; Romanized: *Saarvajanik*

38. **Push** — Hindi: धक्का देना; Romanized: *Dhakka dena*  
   **Opposite:** **Pull** — Hindi: खींचना; Romanized: *Kheenchna*

39. **Rich** — Hindi: धनी; Romanized: *Dhanee*  
   **Opposite:** **Poor** — Hindi: गरीब; Romanized: *Gareeb*

40. **Right** — Hindi: दाएं; Romanized: *Daaein*  
   **Opposite:** **Left** — Hindi: बाएं; Romanized: *Baaein*

41. **Right** — Hindi: सही; Romanized: *Sahee*  
   **Opposite:** **Wrong** — Hindi: गलत; Romanized: *Galat*

42. **Risky** — Hindi: जोखिम भरा; Romanized: *Jokhim bhara*  
   **Opposite:** **Safe** — Hindi: सुरक्षित; Romanized: *Surakshit*

43. **Above** — Hindi: ऊपर; Romanized: *Upar*  
   **Opposite:** **Below** — Hindi: नीचे; Romanized: *Neeche*

44. **Sad** — Hindi: दुखी; Romanized: *Dukhi*  
   **Opposite:** **Happy** — Hindi: खुश; Romanized: *Khush*

45. **Simple** — Hindi: सरल; Romanized: *Saral*  
   **Opposite:** **Hard** — Hindi: कठिन; Romanized: *Kathin*

46. **Bachelor** — Hindi: अविवाहित; Romanized: *Avivaahit*  
   **Opposite:** **Married** — Hindi: विवाहित; Romanized: *Vivaahit*

47. **Able** — Hindi: समर्थ; Romanized: *Samarth*  
   **Opposite:** **Unable** — Hindi: असमर्थ; Romanized: *Asamarth*

48. **Absent** — Hindi: अनुपस्थित; Romanized: *Anupasthit*  
   **Opposite:** **Present** — Hindi: उपस्थित; Romanized: *Upasthit*

49. **Agree** — Hindi: सहमत; Romanized: *Sehmat*  
   **Opposite:** **Disagree** — Hindi: असहमत; Romanized: *Asehmat*

50. **Alone** — Hindi: अकेला; Romanized: *Akela*  
   **Opposite:** **Together** — Hindi: साथ में; Romanized: *Saath me*

51. **Answer** — Hindi: जवाब; Romanized: *Javaab*  
   **Opposite:** **Question** — Hindi: सवाल; Romanized: *Savaal*

52. **Small** — Hindi: छोटा; Romanized: *Chhota*  
   **Opposite:** **Big** — Hindi: बड़ा; Romanized: *Bada*

53. **Safe** — Hindi: सुरक्षित; Romanized: *Surakshit*  
   **Opposite:** **Unsafe** — Hindi: असुरक्षित; Romanized: *Asurakshit*

54. **Ascend** — Hindi: बढ़ना; Romanized: *Badhna*  
   **Opposite:** **Descend** — Hindi: घटना; Romanized: *Ghatna*

55. **Careful** — Hindi: सावधान; Romanized: *Saavdhan*  
   **Opposite:** **Careless** — Hindi: लापरवाह; Romanized: *Laaparvah*

56. **Comfort** — Hindi: आराम; Romanized: *Aaraam*  
   **Opposite:** **Discomfort** — Hindi: बेचैनी; Romanized: *Bechainee*

57. **Costly** — Hindi: महँगा; Romanized: *Mehanga*  
   **Opposite:** **Cheap** — Hindi: सस्ता; Romanized: *Sasta*

58. **Cheerful** — Hindi: हंसमुख; Romanized: *Hansmukh*  
   **Opposite:** **Sad** — Hindi: उदास; Romanized: *Udaas*

59. **Interesting** — Hindi: दिलचस्प; Romanized: *Dilchasp*  
   **Opposite:** **Boring** — Hindi: उबाऊ; Romanized: *Ubaoo*

60. **Complete** — Hindi: पूरा; Romanized: *Poora*  
   **Opposite:** **Incomplete** — Hindi: अधूरा; Romanized: *Adhoora*

61. **Import** — Hindi: आयात; Romanized: *Aayaat*  
   **Opposite:** **Export** — Hindi: निर्यात; Romanized: *Niryaat*

62. **Attack** — Hindi: हमला; Romanized: *Hamla*  
   **Opposite:** **Defend** — Hindi: बचाव; Romanized: *Bachav*

63. **Seller** — Hindi: विक्रेता; Romanized: *Vikreta*  
   **Opposite:** **Buyer** — Hindi: क्रेता; Romanized: *Kreta*

64. **Before** — Hindi: पहले; Romanized: *Pehle*  
   **Opposite:** **After** — Hindi: बाद में; Romanized: *Baad me*

65. **Always** — Hindi: हमेशा; Romanized: *Hamesha*  
   **Opposite:** **Never** — Hindi: कभी नहीं; Romanized: *Kabhi nahi*

66. **Begin** — Hindi: शुरू; Romanized: *Shuroo*  
   **Opposite:** **End** — Hindi: समाप्त; Romanized: *Samapt*

67. **Negative** — Hindi: नकारात्मक; Romanized: *Nakaaraatmak*  
   **Opposite:** **Positive** — Hindi: सकारात्मक; Romanized: *sakaaraatmak*

68. **Behind** — Hindi: पीछे; Romanized: *Peechhe*  
   **Opposite:** **In front of** — Hindi: सामने; Romanized: *Saamne*

69. **Black** — Hindi: काला; Romanized: *Kaala*  
   **Opposite:** **White** — Hindi: सफेद; Romanized: *Safed*

70. **Clean** — Hindi: साफ़; Romanized: *Saaf*  
   **Opposite:** **Dirty** — Hindi: गन्दा; Romanized: *Ganda*

71. **Clever** — Hindi: चतुर; Romanized: *Chatur*  
   **Opposite:** **Stupid** — Hindi: बेवकूफ़; Romanized: *Bewakoof*

72. **Cold** — Hindi: ठंडा; Romanized: *Thanda*  
   **Opposite:** **Hot** — Hindi: गरम; Romanized: *Garam*

73. **Dry** — Hindi: सूखा; Romanized: *Sukha*  
   **Opposite:** **Wet** — Hindi: भीगा हुआ; Romanized: *Bheega hua*

74. **Enter** — Hindi: प्रवेश लेना; Romanized: *Pravesh lena*  
   **Opposite:** **Exit** — Hindi: बाहर निकलना; Romanized: *Baahar nikalna*

75. **Tall** — Hindi: लंबा; Romanized: *Lamba*  
   **Opposite:** **Short** — Hindi: छोटा; Romanized: *Chota*

76. **Fast** — Hindi: तेज़; Romanized: *Tez*  
   **Opposite:** **Slow** — Hindi: धीमा; Romanized: *Dheema*

77. **First** — Hindi: पहला; Romanized: *Pahla*  
   **Opposite:** **Last** — Hindi: आखिरी; Romanized: *Akhiri*

78. **Mature** — Hindi: परिपक्व; Romanized: *Paripakva*  
   **Opposite:** **Immature** — Hindi: अपरिपक्व; Romanized: *Aparipakva*

79. **Maximum** — Hindi: सबसे ज़्यादा; Romanized: *Sabse zyada*  
   **Opposite:** **Minimum** — Hindi: सबसे कम; Romanized: *Sabse kam*

80. **Long** — Hindi: लम्बा; Romanized: *Lamba*  
   **Opposite:** **Short** — Hindi: छोटा; Romanized: *Chota*

81. **Give** — Hindi: देना; Romanized: *Dena*  
   **Opposite:** **Take** — Hindi: लेना; Romanized: *Lena*

82. **Healthy** — Hindi: स्वस्थ; Romanized: *Swasth*  
   **Opposite:** **Sick / ill** — Hindi: बीमार; Romanized: *Beemar*

83. **Win** — Hindi: जीत; Romanized: *Jeet*  
   **Opposite:** **Defeat** — Hindi: हार; Romanized: *Haar*

84. **Increase** — Hindi: बढ़ना; Romanized: *Badhna*  
   **Opposite:** **Decrease** — Hindi: घटना; Romanized: *Ghatna*

85. **Inside** — Hindi: अंदर; Romanized: *Andar*  
   **Opposite:** **Outside** — Hindi: बाहर; Romanized: *Baahar*

86. **Like** — Hindi: पसंद करना; Romanized: *Pasand karna*  
   **Opposite:** **Dislike** — Hindi: नापसंद करना; Romanized: *Napasand karna*

87. **Lock** — Hindi: बंद करना; Romanized: *Band karna*  
   **Opposite:** **Unlock** — Hindi: खोलना; Romanized: *Kholna*

88. **Love** — Hindi: प्यार करना; Romanized: *Pyar karna*  
   **Opposite:** **Hate** — Hindi: नफरत करना; Romanized: *Nafrat karna*

89. **Attentive** — Hindi: सचेत; Romanized: *Sachet*  
   **Opposite:** **Inattentive** — Hindi: असावधान; Romanized: *Asaavdhaan*

90. **Articulate** — Hindi: स्पष्ट; Romanized: *Spasht*  
   **Opposite:** **Inarticulate** — Hindi: धीरे से बोलना; Romanized: *Dheere se bolna*

91. **Adequate** — Hindi: पर्याप्त; Romanized: *Paryaapt*  
   **Opposite:** **Inadequate** — Hindi: अपर्याप्त; Romanized: *Aparyaapt*

92. **Appear** — Hindi: दिखाई देते हैं; Romanized: *Dikhaee dete hain*  
   **Opposite:** **Disappear** — Hindi: गायब होना; Romanized: *Gaayab hona*

93. **Approve** — Hindi: मंजूर; Romanized: *Manjoor*  
   **Opposite:** **Disapprove** — Hindi: अस्वीकार करना; Romanized: *Asvikaar karna*

94. **Advantage** — Hindi: लाभ; Romanized: *Laabh*  
   **Opposite:** **Disadvantage** — Hindi: हानि; Romanized: *Haani*

95. **Affected** — Hindi: लग जाना; Romanized: *Lag jana*  
   **Opposite:** **Unaffected** — Hindi: अप्रभावित; Romanized: *Aprabhaavit*

96. **Balance** — Hindi: संतुलन; Romanized: *Santulan*  
   **Opposite:** **Imbalance** — Hindi: असंतुलन; Romanized: *Asantulan*

97. **Busy** — Hindi: व्यस्त; Romanized: *Vyast*  
   **Opposite:** **Free** — Hindi: खाली; Romanized: *Khaali*

98. **Bright** — Hindi: उज्ज्वल; Romanized: *Ujjval*  
   **Opposite:** **Dark** — Hindi: अंधेरा; Romanized: *Andhera*

99. **Bind** — Hindi: बांधना; Romanized: *Baandhna*  
   **Opposite:** **Release** — Hindi: रिहाई; Romanized: *Rihahi*

100. **Benevolent** — Hindi: भलाई करने वाला; Romanized: *Bhalae karne vala*  
   **Opposite:** **Malevolent** — Hindi: द्रोही; Romanized: *Drohee*

101. **Beauty** — Hindi: सुंदरता; Romanized: *Sundarta*  
   **Opposite:** **Ugliness** — Hindi: भद्दापन; Romanized: *Bhaddaapan*

102. **Batty** — Hindi: बावला; Romanized: *Baavla*  
   **Opposite:** **Sane** — Hindi: समझदार; Romanized: *samajhdaar*

103. **Belie** — Hindi: झुठलाना; Romanized: *Jhuthlaana*  
   **Opposite:** **Justify** — Hindi: उचित सिद्ध करना; Romanized: *Uchit sidh karna*

104. **Barren** — Hindi: बंजर; Romanized: *Banjar*  
   **Opposite:** **Fertile** — Hindi: उपजाऊ; Romanized: *Upajaoo*

105. **Base** — Hindi: आधार; Romanized: *Aadhaar*  
   **Opposite:** **Summit** — Hindi: शिखर; Romanized: *Shikhar*

106. **Bottom** — Hindi: तल; Romanized: *Tal*  
   **Opposite:** **Top** — Hindi: ऊपर; Romanized: *Upar*

107. **Beginning** — Hindi: शुरू; Romanized: *Shuru*  
   **Opposite:** **End** — Hindi: समाप्त; Romanized: *Samaapt*

108. **Broad** — Hindi: विस्तृत; Romanized: *Vistrt*  
   **Opposite:** **Narrow** — Hindi: संकीर्ण; Romanized: *Sankeern*

109. **Birth** — Hindi: जन्म; Romanized: *Janm*  
   **Opposite:** **Death** — Hindi: मृत्यु; Romanized: *Mrtyu*

110. **Bleak** — Hindi: बेरंग; Romanized: *Berang*  
   **Opposite:** **Bright** — Hindi: उज्ज्वल; Romanized: *Ujjval*

111. **Barrier** — Hindi: अवरोध; Romanized: *Avrodh*  
   **Opposite:** **Link** — Hindi: संपर्क; Romanized: *Sampark*

112. **Barbarous** — Hindi: बर्बर; Romanized: *Barbar*  
   **Opposite:** **Civilised** — Hindi: सभ्य; Romanized: *Sabhya*

113. **Build** — Hindi: रचना; Romanized: *Rachna*  
   **Opposite:** **Destroy** — Hindi: नष्ट; Romanized: *Nasht*

114. **Bitter** — Hindi: कड़वा; Romanized: *kadva*  
   **Opposite:** **Sweet** — Hindi: मिठाई; Romanized: *Mithaee*

115. **Boisterous** — Hindi: ऊष्मी; Romanized: *Ushmee*  
   **Opposite:** **Placid** — Hindi: शांत; Romanized: *Shaant*

116. **Beautiful** — Hindi: सुंदर; Romanized: *Sunder*  
   **Opposite:** **Ugly** — Hindi: बुरा; Romanized: *Bura*

117. **Benign** — Hindi: सौम्य; Romanized: *Saumy*  
   **Opposite:** **Malignant** — Hindi: घातक; Romanized: *Ghatak*

118. **Bawdy** — Hindi: गंदा; Romanized: *Ganda*  
   **Opposite:** **Decent** — Hindi: सभ्य; Romanized: *Sabhy*

119. **Brave** — Hindi: बहादुर; Romanized: *Bhaadur*  
   **Opposite:** **Coward** — Hindi: डरपोक; Romanized: *Darapok*

120. **Best** — Hindi: श्रेष्ठ; Romanized: *Shreshth*  
   **Opposite:** **Worst** — Hindi: सबसे खराब; Romanized: *Sabase khraab*

121. **Blunt** — Hindi: मंदबुद्धि; Romanized: *Mandbhudhi*  
   **Opposite:** **Keen** — Hindi: उत्सुक; Romanized: *Utshuk*

122. **Blame** — Hindi: दोष; Romanized: *Dosh*  
   **Opposite:** **Praise** — Hindi: प्रशंसा; Romanized: *Prashansa*

123. **Borrow** — Hindi: उधार; Romanized: *Udhaar*  
   **Opposite:** **Lend** — Hindi: देना; Romanized: *Dena*

124. **Believe** — Hindi: मानना; Romanized: *Maanna*  
   **Opposite:** **Doubt** — Hindi: शक; Romanized: *Shak*

125. **Bold** — Hindi: साहसिक; Romanized: *saahasik*  
   **Opposite:** **Timid** — Hindi: डरपोक; Romanized: *Darpok*

126. **Credible** — Hindi: विश्वसनीय; Romanized: *Vishvasneey*  
   **Opposite:** **Incredible** — Hindi: अतुल्य; Romanized: *Atulay*

127. **Captivate** — Hindi: आकर्षण करना; Romanized: *Aakarshan karna*  
   **Opposite:** **Repel** — Hindi: पीछे हटाना; Romanized: *pichhe hataana*

128. **Calculating** — Hindi: हिसाब; Romanized: *Hisab*  
   **Opposite:** **Artless** — Hindi: अनाड़ी; Romanized: *Anaadi*

129. **Callous** — Hindi: कठोर; Romanized: *Kathor*  
   **Opposite:** **Kind** — Hindi: मेहरबान; Romanized: *Meharabaan*

130. **Calm** — Hindi: शांत; Romanized: *Shaant*  
   **Opposite:** **Stormy** — Hindi: तूफ़ानी; Romanized: *toofani*

131. **Camouflage** — Hindi: छलावरण; Romanized: *Chhalaavaran*  
   **Opposite:** **Reveal** — Hindi: पता चलता है; Romanized: *Pata chalta hai*

132. **Confess** — Hindi: कबूल; Romanized: *Kabool*  
   **Opposite:** **Deny** — Hindi: मना; Romanized: *Mana*

133. **Contract** — Hindi: अनुबंध; Romanized: *Anubandh*  
   **Opposite:** **Expand** — Hindi: विस्तार; Romanized: *Vistaar*

134. **Confidence** — Hindi: आत्मविश्वास; Romanized: *Aatmavishvaas*  
   **Opposite:** **Diffidence** — Hindi: संशय; Romanized: *Sanshay*

135. **Courtesy** — Hindi: सौजन्य से; Romanized: *Saujany se*  
   **Opposite:** **Diffused** — Hindi: दूर तक फैला हुआ; Romanized: *Door tak phaila hua*

136. **Clever** — Hindi: चालाक; Romanized: *chaalaak*  
   **Opposite:** **Stupid** — Hindi: बेवकूफ; Romanized: *Bevkoof*

137. **Casual** — Hindi: आकस्मिक; Romanized: *Aakasmik*  
   **Opposite:** **Formal** — Hindi: औपचारिक; Romanized: *Aupachaarik*

138. **Carnal** — Hindi: कामुक; Romanized: *Kaamuk*  
   **Opposite:** **Tragic** — Hindi: दुखद; Romanized: *Dukhad*

139. **Comic** — Hindi: हास्य; Romanized: *Hassy*  
   **Opposite:** **Spiritual** — Hindi: आध्यात्मिक; Romanized: *Aadhyaatmik*

140. **Celebrated** — Hindi: मशहूर; Romanized: *Mashahoor*  
   **Opposite:** **Unknown** — Hindi: अनजान; Romanized: *Anjaan*

141. **Conceal** — Hindi: छिपाना; Romanized: *Chipana*  
   **Opposite:** **Reveal** — Hindi: पता चलता है; Romanized: *Pata chalta hain*

142. **Condemn** — Hindi: निंदा करना; Romanized: *Ninda karna*  
   **Opposite:** **Approve** — Hindi: मंजूर; Romanized: *Manjoor*

143. **Compare** — Hindi: तुलना; Romanized: *Tulna*  
   **Opposite:** **Contrast** — Hindi: विषमता; Romanized: *Vishamta*

144. **Cheap** — Hindi: सस्ता; Romanized: *Sasta*  
   **Opposite:** **Dear** — Hindi: प्रिय; Romanized: *Priya*

145. **Care** — Hindi: ध्यान; Romanized: *Dhyaan*  
   **Opposite:** **Neglect** — Hindi: उपेक्षा; Romanized: *Upeksha*

146. **Credit** — Hindi: श्रेय; Romanized: *Shery*  
   **Opposite:** **Cash** — Hindi: नकद; Romanized: *Nakad*

147. **Clandestine** — Hindi: गुप्त; Romanized: *Gupt*  
   **Opposite:** **Open** — Hindi: खुला हुआ; Romanized: *Khula hua*

148. **Censure** — Hindi: निंदा; Romanized: *Ninda*  
   **Opposite:** **Praise** — Hindi: प्रशंसा; Romanized: *Prashansa*

149. **Conceit** — Hindi: गुमान; Romanized: *Gumaan*  
   **Opposite:** **Modesty** — Hindi: नम्रता; Romanized: *Namarta*

150. **Coarse** — Hindi: मोटा; Romanized: *Mota*  
   **Opposite:** **Fine** — Hindi: ठीक; Romanized: *Thik*

151. **Create** — Hindi: सृजन करना; Romanized: *Srjan karna*  
   **Opposite:** **Destroy** — Hindi: नष्ट; Romanized: *Nasht*

152. **Cruel** — Hindi: निर्दयी; Romanized: *Nirdayee*  
   **Opposite:** **Kind** — Hindi: मेहरबान; Romanized: *Meharbaan*

153. **Compress** — Hindi: संकुचित करें; Romanized: *Sankuchit Kare*  
   **Opposite:** **Expand** — Hindi: विस्तार; Romanized: *Vistaar*

154. **Common** — Hindi: सामान्य; Romanized: *Samanya*  
   **Opposite:** **Rare** — Hindi: दुर्लभ; Romanized: *Durlabh*

155. **Concord** — Hindi: सामंजस्य; Romanized: *Saamanjasy*  
   **Opposite:** **Discord** — Hindi: कलह; Romanized: *Kalah*

156. **Cunning** — Hindi: चालाक; Romanized: *Chalaak*  
   **Opposite:** **Naive** — Hindi: अनुभवहीन; Romanized: *Anubhavheen*

157. **Country** — Hindi: देश; Romanized: *Desh*  
   **Opposite:** **Urban** — Hindi: शहरी; Romanized: *Sehri*

158. **Continue** — Hindi: जारी रखें; Romanized: *Jari rakhe*  
   **Opposite:** **Terminate** — Hindi: बर्खास्त; Romanized: *Barkhaast*

159. **Consolidate** — Hindi: संघटित करना; Romanized: *Sangathit karna*  
   **Opposite:** **Weaken** — Hindi: कमज़ोर; Romanized: *Kamjor*

160. **Curable** — Hindi: इलाज संभव; Romanized: *Ilaaj sambhav*  
   **Opposite:** **Incurable** — Hindi: लाइलाज; Romanized: *Lailaaj*

161. **Definite** — Hindi: निश्चित; Romanized: *Nishchit*  
   **Opposite:** **Indefinite** — Hindi: अनिश्चित; Romanized: *Anishchit*

162. **Doubt** — Hindi: शक; Romanized: *Shak*  
   **Opposite:** **Trust** — Hindi: विश्वास; Romanized: *Vishvaas*

163. **Devil** — Hindi: शैतान; Romanized: *Shaitaan*  
   **Opposite:** **God** — Hindi: परमेश्वर; Romanized: *Parmeshvar*

164. **Denounce** — Hindi: आरोप लगा देना; Romanized: *Aarop laga dena*  
   **Opposite:** **Defend** — Hindi: बचाव; Romanized: *Bachaav*

165. **Despair** — Hindi: निराशा; Romanized: *Niraasha*  
   **Opposite:** **Hope** — Hindi: आशा; Romanized: *Aasha*

166. **Danger** — Hindi: खतरा; Romanized: *Khatra*  
   **Opposite:** **Safety** — Hindi: सुरक्षा; Romanized: *Suraksha*

167. **Docile** — Hindi: विनम्र; Romanized: *Vinamr*  
   **Opposite:** **Headstrong** — Hindi: हठी; Romanized: *Hathee*

168. **Derogatory** — Hindi: अपमानजनक; Romanized: *Apmaanjanak*  
   **Opposite:** **Laudatory** — Hindi: सराहने योग्य; Romanized: *Saraahane yogy*

169. **Dwarf** — Hindi: बौना आदमी; Romanized: *Bona aadmi*  
   **Opposite:** **Giant** — Hindi: विशाल; Romanized: *Vishaal*

170. **Divide** — Hindi: फूट डालो; Romanized: *Phoot dalo*  
   **Opposite:** **Multiply** — Hindi: गुणा; Romanized: *Guna*

171. **Demote** — Hindi: अवनति; Romanized: *Avnati*  
   **Opposite:** **Promote** — Hindi: बढ़ावा देना; Romanized: *Badhaava dena*

172. **Dense** — Hindi: सघन, ठोस; Romanized: *Saghan. Thosh*  
   **Opposite:** **Sparse** — Hindi: विरल; Romanized: *Viral*

173. **Deep** — Hindi: गहरा; Romanized: *Gehra*  
   **Opposite:** **Shallow** — Hindi: छिछला, उथला; Romanized: *Chichla, Uthla*

174. **Domestic** — Hindi: घरेलू; Romanized: *Ghareloo*  
   **Opposite:** **Foreign** — Hindi: विदेशी; Romanized: *Videshee*

175. **Destructive** — Hindi: हानिकारक; Romanized: *Haanikaarak*  
   **Opposite:** **Constructive** — Hindi: रचनात्मक; Romanized: *Rachnaatmak*

176. **Direct** — Hindi: प्रत्यक्ष; Romanized: *Pratyaksh*  
   **Opposite:** **Indirect** — Hindi: अप्रत्यक्ष; Romanized: *Apratyaksh*

177. **Dappled** — Hindi: विचित्र; Romanized: *Vichitr*  
   **Opposite:** **Plain** — Hindi: सादा; Romanized: *Saada*

178. **Dawn** — Hindi: भोर; Romanized: *Bhor*  
   **Opposite:** **End** — Hindi: समाप्त; Romanized: *Samaapt*

179. **Disaster** — Hindi: आपदा; Romanized: *Aapada*  
   **Opposite:** **Blessing** — Hindi: आशीर्वाद; Romanized: *Aashirvaad*

180. **Eclipse** — Hindi: ग्रहण; Romanized: *Grahan*  
   **Opposite:** **Shine** — Hindi: चमक; Romanized: *Chamak*

181. **Eager** — Hindi: उत्सुक; Romanized: *Utsuk*  
   **Opposite:** **Apathetic** — Hindi: उदासीन; Romanized: *Udaaseen*

182. **Early** — Hindi: जल्दी; Romanized: *Jaldi*  
   **Opposite:** **Disquiet** — Hindi: बेचैनी; Romanized: *Bechainee*

183. **Ease** — Hindi: आसानी; Romanized: *Aasaani*  
   **Opposite:** **Late** — Hindi: देर से; Romanized: *Der se*

184. **Efficient** — Hindi: कुशल; Romanized: *Kusal*  
   **Opposite:** **Inefficient** — Hindi: अप्रभावी; Romanized: *Aprabhave*

185. **Expected** — Hindi: अपेक्षित होना; Romanized: *Apekshit hona*  
   **Opposite:** **Unexpected** — Hindi: अप्रत्याशित; Romanized: *Apratyaashit*

186. **Equal** — Hindi: बराबरी का; Romanized: *Baraabari ka*  
   **Opposite:** **Unequal** — Hindi: असमान; Romanized: *Asamaan*

187. **Equivocal** — Hindi: गोलमोल; Romanized: *Goalmol*  
   **Opposite:** **Unequivocal** — Hindi: स्पष्ट; Romanized: *Spasht*

188. **Finite** — Hindi: सीमित; Romanized: *Seemit*  
   **Opposite:** **Infinite** — Hindi: अनंत; Romanized: *Anant*

189. **Firm** — Hindi: दृढ़; Romanized: *Drdh*  
   **Opposite:** **Infirm** — Hindi: कमज़ोर; Romanized: *Kamjor*

190. **Familiar** — Hindi: परिचित; Romanized: *Parichit*  
   **Opposite:** **Unfamiliar** — Hindi: अनजान; Romanized: *Anjaan*

191. **Favour** — Hindi: एहसान; Romanized: *Ehasaan*  
   **Opposite:** **Disfavour** — Hindi: अनादर; Romanized: *Anaadar*

192. **Glory** — Hindi: महिमा, शोभा; Romanized: *Mahima, Sobha*  
   **Opposite:** **Shame** — Hindi: शर्म!, लानत; Romanized: *Sharm, Laanat*

193. **Gentle** — Hindi: सज्जन; Romanized: *Sajjan*  
   **Opposite:** **Rude** — Hindi: अशिष्ट, रूखा; Romanized: *Ashisht, Rukha*

194. **General** — Hindi: सामान्य; Romanized: *Samaany*  
   **Opposite:** **Particular** — Hindi: विशेष; Romanized: *Vishesh*

195. **Generosity** — Hindi: उदारता; Romanized: *Udaarta*  
   **Opposite:** **Stinginess** — Hindi: लोभ; Romanized: *Lobh*

196. **Gloomy** — Hindi: उदास; Romanized: *Udaas*  
   **Opposite:** **Bright** — Hindi: चमकदार; Romanized: *Chamakdaar*

197. **Gorgeous** — Hindi: भव्य; Romanized: *Bhavy*  
   **Opposite:** **Simple** — Hindi: सरल; Romanized: *Saral*

198. **Gather** — Hindi: इकट्ठा; Romanized: *Ikattha*  
   **Opposite:** **Disperse** — Hindi: फैलाने; Romanized: *Failaane*

199. **Genuine** — Hindi: वास्तविक; Romanized: *Vaastavik*  
   **Opposite:** **Spurious** — Hindi: जाली; Romanized: *Jali*

200. **Hollow** — Hindi: खोखला; Romanized: *Khokhla*  
   **Opposite:** **Solid** — Hindi: ठोस; Romanized: *Thosh*

201. **Help** — Hindi: मदद; Romanized: *Madad*  
   **Opposite:** **Diseased** — Hindi: रोगी; Romanized: *Rogi*

202. **Human** — Hindi: मानव; Romanized: *Maanav*  
   **Opposite:** **Inhuman** — Hindi: अमानवीय; Romanized: *Amaanaveey*

203. **Heaven** — Hindi: स्वर्ग; Romanized: *Svarg*  
   **Opposite:** **Hell** — Hindi: नरक; Romanized: *Narak*

204. **Height** — Hindi: ऊंचाई; Romanized: *Unchai*  
   **Opposite:** **Depth** — Hindi: गहराई; Romanized: *Gahrae*

205. **Hurt** — Hindi: चोट; Romanized: *Chot*  
   **Opposite:** **Heal** — Hindi: चंगा; Romanized: *Changa*

206. **Humble** — Hindi: विनीत; Romanized: *Vineet*  
   **Opposite:** **Proud** — Hindi: गर्व; Romanized: *Grav*

207. **Humility** — Hindi: विनम्रता; Romanized: *Vinamrata*  
   **Opposite:** **Pride** — Hindi: गौरव; Romanized: *gaurav*

208. **Hamstrung** — Hindi: पंख काटना; Romanized: *Pankh katna*  
   **Opposite:** **Aid** — Hindi: सहायता; Romanized: *Sahayta*

209. **Harmony** — Hindi: सामंजस्य, एकता; Romanized: *Saamanjasy, Ekta*  
   **Opposite:** **Discord** — Hindi: कलह; Romanized: *Kalah*

210. **Hasty** — Hindi: आतुर; Romanized: *Aatur*  
   **Opposite:** **Leisurely** — Hindi: आराम से; Romanized: *Aaram se*

211. **Loss** — Hindi: हानि; Romanized: *Haani*  
   **Opposite:** **Benefit** — Hindi: फायदा; Romanized: *Fayda*

212. **Head** — Hindi: सिर; Romanized: *Sir*  
   **Opposite:** **Tail** — Hindi: पूंछ; Romanized: *Pooch*

213. **Hear** — Hindi: सुने; Romanized: *Suno*  
   **Opposite:** **Ignore** — Hindi: नज़रअंदाज़ करना; Romanized: *Nazar andaaz karna*

214. **Hamper** — Hindi: बाधा; Romanized: *baadha*  
   **Opposite:** **Help** — Hindi: मदद; Romanized: *Madad*

215. **Harsh** — Hindi: कठोर; Romanized: *kathor*  
   **Opposite:** **Melodious** — Hindi: मधुर; Romanized: *Madhur*

216. **Hypocrisy** — Hindi: पाखंड; Romanized: *Paakhand*  
   **Opposite:** **Sincerity** — Hindi: सच्चाई; Romanized: *Sacchai*

217. **Hurry** — Hindi: जल्दी कीजिये; Romanized: *Jaldi Kijiye*  
   **Opposite:** **Delay** — Hindi: विलंब; Romanized: *Vilamb*

218. **Honour** — Hindi: सम्मान; Romanized: *Sammaan*  
   **Opposite:** **Shame** — Hindi: शर्म की बात है; Romanized: *Sharm ki baat hai*

219. **Hide** — Hindi: छिपाना; Romanized: *Chipana*  
   **Opposite:** **Divulge** — Hindi: प्रकाशित करना; Romanized: *Prakashit karna*

220. **Happy** — Hindi: प्रसन्न; Romanized: *Prassan*  
   **Opposite:** **Miserable** — Hindi: दुखी; Romanized: *Dukhi*

221. **Healthy** — Hindi: स्वस्थ; Romanized: *Svasth*  
   **Opposite:** **Unhealthy** — Hindi: बीमार; Romanized: *Bimaar*

222. **Insipid** — Hindi: फ़ीका; Romanized: *Fika*  
   **Opposite:** **Tasty** — Hindi: स्वादिष्ट; Romanized: *Svadisht*

223. **Inhale** — Hindi: साँस लेना; Romanized: *Saans lena*  
   **Opposite:** **Exhale** — Hindi: साँस छोड़ना; Romanized: *Saans chodna*

224. **Indifferent** — Hindi: उदासीन; Romanized: *Udaseen*  
   **Opposite:** **Partial** — Hindi: आंशिक; Romanized: *Aansik*

225. **Innocent** — Hindi: मासूम; Romanized: *Masoom*  
   **Opposite:** **Guilty** — Hindi: दोषी; Romanized: *Doshi*

226. **Insult** — Hindi: अपमान; Romanized: *Apmaan*  
   **Opposite:** **Esteem** — Hindi: आदर; Romanized: *Aadar*

227. **Indigent** — Hindi: दरिद्र; Romanized: *Daridar*  
   **Opposite:** **Rich** — Hindi: धनी; Romanized: *Dhani*

228. **Infernal** — Hindi: राक्षसी; Romanized: *Raakshasi*  
   **Opposite:** **Heavenly** — Hindi: स्वर्गीय; Romanized: *Svargiy*

229. **Impenitent** — Hindi: आनेवाला; Romanized: *Aanewala*  
   **Opposite:** **Repentant** — Hindi: पश्चाताप; Romanized: *Pashchataap*

230. **Impulsive** — Hindi: आवेगी, आवेगशील; Romanized: *Aavegi,Aavegseel,*  
   **Opposite:** **Cautious** — Hindi: सतर्क; Romanized: *Satark*

231. **Interesting** — Hindi: दिलचस्प; Romanized: *Dilachasp*  
   **Opposite:** **Dull** — Hindi: सुस्त; Romanized: *Sust*

232. **Imaginative** — Hindi: कल्पनाशील; Romanized: *Kalpanasheel*  
   **Opposite:** **Unimaginative** — Hindi: विचार में न आनेवाला; Romanized: *Vichar mein na aanewala*

233. **Just** — Hindi: केवल; Romanized: *Keval*  
   **Opposite:** **Seriously** — Hindi: गंभीरता से; Romanized: *Gambhirta Se*

234. **Known** — Hindi: मालूम; Romanized: *Maloom*  
   **Opposite:** **Unknown** — Hindi: अनजान; Romanized: *Anjaan*

235. **Kind** — Hindi: मेहरबान; Romanized: *Meharbaan*  
   **Opposite:** **Ignorance** — Hindi: अज्ञान; Romanized: *Agyaan*

236. **Keep** — Hindi: रखना; Romanized: *Rakhna*  
   **Opposite:** **Discard** — Hindi: रद्द करें; Romanized: *Radd karen*

237. **Limit** — Hindi: सीमा; Romanized: *Seema*  
   **Opposite:** **Stretch** — Hindi: खिंचाव; Romanized: *Khinchaav*

238. **Lenient** — Hindi: उदार; Romanized: *Udaar*  
   **Opposite:** **Strict** — Hindi: कठोर; Romanized: *kathor*

239. **Leader** — Hindi: नेता; Romanized: *Neta*  
   **Opposite:** **Follower** — Hindi: अनुयायी; Romanized: *Anuyayi*

240. **Labour** — Hindi: श्रम; Romanized: *Shram*  
   **Opposite:** **Rest** — Hindi: आराम; Romanized: *Aaram*

241. **Law** — Hindi: कानून; Romanized: *kanoon*  
   **Opposite:** **Anarchy** — Hindi: अराजकता; Romanized: *Arajakta*

242. **Loud** — Hindi: जोर; Romanized: *Jor*  
   **Opposite:** **Soft** — Hindi: मुलायम; Romanized: *Mulaayam*

243. **Lethargic** — Hindi: सुस्त; Romanized: *Sust*  
   **Opposite:** **Energetic** — Hindi: शक्तिशाली; Romanized: *Shaktishaali*

244. **Liberty** — Hindi: स्वतंत्रता; Romanized: *Svatantrata*  
   **Opposite:** **Slavery** — Hindi: गुलामी; Romanized: *Gulaami*

245. **Legitimate** — Hindi: वैध; Romanized: *Vaidh*  
   **Opposite:** **Illegitimate** — Hindi: अवैध; Romanized: *Avaidh*

246. **Legal** — Hindi: कानूनी; Romanized: *Kanooni*  
   **Opposite:** **Illegal** — Hindi: अवैध; Romanized: *Avaidh*

247. **Legible** — Hindi: पढ़ने योग्य; Romanized: *Padhne yogy*  
   **Opposite:** **Illegible** — Hindi: अस्पष्ट; Romanized: *Aspasht*

248. **Literate** — Hindi: साक्षर; Romanized: *Saakshar*  
   **Opposite:** **Illiterate** — Hindi: अनपढ़; Romanized: *Anphad*

249. **Movable** — Hindi: घल; Romanized: *Chal*  
   **Opposite:** **Immovable** — Hindi: चल; Romanized: *Achal*

250. **Material** — Hindi: सामग्री; Romanized: *Samagree*  
   **Opposite:** **Immaterial** — Hindi: सारहीन; Romanized: *Saarheen*

251. **Modest** — Hindi: मामूली; Romanized: *Mamooli*  
   **Opposite:** **Immodest** — Hindi: बेशर्म; Romanized: *Besharm*

252. **Moral** — Hindi: नैतिक; Romanized: *Naitik*  
   **Opposite:** **Immoral** — Hindi: अनैतिक; Romanized: *Anaitik*

253. **Moderate** — Hindi: मध्यम; Romanized: *Madhyam*  
   **Opposite:** **Immoderate** — Hindi: अत्यंत; Romanized: *Atyant*

254. **Mask** — Hindi: मुखौटा; Romanized: *Mukhauta*  
   **Opposite:** **Unmask** — Hindi: पोल खोलना; Romanized: *Pol kholna*

255. **Motion** — Hindi: प्रस्ताव; Romanized: *prastaav*  
   **Opposite:** **Rest** — Hindi: आराम; Romanized: *Aaram*

256. **Mighty** — Hindi: शक्तिमान; Romanized: *Shaktimaan*  
   **Opposite:** **Weak** — Hindi: कमज़ोर; Romanized: *kamazor*

257. **Masculine** — Hindi: मर्दाना; Romanized: *Mardaana*  
   **Opposite:** **Feminine** — Hindi: स्त्री; Romanized: *Stree*

258. **Miserly** — Hindi: लालची; Romanized: *Laalchi*  
   **Opposite:** **Generous** — Hindi: उदार; Romanized: *Udaar*

259. **Malice** — Hindi: द्वेष; Romanized: *Dvesh*  
   **Opposite:** **Goodwill** — Hindi: दया-भाव; Romanized: *Daya, Bhaav*

260. **Mandatory** — Hindi: अनिवार्य; Romanized: *Anivaary*  
   **Opposite:** **Optional** — Hindi: ऐच्छिक; Romanized: *Aichhik*

261. **Morbid** — Hindi: रोगी; Romanized: *Rogi*  
   **Opposite:** **Healthy** — Hindi: (स्वस्थ; Romanized: *Savsth*

262. **Mix** — Hindi: मिश्रण; Romanized: *Mishran*  
   **Opposite:** **Separate** — Hindi: अलग; Romanized: *Alag*

263. **Mild** — Hindi: हल्का; Romanized: *Halka*  
   **Opposite:** **Stern** — Hindi: कठोर; Romanized: *Kathor*

264. **Meek** — Hindi: नम्र; Romanized: *Namr*  
   **Opposite:** **Arrogant** — Hindi: अभिमानी; Romanized: *Abhimani*

265. **Normal** — Hindi: साधारण; Romanized: *Saadharan*  
   **Opposite:** **Abnormal** — Hindi: असामान्य; Romanized: *Asamaany*

266. **Nimble** — Hindi: चतुर; Romanized: *Chatur*  
   **Opposite:** **Lazy** — Hindi: आलसी; Romanized: *Aalshi*

267. **Noise** — Hindi: शोर; Romanized: *Shor*  
   **Opposite:** **Quiet** — Hindi: चुप; Romanized: *Chup*

268. **Noble** — Hindi: महान; Romanized: *Mahaan*  
   **Opposite:** **Ignoble** — Hindi: नीच; Romanized: *Neech*

269. **Natural** — Hindi: प्राकृतिक; Romanized: *Prakrtik*  
   **Opposite:** **Unnatural** — Hindi: अस्वाभाविक; Romanized: *Asvabhavik*

270. **Optimist** — Hindi: आशावादी; Romanized: *Aashavadi*  
   **Opposite:** **Pessimist** — Hindi: निराशावादी; Romanized: *Niraashavadi*

271. **Obstinate** — Hindi: जिद्दी; Romanized: *Ziddi*  
   **Opposite:** **Pliable** — Hindi: लचीला; Romanized: *lacheela*

272. **Obstruct** — Hindi: रोकना; Romanized: *Rokna*  
   **Opposite:** **Assist** — Hindi: साथ होना; Romanized: *Saath hona*

273. **Ordinary** — Hindi: साधारण; Romanized: *Saadharan*  
   **Opposite:** **Rare** — Hindi: दुर्लभ; Romanized: *durlabh*

274. **Obscure** — Hindi: अस्पष्ट; Romanized: *Aspasht*  
   **Opposite:** **Prominent** — Hindi: प्रसिद्ध; Romanized: *Prasiddh*

275. **Observe** — Hindi: ध्यान से देखें; Romanized: *Dhyaan se dekhen*  
   **Opposite:** **Disregard** — Hindi: उपेक्षा; Romanized: *upeksha*

276. **Obey** — Hindi: आज्ञा का पालन; Romanized: *Aagya ka paalan*  
   **Opposite:** **Defy** — Hindi: अवहेलना; Romanized: *Avahelna*

277. **Ominous** — Hindi: अमंगल; Romanized: *Amangal*  
   **Opposite:** **Auspicious** — Hindi: मंगल; Romanized: *Mangal*

278. **Orderly** — Hindi: व्यवस्थित; Romanized: *Vyavasthit*  
   **Opposite:** **Disorderly** — Hindi: उल्टा पुल्टा; Romanized: *ulta pulta*

279. **Obedient** — Hindi: आज्ञाकारी; Romanized: *Aagyakari*  
   **Opposite:** **Disobedient** — Hindi: हठी; Romanized: *Hathi*

280. **Pacify** — Hindi: शांत करना; Romanized: *Shaant karna*  
   **Opposite:** **Irritate** — Hindi: जलन; Romanized: *Jalan*

281. **Painful** — Hindi: दर्दनाक; Romanized: *Dardnaak*  
   **Opposite:** **Soothing** — Hindi: सुखदायक; Romanized: *Sukhadaayak*

282. **Particular** — Hindi: विशेष; Romanized: *Vishesh*  
   **Opposite:** **General** — Hindi: सामान्य; Romanized: *saamaany*

283. **Positive** — Hindi: सकारात्मक; Romanized: *Sakaaraatmak*  
   **Opposite:** **Negative** — Hindi: नकारात्मक; Romanized: *Nakaraatmak*

284. **Prudence** — Hindi: विवेक; Romanized: *Vivek*  
   **Opposite:** **Carelessness** — Hindi: लापरवाही; Romanized: *Laaparvahi*

285. **Prolong** — Hindi: लम्बा; Romanized: *Lamba*  
   **Opposite:** **Shorten** — Hindi: छोटा; Romanized: *Chhota*

286. **Persuade** — Hindi: राज़ी करना; Romanized: *Raazi karna*  
   **Opposite:** **Dissuade** — Hindi: विरत करना; Romanized: *Vitrit karna*

287. **Passionate** — Hindi: उत्साही; Romanized: *Utsaahi*  
   **Opposite:** **Dispassionate** — Hindi: आवेगहीन; Romanized: *Aavegheen*

288. **Propagate** — Hindi: प्रचार; Romanized: *Prachaar*  
   **Opposite:** **Suppress** — Hindi: दबाने; Romanized: *Dabaane*

289. **Prohibit** — Hindi: निषेध; Romanized: *Nishedh*  
   **Opposite:** **Permit** — Hindi: परमिट; Romanized: *Parmit*

290. **Permission** — Hindi: अनुमति; Romanized: *Anumati*  
   **Opposite:** **Refusal** — Hindi: इनकार; Romanized: *Inkaar*

291. **Progress** — Hindi: प्रगति; Romanized: *Pragati*  
   **Opposite:** **Decline** — Hindi: पतन; Romanized: *Patan*

292. **Public** — Hindi: जनता; Romanized: *Janta*  
   **Opposite:** **Private** — Hindi: निजी; Romanized: *Nijee*

293. **Pursue** — Hindi: पीछा; Romanized: *Peecha*  
   **Opposite:** **Avoid** — Hindi: टालना; Romanized: *Taalna*

294. **Permanent** — Hindi: स्थायी; Romanized: *Sthaayi*  
   **Opposite:** **Temporary** — Hindi: अस्थायी; Romanized: *Asthaayi*

295. **Profit** — Hindi: फायदा; Romanized: *Fayeda*  
   **Opposite:** **Loss** — Hindi: नुकसान; Romanized: *Nuksaan*

296. **Prompt** — Hindi: प्रेरित करना; Romanized: *Prerit karna*  
   **Opposite:** **Slow** — Hindi: धीरे; Romanized: *Dheere*

297. **Punish** — Hindi: सजा देना; Romanized: *Saja dena*  
   **Opposite:** **Reward** — Hindi: इनाम देना; Romanized: *Inaam dena*

298. **Prologue** — Hindi: प्रस्ताव; Romanized: *Prastaav*  
   **Opposite:** **Epilogue** — Hindi: उपसंहार; Romanized: *Upasanhaar*

299. **Raise** — Hindi: बढ़ाना; Romanized: *Badhaen*  
   **Opposite:** **Lower** — Hindi: कम; Romanized: *kam*

300. **Rapidity** — Hindi: तेज़ी; Romanized: *Tezee*  
   **Opposite:** **Delay** — Hindi: विलंब; Romanized: *Vilamb*

301. **Raid** — Hindi: छापा; Romanized: *Chaapa*  
   **Opposite:** **Retreat** — Hindi: पीछे हटना; Romanized: *Piche hatna*

302. **Rectify** — Hindi: सुधारना; Romanized: *Sudhaarna*  
   **Opposite:** **Falsify** — Hindi: कपट करना; Romanized: *Kapat karna*

303. **Restrain** — Hindi: नियंत्रित करना; Romanized: *Niyantrit karna*  
   **Opposite:** **Incite** — Hindi: उत्तेजित; Romanized: *Uttejit*

304. **Rebellious** — Hindi: बागी; Romanized: *Baagi*  
   **Opposite:** **Submissive** — Hindi: विनम्र; Romanized: *Vinamr*

305. **Reluctant** — Hindi: अनिच्छुक; Romanized: *Anichchhuk*  
   **Opposite:** **Eager** — Hindi: उत्सुक; Romanized: *Utsuk*

306. **Reparable** — Hindi: मरम्मत योग्य; Romanized: *Marammat yogy*  
   **Opposite:** **Irreparable** — Hindi: अपूरणीय; Romanized: *Apooraneey*

307. **Refutable** — Hindi: खंडन करने योग्य; Romanized: *khandan karne yogy*  
   **Opposite:** **Irrefutable** — Hindi: अखंडनीय; Romanized: *Akhandaneey*

308. **Relevant** — Hindi: मिलता जुलता; Romanized: *Milta-Julta*  
   **Opposite:** **Irrelevant** — Hindi: असंगत; Romanized: *Asangat*

309. **Secure** — Hindi: सुरक्षित; Romanized: *surakshit*  
   **Opposite:** **Insecure** — Hindi: असुरक्षित; Romanized: *Asurakshit*

310. **System** — Hindi: प्रणाली; Romanized: *pranaalee*  
   **Opposite:** **Chaos** — Hindi: अराजकता; Romanized: *Araajakta*

311. **Straight** — Hindi: सीधे; Romanized: *Seedhe*  
   **Opposite:** **Curved** — Hindi: मुड़ा हुआ; Romanized: not printed in source

312. **Saviour** — Hindi: मुक्तिदाता; Romanized: *Muktidaata*  
   **Opposite:** **Destroyer** — Hindi: मिटाने वाला; Romanized: *Mitaane wala*

313. **Sacred** — Hindi: धार्मिक; Romanized: *Dhaarmik*  
   **Opposite:** **Profane** — Hindi: अपवित्र; Romanized: *apavitr*

314. **Severe** — Hindi: गंभीर; Romanized: *Gambheer*  
   **Opposite:** **Mild** — Hindi: हल्का; Romanized: *Halka*

315. **Sin** — Hindi: पाप; Romanized: *Paap*  
   **Opposite:** **Virtue** — Hindi: गुण; Romanized: *Gun*

316. **Steep** — Hindi: खड़ी; Romanized: *Khadi*  
   **Opposite:** **Flat** — Hindi: समतल; Romanized: *Samtal*

317. **Sympathy** — Hindi: सहानुभूति; Romanized: *Sahaanubhooti*  
   **Opposite:** **Apathy** — Hindi: उदासीनता; Romanized: not printed in source

318. **Significance** — Hindi: महत्व; Romanized: *mahatv*  
   **Opposite:** **Insignificance** — Hindi: निरर्थकता; Romanized: *Nirarthakta*

319. **Safe** — Hindi: सुरक्षित; Romanized: *Surakshit*  
   **Opposite:** **Risky** — Hindi: जोखिम भरा; Romanized: *Jokhim bhara*

320. **Stranger** — Hindi: अजनबी; Romanized: *Ajanabee*  
   **Opposite:** **Local** — Hindi: स्थानीय; Romanized: *Sthaaneey*

321. **Sublime** — Hindi: उदात्त; Romanized: *udaatt*  
   **Opposite:** **Ridiculous** — Hindi: हास्यास्पद; Romanized: *Haasyaaspad*

322. **Terse** — Hindi: संक्षिप्त; Romanized: *Sankshipt*  
   **Opposite:** **Gentle** — Hindi: सज्जन; Romanized: *Sajjan*

323. **Domestic** — Hindi: पालतू; Romanized: *Paaltu*  
   **Opposite:** **Wild** — Hindi: जंगली; Romanized: *Jangalee*

324. **Teacher** — Hindi: अध्यापक; Romanized: *Adhyaapak*  
   **Opposite:** **Student** — Hindi: छात्र; Romanized: *Chhaatr*

325. **Tranquil** — Hindi: शांत; Romanized: *Shaant*  
   **Opposite:** **Agitated** — Hindi: उत्तेजित; Romanized: *Uttejit*

326. **Thick** — Hindi: मोटा; Romanized: *Mota*  
   **Opposite:** **Thin** — Hindi: पतला; Romanized: *Patla*

327. **Transparent** — Hindi: पारदर्शक; Romanized: *Paaradarshak*  
   **Opposite:** **Opaque** — Hindi: अपारदर्शी; Romanized: *Apaaradarshak*

328. **Thrifty** — Hindi: किफ़ायती; Romanized: *Kifayati*  
   **Opposite:** **Extravagant** — Hindi: फ़िजूल ख़र्च; Romanized: *fijool kharch*

329. **Tragedy** — Hindi: शोकपूर्ण घटना; Romanized: *Shokapoorn ghatna*  
   **Opposite:** **Comedy** — Hindi: कॉमेडी; Romanized: *Comedy*

330. **Tolerable** — Hindi: संतोषजनक; Romanized: *Santoshjanak*  
   **Opposite:** **Intolerable** — Hindi: असहनीय; Romanized: *Asahaneey*

331. **Tangible** — Hindi: वास्तविक; Romanized: *Vaastavik*  
   **Opposite:** **Intangible** — Hindi: अमूर्त; Romanized: *Amoort*

332. **Taste** — Hindi: स्वाद; Romanized: *Svaad*  
   **Opposite:** **Distaste** — Hindi: घृणा; Romanized: *Ghirna*

333. **Trust** — Hindi: विश्वास; Romanized: *Vishvaas*  
   **Opposite:** **Distrust** — Hindi: शक; Romanized: *Shak*

334. **Union** — Hindi: संघ; Romanized: *Sangh*  
   **Opposite:** **Discord** — Hindi: कलह; Romanized: *kalah*

335. **Violent** — Hindi: हिंसा करने वाला; Romanized: *Hinsa karne wala*  
   **Opposite:** **Gentle** — Hindi: सज्जन; Romanized: *sajjan*

336. **Voluntary** — Hindi: स्वैच्छिक; Romanized: *Svaichchhik*  
   **Opposite:** **Compulsory** — Hindi: अनिवार्य; Romanized: *Anivaary*

337. **Vain** — Hindi: व्यर्थ; Romanized: *Vyarth*  
   **Opposite:** **Modest** — Hindi: मामूली; Romanized: *Maamooli*

338. **Victory** — Hindi: विजय; Romanized: *Vijay*  
   **Opposite:** **Defeat** — Hindi: हार; Romanized: *Haar*

339. **Vulgar** — Hindi: अशिष्ट; Romanized: *Ashisht*  
   **Opposite:** **Cultured** — Hindi: सुसंस्कृत; Romanized: *Susanskrit*

340. **Vacant** — Hindi: रिक्त; Romanized: *Rikt*  
   **Opposite:** **Occupied** — Hindi: अधिकृत; Romanized: *Aadhikrit*

341. **Vivid** — Hindi: ज्वलंत; Romanized: *jvalant*  
   **Opposite:** **Dull** — Hindi: कुंठित; Romanized: *Kunthit*

342. **Wealth** — Hindi: धन; Romanized: *Dhan*  
   **Opposite:** **Poverty** — Hindi: दरिद्रता; Romanized: *Daridrata*

343. **Wide** — Hindi: चौड़ा; Romanized: *Choda*  
   **Opposite:** **Narrow** — Hindi: संकीर्ण; Romanized: *Sankeern*

344. **Wit** — Hindi: बुद्धि; Romanized: *Buddhi*  
   **Opposite:** **Stupidity** — Hindi: मूर्खता; Romanized: *Moorkhata*

345. **Wicked** — Hindi: शैतान; Romanized: *Shaitaan*  
   **Opposite:** **Virtuous** — Hindi: धार्मिक; Romanized: *Dhaarmik*

346. **War** — Hindi: युद्ध; Romanized: *Yuddh*  
   **Opposite:** **Peace** — Hindi: शांति; Romanized: *Shaanti*

347. **Waste** — Hindi: बेकार; Romanized: *Bekaar*  
   **Opposite:** **Save** — Hindi: सहेजें; Romanized: *Sahejen*

348. **Warmth** — Hindi: गर्मजोशी; Romanized: *Garmajoshee*  
   **Opposite:** **Coldness** — Hindi: शीतलता; Romanized: *Sheetalta*

349. **Zenith** — Hindi: शीर्षबिंदु; Romanized: *Sheershabindu*  
   **Opposite:** **Nadir** — Hindi: पतन; Romanized: *Patan*

## Source and verification notes

The source lists prompts 1–349 on PDF pages 420–429 and a separately numbered **Answers** key on pages 429–438. Entries are paired by their matching printed number.

Scan-confirmed Hindi OCR errors were corrected. English headwords and Romanized spellings are retained as printed. The source does not print Romanized glosses for answer entries 311 (Curved) and 317 (Apathy); these are left blank rather than inferred. The Hindi words are legible in the scan.

Item 241 uses a curly-brace opening delimiter in the source text; its English, Hindi, and Romanized fields are retained. No unreadable text was identified.
