# Lesson index

The PDF has 788 pages and 40 lessons. Printed page numbers are one lower than PDF page numbers.

| Lesson | Title | PDF pages | Printed pages | Status |
|---:|---|---:|---:|---|
| 01 | Use of “This, That, These & Those” | 6-12 | 5-11 | complete |
| 02 | What is the time? | 13-20 | 12-19 | complete |
| 03 | WH Family Words in English | 21-32 | 20-31 | complete |
| 04 | Three Forms of Verbs | 33-49 | 32-48 | complete |
| 05 | Three Degrees of Adjectives | 50-53 | 49-52 | complete |
| 06 | Three Degrees of Adverbs | 54-55 | 53-54 | complete |
| 07 | Placement of Adverbs | 56-58 | 55-57 | complete |
| 08 | Simple Sentences (No action by the Subject) | 59-67 | 58-66 | complete |
| 09 | Use of THERE | 68-86 | 67-85 | complete |
| 10 | All Tenses in English | 87-116 | 86-115 | complete |
| 11 | Modal Verbs | 117-127 | 116-126 | complete |
| 12 | Should + Be, Have & Been | 128-138 | 127-137 | complete |
| 13 | Can/Could + Be, Have & Been | 139-145 | 138-144 | complete |
| 14 | Would + Be, Have & Been | 146-156 | 145-155 | complete |
| 15 | Conditional Sentences – Type 0, 1, 2 & 3 | 157-198 | 156-197 | complete |
| 16 | All Auxiliary/Helping/Modal Verbs | 199-223 | 198-222 | complete |
| 17 | Use of IT | 224-229 | 223-228 | complete |
| 18 | Prepositions | 230-273 | 229-272 | complete |
| 19 | Position Sense | 274-279 | 273-278 | complete |
| 20 | Conjunctions | 280-293 | 279-292 | complete |
| 21 | Use of LET | 294-303 | 293-302 | complete |
| 22 | Imperative Sentences | 304-321 | 303-320 | complete |
| 23 | Causative Verbs | 322-335 | 321-334 | complete |
| 24 | Active to Passive Voice | 336-346 | 335-345 | complete |
| 25 | Passive Voice | 347-355 | 346-354 | complete |
| 26 | Use of “Have, Having...” | 356-359 | 355-358 | complete |
| 27 | Use of “Be, Being & Been” | 360-364 | 359-363 | complete |
| 28 | WH + Ever | 365-379 | 364-378 | complete |
| 29 | Use of Ever & Never | 380-401 | 379-400 | complete |
| 30 | Direct to Indirect Speech | 402-414 | 401-413 | complete |
| 31 | Homonyms | 415-416 | 414-415 | complete |
| 32 | Question Tags | 417-419 | 416-418 | complete |
| 33 | Antonyms | 420-438 | 419-437 | complete |
| 34 | Synonyms | 439-450 | 438-449 | complete |
| 35 | Special Cases | 451-454 | 450-453 | complete |
| 36 | Mixed Practice Exercise | 455-462 | 454-461 | complete |
| 37 | Sentence Correction Exercise | 463-474 | 462-473 | complete |
| 38 | Singular to Plural | 475-477 | 474-476 | complete |
| 39 | 1500+ MCQs | 478-686 | 477-685 | complete |
| 40 | Test Papers | 687-788 | 686-787 | complete |
