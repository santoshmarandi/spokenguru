# Spoken English Guru — Complete Lesson Extraction

All 40 lessons from the 788-page eBook have been extracted into paired plain-text (`.txt`) and Markdown (`.md`) files. The lesson files retain the source page range, headings and instructions, bilingual text, exercises, choices, printed answers, and source notes where applicable.

The [lesson index](lesson_index.md) lists every lesson title, PDF page range, printed page range, and completion status. Each lesson is named `Lesson_XX.txt` and `Lesson_XX.md`.

The extraction was completed sequentially through Lesson 40. Printed page numbers are one lower than PDF page numbers. Corrections and source-key anomalies are documented within the relevant lesson files. In Lesson 40, the embedded Hindi text/font layer contains visible glyph distortions in places; uncertain source wording was not guessed.
